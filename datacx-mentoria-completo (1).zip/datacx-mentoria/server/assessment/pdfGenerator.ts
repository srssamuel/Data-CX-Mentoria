/**
 * Assessment PDF Report Generator
 * 
 * Generates a styled PDF from the assessment report JSON.
 * Uses html-pdf-node for server-side PDF generation.
 */

import type { BlockScore } from "./scoringEngine";

interface ReportData {
  report: any;
  scores: BlockScore[];
  session: {
    mode?: string;
    currentRole?: string;
    completedAt?: Date | string | null;
    createdAt?: Date | string;
  };
  userName?: string;
}

const BLOCK_LABELS: Record<string, { emoji: string; label: string }> = {
  core_personality: { emoji: "🧠", label: "Personalidade" },
  core_communication: { emoji: "💬", label: "Comunicação" },
  core_leadership: { emoji: "👑", label: "Liderança" },
  core_vitality: { emoji: "💚", label: "Vitalidade" },
  quality_check: { emoji: "✅", label: "Verificação" },
};

function getBarColor(score: number): string {
  if (score >= 70) return "#22c55e";
  if (score >= 40) return "#3b82f6";
  return "#f97316";
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function formatDate(d: Date | string | null | undefined): string {
  if (!d) return new Date().toLocaleDateString("pt-BR");
  return new Date(d).toLocaleDateString("pt-BR");
}

export function generateReportHtml(data: ReportData): string {
  const { report, scores, session, userName } = data;
  const confidence = report.meta?.confidence_overall_0_1 ?? 0;
  const qualityFlags = report.meta?.quality_flags || [];
  const execSummary = report.executive_summary || {};
  const fitContext = report.fit_and_context || {};
  const pdi = report.pdi_30_60_90 || {};
  const questions = report.questions_for_debrief || [];

  // Group scores by block
  const scoresByBlock = new Map<string, any[]>();
  for (const s of scores) {
    const existing = scoresByBlock.get(s.block) || [];
    existing.push(s);
    scoresByBlock.set(s.block, existing);
  }

  const scoresHtml = Array.from(scoresByBlock.entries())
    .map(([block, blockScores]) => {
      const info = BLOCK_LABELS[block] || { emoji: "📊", label: block };
      const rows = blockScores
        .map((s: any) => {
          const score = Math.round(Number(s.score0to100 || s.score_0_100 || 0));
          const facetLabel = (s.facet || s.construct || "").replace(/_/g, " ");
          return `
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
              <span style="width:160px;font-size:11px;color:#94a3b8;text-transform:capitalize;">${escapeHtml(facetLabel)}</span>
              <div style="flex:1;background:#1e293b;border-radius:4px;height:14px;overflow:hidden;">
                <div style="width:${score}%;background:${getBarColor(score)};height:100%;border-radius:4px;"></div>
              </div>
              <span style="width:30px;text-align:right;font-size:11px;font-weight:600;color:#e2e8f0;">${score}</span>
            </div>`;
        })
        .join("");
      return `
        <div style="margin-bottom:16px;">
          <h3 style="font-size:13px;font-weight:600;color:#f8fafc;margin-bottom:8px;">${info.emoji} ${info.label}</h3>
          ${rows}
        </div>`;
    })
    .join("");

  // Executive summary bullets
  const bulletsHtml = (execSummary.bullets || [])
    .map((b: string) => `<li style="margin-bottom:4px;color:#cbd5e1;font-size:11px;">• ${escapeHtml(b)}</li>`)
    .join("");

  // Strengths & watchouts
  const strengthsHtml = (execSummary.top_strengths || [])
    .map((s: string) => `<li style="color:#4ade80;font-size:11px;margin-bottom:2px;">✓ ${escapeHtml(s)}</li>`)
    .join("");
  const watchoutsHtml = (execSummary.top_watchouts || [])
    .map((w: string) => `<li style="color:#fbbf24;font-size:11px;margin-bottom:2px;">⚠ ${escapeHtml(w)}</li>`)
    .join("");

  // Fit & context
  const fitSections = [
    { title: "Ambientes Ideais", items: fitContext.best_fit_environments || [], color: "#4ade80" },
    { title: "Motivadores", items: fitContext.motivators || [], color: "#60a5fa" },
    { title: "Contextos de Risco", items: fitContext.risk_contexts || [], color: "#fbbf24" },
    { title: "Descarriladores", items: fitContext.derailers || [], color: "#f87171" },
  ]
    .filter(s => s.items.length > 0)
    .map(
      s => `
      <div style="margin-bottom:12px;">
        <h4 style="font-size:11px;font-weight:600;color:${s.color};margin-bottom:4px;">${s.title}</h4>
        <ul style="margin:0;padding-left:16px;">
          ${s.items.map((i: string) => `<li style="font-size:10px;color:#cbd5e1;margin-bottom:2px;">${escapeHtml(i)}</li>`).join("")}
        </ul>
      </div>`
    )
    .join("");

  // PDI
  const pdiPlan = (pdi.plan || [])
    .map((p: any) => {
      const goals = (p.goals || [])
        .map((g: any) => `<li style="font-size:10px;color:#cbd5e1;margin-bottom:2px;"><strong>${escapeHtml(g.goal || "")}</strong> — Métrica: ${escapeHtml(g.metric || "N/A")}</li>`)
        .join("");
      const actions = (p.actions || [])
        .map((a: any) => `<li style="font-size:10px;color:#cbd5e1;margin-bottom:2px;">${escapeHtml(a.action || "")} (${escapeHtml(a.frequency || "")})</li>`)
        .join("");
      return `
        <div style="margin-bottom:12px;padding:8px;background:#1e293b;border-radius:6px;">
          <h4 style="font-size:12px;font-weight:600;color:#818cf8;margin-bottom:6px;">${p.horizon} Dias</h4>
          ${goals ? `<div style="margin-bottom:4px;"><strong style="font-size:10px;color:#94a3b8;">Metas:</strong><ul style="margin:2px 0;padding-left:16px;">${goals}</ul></div>` : ""}
          ${actions ? `<div><strong style="font-size:10px;color:#94a3b8;">Ações:</strong><ul style="margin:2px 0;padding-left:16px;">${actions}</ul></div>` : ""}
        </div>`;
    })
    .join("");

  // Questions
  const questionsHtml = questions
    .map((q: string, i: number) => `<li style="font-size:10px;color:#cbd5e1;margin-bottom:4px;"><strong>${i + 1}.</strong> ${escapeHtml(q)}</li>`)
    .join("");

  // Weekly rhythm
  const rhythm = pdi.weekly_rhythm || {};
  const rhythmHtml = Object.keys(rhythm).length > 0
    ? `<div style="margin-top:8px;padding:8px;background:#1e293b;border-radius:6px;">
        <h4 style="font-size:11px;font-weight:600;color:#818cf8;margin-bottom:4px;">Ritmo Semanal</h4>
        ${rhythm["15min_daily"] ? `<p style="font-size:10px;color:#cbd5e1;margin-bottom:2px;"><strong>15min diários:</strong> ${escapeHtml(rhythm["15min_daily"])}</p>` : ""}
        ${rhythm["45min_weekly_review"] ? `<p style="font-size:10px;color:#cbd5e1;margin-bottom:2px;"><strong>45min revisão semanal:</strong> ${escapeHtml(rhythm["45min_weekly_review"])}</p>` : ""}
        ${rhythm.mentor_session_script ? `<p style="font-size:10px;color:#cbd5e1;margin-bottom:2px;"><strong>Sessão com mentor:</strong> ${escapeHtml(rhythm.mentor_session_script)}</p>` : ""}
      </div>`
    : "";

  const confidenceBadgeColor = confidence >= 0.65 ? "#22c55e" : "#ef4444";

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #0f172a; color: #e2e8f0; padding: 32px; }
    .page { max-width: 720px; margin: 0 auto; }
    .header { text-align: center; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid #334155; }
    .section { margin-bottom: 20px; padding: 16px; background: #1e293b; border-radius: 8px; }
    .section-title { font-size: 14px; font-weight: 700; color: #f8fafc; margin-bottom: 10px; display: flex; align-items: center; gap: 6px; }
    .warning { background: rgba(245,158,11,0.1); border: 1px solid rgba(245,158,11,0.3); border-radius: 8px; padding: 10px; margin-bottom: 16px; }
    .footer { text-align: center; margin-top: 24px; padding-top: 16px; border-top: 1px solid #334155; font-size: 9px; color: #64748b; }
    @media print { body { padding: 16px; } }
  </style>
</head>
<body>
  <div class="page">
    <div class="header">
      <div style="font-size:10px;color:#818cf8;font-weight:600;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">Data CX — Protocolo Vértice</div>
      <h1 style="font-size:20px;font-weight:700;color:#f8fafc;margin-bottom:4px;">${escapeHtml(execSummary.headline || "Seu Perfil Profissional")}</h1>
      <p style="font-size:11px;color:#94a3b8;">${session.mode === "quick" ? "Modo Rápido" : "Modo Completo"} — ${formatDate(session.completedAt || session.createdAt)}${userName ? ` — ${escapeHtml(userName)}` : ""}</p>
      <div style="display:inline-block;margin-top:6px;padding:2px 10px;border-radius:12px;font-size:10px;font-weight:600;color:white;background:${confidenceBadgeColor};">
        Confiança: ${Math.round(confidence * 100)}%
      </div>
    </div>

    ${qualityFlags.length > 0 ? `
    <div class="warning">
      <p style="font-size:10px;color:#fbbf24;">
        <strong>⚠ Atenção:</strong> Foram detectados indicadores de qualidade: ${qualityFlags.join(", ")}. Os insights devem ser interpretados como hipóteses.
      </p>
    </div>` : ""}

    ${bulletsHtml || strengthsHtml || watchoutsHtml ? `
    <div class="section">
      <div class="section-title">✨ Resumo Executivo</div>
      ${bulletsHtml ? `<ul style="list-style:none;margin-bottom:10px;">${bulletsHtml}</ul>` : ""}
      <div style="display:flex;gap:12px;">
        ${strengthsHtml ? `<div style="flex:1;"><h4 style="font-size:11px;color:#4ade80;margin-bottom:4px;">Forças</h4><ul style="list-style:none;">${strengthsHtml}</ul></div>` : ""}
        ${watchoutsHtml ? `<div style="flex:1;"><h4 style="font-size:11px;color:#fbbf24;margin-bottom:4px;">Pontos de Atenção</h4><ul style="list-style:none;">${watchoutsHtml}</ul></div>` : ""}
      </div>
    </div>` : ""}

    <div class="section">
      <div class="section-title">📊 Escores por Dimensão</div>
      ${scoresHtml}
    </div>

    ${fitSections ? `
    <div class="section">
      <div class="section-title">🎯 Fit & Contexto</div>
      ${fitSections}
    </div>` : ""}

    ${pdiPlan || rhythmHtml ? `
    <div class="section">
      <div class="section-title">📋 PDI 30/60/90 Dias</div>
      ${(pdi.principles || []).length > 0 ? `
        <div style="margin-bottom:8px;">
          <strong style="font-size:10px;color:#94a3b8;">Princípios:</strong>
          <ul style="margin:2px 0;padding-left:16px;">
            ${pdi.principles.map((p: string) => `<li style="font-size:10px;color:#cbd5e1;">${escapeHtml(p)}</li>`).join("")}
          </ul>
        </div>` : ""}
      ${pdiPlan}
      ${rhythmHtml}
    </div>` : ""}

    ${questionsHtml ? `
    <div class="section">
      <div class="section-title">💡 Perguntas para Devolutiva</div>
      <ol style="list-style:none;padding:0;">${questionsHtml}</ol>
    </div>` : ""}

    <div class="footer">
      <p>${escapeHtml(report.disclaimer || "Este relatório é para fins de desenvolvimento e mentoria. Não constitui diagnóstico clínico ou laudo psicológico.")}</p>
      <p style="margin-top:4px;">Data CX — Protocolo Vértice | ${formatDate(session.completedAt || session.createdAt)}</p>
    </div>
  </div>
</body>
</html>`;
}
