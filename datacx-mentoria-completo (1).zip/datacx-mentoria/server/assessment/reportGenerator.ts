/**
 * Assessment Report Generator — Uses LLM for interpretation + PDI
 * 
 * The scoring is deterministic (scoringEngine.ts).
 * This module ONLY translates scores into human-readable insights and PDI.
 */

import { invokeLLM } from "../_core/llm";
import type { ScoringPacket } from "./scoringEngine";
import { aggregateScoresForReport } from "./scoringEngine";
import type { BlockScore } from "./scoringEngine";

const SYSTEM_PROMPT = `Você é um especialista em People Analytics e Desenvolvimento Profissional.
Sua função é interpretar escores de uma avaliação de perfil profissional e gerar um relatório executivo + PDI (Plano de Desenvolvimento Individual) 30/60/90 dias.

REGRAS OBRIGATÓRIAS:
1. Cada insight DEVE listar evidências internas (quais scores/flags suportam a afirmação).
2. Se confidence_overall < 0.65 OU existem flags críticas: escreva como HIPÓTESE e sugira perguntas de validação.
3. NUNCA afirme causalidade sem evidência. Use linguagem probabilística: "tende a", "sugere que", "padrão observado".
4. NÃO diagnostique. NÃO rotule ("você é..."). Use: "tendências", "padrões", "hipóteses", "contextos".
5. SEMPRE proponha ações concretas com métrica e ritual no PDI.
6. Responda EXCLUSIVAMENTE em JSON válido, sem markdown, sem comentários.
7. Todos os textos devem ser em português brasileiro.
8. O disclaimer deve incluir: "Este relatório é para fins de desenvolvimento e mentoria. Não constitui diagnóstico clínico ou laudo psicológico."
9. TODOS os campos do formato de saída são OBRIGATÓRIOS. Não omita nenhum campo.

FORMATO DE SAÍDA (JSON estrito — TODOS os campos são obrigatórios):
{
  "meta": {
    "confidence_overall_0_1": number,
    "quality_flags": string[]
  },
  "executive_summary": {
    "headline": "string (1 frase impactante sobre o perfil)",
    "bullets": ["5 pontos-chave do perfil"],
    "top_strengths": ["3 forças principais"],
    "top_watchouts": ["3 pontos de atenção"]
  },
  "radars": {
    // Para cada bloco avaliado, incluir:
    // "block_name": { "dimensions_0_100": {...}, "interpretation": ["insights baseados nos scores"] }
  },
  "fit_and_context": {
    "best_fit_environments": ["3 ambientes ideais"],
    "risk_contexts": ["3 contextos de risco"],
    "motivators": ["3 motivadores principais"],
    "derailers": ["3 descarriladores potenciais"]
  },
  "pdi_30_60_90": {
    "principles": ["3 princípios norteadores"],
    "plan": [
      {
        "horizon": "30",
        "goals": [{"goal": "string", "metric": "string", "baseline": "string", "target": "string"}],
        "actions": [{"action": "string", "ritual": "string", "frequency": "string", "measurement": "string"}],
        "experiments": [{"hypothesis": "string", "test": "string", "success_criteria": "string"}]
      },
      {
        "horizon": "60",
        "goals": [{"goal": "string", "metric": "string", "baseline": "string", "target": "string"}],
        "actions": [{"action": "string", "ritual": "string", "frequency": "string", "measurement": "string"}],
        "experiments": [{"hypothesis": "string", "test": "string", "success_criteria": "string"}]
      },
      {
        "horizon": "90",
        "goals": [{"goal": "string", "metric": "string", "baseline": "string", "target": "string"}],
        "actions": [{"action": "string", "ritual": "string", "frequency": "string", "measurement": "string"}],
        "experiments": [{"hypothesis": "string", "test": "string", "success_criteria": "string"}]
      }
    ],
    "weekly_rhythm": {
      "15min_daily": "string",
      "45min_weekly_review": "string",
      "mentor_session_script": "string"
    }
  },
  "questions_for_debrief": ["5 perguntas para sessão de devolutiva"],
  "disclaimer": "string"
}`;

const DEFAULT_DISCLAIMER = "Este relatório é para fins de desenvolvimento e mentoria. Não constitui diagnóstico clínico ou laudo psicológico.";

function ensureDefaults(report: any, radars: any, scoringPacket: ScoringPacket): any {
  // Ensure meta — force deterministic values over LLM output
  const existingMeta = report.meta || {};
  report.meta = {
    ...existingMeta,
    confidence_overall_0_1: scoringPacket.confidenceOverall,
    quality_flags: scoringPacket.qualityFlags,
  };

  // Ensure executive_summary
  if (!report.executive_summary || typeof report.executive_summary !== "object") {
    report.executive_summary = {
      headline: "Relatório parcial — geração de insights indisponível",
      bullets: [
        "Os escores foram calculados com sucesso.",
        "A interpretação por IA não pôde ser gerada completamente neste momento.",
        "Consulte os radares para visualizar seus resultados.",
        "Recomendamos discutir os resultados com seu mentor.",
        "Tente gerar o relatório novamente mais tarde.",
      ],
      top_strengths: [],
      top_watchouts: [],
    };
  } else {
    report.executive_summary.headline = report.executive_summary.headline || "Seu Perfil Profissional";
    report.executive_summary.bullets = report.executive_summary.bullets || [];
    report.executive_summary.top_strengths = report.executive_summary.top_strengths || [];
    report.executive_summary.top_watchouts = report.executive_summary.top_watchouts || [];
  }

  // Ensure radars (merge deterministic data with LLM interpretations)
  report.radars = { ...radars, ...(report.radars || {}) };

  // Ensure fit_and_context
  if (!report.fit_and_context || typeof report.fit_and_context !== "object") {
    report.fit_and_context = {
      best_fit_environments: [],
      risk_contexts: [],
      motivators: [],
      derailers: [],
    };
  } else {
    report.fit_and_context.best_fit_environments = report.fit_and_context.best_fit_environments || [];
    report.fit_and_context.risk_contexts = report.fit_and_context.risk_contexts || [];
    report.fit_and_context.motivators = report.fit_and_context.motivators || [];
    report.fit_and_context.derailers = report.fit_and_context.derailers || [];
  }

  // Ensure pdi_30_60_90
  if (!report.pdi_30_60_90 || typeof report.pdi_30_60_90 !== "object") {
    report.pdi_30_60_90 = { principles: [], plan: [], weekly_rhythm: {} };
  } else {
    report.pdi_30_60_90.principles = report.pdi_30_60_90.principles || [];
    report.pdi_30_60_90.plan = report.pdi_30_60_90.plan || [];
    report.pdi_30_60_90.weekly_rhythm = report.pdi_30_60_90.weekly_rhythm || {};
  }

  // Ensure questions_for_debrief
  if (!Array.isArray(report.questions_for_debrief)) {
    report.questions_for_debrief = [];
  }

  // Ensure disclaimer
  report.disclaimer = report.disclaimer || DEFAULT_DISCLAIMER;

  return report;
}

export async function generateReport(
  scoringPacket: ScoringPacket,
  scores: BlockScore[]
): Promise<any> {
  const radars = aggregateScoresForReport(scores);

  const userPrompt = `SCORING PACKET (dados determinísticos — NÃO invente valores):
${JSON.stringify({
    sessionId: scoringPacket.sessionId,
    confidenceOverall: scoringPacket.confidenceOverall,
    qualityFlags: scoringPacket.qualityFlags,
    blockConfidences: scoringPacket.blockConfidences,
    context: scoringPacket.context,
  }, null, 2)}

RADARS (escores agregados por bloco):
${JSON.stringify(radars, null, 2)}

SCORES DETALHADOS (por constructo/faceta):
${JSON.stringify(scores.map(s => ({
    block: s.block,
    construct: s.construct,
    facet: s.facet,
    score0to100: s.score0to100,
    confidence: s.confidence,
    flags: s.flags,
  })), null, 2)}

Com base nos dados acima, gere o relatório executivo completo + PDI 30/60/90. 
IMPORTANTE: Todos os campos do formato de saída são OBRIGATÓRIOS, especialmente executive_summary, fit_and_context, pdi_30_60_90 e disclaimer.
Lembre-se: cada insight deve referenciar scores específicos como evidência.
${scoringPacket.confidenceOverall < 0.65 ? "ATENÇÃO: Confiança geral BAIXA. Escreva insights como hipóteses e sugira perguntas de validação." : ""}
${scoringPacket.qualityFlags.length > 0 ? `ATENÇÃO: Flags de qualidade detectadas: ${scoringPacket.qualityFlags.join(", ")}. Considere isso na interpretação.` : ""}`;

  try {
    const response = await invokeLLM({
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: userPrompt },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "assessment_report",
          strict: false,
          schema: {
            type: "object",
            properties: {
              meta: { type: "object" },
              executive_summary: { type: "object" },
              radars: { type: "object" },
              fit_and_context: { type: "object" },
              pdi_30_60_90: { type: "object" },
              questions_for_debrief: { type: "array", items: { type: "string" } },
              disclaimer: { type: "string" },
            },
            required: ["executive_summary", "fit_and_context", "pdi_30_60_90", "questions_for_debrief", "disclaimer"],
          },
        },
      },
    });

    const content = response.choices?.[0]?.message?.content as string | undefined;
    if (!content) throw new Error("Empty LLM response");

    const report = JSON.parse(content);

    // Apply defaults for any missing fields
    return ensureDefaults(report, radars, scoringPacket);
  } catch (error) {
    console.error("[Assessment] Report generation failed:", error);
    // Return a minimal report with just the scores
    return ensureDefaults({}, radars, scoringPacket);
  }
}
