/**
 * Assessment Scoring Engine — Deterministic, no LLM
 * 
 * Handles:
 * - Likert scoring (with reversal for negative polarity)
 * - Circumplex scoring (Agency x Communion → quadrant)
 * - WHO-5 scoring (0-25 → 0-100)
 * - SJT scoring (keyed alternatives)
 * - Quality flags (rapid responding, straightlining, missing data, inconsistency)
 * - Confidence calculation per block and overall
 */

import type { AssessmentItem, AssessmentResponse } from "../../drizzle/schema";

// ============ TYPES ============

export interface ScoringPacket {
  sessionId: number;
  scores: BlockScore[];
  qualityFlags: string[];
  confidenceOverall: number;
  blockConfidences: Record<string, number>;
  context?: {
    currentRole?: string;
    seniority?: string;
    area?: string;
    segment?: string;
    primaryObjective?: string;
    contextDescription?: string;
  };
}

export interface BlockScore {
  block: string;
  construct: string;
  facet: string | null;
  scoreRaw: number;
  score0to100: number;
  confidence: number;
  flags: string[];
}

interface ResponseWithItem {
  response: AssessmentResponse;
  item: AssessmentItem;
}

// ============ MAIN SCORING FUNCTION ============

export function computeScores(
  items: AssessmentItem[],
  responses: AssessmentResponse[]
): ScoringPacket {
  // Map responses to items
  const responseMap = new Map<number, AssessmentResponse>();
  for (const r of responses) {
    responseMap.set(r.itemId, r);
  }

  const responsesWithItems: ResponseWithItem[] = [];
  for (const item of items) {
    const response = responseMap.get(item.id);
    if (response) {
      responsesWithItems.push({ response, item });
    }
  }

  // Compute quality flags
  const qualityFlags = computeQualityFlags(responsesWithItems, items);

  // Group by block → construct → facet
  const grouped = groupByBlockConstructFacet(responsesWithItems);

  const scores: BlockScore[] = [];
  const blockConfidences: Record<string, number> = {};

  for (const [block, constructs] of Object.entries(grouped)) {
    const blockScores: BlockScore[] = [];

    for (const [construct, facets] of Object.entries(constructs)) {
      for (const [facet, rwis] of Object.entries(facets)) {
        let score: BlockScore;

        if (block === "core_communication") {
          score = scoreCircumplex(block, construct, facet === "__none__" ? null : facet, rwis);
        } else if (block === "core_vitality" && construct === "wellbeing") {
          score = scoreWHO5(block, construct, facet === "__none__" ? null : facet, rwis);
        } else if (rwis[0]?.item.itemType === "sjt") {
          score = scoreSJT(block, construct, facet === "__none__" ? null : facet, rwis);
        } else if (rwis[0]?.item.itemType === "likert") {
          score = scoreLikert(block, construct, facet === "__none__" ? null : facet, rwis);
        } else {
          // micro_work_sample and attention_check — skip scoring
          continue;
        }

        blockScores.push(score);
        scores.push(score);
      }
    }

    // Block-level confidence
    if (blockScores.length > 0) {
      const avgConf = blockScores.reduce((sum, s) => sum + s.confidence, 0) / blockScores.length;
      blockConfidences[block] = Math.round(avgConf * 100) / 100;
    }
  }

  // Overall confidence
  const allConfs = Object.values(blockConfidences);
  const confidenceOverall = allConfs.length > 0
    ? Math.round((allConfs.reduce((a, b) => a + b, 0) / allConfs.length) * 100) / 100
    : 0;

  // Reduce confidence if quality flags exist
  const flagPenalty = qualityFlags.length * 0.05;
  const adjustedConfidence = Math.max(0, Math.round((confidenceOverall - flagPenalty) * 100) / 100);

  return {
    sessionId: responses[0]?.sessionId || 0,
    scores,
    qualityFlags,
    confidenceOverall: adjustedConfidence,
    blockConfidences,
  };
}

// ============ LIKERT SCORING ============

function scoreLikert(block: string, construct: string, facet: string | null, rwis: ResponseWithItem[]): BlockScore {
  const values: number[] = [];

  for (const { response, item } of rwis) {
    if (item.itemType !== "likert") continue;
    let val = parseFloat(response.responseValue);
    if (isNaN(val)) continue;

    // Reverse scoring for negative polarity (1→5, 2→4, 3→3, 4→2, 5→1)
    if (item.polarity === "negative") {
      val = 6 - val;
    }
    values.push(val);
  }

  if (values.length === 0) {
    return { block, construct, facet, scoreRaw: 0, score0to100: 0, confidence: 0, flags: ["no_data"] };
  }

  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  // Normalize 1-5 → 0-100
  const score0to100 = Math.round(((mean - 1) / 4) * 100 * 100) / 100;

  // Confidence based on number of items and variance
  const variance = values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length;
  const itemCountFactor = Math.min(1, values.length / 4); // At least 4 items for full confidence
  const varianceFactor = Math.max(0.5, 1 - (variance / 4)); // High variance = lower confidence
  const confidence = Math.round(itemCountFactor * varianceFactor * 100) / 100;

  return { block, construct, facet, scoreRaw: Math.round(mean * 1000) / 1000, score0to100, confidence, flags: [] };
}

// ============ CIRCUMPLEX SCORING ============

function scoreCircumplex(block: string, construct: string, facet: string | null, rwis: ResponseWithItem[]): BlockScore {
  // Same as Likert but the construct determines Agency vs Communion
  return scoreLikert(block, construct, facet, rwis);
}

// ============ WHO-5 SCORING ============

function scoreWHO5(block: string, construct: string, facet: string | null, rwis: ResponseWithItem[]): BlockScore {
  const values: number[] = [];

  for (const { response, item } of rwis) {
    let val = parseFloat(response.responseValue);
    if (isNaN(val)) continue;
    if (item.polarity === "negative") val = 6 - val;
    values.push(val);
  }

  if (values.length === 0) {
    return { block, construct, facet, scoreRaw: 0, score0to100: 0, confidence: 0, flags: ["no_data"] };
  }

  // WHO-5: sum of 5 items (each 0-5), total 0-25, multiply by 4 for 0-100
  // Our scale is 1-5, so we adjust: (val-1) gives 0-4, sum gives 0-20, multiply by 5 for 0-100
  const adjustedValues = values.map(v => v - 1); // 0-4 range
  const sum = adjustedValues.reduce((a, b) => a + b, 0);
  const maxPossible = values.length * 4;
  const score0to100 = Math.round((sum / maxPossible) * 100 * 100) / 100;

  const confidence = Math.min(1, values.length / 5);

  return { block, construct, facet, scoreRaw: Math.round(sum * 1000) / 1000, score0to100, confidence, flags: [] };
}

// ============ SJT SCORING ============

function scoreSJT(block: string, construct: string, facet: string | null, rwis: ResponseWithItem[]): BlockScore {
  const scores: number[] = [];

  for (const { response, item } of rwis) {
    if (item.itemType !== "sjt" || !item.keyJson) continue;
    const key = item.keyJson as Record<string, number>;
    const answer = response.responseValue.toUpperCase();
    const score = key[answer] ?? 0;
    scores.push(score);
  }

  if (scores.length === 0) {
    return { block, construct, facet, scoreRaw: 0, score0to100: 0, confidence: 0, flags: ["no_data"] };
  }

  const mean = scores.reduce((a, b) => a + b, 0) / scores.length;
  // SJT scores are 1-4, normalize to 0-100
  const score0to100 = Math.round(((mean - 1) / 3) * 100 * 100) / 100;

  const confidence = Math.min(1, scores.length / 3); // At least 3 SJTs for full confidence

  return { block, construct, facet, scoreRaw: Math.round(mean * 1000) / 1000, score0to100, confidence, flags: [] };
}

// ============ QUALITY FLAGS ============

function computeQualityFlags(rwis: ResponseWithItem[], allItems: AssessmentItem[]): string[] {
  const flags: string[] = [];

  if (rwis.length === 0) return ["no_responses"];

  // 1. Missing data: if < 80% of items answered
  const completionRate = rwis.length / allItems.filter(i => i.itemType !== "attention_check").length;
  if (completionRate < 0.8) {
    flags.push("missing_data");
  }

  // 2. Rapid responding: if > 30% of responses under 3 seconds
  const rapidCount = rwis.filter(r => (r.response.responseTimeMs || 0) < 3000 && r.item.itemType === "likert").length;
  const likertCount = rwis.filter(r => r.item.itemType === "likert").length;
  if (likertCount > 0 && rapidCount / likertCount > 0.3) {
    flags.push("rapid_responding");
  }

  // 3. Straightlining: if > 60% of Likert responses are the same value
  const likertValues = rwis
    .filter(r => r.item.itemType === "likert")
    .map(r => r.response.responseValue);
  if (likertValues.length >= 10) {
    const valueCounts: Record<string, number> = {};
    for (const v of likertValues) {
      valueCounts[v] = (valueCounts[v] || 0) + 1;
    }
    const maxCount = Math.max(...Object.values(valueCounts));
    if (maxCount / likertValues.length > 0.6) {
      flags.push("straightlining");
    }
  }

  // 4. Attention check failures
  const attentionItems = rwis.filter(r => r.item.itemType === "attention_check");
  for (const { response, item } of attentionItems) {
    if (item.keyJson) {
      const expected = (item.keyJson as { expected: string }).expected;
      if (response.responseValue !== expected) {
        flags.push("attention_check_failed");
        break;
      }
    }
  }

  // 5. Inconsistency: check consistency pairs (same construct, different facets)
  const consistencyPairs = rwis.filter(r => r.item.block === "quality_check" && r.item.construct === "consistency");
  if (consistencyPairs.length >= 2) {
    // Compare with original items of same construct
    const originalSelfDiscipline = rwis.find(r => 
      r.item.construct === "conscientiousness" && r.item.facet === "self_discipline" && r.item.polarity === "positive"
    );
    const consistencySelfDiscipline = consistencyPairs.find(r => 
      r.item.facet === "consistency_check" && r.item.sortOrder === 106
    );
    if (originalSelfDiscipline && consistencySelfDiscipline) {
      const diff = Math.abs(
        parseFloat(originalSelfDiscipline.response.responseValue) - 
        parseFloat(consistencySelfDiscipline.response.responseValue)
      );
      if (diff > 2) {
        flags.push("inconsistency");
      }
    }
  }

  return flags;
}

// ============ HELPERS ============

function groupByBlockConstructFacet(rwis: ResponseWithItem[]): Record<string, Record<string, Record<string, ResponseWithItem[]>>> {
  const grouped: Record<string, Record<string, Record<string, ResponseWithItem[]>>> = {};

  for (const rwi of rwis) {
    const block = rwi.item.block;
    const construct = rwi.item.construct;
    const facet = rwi.item.facet || "__none__";

    if (!grouped[block]) grouped[block] = {};
    if (!grouped[block][construct]) grouped[block][construct] = {};
    if (!grouped[block][construct][facet]) grouped[block][construct][facet] = [];
    grouped[block][construct][facet].push(rwi);
  }

  return grouped;
}

// ============ AGGREGATE SCORES FOR REPORT ============

export function aggregateScoresForReport(scores: BlockScore[]): Record<string, any> {
  const radars: Record<string, any> = {};

  // Group scores by block
  const byBlock: Record<string, BlockScore[]> = {};
  for (const s of scores) {
    if (!byBlock[s.block]) byBlock[s.block] = [];
    byBlock[s.block].push(s);
  }

  // Personality (Big Five)
  if (byBlock["core_personality"]) {
    const domainScores: Record<string, number> = {};
    const facetScores: Record<string, number> = {};
    
    // Group by construct (domain)
    const byConstruct: Record<string, BlockScore[]> = {};
    for (const s of byBlock["core_personality"]) {
      if (!byConstruct[s.construct]) byConstruct[s.construct] = [];
      byConstruct[s.construct].push(s);
    }
    
    for (const [construct, facets] of Object.entries(byConstruct)) {
      const avg = facets.reduce((sum, f) => sum + f.score0to100, 0) / facets.length;
      domainScores[construct] = Math.round(avg * 100) / 100;
      for (const f of facets) {
        if (f.facet) facetScores[`${construct}.${f.facet}`] = f.score0to100;
      }
    }
    
    radars.personality = { domain_scores_0_100: domainScores, facet_scores_0_100: facetScores };
  }

  // Communication (Circumplex)
  if (byBlock["core_communication"]) {
    const agencyScores = byBlock["core_communication"].filter(s => s.construct === "agency");
    const communionScores = byBlock["core_communication"].filter(s => s.construct === "communion");
    
    const agency = agencyScores.length > 0
      ? Math.round(agencyScores.reduce((sum, s) => sum + s.score0to100, 0) / agencyScores.length * 100) / 100
      : 0;
    const communion = communionScores.length > 0
      ? Math.round(communionScores.reduce((sum, s) => sum + s.score0to100, 0) / communionScores.length * 100) / 100
      : 0;
    
    let quadrant = "Balanced";
    if (agency >= 60 && communion >= 60) quadrant = "Líder Colaborativo";
    else if (agency >= 60 && communion < 40) quadrant = "Líder Diretivo";
    else if (agency < 40 && communion >= 60) quadrant = "Facilitador";
    else if (agency < 40 && communion < 40) quadrant = "Analítico Reservado";
    
    radars.communication = { agency_0_100: agency, communion_0_100: communion, quadrant };
  }

  // Leadership
  if (byBlock["core_leadership"]) {
    const dims: Record<string, number> = {};
    for (const s of byBlock["core_leadership"]) {
      const dim = s.facet || s.construct;
      dims[dim] = s.score0to100;
    }
    radars.leadership = { dimensions_0_100: dims };
  }

  // Vitality
  if (byBlock["core_vitality"]) {
    const wellbeing = byBlock["core_vitality"].filter(s => s.construct === "wellbeing");
    const vitality = byBlock["core_vitality"].filter(s => s.construct === "vitality");
    
    radars.vitality = {
      wellbeing_0_100: wellbeing.length > 0
        ? Math.round(wellbeing.reduce((sum, s) => sum + s.score0to100, 0) / wellbeing.length * 100) / 100
        : 0,
      vitality_0_100: vitality.length > 0
        ? Math.round(vitality.reduce((sum, s) => sum + s.score0to100, 0) / vitality.length * 100) / 100
        : 0,
    };
  }

  // Additional modules
  const moduleBlocks = ["mod_innovation", "mod_data", "mod_decision", "mod_learning", "mod_execution", "mod_motivation", "mod_values", "mod_career", "mod_collaboration"];
  const moduleNames: Record<string, string> = {
    mod_innovation: "innovation",
    mod_data: "data",
    mod_decision: "decision",
    mod_learning: "learning_agility",
    mod_execution: "execution",
    mod_motivation: "motivation_values",
    mod_values: "values",
    mod_career: "career_fit",
    mod_collaboration: "collaboration_safety",
  };

  for (const block of moduleBlocks) {
    if (byBlock[block]) {
      const dims: Record<string, number> = {};
      for (const s of byBlock[block]) {
        const key = s.facet || s.construct;
        dims[key] = s.score0to100;
      }
      const name = moduleNames[block] || block;
      if (name === "career_fit") {
        radars[name] = { riasec_0_100: dims };
      } else {
        radars[name] = { dimensions_0_100: dims };
      }
    }
  }

  return radars;
}
