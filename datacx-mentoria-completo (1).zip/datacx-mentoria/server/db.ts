import { eq, desc, and, sql, count, sum } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  mentorshipPrograms, InsertMentorshipProgram,
  enrollments, InsertEnrollment,
  contents, InsertContent,
  userProgress, InsertUserProgress,
  testimonials, InsertTestimonial,
  contactSubmissions, InsertContactSubmission,
  analyticsEvents, InsertAnalyticsEvent,
  userPoints, InsertUserPoints,
  pointTransactions, InsertPointTransaction,
  badges, InsertBadge,
  userBadges, InsertUserBadge,
  communityPosts, InsertCommunityPost,
  communityComments, InsertCommunityComment,
  communityLikes, InsertCommunityLike,
  certificates, InsertCertificate,
  quizzes, InsertQuiz,
  quizQuestions, InsertQuizQuestion,
  quizAttempts, InsertQuizAttempt,
  planModuleAccess,
  moduleChats, InsertModuleChat,
  moduleMaterials, InsertModuleMaterial,
  consultingProjects, InsertConsultingProject,
  projectTasks, InsertProjectTask,
  projectDocuments, InsertProjectDocument,
  projectMeetings, InsertProjectMeeting,
  projectMilestones, InsertProjectMilestone,
  projectChats, InsertProjectChat,
  projectStages, InsertProjectStage,
  stageDeliverables, InsertStageDeliverable,
  communityEvents, InsertCommunityEvent,
  eventRegistrations, InsertEventRegistration,
  directMessages, InsertDirectMessage,
  notifications, InsertNotification,
  auditLogs, InsertAuditLog,
  systemHealthLogs, InsertSystemHealthLog,
  radarNurtureMessages, InsertRadarNurtureMessage,
  contentPersonaVersions, InsertContentPersonaVersion,
  chatFeedback, InsertChatFeedback,
  userModuleOverrides,
  stageContents, InsertStageContent,
  stageChecklistItems, InsertStageChecklistItem,
  stageChecklistProgress, InsertStageChecklistProgress,
  stageComments, InsertStageComment,
  stageMemberProgress, InsertStageMemberProgress,
  assessmentItemBank, InsertAssessmentItem,
  assessmentSessions, InsertAssessmentSession,
  assessmentResponses, InsertAssessmentResponse,
  assessmentScores, InsertAssessmentScore,
  assessmentReports, InsertAssessmentReport,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ USER OPERATIONS ============
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "avatarUrl", "phone", "company", "position", "bio"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(desc(users.createdAt));
}

export async function updateUserProfile(userId: number, data: Partial<InsertUser>) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ ...data, updatedAt: new Date() }).where(eq(users.id, userId));
}

export async function updateUserById(id: number, data: Partial<InsertUser>) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ ...data, updatedAt: new Date() }).where(eq(users.id, id));
}

export async function deleteUserById(id: number) {
  const db = await getDb();
  if (!db) return;
  // Primeiro, excluir registros relacionados
  await db.delete(enrollments).where(eq(enrollments.userId, id));
  await db.delete(userProgress).where(eq(userProgress.userId, id));
  await db.delete(userPoints).where(eq(userPoints.userId, id));
  await db.delete(userBadges).where(eq(userBadges.userId, id));
  await db.delete(communityPosts).where(eq(communityPosts.userId, id));
  await db.delete(communityComments).where(eq(communityComments.userId, id));
  await db.delete(communityLikes).where(eq(communityLikes.userId, id));
  // Finalmente, excluir o usuário
  await db.delete(users).where(eq(users.id, id));
}

// ============ MENTORSHIP PROGRAMS ============
export async function getAllPrograms(activeOnly = true) {
  const db = await getDb();
  if (!db) return [];
  if (activeOnly) {
    return db.select().from(mentorshipPrograms).where(eq(mentorshipPrograms.isActive, true));
  }
  return db.select().from(mentorshipPrograms);
}

export async function getProgramBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(mentorshipPrograms).where(eq(mentorshipPrograms.slug, slug)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getProgramById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(mentorshipPrograms).where(eq(mentorshipPrograms.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createProgram(data: InsertMentorshipProgram) {
  const db = await getDb();
  if (!db) return;
  await db.insert(mentorshipPrograms).values(data);
}

export async function updateProgram(id: number, data: Partial<InsertMentorshipProgram>) {
  const db = await getDb();
  if (!db) return;
  await db.update(mentorshipPrograms).set({ ...data, updatedAt: new Date() }).where(eq(mentorshipPrograms.id, id));
}

// ============ ENROLLMENTS ============
export async function getUserEnrollments(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(enrollments).where(eq(enrollments.userId, userId)).orderBy(desc(enrollments.createdAt));
}

export async function getEnrollmentsByProgram(programId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(enrollments).where(eq(enrollments.programId, programId));
}

export async function getAllEnrollments() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(enrollments).orderBy(desc(enrollments.createdAt));
}

export async function createEnrollment(data: InsertEnrollment) {
  const db = await getDb();
  if (!db) return;
  await db.insert(enrollments).values(data);
}

export async function updateEnrollment(id: number, data: Partial<InsertEnrollment>) {
  const db = await getDb();
  if (!db) return;
  await db.update(enrollments).set({ ...data, updatedAt: new Date() }).where(eq(enrollments.id, id));
}

export async function getEnrollmentByStripePaymentIntent(paymentIntentId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(enrollments).where(eq(enrollments.stripePaymentIntentId, paymentIntentId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============ CONTENTS ============
export async function getAllContents() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(contents).orderBy(contents.sortOrder);
}

export async function getContentsByProgram(programId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(contents).where(eq(contents.programId, programId)).orderBy(contents.sortOrder);
}

export async function getPublicContents() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(contents).where(eq(contents.isPublic, true)).orderBy(contents.sortOrder);
}

export async function getContentById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(contents).where(eq(contents.id, id));
  return result[0] || null;
}

export async function getContentsByCategory(category?: string) {
  const db = await getDb();
  if (!db) return [];
  if (category) {
    return db.select().from(contents).where(eq(contents.category, category as any)).orderBy(contents.sortOrder);
  }
  return db.select().from(contents).orderBy(contents.category, contents.sortOrder);
}

export async function createContent(data: InsertContent) {
  const db = await getDb();
  if (!db) return;
  await db.insert(contents).values(data);
}

export async function updateContent(id: number, data: Partial<InsertContent>) {
  const db = await getDb();
  if (!db) return;
  await db.update(contents).set({ ...data, updatedAt: new Date() }).where(eq(contents.id, id));
}

export async function deleteContent(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(contents).where(eq(contents.id, id));
}

// ============ USER PROGRESS ============
export async function getUserProgressByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(userProgress).where(eq(userProgress.userId, userId));
}

export async function markContentComplete(userId: number, contentId: number) {
  const db = await getDb();
  if (!db) return;
  await db.insert(userProgress).values({
    userId,
    contentId,
    completed: true,
    completedAt: new Date(),
  }).onDuplicateKeyUpdate({
    set: { completed: true, completedAt: new Date() }
  });
}

// ============ TESTIMONIALS ============
export async function getActiveTestimonials() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(testimonials).where(eq(testimonials.isActive, true)).orderBy(testimonials.sortOrder);
}

export async function getAllTestimonials() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(testimonials).orderBy(testimonials.sortOrder);
}

export async function createTestimonial(data: InsertTestimonial) {
  const db = await getDb();
  if (!db) return;
  await db.insert(testimonials).values(data);
}

export async function updateTestimonial(id: number, data: Partial<InsertTestimonial>) {
  const db = await getDb();
  if (!db) return;
  await db.update(testimonials).set(data).where(eq(testimonials.id, id));
}

export async function deleteTestimonial(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(testimonials).where(eq(testimonials.id, id));
}

// ============ CONTACT SUBMISSIONS ============
export async function createContactSubmission(data: InsertContactSubmission) {
  const db = await getDb();
  if (!db) return;
  await db.insert(contactSubmissions).values(data);
}

export async function getAllContactSubmissions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(contactSubmissions).orderBy(desc(contactSubmissions.createdAt));
}

export async function updateContactSubmission(id: number, data: Partial<InsertContactSubmission>) {
  const db = await getDb();
  if (!db) return;
  await db.update(contactSubmissions).set({ ...data, updatedAt: new Date() }).where(eq(contactSubmissions.id, id));
}

// ============ ANALYTICS ============
export async function trackEvent(data: InsertAnalyticsEvent) {
  const db = await getDb();
  if (!db) return;
  await db.insert(analyticsEvents).values(data);
}

export async function getAnalyticsEvents(limit = 100) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(analyticsEvents).orderBy(desc(analyticsEvents.createdAt)).limit(limit);
}

// ============ DASHBOARD METRICS ============
export async function getDashboardMetrics() {
  const db = await getDb();
  if (!db) return { totalUsers: 0, totalEnrollments: 0, activeEnrollments: 0, totalRevenue: 0, pendingContacts: 0 };

  const [userCount] = await db.select({ count: count() }).from(users);
  const [enrollmentCount] = await db.select({ count: count() }).from(enrollments);
  const [activeEnrollmentCount] = await db.select({ count: count() }).from(enrollments).where(eq(enrollments.status, 'active'));
  const [revenueSum] = await db.select({ total: sum(enrollments.paidAmount) }).from(enrollments).where(eq(enrollments.paymentStatus, 'paid'));
  const [pendingContactCount] = await db.select({ count: count() }).from(contactSubmissions).where(eq(contactSubmissions.status, 'new'));

  return {
    totalUsers: userCount?.count || 0,
    totalEnrollments: enrollmentCount?.count || 0,
    activeEnrollments: activeEnrollmentCount?.count || 0,
    totalRevenue: Number(revenueSum?.total) || 0,
    pendingContacts: pendingContactCount?.count || 0,
  };
}


// ============ RADAR VÉRTICE ============
import { radarLeads, InsertRadarLead } from "../drizzle/schema";

export async function createRadarLead(data: InsertRadarLead) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(radarLeads).values(data);
  // Retornar o ID do lead inserido
  const inserted = await db.select({ id: radarLeads.id }).from(radarLeads).where(eq(radarLeads.email, data.email)).orderBy(desc(radarLeads.createdAt)).limit(1);
  return inserted[0] || null;
}

export async function getRadarLeadByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(radarLeads).where(eq(radarLeads.email, email)).orderBy(desc(radarLeads.createdAt)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getRadarLeadById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(radarLeads).where(eq(radarLeads.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllRadarLeads() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(radarLeads).orderBy(desc(radarLeads.createdAt));
}

export async function getRadarLeadsByPersona(persona: "jovem" | "gestor" | "executivo" | "empresario") {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(radarLeads).where(eq(radarLeads.persona, persona)).orderBy(desc(radarLeads.createdAt));
}

export async function getRadarLeadsByRecommendation(level: "fundamentos" | "aplicacao" | "escala" | "estrategia") {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(radarLeads).where(eq(radarLeads.recommendedLevel, level)).orderBy(desc(radarLeads.createdAt));
}

export async function updateRadarLeadStatus(id: number, status: "new" | "contacted" | "nurturing" | "converted" | "lost") {
  const db = await getDb();
  if (!db) return;
  await db.update(radarLeads).set({ status, updatedAt: new Date() }).where(eq(radarLeads.id, id));
}

export async function markRadarReportSent(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(radarLeads).set({ reportSentAt: new Date(), updatedAt: new Date() }).where(eq(radarLeads.id, id));
}

export async function getRadarMetrics() {
  const db = await getDb();
  if (!db) return { total: 0, newLeads: 0, contacted: 0, converted: 0 };

  const [totalCount] = await db.select({ count: count() }).from(radarLeads);
  const [newCount] = await db.select({ count: count() }).from(radarLeads).where(eq(radarLeads.status, 'new'));
  const [contactedCount] = await db.select({ count: count() }).from(radarLeads).where(eq(radarLeads.status, 'contacted'));
  const [convertedCount] = await db.select({ count: count() }).from(radarLeads).where(eq(radarLeads.status, 'converted'));

  // Segment counts
  const segmentCategories = ["dados", "cx", "ia", "governanca", "cultura"] as const;
  const segmentCounts: Record<string, number> = {};
  for (const seg of segmentCategories) {
    const [segCount] = await db.select({ count: count() }).from(radarLeads).where(eq(radarLeads.challengeSegment, seg));
    segmentCounts[seg] = segCount?.count || 0;
  }
  const [noSegmentCount] = await db.select({ count: count() }).from(radarLeads).where(isNull(radarLeads.challengeSegment));
  segmentCounts["none"] = noSegmentCount?.count || 0;

  return {
    total: totalCount?.count || 0,
    newLeads: newCount?.count || 0,
    contacted: contactedCount?.count || 0,
    converted: convertedCount?.count || 0,
    segments: segmentCounts,
  };
}

export async function getSegmentTrends(months: number = 6) {
  const db = await getDb();
  if (!db) return [];
  
  const startDate = new Date();
  startDate.setMonth(startDate.getMonth() - months);
  
  const monthExpr = sql<string>`DATE_FORMAT(${radarLeads.createdAt}, '%Y-%m')`;
  const results = await db.select({
    month: monthExpr.as('month_period'),
    segment: radarLeads.challengeSegment,
    count: count(),
  })
    .from(radarLeads)
    .where(gte(radarLeads.createdAt, startDate))
    .groupBy(sql`month_period`, radarLeads.challengeSegment)
    .orderBy(sql`month_period`);
  
  return results;
}

export async function getLeadsBySegment(segment: string) {
  const db = await getDb();
  if (!db) return [];
  if (segment === "none") {
    return db.select().from(radarLeads).where(isNull(radarLeads.challengeSegment)).orderBy(desc(radarLeads.createdAt));
  }
  return db.select().from(radarLeads).where(eq(radarLeads.challengeSegment, segment as any)).orderBy(desc(radarLeads.createdAt));
}


// ============ COUPONS ============
import { coupons, couponUsages, InsertCoupon, InsertCouponUsage } from "../drizzle/schema";
import { gte, lte, or, isNull, lt, inArray, like, asc, avg } from "drizzle-orm";

export async function getAllCoupons() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(coupons).orderBy(desc(coupons.createdAt));
}

export async function getCouponById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(coupons).where(eq(coupons.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getCouponByCode(code: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(coupons).where(eq(coupons.code, code.toUpperCase())).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createCoupon(data: InsertCoupon) {
  const db = await getDb();
  if (!db) return null;
  // Ensure code is uppercase
  const couponData = { ...data, code: data.code.toUpperCase() };
  const result = await db.insert(coupons).values(couponData);
  return result;
}

export async function updateCoupon(id: number, data: Partial<InsertCoupon>) {
  const db = await getDb();
  if (!db) return;
  const updateData = { ...data, updatedAt: new Date() };
  if (data.code) {
    updateData.code = data.code.toUpperCase();
  }
  await db.update(coupons).set(updateData).where(eq(coupons.id, id));
}

export async function deleteCoupon(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(coupons).where(eq(coupons.id, id));
}

export async function incrementCouponUsage(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(coupons).set({ 
    usageCount: sql`${coupons.usageCount} + 1`,
    updatedAt: new Date() 
  }).where(eq(coupons.id, id));
}

export async function validateCoupon(code: string, productSlug?: string): Promise<{ valid: boolean; coupon?: typeof coupons.$inferSelect; error?: string }> {
  const db = await getDb();
  if (!db) return { valid: false, error: "Banco de dados indisponível" };

  const coupon = await getCouponByCode(code);
  
  if (!coupon) {
    return { valid: false, error: "Cupom não encontrado" };
  }

  if (!coupon.isActive) {
    return { valid: false, error: "Cupom inativo" };
  }

  const now = new Date();
  
  if (coupon.validFrom && coupon.validFrom > now) {
    return { valid: false, error: "Cupom ainda não está válido" };
  }

  if (coupon.validUntil && coupon.validUntil < now) {
    return { valid: false, error: "Cupom expirado" };
  }

  if (coupon.usageLimit && coupon.usageCount >= coupon.usageLimit) {
    return { valid: false, error: "Limite de uso do cupom atingido" };
  }

  // Check if coupon is applicable to the product
  if (coupon.applicableProducts && productSlug) {
    const applicableProducts = coupon.applicableProducts as string[];
    if (applicableProducts.length > 0 && !applicableProducts.includes(productSlug)) {
      return { valid: false, error: "Cupom não aplicável a este produto" };
    }
  }

  return { valid: true, coupon };
}

export async function calculateDiscount(coupon: typeof coupons.$inferSelect, originalAmount: number): Promise<{ discount: number; finalAmount: number }> {
  let discount = 0;
  
  if (coupon.discountType === "percentage") {
    discount = (originalAmount * Number(coupon.discountValue)) / 100;
  } else {
    discount = Number(coupon.discountValue);
  }

  // Apply max discount limit if set
  if (coupon.maxDiscountAmount && discount > Number(coupon.maxDiscountAmount)) {
    discount = Number(coupon.maxDiscountAmount);
  }

  // Ensure discount doesn't exceed original amount
  if (discount > originalAmount) {
    discount = originalAmount;
  }

  const finalAmount = originalAmount - discount;

  return { discount, finalAmount };
}

export async function recordCouponUsage(data: InsertCouponUsage) {
  const db = await getDb();
  if (!db) return;
  await db.insert(couponUsages).values(data);
}

export async function getCouponUsages(couponId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(couponUsages).where(eq(couponUsages.couponId, couponId)).orderBy(desc(couponUsages.createdAt));
}

export async function getUserCouponUsageCount(userId: number, couponId: number) {
  const db = await getDb();
  if (!db) return 0;
  const [result] = await db.select({ count: count() }).from(couponUsages)
    .where(and(eq(couponUsages.userId, userId), eq(couponUsages.couponId, couponId)));
  return result?.count || 0;
}

export async function getCouponMetrics() {
  const db = await getDb();
  if (!db) return { totalCoupons: 0, activeCoupons: 0, totalUsages: 0, totalDiscount: 0 };

  const [totalCount] = await db.select({ count: count() }).from(coupons);
  const [activeCount] = await db.select({ count: count() }).from(coupons).where(eq(coupons.isActive, true));
  const [usageCount] = await db.select({ count: count() }).from(couponUsages);
  const [discountSum] = await db.select({ total: sum(couponUsages.discountApplied) }).from(couponUsages);

  return {
    totalCoupons: totalCount?.count || 0,
    activeCoupons: activeCount?.count || 0,
    totalUsages: usageCount?.count || 0,
    totalDiscount: Number(discountSum?.total) || 0,
  };
}


// ============ GAMIFICATION - POINTS ============

export async function getUserPoints(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(userPoints).where(eq(userPoints.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createOrUpdateUserPoints(userId: number, pointsToAdd: number, reason: string, referenceType?: string, referenceId?: number) {
  const db = await getDb();
  if (!db) return;
  
  // Get or create user points
  let points = await getUserPoints(userId);
  if (!points) {
    await db.insert(userPoints).values({ userId, points: 0, level: 1, levelName: "Iniciante", totalPointsEarned: 0 });
    points = await getUserPoints(userId);
  }
  
  const newPoints = (points?.points || 0) + pointsToAdd;
  const newTotalEarned = (points?.totalPointsEarned || 0) + (pointsToAdd > 0 ? pointsToAdd : 0);
  
  // Calculate level based on total points earned
  const { level, levelName } = calculateLevel(newTotalEarned);
  
  await db.update(userPoints).set({
    points: newPoints,
    totalPointsEarned: newTotalEarned,
    level,
    levelName,
    updatedAt: new Date(),
  }).where(eq(userPoints.userId, userId));
  
  // Record transaction
  await db.insert(pointTransactions).values({
    userId,
    points: pointsToAdd,
    type: pointsToAdd > 0 ? "earned" : "spent",
    reason,
    referenceType,
    referenceId,
  });
}

function calculateLevel(totalPoints: number): { level: number; levelName: string } {
  const levels = [
    { min: 0, level: 1, name: "Iniciante" },
    { min: 100, level: 2, name: "Aprendiz" },
    { min: 300, level: 3, name: "Praticante" },
    { min: 600, level: 4, name: "Especialista" },
    { min: 1000, level: 5, name: "Mestre" },
    { min: 2000, level: 6, name: "Vértice" },
    { min: 5000, level: 7, name: "Lenda" },
  ];
  
  for (let i = levels.length - 1; i >= 0; i--) {
    if (totalPoints >= levels[i].min) {
      return { level: levels[i].level, levelName: levels[i].name };
    }
  }
  return { level: 1, levelName: "Iniciante" };
}

export async function getPointTransactions(userId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(pointTransactions).where(eq(pointTransactions.userId, userId)).orderBy(desc(pointTransactions.createdAt)).limit(limit);
}

export async function getLeaderboard(limit = 10) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(userPoints).orderBy(desc(userPoints.totalPointsEarned)).limit(limit);
}

// ============ BADGES ============
export async function getAllBadges() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(badges).where(eq(badges.isActive, true)).orderBy(badges.sortOrder);
}

export async function createBadge(data: InsertBadge) {
  const db = await getDb();
  if (!db) return;
  await db.insert(badges).values(data);
}

export async function getUserBadges(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(userBadges).where(eq(userBadges.userId, userId));
}

export async function awardBadge(userId: number, badgeId: number) {
  const db = await getDb();
  if (!db) return;
  
  // Check if already has badge
  const existing = await db.select().from(userBadges)
    .where(and(eq(userBadges.userId, userId), eq(userBadges.badgeId, badgeId))).limit(1);
  if (existing.length > 0) return;
  
  await db.insert(userBadges).values({ userId, badgeId });
  
  // Award points for badge
  const badge = await db.select().from(badges).where(eq(badges.id, badgeId)).limit(1);
  if (badge[0]?.pointsReward) {
    await createOrUpdateUserPoints(userId, badge[0].pointsReward, `Badge: ${badge[0].name}`, "badge", badgeId);
  }
}

// ============ COMMUNITY ============
export async function getCommunityPosts(programId?: number, space?: string, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  
  const conditions = [eq(communityPosts.isActive, true)];
  if (programId) conditions.push(eq(communityPosts.programId, programId));
  if (space && space !== "geral") conditions.push(eq(communityPosts.space, space));
  
  return db.select().from(communityPosts)
    .where(and(...conditions))
    .orderBy(desc(communityPosts.isPinned), desc(communityPosts.createdAt))
    .limit(limit);
}

export async function getPostById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(communityPosts).where(eq(communityPosts.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createPost(data: InsertCommunityPost) {
  const db = await getDb();
  if (!db) return;
  await db.insert(communityPosts).values(data);
  
  // Award points for posting
  await createOrUpdateUserPoints(data.userId, 10, "Criou um post na comunidade", "post");
}

export async function updatePost(id: number, data: Partial<InsertCommunityPost>) {
  const db = await getDb();
  if (!db) return;
  await db.update(communityPosts).set({ ...data, updatedAt: new Date() }).where(eq(communityPosts.id, id));
}

export async function deletePost(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(communityPosts).set({ isActive: false }).where(eq(communityPosts.id, id));
}

export async function updatePostPin(id: number, isPinned: boolean) {
  const db = await getDb();
  if (!db) return;
  await db.update(communityPosts).set({ isPinned }).where(eq(communityPosts.id, id));
}

export async function deleteComment(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(communityComments).set({ isActive: false }).where(eq(communityComments.id, id));
}

export async function getPostComments(postId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(communityComments)
    .where(and(eq(communityComments.postId, postId), eq(communityComments.isActive, true)))
    .orderBy(communityComments.createdAt);
}

export async function createComment(data: InsertCommunityComment) {
  const db = await getDb();
  if (!db) return;
  await db.insert(communityComments).values(data);
  
  // Update comment count
  await db.update(communityPosts)
    .set({ commentsCount: sql`${communityPosts.commentsCount} + 1` })
    .where(eq(communityPosts.id, data.postId));
  
  // Award points for commenting
  await createOrUpdateUserPoints(data.userId, 5, "Comentou em um post", "comment");
}

export async function toggleLike(userId: number, postId?: number, commentId?: number) {
  const db = await getDb();
  if (!db) return { liked: false };
  
  // Check existing like
  const existing = await db.select().from(communityLikes)
    .where(and(
      eq(communityLikes.userId, userId),
      postId ? eq(communityLikes.postId, postId) : eq(communityLikes.commentId, commentId!)
    )).limit(1);
  
  if (existing.length > 0) {
    // Remove like
    await db.delete(communityLikes).where(eq(communityLikes.id, existing[0].id));
    if (postId) {
      await db.update(communityPosts)
        .set({ likesCount: sql`${communityPosts.likesCount} - 1` })
        .where(eq(communityPosts.id, postId));
    }
    return { liked: false };
  } else {
    // Add like
    await db.insert(communityLikes).values({ userId, postId, commentId });
    if (postId) {
      await db.update(communityPosts)
        .set({ likesCount: sql`${communityPosts.likesCount} + 1` })
        .where(eq(communityPosts.id, postId));
    }
    // Award points for receiving a like (to post author)
    if (postId) {
      const post = await getPostById(postId);
      if (post && post.userId !== userId) {
        await createOrUpdateUserPoints(post.userId, 2, "Recebeu um like", "like");
      }
    }
    return { liked: true };
  }
}

export async function getUserLikes(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(communityLikes).where(eq(communityLikes.userId, userId));
}

// ============ CERTIFICATES ============
export async function getUserCertificates(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(certificates).where(eq(certificates.userId, userId)).orderBy(desc(certificates.completionDate));
}

export async function createCertificate(data: InsertCertificate) {
  const db = await getDb();
  if (!db) return;
  await db.insert(certificates).values(data);
}

export async function getCertificateById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(certificates).where(eq(certificates.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getCertificateByVerificationCode(code: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(certificates).where(eq(certificates.verificationCode, code)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function generateCertificateNumber(): Promise<string> {
  const year = new Date().getFullYear();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `DCX-${year}-${random}`;
}

export async function generateVerificationCode(): Promise<string> {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

export async function updateCertificatePdfUrl(id: number, pdfUrl: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(certificates).set({ pdfUrl }).where(eq(certificates.id, id));
}

export async function checkProgramCompletion(userId: number): Promise<{
  completedPrograms: { programId: number; programName: string; category: string }[];
  progress: { category: string; completed: number; total: number }[];
}> {
  const db = await getDb();
  if (!db) return { completedPrograms: [], progress: [] };
  
  const userProgressList = await db.select().from(userProgress)
    .where(and(eq(userProgress.userId, userId), eq(userProgress.completed, true)));
  const completedContentIds = new Set(userProgressList.map(p => p.contentId));
  
  const allContents = await db.select().from(contents);
  
  // Group by category
  const categoryMap: Record<string, { completed: number; total: number }> = {};
  allContents.forEach(content => {
    const cat = content.category || 'introducao';
    if (!categoryMap[cat]) categoryMap[cat] = { completed: 0, total: 0 };
    categoryMap[cat].total++;
    if (completedContentIds.has(content.id)) {
      categoryMap[cat].completed++;
    }
  });
  
  const progress = Object.entries(categoryMap).map(([category, data]) => ({
    category,
    ...data,
  }));
  
  const completedPrograms = progress
    .filter(p => p.total > 0 && p.completed >= p.total)
    .map(p => ({
      programId: 0, // Will be resolved by caller if needed
      programName: getCategoryDisplayName(p.category),
      category: p.category,
    }));
  
  return { completedPrograms, progress };
}

export async function getCertificateByUserAndProgram(userId: number, programId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(certificates)
    .where(and(eq(certificates.userId, userId), eq(certificates.programId, programId)))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getContentsByProgramId(programId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(contents).where(eq(contents.programId, programId)).orderBy(contents.sortOrder);
}

export async function getUserProgressByProgram(userId: number, programId: number) {
  const db = await getDb();
  if (!db) return [];
  const programContents = await getContentsByProgramId(programId);
  const contentIds = programContents.map(c => c.id);
  if (contentIds.length === 0) return [];
  return db.select().from(userProgress)
    .where(and(
      eq(userProgress.userId, userId),
      inArray(userProgress.contentId, contentIds)
    ));
}

// ============ QUIZZES ============
export async function getQuizByContentId(contentId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(quizzes).where(eq(quizzes.contentId, contentId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getQuizById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(quizzes).where(eq(quizzes.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createQuiz(data: InsertQuiz) {
  const db = await getDb();
  if (!db) return;
  await db.insert(quizzes).values(data);
}

export async function getQuizQuestions(quizId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(quizQuestions).where(eq(quizQuestions.quizId, quizId)).orderBy(quizQuestions.sortOrder);
}

export async function createQuizQuestion(data: InsertQuizQuestion) {
  const db = await getDb();
  if (!db) return;
  await db.insert(quizQuestions).values(data);
}

export async function getUserQuizAttempts(userId: number, quizId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(quizAttempts)
    .where(and(eq(quizAttempts.userId, userId), eq(quizAttempts.quizId, quizId)))
    .orderBy(desc(quizAttempts.completedAt));
}

export async function createQuizAttempt(data: InsertQuizAttempt) {
  const db = await getDb();
  if (!db) return;
  await db.insert(quizAttempts).values(data);
  
  // Award points if passed
  if (data.passed && data.pointsEarned && data.pointsEarned > 0) {
    await createOrUpdateUserPoints(data.userId, data.pointsEarned, "Completou quiz com sucesso", "quiz", data.quizId);  
  }
}

export async function getAllQuizzes() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(quizzes).where(eq(quizzes.isActive, true));
}


// ============ MODULE CHAT ============

export async function getModuleChatHistory(userId: number, contentId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(moduleChats)
    .where(and(eq(moduleChats.userId, userId), eq(moduleChats.contentId, contentId)))
    .orderBy(moduleChats.createdAt);
}

export async function createModuleChatMessage(data: InsertModuleChat) {
  const db = await getDb();
  if (!db) return null;
  const [result] = await db.insert(moduleChats).values(data);
  return result.insertId;
}

// ============ CHAT FEEDBACK ============

export async function submitChatFeedback(data: InsertChatFeedback) {
  const db = await getDb();
  if (!db) return null;
  
  // Check if feedback already exists for this message+user
  const existing = await db.select().from(chatFeedback)
    .where(and(
      eq(chatFeedback.chatMessageId, data.chatMessageId),
      eq(chatFeedback.userId, data.userId)
    ))
    .limit(1);
  
  if (existing.length > 0) {
    // Update existing feedback
    await db.update(chatFeedback)
      .set({ rating: data.rating, comment: data.comment })
      .where(eq(chatFeedback.id, existing[0].id));
    return existing[0].id;
  }
  
  const [result] = await db.insert(chatFeedback).values(data);
  return result.insertId;
}

export async function getChatFeedbackByContent(userId: number, contentId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(chatFeedback)
    .where(and(
      eq(chatFeedback.userId, userId),
      eq(chatFeedback.contentId, contentId)
    ));
}

export async function getChatFeedbackStats() {
  const db = await getDb();
  if (!db) return { totalFeedback: 0, avgRating: 0, ratingDistribution: {} };
  
  const stats = await db.select({
    totalFeedback: count(),
    avgRating: sql<number>`AVG(${chatFeedback.rating})`,
  }).from(chatFeedback);
  
  const distribution = await db.select({
    rating: chatFeedback.rating,
    count: count(),
  }).from(chatFeedback).groupBy(chatFeedback.rating);
  
  const ratingDistribution: Record<number, number> = {};
  distribution.forEach(d => { ratingDistribution[d.rating] = d.count; });
  
  return {
    totalFeedback: stats[0]?.totalFeedback || 0,
    avgRating: Math.round((stats[0]?.avgRating || 0) * 10) / 10,
    ratingDistribution,
  };
}

// ============ MODULE MATERIALS ============
export async function getModuleMaterials(contentId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(moduleMaterials)
    .where(and(eq(moduleMaterials.contentId, contentId), eq(moduleMaterials.isLatest, true)))
    .orderBy(moduleMaterials.createdAt);
}

export async function createModuleMaterial(data: InsertModuleMaterial) {
  const db = await getDb();
  if (!db) return;
  // Mark previous versions as not latest
  await db.update(moduleMaterials)
    .set({ isLatest: false })
    .where(and(eq(moduleMaterials.contentId, data.contentId), eq(moduleMaterials.name, data.name)));
  await db.insert(moduleMaterials).values(data);
}

// ============ CONSULTING PROJECTS ============
export async function getConsultingProjects(clientUserId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (clientUserId) {
    return db.select().from(consultingProjects)
      .where(eq(consultingProjects.clientUserId, clientUserId))
      .orderBy(desc(consultingProjects.createdAt));
  }
  return db.select().from(consultingProjects).orderBy(desc(consultingProjects.createdAt));
}

export async function getConsultingProjectById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(consultingProjects).where(eq(consultingProjects.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createConsultingProject(data: InsertConsultingProject) {
  const db = await getDb();
  if (!db) return;
  await db.insert(consultingProjects).values(data);
}

export async function updateConsultingProject(id: number, data: Partial<InsertConsultingProject>) {
  const db = await getDb();
  if (!db) return;
  await db.update(consultingProjects).set({ ...data, updatedAt: new Date() }).where(eq(consultingProjects.id, id));
}

// ============ PROJECT TASKS ============
export async function getProjectTasks(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(projectTasks)
    .where(eq(projectTasks.projectId, projectId))
    .orderBy(projectTasks.sortOrder);
}

export async function createProjectTask(data: InsertProjectTask) {
  const db = await getDb();
  if (!db) return;
  await db.insert(projectTasks).values(data);
}

export async function updateProjectTask(id: number, data: Partial<InsertProjectTask>) {
  const db = await getDb();
  if (!db) return;
  await db.update(projectTasks).set({ ...data, updatedAt: new Date() }).where(eq(projectTasks.id, id));
}

export async function deleteProjectTask(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(projectTasks).where(eq(projectTasks.id, id));
}

// ============ PROJECT DOCUMENTS ============
export async function getProjectDocuments(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(projectDocuments)
    .where(eq(projectDocuments.projectId, projectId))
    .orderBy(desc(projectDocuments.createdAt));
}

export async function createProjectDocument(data: InsertProjectDocument) {
  const db = await getDb();
  if (!db) return;
  await db.insert(projectDocuments).values(data);
}

export async function deleteProjectDocument(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(projectDocuments).where(eq(projectDocuments.id, id));
}

// ============ PROJECT MEETINGS ============
export async function getProjectMeetings(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(projectMeetings)
    .where(eq(projectMeetings.projectId, projectId))
    .orderBy(desc(projectMeetings.date));
}

export async function createProjectMeeting(data: InsertProjectMeeting) {
  const db = await getDb();
  if (!db) return;
  await db.insert(projectMeetings).values(data);
}

export async function updateProjectMeeting(id: number, data: Partial<InsertProjectMeeting>) {
  const db = await getDb();
  if (!db) return;
  await db.update(projectMeetings).set({ ...data, updatedAt: new Date() }).where(eq(projectMeetings.id, id));
}

// ============ PROJECT MILESTONES ============
export async function getProjectMilestones(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(projectMilestones)
    .where(eq(projectMilestones.projectId, projectId))
    .orderBy(projectMilestones.sortOrder);
}

export async function createProjectMilestone(data: InsertProjectMilestone) {
  const db = await getDb();
  if (!db) return;
  await db.insert(projectMilestones).values(data);
}

export async function updateProjectMilestone(id: number, data: Partial<InsertProjectMilestone>) {
  const db = await getDb();
  if (!db) return;
  await db.update(projectMilestones).set(data).where(eq(projectMilestones.id, id));
}

// ============ PROJECT CHAT ============
export async function getProjectChatMessages(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(projectChats)
    .where(eq(projectChats.projectId, projectId))
    .orderBy(projectChats.createdAt);
}

export async function createProjectChatMessage(data: InsertProjectChat) {
  const db = await getDb();
  if (!db) return;
  await db.insert(projectChats).values(data);
}

// ============ PROJECT STAGES (JORNADA) ============
export async function getProjectStages(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(projectStages)
    .where(eq(projectStages.projectId, projectId))
    .orderBy(projectStages.sortOrder);
}

export async function getProjectStageById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(projectStages).where(eq(projectStages.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createProjectStage(data: InsertProjectStage) {
  const db = await getDb();
  if (!db) return;
  await db.insert(projectStages).values(data);
}

export async function updateProjectStage(id: number, data: Partial<InsertProjectStage>) {
  const db = await getDb();
  if (!db) return;
  await db.update(projectStages).set({ ...data, updatedAt: new Date() }).where(eq(projectStages.id, id));
}

export async function deleteProjectStage(id: number) {
  const db = await getDb();
  if (!db) return;
  // Delete deliverables first
  await db.delete(stageDeliverables).where(eq(stageDeliverables.stageId, id));
  await db.delete(projectStages).where(eq(projectStages.id, id));
}

// ============ STUDENT JOURNEY DASHBOARD ============
export async function getStudentJourneyDashboard(userId: number) {
  const db = await getDb();
  if (!db) return null;

  const projects = await db.select().from(consultingProjects)
    .where(eq(consultingProjects.clientUserId, userId))
    .orderBy(desc(consultingProjects.updatedAt));

  if (projects.length === 0) return {
    projects: [],
    summary: {
      totalProjects: 0, activeProjects: 0, completedProjects: 0, overallProgress: 0,
      totalStages: 0, completedStages: 0, totalTasks: 0, completedTasks: 0,
      totalDeliverables: 0, approvedDeliverables: 0, pendingDeliverables: 0,
      totalMilestones: 0, completedMilestones: 0,
      upcomingDeadlines: [] as Array<{ type: string; title: string; dueDate: Date; projectName: string; projectId: number }>,
      recentActivity: [] as Array<{ type: string; title: string; date: Date; projectName: string; status?: string }>,
    },
  };

  const projectIds = projects.map(p => p.id);

  const allStages = await db.select().from(projectStages)
    .where(inArray(projectStages.projectId, projectIds))
    .orderBy(projectStages.sortOrder);

  const allTasks = await db.select().from(projectTasks)
    .where(inArray(projectTasks.projectId, projectIds))
    .orderBy(desc(projectTasks.updatedAt));

  const allMilestones = await db.select().from(projectMilestones)
    .where(inArray(projectMilestones.projectId, projectIds))
    .orderBy(projectMilestones.sortOrder);

  const allDeliverables = await db.select().from(stageDeliverables)
    .where(inArray(stageDeliverables.projectId, projectIds))
    .orderBy(desc(stageDeliverables.updatedAt));

  const recentDocs = await db.select().from(projectDocuments)
    .where(inArray(projectDocuments.projectId, projectIds))
    .orderBy(desc(projectDocuments.createdAt))
    .limit(5);

  const completedStages = allStages.filter(s => s.status === 'completed').length;
  const completedTasks = allTasks.filter(t => t.status === 'done').length;
  const completedMilestones = allMilestones.filter(m => m.status === 'completed').length;
  const approvedDeliverables = allDeliverables.filter(d => d.status === 'approved').length;
  const pendingDeliverables = allDeliverables.filter(d => d.status === 'pending' || d.status === 'revision_needed').length;
  const activeProjects = projects.filter(p => p.status !== 'completed' && p.status !== 'on_hold').length;
  const completedProjects = projects.filter(p => p.status === 'completed').length;

  const stageProgress = allStages.length > 0 ? (completedStages / allStages.length) * 100 : 0;
  const taskProgress = allTasks.length > 0 ? (completedTasks / allTasks.length) * 100 : 0;
  const milestoneProgress = allMilestones.length > 0 ? (completedMilestones / allMilestones.length) * 100 : 0;
  const overallProgress = allStages.length > 0 || allTasks.length > 0 || allMilestones.length > 0
    ? Math.round(stageProgress * 0.4 + taskProgress * 0.3 + milestoneProgress * 0.3)
    : Math.round(projects.reduce((acc, p) => acc + p.progress, 0) / projects.length);

  const now = new Date();
  const thirtyDays = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  const upcomingDeadlines: Array<{ type: string; title: string; dueDate: Date; projectName: string; projectId: number }> = [];

  for (const stage of allStages) {
    if (stage.dueDate && stage.status !== 'completed' && stage.dueDate <= thirtyDays) {
      const proj = projects.find(p => p.id === stage.projectId);
      upcomingDeadlines.push({ type: 'stage', title: stage.title, dueDate: stage.dueDate, projectName: proj?.name || '', projectId: stage.projectId });
    }
  }
  for (const task of allTasks) {
    if (task.dueDate && task.status !== 'done' && task.dueDate <= thirtyDays) {
      const proj = projects.find(p => p.id === task.projectId);
      upcomingDeadlines.push({ type: 'task', title: task.title, dueDate: task.dueDate, projectName: proj?.name || '', projectId: task.projectId });
    }
  }
  for (const ms of allMilestones) {
    if (ms.dueDate && ms.status !== 'completed' && ms.dueDate <= thirtyDays) {
      const proj = projects.find(p => p.id === ms.projectId);
      upcomingDeadlines.push({ type: 'milestone', title: ms.title, dueDate: ms.dueDate, projectName: proj?.name || '', projectId: ms.projectId });
    }
  }
  upcomingDeadlines.sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime());

  const recentActivity: Array<{ type: string; title: string; date: Date; projectName: string; status?: string }> = [];
  for (const stage of allStages.filter(s => s.completedAt)) {
    const proj = projects.find(p => p.id === stage.projectId);
    recentActivity.push({ type: 'stage_completed', title: stage.title, date: stage.completedAt!, projectName: proj?.name || '' });
  }
  for (const task of allTasks.filter(t => t.completedAt)) {
    const proj = projects.find(p => p.id === task.projectId);
    recentActivity.push({ type: 'task_completed', title: task.title, date: task.completedAt!, projectName: proj?.name || '' });
  }
  for (const del of allDeliverables.filter(d => d.status === 'approved' || d.status === 'uploaded')) {
    const proj = projects.find(p => p.id === del.projectId);
    recentActivity.push({ type: 'deliverable_' + del.status, title: del.title, date: del.updatedAt, projectName: proj?.name || '', status: del.status });
  }
  for (const doc of recentDocs) {
    const proj = projects.find(p => p.id === doc.projectId);
    recentActivity.push({ type: 'document_added', title: doc.name, date: doc.createdAt, projectName: proj?.name || '' });
  }
  recentActivity.sort((a, b) => b.date.getTime() - a.date.getTime());

  const projectDetails = projects.map(project => {
    const stages = allStages.filter(s => s.projectId === project.id);
    const tasks = allTasks.filter(t => t.projectId === project.id);
    const milestones = allMilestones.filter(m => m.projectId === project.id);
    const deliverables = allDeliverables.filter(d => d.projectId === project.id);
    const stagesCompleted = stages.filter(s => s.status === 'completed').length;
    const tasksCompleted = tasks.filter(t => t.status === 'done').length;
    const milestonesCompleted = milestones.filter(m => m.status === 'completed').length;
    const nextStage = stages.find(s => s.status === 'available' || s.status === 'in_progress');
    const pendingTasks = tasks.filter(t => t.status !== 'done').length;

    return {
      ...project,
      stages,
      stagesCompleted,
      stagesTotal: stages.length,
      tasksCompleted,
      tasksTotal: tasks.length,
      pendingTasks,
      milestonesCompleted,
      milestonesTotal: milestones.length,
      deliverablesTotal: deliverables.length,
      deliverablesApproved: deliverables.filter(d => d.status === 'approved').length,
      nextStage,
      milestones,
    };
  });

  return {
    projects: projectDetails,
    summary: {
      totalProjects: projects.length,
      activeProjects,
      completedProjects,
      overallProgress,
      totalStages: allStages.length,
      completedStages,
      totalTasks: allTasks.length,
      completedTasks,
      totalDeliverables: allDeliverables.length,
      approvedDeliverables,
      pendingDeliverables,
      totalMilestones: allMilestones.length,
      completedMilestones,
      upcomingDeadlines: upcomingDeadlines.slice(0, 10),
      recentActivity: recentActivity.slice(0, 10),
    },
  };
}

// ============ STAGE DELIVERABLES ============
export async function getStageDeliverables(stageId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(stageDeliverables)
    .where(eq(stageDeliverables.stageId, stageId))
    .orderBy(stageDeliverables.createdAt);
}

export async function getProjectDeliverables(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(stageDeliverables)
    .where(eq(stageDeliverables.projectId, projectId))
    .orderBy(desc(stageDeliverables.createdAt));
}

export async function createStageDeliverable(data: InsertStageDeliverable) {
  const db = await getDb();
  if (!db) return;
  await db.insert(stageDeliverables).values(data);
}

export async function updateStageDeliverable(id: number, data: Partial<InsertStageDeliverable>) {
  const db = await getDb();
  if (!db) return;
  await db.update(stageDeliverables).set({ ...data, updatedAt: new Date() }).where(eq(stageDeliverables.id, id));
}

export async function deleteStageDeliverable(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(stageDeliverables).where(eq(stageDeliverables.id, id));
}

// ============ COMMUNITY EVENTS ============
export async function getCommunityEvents(programId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (programId) {
    return db.select().from(communityEvents)
      .where(eq(communityEvents.programId, programId))
      .orderBy(communityEvents.startTime);
  }
  return db.select().from(communityEvents).orderBy(communityEvents.startTime);
}

export async function getUpcomingEvents() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(communityEvents)
    .where(sql`${communityEvents.startTime} > NOW()`)
    .orderBy(communityEvents.startTime);
}

export async function createCommunityEvent(data: InsertCommunityEvent) {
  const db = await getDb();
  if (!db) return;
  await db.insert(communityEvents).values(data);
}

export async function updateCommunityEvent(id: number, data: Partial<InsertCommunityEvent>) {
  const db = await getDb();
  if (!db) return;
  await db.update(communityEvents).set({ ...data, updatedAt: new Date() }).where(eq(communityEvents.id, id));
}

// ============ EVENT REGISTRATIONS ============
export async function getEventRegistrations(eventId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(eventRegistrations).where(eq(eventRegistrations.eventId, eventId));
}

export async function registerForEvent(data: InsertEventRegistration) {
  const db = await getDb();
  if (!db) return;
  await db.insert(eventRegistrations).values(data);
}

export async function updateEventRegistration(id: number, data: Partial<InsertEventRegistration>) {
  const db = await getDb();
  if (!db) return;
  await db.update(eventRegistrations).set(data).where(eq(eventRegistrations.id, id));
}

// ============ DIRECT MESSAGES ============
export async function getDirectMessages(userId: number, otherUserId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(directMessages)
    .where(sql`(${directMessages.senderId} = ${userId} AND ${directMessages.receiverId} = ${otherUserId}) OR (${directMessages.senderId} = ${otherUserId} AND ${directMessages.receiverId} = ${userId})`)
    .orderBy(directMessages.createdAt);
}

export async function getUnreadMessageCount(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: count() }).from(directMessages)
    .where(and(eq(directMessages.receiverId, userId), eq(directMessages.isRead, false)));
  return result[0]?.count || 0;
}

export async function getUserConversations(userId: number) {
  const db = await getDb();
  if (!db) return [];
  // Get unique conversation partners
  const sent = await db.select({ partnerId: directMessages.receiverId }).from(directMessages)
    .where(eq(directMessages.senderId, userId));
  const received = await db.select({ partnerId: directMessages.senderId }).from(directMessages)
    .where(eq(directMessages.receiverId, userId));
  
  const partnerIds = Array.from(new Set([...sent.map(s => s.partnerId), ...received.map(r => r.partnerId)]));
  return partnerIds;
}

export async function createDirectMessage(data: InsertDirectMessage) {
  const db = await getDb();
  if (!db) return;
  await db.insert(directMessages).values(data);
}

export async function markMessagesAsRead(userId: number, senderId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(directMessages)
    .set({ isRead: true, readAt: new Date() })
    .where(and(eq(directMessages.receiverId, userId), eq(directMessages.senderId, senderId)));
}

// ============ NOTIFICATIONS ============
export async function getUserNotifications(userId: number, unreadOnly = false) {
  const db = await getDb();
  if (!db) return [];
  if (unreadOnly) {
    return db.select().from(notifications)
      .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)))
      .orderBy(desc(notifications.createdAt));
  }
  return db.select().from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt));
}

export async function createNotification(data: InsertNotification) {
  const db = await getDb();
  if (!db) return;
  await db.insert(notifications).values(data);
}

export async function markNotificationAsRead(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications).set({ isRead: true, readAt: new Date() }).where(eq(notifications.id, id));
}

export async function markAllNotificationsAsRead(userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications)
    .set({ isRead: true, readAt: new Date() })
    .where(eq(notifications.userId, userId));
}

// ============ AUDIT LOGS ============
export async function createAuditLog(data: InsertAuditLog) {
  const db = await getDb();
  if (!db) return;
  await db.insert(auditLogs).values(data);
}

export async function getAuditLogs(limit = 100, entityType?: string) {
  const db = await getDb();
  if (!db) return [];
  if (entityType) {
    return db.select().from(auditLogs)
      .where(eq(auditLogs.entityType, entityType))
      .orderBy(desc(auditLogs.createdAt))
      .limit(limit);
  }
  return db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(limit);
}

// ============ SYSTEM HEALTH LOGS ============
export async function createSystemHealthLog(data: InsertSystemHealthLog) {
  const db = await getDb();
  if (!db) return;
  await db.insert(systemHealthLogs).values(data);
}

export async function getSystemHealthLogs(limit = 100) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(systemHealthLogs).orderBy(desc(systemHealthLogs.createdAt)).limit(limit);
}

export async function getSystemHealthStats() {
  const db = await getDb();
  if (!db) return { totalRequests: 0, errorRate: 0, avgResponseTime: 0 };
  
  const stats = await db.select({
    totalRequests: count(),
    errorCount: sql<number>`SUM(CASE WHEN ${systemHealthLogs.statusCode} >= 400 THEN 1 ELSE 0 END)`,
    avgResponseTime: sql<number>`AVG(${systemHealthLogs.responseTime})`,
  }).from(systemHealthLogs);
  
  const result = stats[0];
  return {
    totalRequests: result?.totalRequests || 0,
    errorRate: result?.totalRequests ? ((result?.errorCount || 0) / result.totalRequests) * 100 : 0,
    avgResponseTime: result?.avgResponseTime || 0,
  };
}

// ============ RADAR NURTURE MESSAGES ============
export async function createNurtureSequence(leadId: number, leadData: { name: string; email: string; recommendedProduct?: string | null; scoreCX?: string | null; scoreData?: string | null; scoreIA?: string | null; scoreGovernance?: string | null; challenges?: string; challengeSegment?: string }) {
  const db = await getDb();
  if (!db) return;
  
  const now = new Date();
  
  // Import segment definitions for personalized nurture
  const { getSegmentById, getMatchingSegments, SEGMENTS } = await import("../shared/challengeSegments");
  type SegmentCategory = "dados" | "cx" | "ia" | "governanca" | "cultura";
  
  const primarySegment = leadData.challengeSegment ? getSegmentById(leadData.challengeSegment as SegmentCategory) : null;
  const allSegments = leadData.challenges ? getMatchingSegments(leadData.challenges) : [];
  
  // Step 1: Diagnosis (immediate) - same as before
  const messages: InsertRadarNurtureMessage[] = [
    {
      leadId,
      sequenceStep: 1,
      messageType: "diagnosis",
      subject: `${leadData.name}, seu diagnóstico Radar Vértice está pronto!`,
      content: `Olá ${leadData.name}! Seu diagnóstico do Radar Vértice foi concluído. Acesse o portal para ver seus resultados detalhados e recomendações personalizadas.`,
      scheduledAt: now,
    },
  ];
  
  // Step 2: Segmented content email (+2 days) - personalized by primary challenge segment
  if (primarySegment) {
    messages.push({
      leadId,
      sequenceStep: 2,
      messageType: "content",
      subject: primarySegment.nurtureSubject.replace(/\{\{name\}\}/g, leadData.name),
      content: primarySegment.nurtureContent.replace(/\{\{name\}\}/g, leadData.name),
      scheduledAt: new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000),
    });
  } else {
    messages.push({
      leadId,
      sequenceStep: 2,
      messageType: "content",
      subject: `Conteúdo exclusivo para você, ${leadData.name}`,
      content: `Olá ${leadData.name}! Baseado no seu diagnóstico, preparamos um conteúdo especial sobre as áreas que você pode melhorar. Confira!`,
      scheduledAt: new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000),
    });
  }
  
  // Step 3: Secondary segment content (+5 days) - if lead has multiple segments
  const secondarySegmentId = allSegments.length > 1 ? allSegments[1] : null;
  const secondarySegment = secondarySegmentId ? getSegmentById(secondarySegmentId) : null;
  if (secondarySegment) {
    messages.push({
      leadId,
      sequenceStep: 3,
      messageType: "content",
      subject: secondarySegment.nurtureSubject.replace(/\{\{name\}\}/g, leadData.name),
      content: secondarySegment.nurtureContent.replace(/\{\{name\}\}/g, leadData.name),
      scheduledAt: new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000),
    });
  } else {
    messages.push({
      leadId,
      sequenceStep: 3,
      messageType: "invite",
      subject: `Convite especial: Sessão diagnóstica gratuita`,
      content: `${leadData.name}, gostaria de convidá-lo para uma sessão diagnóstica gratuita de 30 minutos. Vamos conversar sobre como acelerar sua transformação digital.`,
      scheduledAt: new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000),
    });
  }
  
  // Step 4: Social proof (+8 days)
  messages.push({
    leadId,
    sequenceStep: 4,
    messageType: "social_proof",
    subject: `Como empresas como a sua estão transformando resultados`,
    content: `Veja como outros profissionais e empresas alcançaram resultados expressivos com o Protocolo Vértice.`,
    scheduledAt: new Date(now.getTime() + 8 * 24 * 60 * 60 * 1000),
  });
  
  // Step 5: Offer (+12 days)
  messages.push({
    leadId,
    sequenceStep: 5,
    messageType: "offer",
    subject: `Oferta especial: ${leadData.recommendedProduct || 'Mentoria Vértice'}`,
    content: `${leadData.name}, preparamos uma condição especial para você iniciar sua jornada de transformação. Válido por tempo limitado!`,
    scheduledAt: new Date(now.getTime() + 12 * 24 * 60 * 60 * 1000),
  });
  
  for (const msg of messages) {
    await db.insert(radarNurtureMessages).values(msg);
  }
}

export async function getNurtureMessages(leadId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(radarNurtureMessages)
    .where(eq(radarNurtureMessages.leadId, leadId))
    .orderBy(radarNurtureMessages.sequenceStep);
}

export async function getPendingNurtureMessages() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(radarNurtureMessages)
    .where(and(
      eq(radarNurtureMessages.status, "scheduled"),
      sql`${radarNurtureMessages.scheduledAt} <= NOW()`
    ))
    .orderBy(radarNurtureMessages.scheduledAt);
}

export async function updateNurtureMessage(id: number, data: Partial<InsertRadarNurtureMessage>) {
  const db = await getDb();
  if (!db) return;
  await db.update(radarNurtureMessages).set(data).where(eq(radarNurtureMessages.id, id));
}

// ============ AUTOMATIC BADGE CHECKING ============
export interface AwardedBadge {
  id: number;
  slug: string;
  name: string;
  description: string | null;
  iconUrl: string | null;
  category: string;
  pointsReward: number;
}

export async function checkAndAwardBadges(userId: number): Promise<AwardedBadge[]> {
  const db = await getDb();
  if (!db) return [];
  
  const awardedBadges: AwardedBadge[] = [];
  
  // Get user's current progress
  const userProgressList = await db.select().from(userProgress).where(eq(userProgress.userId, userId));
  const completedCount = userProgressList.filter(p => p.completed).length;
  const completedContentIds = userProgressList.filter(p => p.completed).map(p => p.contentId);
  
  // Get all contents to check categories
  const allContents = await db.select().from(contents);
  const completedContents = allContents.filter(c => completedContentIds.includes(c.id));
  
  // Count by category
  const categoryProgress: Record<string, { completed: number; total: number }> = {
    introducao: { completed: 0, total: 0 },
    cx: { completed: 0, total: 0 },
    dados: { completed: 0, total: 0 },
    ia: { completed: 0, total: 0 },
  };
  
  allContents.forEach(content => {
    const cat = content.category || 'introducao';
    if (categoryProgress[cat]) {
      categoryProgress[cat].total++;
      if (completedContentIds.includes(content.id)) {
        categoryProgress[cat].completed++;
      }
    }
  });
  
  // Get user's existing badges
  const existingBadges = await db.select().from(userBadges).where(eq(userBadges.userId, userId));
  const existingBadgeIds = existingBadges.map(b => b.badgeId);
  
  // Get all available badges
  const allBadges = await db.select().from(badges).where(eq(badges.isActive, true));
  
  // Check each badge
  for (const badge of allBadges) {
    // Skip if already has this badge
    if (existingBadgeIds.includes(badge.id)) continue;
    
    let shouldAward = false;
    const req = badge.requirement as { type: string; value: number; target?: string } | null;
    
    if (req) {
      switch (req.type) {
        case 'content_count':
          // Badges for completing X contents
          shouldAward = completedCount >= req.value;
          break;
          
        case 'category_complete':
          // Badges for completing all contents in a category
          if (req.target && categoryProgress[req.target]) {
            const cat = categoryProgress[req.target];
            shouldAward = cat.total > 0 && cat.completed >= cat.total;
          }
          break;
          
        case 'all_content':
          // Badge for completing all content
          shouldAward = allContents.length > 0 && completedCount >= allContents.length;
          break;
          
        case 'radar_complete':
          // Badge for completing Radar Vértice (check radarLeads table)
          const radarResults = await db.select().from(radarLeads)
            .where(eq(radarLeads.userId, userId)).limit(1);
          shouldAward = radarResults.length > 0;
          break;
          
        case 'quiz_complete':
          // Badge for completing first quiz
          const quizResults = await db.select().from(quizAttempts)
            .where(eq(quizAttempts.userId, userId)).limit(1);
          shouldAward = quizResults.length > 0;
          break;
          
        case 'quiz_perfect':
          // Badge for getting 100% on a quiz
          const perfectQuiz = await db.select().from(quizAttempts)
            .where(and(eq(quizAttempts.userId, userId), eq(quizAttempts.score, 100))).limit(1);
          shouldAward = perfectQuiz.length > 0;
          break;
          
        case 'early_adopter':
          // Badge for being one of the first users
          const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
          if (user[0]) {
            const userCount = await db.select({ count: count() }).from(users)
              .where(sql`${users.createdAt} <= ${user[0].createdAt}`);
            shouldAward = (userCount[0]?.count || 0) <= req.value;
          }
          break;
          
        case 'points_total':
          // Badge for reaching X total points
          const userPointsRecord = await db.select().from(userPoints)
            .where(eq(userPoints.userId, userId)).limit(1);
          shouldAward = (userPointsRecord[0]?.totalPointsEarned || 0) >= req.value;
          break;
      }
    }
    
    if (shouldAward) {
      // Award the badge
      await db.insert(userBadges).values({ userId, badgeId: badge.id });
      
      // Award points for badge
      if (badge.pointsReward > 0) {
        await createOrUpdateUserPoints(userId, badge.pointsReward, `Badge: ${badge.name}`, "badge", badge.id);
      }
      
      awardedBadges.push({
        id: badge.id,
        slug: badge.slug,
        name: badge.name,
        description: badge.description,
        iconUrl: badge.iconUrl,
        category: badge.category,
        pointsReward: badge.pointsReward,
      });
    }
  }
  
  return awardedBadges;
}

// Get badge by slug
export async function getBadgeBySlug(slug: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(badges).where(eq(badges.slug, slug)).limit(1);
  return result.length > 0 ? result[0] : null;
}


// ============ CATEGORY CERTIFICATES ============

export async function getCertificateByUserAndCategory(userId: number, category: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(certificates)
    .where(and(
      eq(certificates.userId, userId), 
      eq(certificates.category, category as any),
      eq(certificates.type, "category")
    ))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createCategoryCertificate(userId: number, category: string) {
  const db = await getDb();
  if (!db) return null;
  
  // Check if already has certificate for this category
  const existing = await getCertificateByUserAndCategory(userId, category);
  if (existing) return existing;
  
  const certificateNumber = await generateCertificateNumber();
  const verificationCode = await generateVerificationCode();
  
  const newCertificate: InsertCertificate = {
    userId,
    category: category as any,
    type: "category",
    certificateNumber,
    completionDate: new Date(),
    verificationCode,
  };
  
  await db.insert(certificates).values(newCertificate);
  
  // Get the created certificate
  const result = await db.select().from(certificates)
    .where(eq(certificates.verificationCode, verificationCode))
    .limit(1);
  
  return result.length > 0 ? result[0] : null;
}

export interface CategoryProgress {
  category: string;
  completed: number;
  total: number;
  isComplete: boolean;
}

export async function checkCategoryCompletion(userId: number): Promise<{ 
  completedCategories: string[];
  progress: CategoryProgress[];
}> {
  const db = await getDb();
  if (!db) return { completedCategories: [], progress: [] };
  
  // Get user's completed contents
  const userProgressList = await db.select().from(userProgress)
    .where(and(eq(userProgress.userId, userId), eq(userProgress.completed, true)));
  const completedContentIds = userProgressList.map(p => p.contentId);
  
  // Get all contents
  const allContents = await db.select().from(contents);
  
  // Calculate progress by category
  const categoryProgress: Record<string, { completed: number; total: number }> = {
    introducao: { completed: 0, total: 0 },
    cx: { completed: 0, total: 0 },
    dados: { completed: 0, total: 0 },
    ia: { completed: 0, total: 0 },
  };
  
  allContents.forEach(content => {
    const cat = content.category || 'introducao';
    if (categoryProgress[cat]) {
      categoryProgress[cat].total++;
      if (completedContentIds.includes(content.id)) {
        categoryProgress[cat].completed++;
      }
    }
  });
  
  const completedCategories: string[] = [];
  const progress: CategoryProgress[] = [];
  
  for (const [category, stats] of Object.entries(categoryProgress)) {
    const isComplete = stats.total > 0 && stats.completed >= stats.total;
    progress.push({
      category,
      completed: stats.completed,
      total: stats.total,
      isComplete,
    });
    if (isComplete) {
      completedCategories.push(category);
    }
  }
  
  return { completedCategories, progress };
}

export interface NewCertificate {
  id: number;
  category: string;
  certificateNumber: string;
  verificationCode: string;
  completionDate: Date;
}

export async function checkAndAwardCertificates(userId: number): Promise<NewCertificate[]> {
  const db = await getDb();
  if (!db) return [];
  
  const { completedCategories } = await checkCategoryCompletion(userId);
  const newCertificates: NewCertificate[] = [];
  
  for (const category of completedCategories) {
    // Check if already has certificate
    const existing = await getCertificateByUserAndCategory(userId, category);
    if (!existing) {
      const cert = await createCategoryCertificate(userId, category);
      if (cert) {
        newCertificates.push({
          id: cert.id,
          category: cert.category || category,
          certificateNumber: cert.certificateNumber,
          verificationCode: cert.verificationCode,
          completionDate: cert.completionDate,
        });
        
        // Award points for certificate
        await createOrUpdateUserPoints(userId, 100, `Certificado: ${getCategoryDisplayName(category)}`, "certificate", cert.id);
        
        // Auto-generate PDF and send email
        try {
          const { generateCertificatePDF, buildCertificateData } = await import("./certificateGenerator");
          const { sendCertificateEmail } = await import("./emailService");
          
          const user = await getUserById(userId);
          const userName = user?.name || "Aluno";
          const categoryName = getCategoryDisplayName(category);
          
          const certData = buildCertificateData(userName, cert);
          const { url: pdfUrl } = await generateCertificatePDF(certData);
          
          // Save PDF URL to database
          await updateCertificatePdfUrl(cert.id, pdfUrl);
          
          // Send email notification
          if (user?.email) {
            const portalUrl = process.env.VITE_APP_URL || "https://datacx-mentoria.manus.space";
            await sendCertificateEmail(
              user.email,
              userName,
              categoryName,
              cert.certificateNumber,
              cert.verificationCode,
              pdfUrl,
              portalUrl
            );
          }
          
          console.log(`[Certificate] Auto-generated PDF for cert #${cert.id} (${category}) - ${pdfUrl}`);
        } catch (pdfError) {
          console.error(`[Certificate] Failed to auto-generate PDF for cert #${cert.id}:`, pdfError);
          // Certificate is still created, PDF can be generated on demand
        }
      }
    }
  }
  
   // ─── Check for General Certificate (all 4 categories completed) ───
  const ALL_CATEGORIES = ["introducao", "cx", "dados", "ia"];
  const { completedCategories: allCompleted } = await checkCategoryCompletion(userId);
  const hasAllFour = ALL_CATEGORIES.every(cat => allCompleted.includes(cat));
  
  if (hasAllFour) {
    const existingGeneral = await getGeneralCertificate(userId);
    if (!existingGeneral) {
      const generalCert = await createGeneralCertificate(userId);
      if (generalCert) {
        newCertificates.push({
          id: generalCert.id,
          category: "general",
          certificateNumber: generalCert.certificateNumber,
          verificationCode: generalCert.verificationCode,
          completionDate: generalCert.completionDate,
        });
        
        // Award bonus points for general certificate
        await createOrUpdateUserPoints(userId, 500, "Certificado: Protocolo Vértice Completo", "certificate", generalCert.id);
        
        // Auto-generate premium PDF and send special email
        try {
          const { generateGeneralCertificatePDF, buildGeneralCertificateData } = await import("./certificateGenerator");
          const { sendGeneralCertificateEmail } = await import("./emailService");
          
          const user = await getUserById(userId);
          const userName = user?.name || "Aluno";
          
          const certData = buildGeneralCertificateData(userName, generalCert);
          const { url: pdfUrl } = await generateGeneralCertificatePDF(certData);
          
          await updateCertificatePdfUrl(generalCert.id, pdfUrl);
          
          if (user?.email) {
            const portalUrl = process.env.VITE_APP_URL || "https://datacx-mentoria.manus.space";
            await sendGeneralCertificateEmail(
              user.email,
              userName,
              generalCert.certificateNumber,
              generalCert.verificationCode,
              pdfUrl,
              portalUrl
            );
          }
          
          console.log(`[Certificate] 🌟 General certificate generated for user #${userId} - ${pdfUrl}`);
        } catch (pdfError) {
          console.error(`[Certificate] Failed to generate general certificate PDF:`, pdfError);
        }
      }
    }
  }
  
  return newCertificates;
}

export async function getGeneralCertificate(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(certificates)
    .where(and(
      eq(certificates.userId, userId),
      eq(certificates.type, "general")
    ))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createGeneralCertificate(userId: number) {
  const db = await getDb();
  if (!db) return null;
  
  // Check if already exists
  const existing = await getGeneralCertificate(userId);
  if (existing) return existing;
  
  const certificateNumber = await generateCertificateNumber();
  const verificationCode = await generateVerificationCode();
  
  const newCertificate: InsertCertificate = {
    userId,
    category: null as any,
    type: "general",
    certificateNumber: `PV-${certificateNumber}`, // PV prefix for Protocolo Vértice
    completionDate: new Date(),
    verificationCode,
  };
  
  await db.insert(certificates).values(newCertificate);
  
  const result = await db.select().from(certificates)
    .where(eq(certificates.verificationCode, verificationCode))
    .limit(1);
  
  return result.length > 0 ? result[0] : null;
}

function getCategoryDisplayName(category: string): string {
  const names: Record<string, string> = {
    introducao: "Introdução",
    cx: "Customer Experience (CX)",
    dados: "Dados",
    ia: "Inteligência Artificial (IA)",
    general: "Protocolo Vértice — Formação Completa",
  };
  return names[category] || category;
}


// ============ V2 - TRAILS & MODULE ACCESS ============

export async function getTrails() {
  const db = await getDb();
  if (!db) return [];
  
  const allContents = await db.select().from(contents).orderBy(contents.sortOrder);
  
  const pilars = ['INTRO', 'CX', 'DADOS', 'IA'];
  const pilarNames: Record<string, string> = {
    'INTRO': 'Introdução ao Protocolo Vértice',
    'CX': 'Customer Experience',
    'DADOS': 'Dados & Analytics',
    'IA': 'Inteligência Artificial',
  };
  const pilarDescriptions: Record<string, string> = {
    'INTRO': 'Fundamentos do Protocolo Vértice e conceitos essenciais para sua jornada',
    'CX': 'Estratégias e práticas para transformar a experiência do cliente',
    'DADOS': 'Análise de dados, métricas e tomada de decisão baseada em evidências',
    'IA': 'Inteligência artificial aplicada a negócios e experiência do cliente',
  };
  const pilarColors: Record<string, string> = {
    'INTRO': '#3B82F6',
    'CX': '#10B981',
    'DADOS': '#8B5CF6',
    'IA': '#F59E0B',
  };
  
  return pilars.map(pilar => {
    const modules = allContents.filter(c => c.pilar === pilar);
    return {
      pilar,
      name: pilarNames[pilar] || pilar,
      description: pilarDescriptions[pilar] || '',
      color: pilarColors[pilar] || '#6B7280',
      moduleCount: modules.length,
      modules,
    };
  });
}

export async function getModulesByPilar(pilar: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(contents)
    .where(eq(contents.pilar, pilar))
    .orderBy(contents.sortOrder);
}

export async function getModuleByCode(moduleCode: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(contents)
    .where(eq(contents.moduleCode, moduleCode))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function searchModules(query: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(contents)
    .where(sql`${contents.title} LIKE ${`%${query}%`} OR ${contents.description} LIKE ${`%${query}%`} OR ${contents.moduleCode} LIKE ${`%${query}%`}`)
    .orderBy(contents.sortOrder);
}

export async function getUserProgressForModules(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(userProgress)
    .where(eq(userProgress.userId, userId));
}

export async function getRecentlyViewedModules(userId: number, limit = 5) {
  const db = await getDb();
  if (!db) return [];
  
  const progress = await db.select().from(userProgress)
    .where(eq(userProgress.userId, userId))
    .orderBy(desc(userProgress.createdAt))
    .limit(limit);
  
  if (progress.length === 0) return [];
  
  const contentIds = progress.map(p => p.contentId);
  const modules = await db.select().from(contents)
    .where(sql`${contents.id} IN (${sql.join(contentIds.map(id => sql`${id}`), sql`, `)})`);
  
  // Return in order of most recently viewed
  return contentIds.map(id => modules.find(m => m.id === id)).filter(Boolean);
}

export async function getAccessibleModuleCodes(planSlug: string) {
  const db = await getDb();
  if (!db) return [];
  const result = await db.select({ moduleCode: planModuleAccess.moduleCode })
    .from(planModuleAccess)
    .where(eq(planModuleAccess.planSlug, planSlug));
  return result.map(r => r.moduleCode);
}

export async function getUserActivePlanSlugs(userId: number): Promise<string[]> {
  const db = await getDb();
  if (!db) return [];
  
  const activeEnrollments = await db.select().from(enrollments)
    .where(and(
      eq(enrollments.userId, userId),
      eq(enrollments.status, "active")
    ));
  
  if (activeEnrollments.length === 0) return [];
  
  const programIds = activeEnrollments.map(e => e.programId);
  const programs = await db.select().from(mentorshipPrograms)
    .where(inArray(mentorshipPrograms.id, programIds));
  
  return programs.map(p => p.slug);
}

// Backward compat
export async function getUserActivePlanSlug(userId: number): Promise<string | null> {
  const slugs = await getUserActivePlanSlugs(userId);
  return slugs.length > 0 ? slugs[0] : null;
}

export async function getUserAccessibleModuleCodes(userId: number): Promise<string[]> {
  const db = await getDb();
  if (!db) return [];
  
  // Admin gets all
  const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (user[0]?.role === 'admin') {
    const allModules = await db.select({ moduleCode: contents.moduleCode }).from(contents);
    return allModules.map(m => m.moduleCode).filter(Boolean) as string[];
  }
  
  // Get plan-based access
  const planSlugs = await getUserActivePlanSlugs(userId);
  let planModules: string[] = [];
  if (planSlugs.length > 0) {
    const accessRows = await db.select().from(planModuleAccess)
      .where(inArray(planModuleAccess.planSlug, planSlugs));
    planModules = accessRows.map(r => r.moduleCode);
  }
  
  // Get admin overrides (grant/revoke)
  const overrides = await db.select().from(userModuleOverrides)
    .where(eq(userModuleOverrides.userId, userId));
  
  const now = new Date();
  const grantedCodes = new Set<string>();
  const revokedCodes = new Set<string>();
  
  for (const o of overrides) {
    // Skip expired overrides
    if (o.expiresAt && o.expiresAt < now) continue;
    if (o.action === 'grant') grantedCodes.add(o.moduleCode);
    if (o.action === 'revoke') revokedCodes.add(o.moduleCode);
  }
  
  // Combine: plan modules + grants - revokes
  const allCodes = new Set([...planModules, ...Array.from(grantedCodes)]);
  for (const code of Array.from(revokedCodes)) allCodes.delete(code);
  
  return Array.from(allCodes);
}

export async function checkModuleAccess(userId: number, moduleCode: string): Promise<boolean> {
  const accessibleCodes = await getUserAccessibleModuleCodes(userId);
  return accessibleCodes.includes(moduleCode);
}

// Admin functions for managing user access overrides
export async function getUserOverrides(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(userModuleOverrides)
    .where(eq(userModuleOverrides.userId, userId));
}

export async function setUserModuleOverride(data: {
  userId: number;
  moduleCode: string;
  action: 'grant' | 'revoke';
  reason?: string;
  grantedBy?: number;
  expiresAt?: Date;
}) {
  const db = await getDb();
  if (!db) return null;
  
  // Remove existing override for this user+module
  await db.delete(userModuleOverrides).where(and(
    eq(userModuleOverrides.userId, data.userId),
    eq(userModuleOverrides.moduleCode, data.moduleCode)
  ));
  
  // Insert new override
  const result = await db.insert(userModuleOverrides).values({
    userId: data.userId,
    moduleCode: data.moduleCode,
    action: data.action,
    reason: data.reason || null,
    grantedBy: data.grantedBy || null,
    expiresAt: data.expiresAt || null,
  });
  return result;
}

export async function removeUserModuleOverride(userId: number, moduleCode: string) {
  const db = await getDb();
  if (!db) return;
  await db.delete(userModuleOverrides).where(and(
    eq(userModuleOverrides.userId, userId),
    eq(userModuleOverrides.moduleCode, moduleCode)
  ));
}

export async function getUserAccessDetails(userId: number) {
  const db = await getDb();
  if (!db) return { planSlugs: [], planModules: [], overrides: [], effectiveModules: [] };
  
  const planSlugs = await getUserActivePlanSlugs(userId);
  let planModules: string[] = [];
  if (planSlugs.length > 0) {
    const accessRows = await db.select().from(planModuleAccess)
      .where(inArray(planModuleAccess.planSlug, planSlugs));
    planModules = accessRows.map(r => r.moduleCode);
  }
  
  const overrides = await db.select().from(userModuleOverrides)
    .where(eq(userModuleOverrides.userId, userId));
  
  const effectiveModules = await getUserAccessibleModuleCodes(userId);
  
  return { planSlugs, planModules, overrides, effectiveModules };
}

export async function getAllModulesWithProgress(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const allModules = await db.select().from(contents).orderBy(contents.sortOrder);
  const progress = await db.select().from(userProgress)
    .where(eq(userProgress.userId, userId));
  
  const progressMap = new Map(progress.map(p => [p.contentId, p]));
  
  const now = new Date();
  return allModules.map(mod => ({
    ...mod,
    isCompleted: progressMap.get(mod.id)?.completed || false,
    completedAt: progressMap.get(mod.id)?.completedAt || null,
    isReleased: !mod.releaseDate || mod.releaseDate <= now,
    releaseDate: mod.releaseDate || null,
  }));
}

// Get quiz by moduleCode
export async function getQuizByModuleCode(moduleCode: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(quizzes)
    .where(eq(quizzes.moduleCode, moduleCode))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

// Get random questions for a quiz attempt
export async function getRandomQuizQuestions(quizId: number, count: number = 10) {
  const db = await getDb();
  if (!db) return [];
  const allQuestions = await db.select().from(quizQuestions)
    .where(eq(quizQuestions.quizId, quizId));
  
  // Shuffle and take count
  const shuffled = allQuestions.sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}



// ─── Content Persona Versions ───

export async function getPersonaVersion(contentId: number, persona: string) {
  const db = await getDb();
  if (!db) return null;
  const [row] = await db.select().from(contentPersonaVersions)
    .where(and(
      eq(contentPersonaVersions.contentId, contentId),
      eq(contentPersonaVersions.persona, persona as any)
    ))
    .limit(1);
  return row || null;
}

export async function getPersonaVersionsByContent(contentId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(contentPersonaVersions)
    .where(eq(contentPersonaVersions.contentId, contentId));
}

export async function upsertPersonaVersion(data: {
  contentId: number;
  persona: string;
  apostilaMarkdown?: string | null;
  audioUrl?: string | null;
  audioDurationSeconds?: number | null;
  audioScriptAdmin?: string | null;
  apostilaStatus?: string;
  audioStatus?: string;
  generatedAt?: Date | null;
}) {
  const db = await getDb();
  if (!db) return null;
  
  const existing = await getPersonaVersion(data.contentId, data.persona);
  
  if (existing) {
    await db.update(contentPersonaVersions)
      .set({
        ...(data.apostilaMarkdown !== undefined && { apostilaMarkdown: data.apostilaMarkdown }),
        ...(data.audioUrl !== undefined && { audioUrl: data.audioUrl }),
        ...(data.audioDurationSeconds !== undefined && { audioDurationSeconds: data.audioDurationSeconds }),
        ...(data.audioScriptAdmin !== undefined && { audioScriptAdmin: data.audioScriptAdmin }),
        ...(data.apostilaStatus !== undefined && { apostilaStatus: data.apostilaStatus as any }),
        ...(data.audioStatus !== undefined && { audioStatus: data.audioStatus as any }),
        ...(data.generatedAt !== undefined && { generatedAt: data.generatedAt }),
      })
      .where(eq(contentPersonaVersions.id, existing.id));
    return { ...existing, ...data };
  } else {
    const [result] = await db.insert(contentPersonaVersions).values({
      contentId: data.contentId,
      persona: data.persona as any,
      apostilaMarkdown: data.apostilaMarkdown || null,
      audioUrl: data.audioUrl || null,
      audioDurationSeconds: data.audioDurationSeconds || null,
      audioScriptAdmin: data.audioScriptAdmin || null,
      apostilaStatus: (data.apostilaStatus || "pending") as any,
      audioStatus: (data.audioStatus || "pending") as any,
      generatedAt: data.generatedAt || null,
    });
    return { id: result.insertId, ...data };
  }
}

export async function getAllPersonaVersionsStatus() {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    contentId: contentPersonaVersions.contentId,
    persona: contentPersonaVersions.persona,
    apostilaStatus: contentPersonaVersions.apostilaStatus,
    audioStatus: contentPersonaVersions.audioStatus,
    audioUrl: contentPersonaVersions.audioUrl,
  }).from(contentPersonaVersions);
}

export async function getContentWithPersona(contentId: number, persona: string) {
  const db = await getDb();
  if (!db) return null;
  
  const [content] = await db.select().from(contents)
    .where(eq(contents.id, contentId))
    .limit(1);
  
  if (!content) return null;
  
  const version = await getPersonaVersion(contentId, persona);
  
  return {
    ...content,
    personaVersion: version,
  };
}


// Get user's persona from radar (most recent)
export async function getUserPersonaFromRadar(userId: number): Promise<string | null> {
  const db = await getDb();
  if (!db) return null;
  const [result] = await db.select({ persona: radarLeads.persona })
    .from(radarLeads)
    .where(eq(radarLeads.userId, userId))
    .orderBy(desc(radarLeads.createdAt))
    .limit(1);
  return result?.persona || null;
}


// ============ ADMIN ADVANCED METRICS ============

/**
 * Enhanced dashboard metrics with trends (7-day comparison)
 */
export async function getEnhancedDashboardMetrics() {
  const db = await getDb();
  if (!db) return null;

  const now = new Date();
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const fourteenDaysAgo = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);

  // Current period (last 7 days)
  const [newUsersThisWeek] = await db.select({ count: count() }).from(users)
    .where(gte(users.createdAt, sevenDaysAgo));
  const [newUsersPrevWeek] = await db.select({ count: count() }).from(users)
    .where(and(gte(users.createdAt, fourteenDaysAgo), lt(users.createdAt, sevenDaysAgo)));

  const [newEnrollmentsThisWeek] = await db.select({ count: count() }).from(enrollments)
    .where(gte(enrollments.createdAt, sevenDaysAgo));
  const [newEnrollmentsPrevWeek] = await db.select({ count: count() }).from(enrollments)
    .where(and(gte(enrollments.createdAt, fourteenDaysAgo), lt(enrollments.createdAt, sevenDaysAgo)));

  // Chat messages (engagement proxy)
  const [chatThisWeek] = await db.select({ count: count() }).from(moduleChats)
    .where(gte(moduleChats.createdAt, sevenDaysAgo));
  const [chatPrevWeek] = await db.select({ count: count() }).from(moduleChats)
    .where(and(gte(moduleChats.createdAt, fourteenDaysAgo), lt(moduleChats.createdAt, sevenDaysAgo)));

  // Quiz attempts this week
  const [quizThisWeek] = await db.select({ count: count() }).from(quizAttempts)
    .where(gte(quizAttempts.completedAt, sevenDaysAgo));
  const [quizPrevWeek] = await db.select({ count: count() }).from(quizAttempts)
    .where(and(gte(quizAttempts.completedAt, fourteenDaysAgo), lt(quizAttempts.completedAt, sevenDaysAgo)));

  // Completions this week
  const [completionsThisWeek] = await db.select({ count: count() }).from(userProgress)
    .where(and(eq(userProgress.completed, true), gte(userProgress.createdAt, sevenDaysAgo)));
  const [completionsPrevWeek] = await db.select({ count: count() }).from(userProgress)
    .where(and(eq(userProgress.completed, true), gte(userProgress.createdAt, fourteenDaysAgo), lt(userProgress.createdAt, sevenDaysAgo)));

  // Total modules
  const [totalModules] = await db.select({ count: count() }).from(contents)
    .where(eq(contents.type, 'module'));

  // Total feedback
  const [feedbackStats] = await db.select({
    count: count(),
    avgRating: sql<number>`AVG(${chatFeedback.rating})`,
  }).from(chatFeedback);

  return {
    newUsersThisWeek: newUsersThisWeek?.count || 0,
    newUsersPrevWeek: newUsersPrevWeek?.count || 0,
    newEnrollmentsThisWeek: newEnrollmentsThisWeek?.count || 0,
    newEnrollmentsPrevWeek: newEnrollmentsPrevWeek?.count || 0,
    chatMessagesThisWeek: chatThisWeek?.count || 0,
    chatMessagesPrevWeek: chatPrevWeek?.count || 0,
    quizAttemptsThisWeek: quizThisWeek?.count || 0,
    quizAttemptsPrevWeek: quizPrevWeek?.count || 0,
    completionsThisWeek: completionsThisWeek?.count || 0,
    completionsPrevWeek: completionsPrevWeek?.count || 0,
    totalModules: totalModules?.count || 0,
    totalFeedback: feedbackStats?.count || 0,
    avgFeedbackRating: Math.round((feedbackStats?.avgRating || 0) * 10) / 10,
  };
}

/**
 * Feedback analytics for admin - feedbacks with module info
 */
export async function getAdminFeedbackList(options?: { minRating?: number; maxRating?: number; limit?: number }) {
  const db = await getDb();
  if (!db) return [];

  const limit = options?.limit || 100;
  
  const results = await db.select({
    id: chatFeedback.id,
    rating: chatFeedback.rating,
    comment: chatFeedback.comment,
    createdAt: chatFeedback.createdAt,
    userName: users.name,
    userEmail: users.email,
    contentId: chatFeedback.contentId,
    contentTitle: contents.title,
    moduleCode: contents.moduleCode,
    category: contents.category,
  })
    .from(chatFeedback)
    .leftJoin(users, eq(chatFeedback.userId, users.id))
    .leftJoin(contents, eq(chatFeedback.contentId, contents.id))
    .orderBy(desc(chatFeedback.createdAt))
    .limit(limit);

  return results;
}

/**
 * Feedback stats per module for admin
 */
export async function getFeedbackStatsByModule() {
  const db = await getDb();
  if (!db) return [];

  const results = await db.select({
    contentId: chatFeedback.contentId,
    contentTitle: contents.title,
    moduleCode: contents.moduleCode,
    category: contents.category,
    totalFeedback: count(),
    avgRating: sql<number>`ROUND(AVG(${chatFeedback.rating}), 1)`,
    totalComments: sql<number>`SUM(CASE WHEN ${chatFeedback.comment} IS NOT NULL AND ${chatFeedback.comment} != '' THEN 1 ELSE 0 END)`,
  })
    .from(chatFeedback)
    .leftJoin(contents, eq(chatFeedback.contentId, contents.id))
    .groupBy(chatFeedback.contentId, contents.title, contents.moduleCode, contents.category)
    .orderBy(sql`AVG(${chatFeedback.rating}) ASC`);

  return results;
}

/**
 * Student progress overview for admin
 */
export async function getStudentProgressOverview() {
  const db = await getDb();
  if (!db) return [];

  // Get all users with their progress stats
  const results = await db.select({
    userId: users.id,
    userName: users.name,
    userEmail: users.email,
    company: users.company,
    lastSignedIn: users.lastSignedIn,
    createdAt: users.createdAt,
    totalCompleted: sql<number>`(SELECT COUNT(*) FROM user_progress WHERE user_progress.userId = ${users.id} AND user_progress.completed = 1)`,
    totalChatMessages: sql<number>`(SELECT COUNT(*) FROM module_chats WHERE module_chats.userId = ${users.id})`,
    totalQuizAttempts: sql<number>`(SELECT COUNT(*) FROM quiz_attempts WHERE quiz_attempts.userId = ${users.id})`,
    avgQuizScore: sql<number>`(SELECT ROUND(AVG(score), 1) FROM quiz_attempts WHERE quiz_attempts.userId = ${users.id})`,
    lastActivity: sql<Date>`GREATEST(
      COALESCE((SELECT MAX(createdAt) FROM user_progress WHERE user_progress.userId = ${users.id}), '2000-01-01'),
      COALESCE((SELECT MAX(createdAt) FROM module_chats WHERE module_chats.userId = ${users.id}), '2000-01-01'),
      COALESCE((SELECT MAX(createdAt) FROM quiz_attempts WHERE quiz_attempts.userId = ${users.id}), '2000-01-01')
    )`,
  })
    .from(users)
    .where(eq(users.role, 'user'))
    .orderBy(desc(users.lastSignedIn));

  return results;
}

/**
 * Module engagement metrics for admin
 */
export async function getModuleEngagementMetrics() {
  const db = await getDb();
  if (!db) return [];

  const results = await db.select({
    contentId: contents.id,
    title: contents.title,
    moduleCode: contents.moduleCode,
    category: contents.category,
    nivel: contents.nivel,
    totalCompletions: sql<number>`(SELECT COUNT(*) FROM user_progress WHERE user_progress.contentId = ${contents.id} AND user_progress.completed = 1)`,
    totalChatMessages: sql<number>`(SELECT COUNT(*) FROM module_chats WHERE module_chats.contentId = ${contents.id})`,
    uniqueChatUsers: sql<number>`(SELECT COUNT(DISTINCT userId) FROM module_chats WHERE module_chats.contentId = ${contents.id})`,
    totalFeedback: sql<number>`(SELECT COUNT(*) FROM chat_feedback WHERE chat_feedback.contentId = ${contents.id})`,
    avgFeedbackRating: sql<number>`(SELECT ROUND(AVG(rating), 1) FROM chat_feedback WHERE chat_feedback.contentId = ${contents.id})`,
    hasApostila: sql<number>`(SELECT COUNT(*) FROM content_persona_versions WHERE content_persona_versions.contentId = ${contents.id} AND content_persona_versions.apostilaStatus = 'ready')`,
    hasAudio: sql<number>`(SELECT COUNT(*) FROM content_persona_versions WHERE content_persona_versions.contentId = ${contents.id} AND content_persona_versions.audioStatus = 'ready')`,
  })
    .from(contents)
    .where(eq(contents.type, 'module'))
    .orderBy(contents.category, contents.sortOrder);

  return results;
}

/**
 * Quiz performance metrics for admin
 */
export async function getQuizPerformanceMetrics() {
  const db = await getDb();
  if (!db) return [];

  const results = await db.select({
    quizId: quizzes.id,
    quizTitle: quizzes.title,
    contentId: quizzes.contentId,
    moduleCode: contents.moduleCode,
    category: contents.category,
    totalAttempts: sql<number>`(SELECT COUNT(*) FROM quiz_attempts WHERE quiz_attempts.quizId = ${quizzes.id})`,
    passCount: sql<number>`(SELECT COUNT(*) FROM quiz_attempts WHERE quiz_attempts.quizId = ${quizzes.id} AND quiz_attempts.passed = 1)`,
    avgScore: sql<number>`(SELECT ROUND(AVG(score), 1) FROM quiz_attempts WHERE quiz_attempts.quizId = ${quizzes.id})`,
    uniqueUsers: sql<number>`(SELECT COUNT(DISTINCT userId) FROM quiz_attempts WHERE quiz_attempts.quizId = ${quizzes.id})`,
  })
    .from(quizzes)
    .leftJoin(contents, eq(quizzes.contentId, contents.id))
    .orderBy(contents.category, contents.sortOrder);

  return results;
}


// ===== Radar History Functions =====

/**
 * Get radar history for a user (ordered by newest first)
 */
export async function getRadarHistoryByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const results = await db.select({
    id: radarLeads.id,
    name: radarLeads.name,
    email: radarLeads.email,
    persona: radarLeads.persona,
    sector: radarLeads.sector,
    scoreCX: radarLeads.scoreCX,
    scoreData: radarLeads.scoreData,
    scoreIA: radarLeads.scoreIA,
    scoreGovernance: radarLeads.scoreGovernance,
    scoreTotal: radarLeads.scoreTotal,
    recommendedLevel: radarLeads.recommendedLevel,
    recommendedProduct: radarLeads.recommendedProduct,
    aiAnalysis: radarLeads.aiAnalysis,
    answers: radarLeads.answers,
    challenges: radarLeads.challenges,
    createdAt: radarLeads.createdAt,
  })
    .from(radarLeads)
    .where(eq(radarLeads.userId, userId))
    .orderBy(sql`${radarLeads.createdAt} DESC`);
  return results;
}

/**
 * Save AI analysis to a radar lead
 */
export async function saveRadarAiAnalysis(leadId: number, analysis: string) {
  const db = await getDb();
  if (!db) return null;
  await db.update(radarLeads)
    .set({ aiAnalysis: analysis })
    .where(eq(radarLeads.id, leadId));
  return true;
}

/**
 * Mark email as sent for a radar lead
 */
export async function markRadarEmailSent(leadId: number) {
  const db = await getDb();
  if (!db) return null;
  await db.update(radarLeads)
    .set({ emailSentAt: new Date() })
    .where(eq(radarLeads.id, leadId));
  return true;
}


// ============ STAGE CONTENTS ============

export async function getStageContents(stageId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(stageContents)
    .where(eq(stageContents.stageId, stageId))
    .orderBy(stageContents.sortOrder);
}

export async function createStageContent(data: InsertStageContent) {
  const db = await getDb();
  if (!db) return null;
  const [result] = await db.insert(stageContents).values(data);
  return result.insertId;
}

export async function updateStageContent(id: number, data: Partial<InsertStageContent>) {
  const db = await getDb();
  if (!db) return;
  await db.update(stageContents).set({ ...data, updatedAt: new Date() }).where(eq(stageContents.id, id));
}

export async function deleteStageContent(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(stageContents).where(eq(stageContents.id, id));
}

// ============ STAGE CHECKLIST ITEMS ============

export async function getStageChecklistItems(stageId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(stageChecklistItems)
    .where(eq(stageChecklistItems.stageId, stageId))
    .orderBy(stageChecklistItems.sortOrder);
}

export async function createStageChecklistItem(data: InsertStageChecklistItem) {
  const db = await getDb();
  if (!db) return null;
  const [result] = await db.insert(stageChecklistItems).values(data);
  return result.insertId;
}

export async function updateStageChecklistItem(id: number, data: Partial<InsertStageChecklistItem>) {
  const db = await getDb();
  if (!db) return;
  await db.update(stageChecklistItems).set(data).where(eq(stageChecklistItems.id, id));
}

export async function deleteStageChecklistItem(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(stageChecklistProgress).where(eq(stageChecklistProgress.checklistItemId, id));
  await db.delete(stageChecklistItems).where(eq(stageChecklistItems.id, id));
}

// ============ STAGE CHECKLIST PROGRESS (MEMBER) ============

export async function getChecklistProgressForUser(stageId: number, userId: number) {
  const db = await getDb();
  if (!db) return [];
  const items = await getStageChecklistItems(stageId);
  if (items.length === 0) return [];
  const itemIds = items.map(i => i.id);
  const progress = await db.select().from(stageChecklistProgress)
    .where(and(
      inArray(stageChecklistProgress.checklistItemId, itemIds),
      eq(stageChecklistProgress.userId, userId)
    ));
  return progress;
}

export async function toggleChecklistItem(checklistItemId: number, userId: number, completed: boolean) {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select().from(stageChecklistProgress)
    .where(and(
      eq(stageChecklistProgress.checklistItemId, checklistItemId),
      eq(stageChecklistProgress.userId, userId)
    )).limit(1);
  if (existing.length > 0) {
    await db.update(stageChecklistProgress)
      .set({ completed, completedAt: completed ? new Date() : null })
      .where(eq(stageChecklistProgress.id, existing[0].id));
  } else {
    await db.insert(stageChecklistProgress).values({
      checklistItemId,
      userId,
      completed,
      completedAt: completed ? new Date() : null,
    });
  }
}

// ============ STAGE COMMENTS ============

export async function getStageComments(stageId: number) {
  const db = await getDb();
  if (!db) return [];
  const comments = await db.select({
    id: stageComments.id,
    stageId: stageComments.stageId,
    projectId: stageComments.projectId,
    userId: stageComments.userId,
    message: stageComments.message,
    parentId: stageComments.parentId,
    isAdminReply: stageComments.isAdminReply,
    createdAt: stageComments.createdAt,
    updatedAt: stageComments.updatedAt,
    userName: users.name,
    userAvatar: users.avatarUrl,
    userRole: users.role,
  })
    .from(stageComments)
    .leftJoin(users, eq(stageComments.userId, users.id))
    .where(eq(stageComments.stageId, stageId))
    .orderBy(stageComments.createdAt);
  return comments;
}

export async function createStageComment(data: InsertStageComment) {
  const db = await getDb();
  if (!db) return null;
  const [result] = await db.insert(stageComments).values(data);
  return result.insertId;
}

export async function deleteStageComment(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(stageComments).where(eq(stageComments.id, id));
}

// ============ STAGE MEMBER PROGRESS ============

export async function getStageMemberProgress(stageId: number, userId: number) {
  const db = await getDb();
  if (!db) return null;
  const [result] = await db.select().from(stageMemberProgress)
    .where(and(
      eq(stageMemberProgress.stageId, stageId),
      eq(stageMemberProgress.userId, userId)
    )).limit(1);
  return result || null;
}

export async function updateStageMemberProgress(stageId: number, userId: number, status: string) {
  const db = await getDb();
  if (!db) return;
  const existing = await getStageMemberProgress(stageId, userId);
  if (existing) {
    await db.update(stageMemberProgress)
      .set({
        status: status as any,
        ...(status === 'in_progress' && !existing.startedAt ? { startedAt: new Date() } : {}),
        ...(status === 'completed' ? { completedAt: new Date() } : {}),
        updatedAt: new Date(),
      })
      .where(eq(stageMemberProgress.id, existing.id));
  } else {
    await db.insert(stageMemberProgress).values({
      stageId,
      userId,
      status: status as any,
      ...(status === 'in_progress' ? { startedAt: new Date() } : {}),
      ...(status === 'completed' ? { startedAt: new Date(), completedAt: new Date() } : {}),
    });
  }
}

// ============ FULL STAGE DETAIL (for member view) ============

export async function getFullStageDetail(stageId: number, userId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const stage = await getProjectStageById(stageId);
  if (!stage) return null;
  
  const contents = await getStageContents(stageId);
  const checklistItems = await getStageChecklistItems(stageId);
  const checklistProgress = await getChecklistProgressForUser(stageId, userId);
  const comments = await getStageComments(stageId);
  const memberProgress = await getStageMemberProgress(stageId, userId);
  const deliverables = await getStageDeliverables(stageId);
  
  const progressMap = new Map(checklistProgress.map(p => [p.checklistItemId, p.completed]));
  const checklistWithProgress = checklistItems.map(item => ({
    ...item,
    completed: progressMap.get(item.id) || false,
  }));
  
  const totalChecklist = checklistItems.length;
  const completedChecklist = checklistWithProgress.filter(i => i.completed).length;
  
  return {
    ...stage,
    contents,
    checklist: checklistWithProgress,
    checklistProgress: { total: totalChecklist, completed: completedChecklist },
    comments,
    memberProgress,
    deliverables,
  };
}

// ============ ADMIN: GET ALL PROJECTS WITH STAGES ============

export async function getAllProjectsWithStages() {
  const db = await getDb();
  if (!db) return [];
  
  const projects = await db.select({
    id: consultingProjects.id,
    name: consultingProjects.name,
    description: consultingProjects.description,
    type: consultingProjects.type,
    status: consultingProjects.status,
    progress: consultingProjects.progress,
    clientUserId: consultingProjects.clientUserId,
    startDate: consultingProjects.startDate,
    endDate: consultingProjects.endDate,
    createdAt: consultingProjects.createdAt,
    clientName: users.name,
    clientEmail: users.email,
  })
    .from(consultingProjects)
    .leftJoin(users, eq(consultingProjects.clientUserId, users.id))
    .orderBy(desc(consultingProjects.updatedAt));
  
  const result = [];
  for (const project of projects) {
    const stages = await getProjectStages(project.id);
    const stagesWithDetails = [];
    for (const stage of stages) {
      const stageContentsData = await getStageContents(stage.id);
      const checklistItems = await getStageChecklistItems(stage.id);
      const deliverables = await getStageDeliverables(stage.id);
      const commentsData = await getStageComments(stage.id);
      stagesWithDetails.push({
        ...stage,
        contents: stageContentsData,
        checklistItems,
        deliverables,
        commentsCount: commentsData.length,
      });
    }
    result.push({
      ...project,
      stages: stagesWithDetails,
    });
  }
  
  return result;
}


// ============ REORDER STAGES ============

export async function reorderProjectStages(stageOrders: { id: number; sortOrder: number }[]) {
  const db = await getDb();
  if (!db) return;
  for (const { id, sortOrder } of stageOrders) {
    await db.update(projectStages)
      .set({ sortOrder, updatedAt: new Date() })
      .where(eq(projectStages.id, id));
  }
}


// ============ ASSESSMENT MODULE ============

export async function getAssessmentItems(blocks?: string[]) {
  const db = await getDb();
  if (!db) return [];
  if (blocks && blocks.length > 0) {
    return db.select().from(assessmentItemBank)
      .where(and(eq(assessmentItemBank.isActive, true), inArray(assessmentItemBank.block, blocks)))
      .orderBy(assessmentItemBank.sortOrder);
  }
  return db.select().from(assessmentItemBank)
    .where(eq(assessmentItemBank.isActive, true))
    .orderBy(assessmentItemBank.sortOrder);
}

export async function getAssessmentItemsByBlock(block: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(assessmentItemBank)
    .where(and(eq(assessmentItemBank.block, block), eq(assessmentItemBank.isActive, true)))
    .orderBy(assessmentItemBank.sortOrder);
}

export async function createAssessmentSession(data: InsertAssessmentSession) {
  const db = await getDb();
  if (!db) return null;
  const [result] = await db.insert(assessmentSessions).values(data);
  return result.insertId;
}

export async function getAssessmentSession(sessionId: number) {
  const db = await getDb();
  if (!db) return null;
  const [session] = await db.select().from(assessmentSessions).where(eq(assessmentSessions.id, sessionId));
  return session || null;
}

export async function getUserAssessmentSessions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(assessmentSessions)
    .where(eq(assessmentSessions.userId, userId))
    .orderBy(desc(assessmentSessions.createdAt));
}

export async function updateAssessmentSession(sessionId: number, data: Partial<InsertAssessmentSession>) {
  const db = await getDb();
  if (!db) return;
  await db.update(assessmentSessions).set(data).where(eq(assessmentSessions.id, sessionId));
}

export async function saveAssessmentResponse(data: InsertAssessmentResponse) {
  const db = await getDb();
  if (!db) return null;
  const [result] = await db.insert(assessmentResponses).values(data);
  return result.insertId;
}

export async function saveAssessmentResponses(data: InsertAssessmentResponse[]) {
  const db = await getDb();
  if (!db) return;
  if (data.length === 0) return;
  await db.insert(assessmentResponses).values(data);
}

export async function getAssessmentResponses(sessionId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(assessmentResponses).where(eq(assessmentResponses.sessionId, sessionId));
}

export async function saveAssessmentScores(data: InsertAssessmentScore[]) {
  const db = await getDb();
  if (!db) return;
  if (data.length === 0) return;
  // Delete existing scores for this session first
  if (data[0]?.sessionId) {
    await db.delete(assessmentScores).where(eq(assessmentScores.sessionId, data[0].sessionId));
  }
  await db.insert(assessmentScores).values(data);
}

export async function getAssessmentScores(sessionId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(assessmentScores).where(eq(assessmentScores.sessionId, sessionId));
}

export async function saveAssessmentReport(data: InsertAssessmentReport) {
  const db = await getDb();
  if (!db) return null;
  const [result] = await db.insert(assessmentReports).values(data);
  return result.insertId;
}

export async function getAssessmentReport(sessionId: number) {
  const db = await getDb();
  if (!db) return null;
  const [report] = await db.select().from(assessmentReports)
    .where(eq(assessmentReports.sessionId, sessionId))
    .orderBy(desc(assessmentReports.createdAt))
    .limit(1);
  return report || null;
}

export async function updateAssessmentReport(reportId: number, data: Partial<InsertAssessmentReport>) {
  const db = await getDb();
  if (!db) return;
  await db.update(assessmentReports).set(data).where(eq(assessmentReports.id, reportId));
}


// ============ COMPARATIVO DE AVALIAÇÕES ============

export async function getMultipleSessionScores(sessionIds: number[]) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(assessmentScores)
    .where(inArray(assessmentScores.sessionId, sessionIds));
}

export async function getUserCompletedSessions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(assessmentSessions)
    .where(and(
      eq(assessmentSessions.userId, userId),
      eq(assessmentSessions.status, "completed")
    ))
    .orderBy(desc(assessmentSessions.createdAt));
}

// ============ ADMIN STATS ============

export async function getAllAssessmentSessions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(assessmentSessions)
    .orderBy(desc(assessmentSessions.createdAt));
}

export async function getAllAssessmentScores() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(assessmentScores);
}

export async function getAssessmentSessionsWithUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    session: assessmentSessions,
    userName: users.name,
    userEmail: users.email,
  })
    .from(assessmentSessions)
    .innerJoin(users, eq(assessmentSessions.userId, users.id))
    .orderBy(desc(assessmentSessions.createdAt));
}

// ============ PDI-JORNADA INTEGRATION ============

export async function getUserProjectByUserId(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const [project] = await db.select().from(consultingProjects)
    .where(eq(consultingProjects.clientUserId, userId))
    .orderBy(desc(consultingProjects.createdAt))
    .limit(1);
  return project || null;
}

export async function getMaxSortOrderForStages(projectId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ maxOrder: sql<number>`COALESCE(MAX(${projectStages.sortOrder}), 0)` })
    .from(projectStages)
    .where(eq(projectStages.projectId, projectId));
  return result[0]?.maxOrder ?? 0;
}
