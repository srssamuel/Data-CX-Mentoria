import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createMemberContext(id = 2): TrpcContext {
  const user: AuthenticatedUser = {
    id,
    openId: "member-user",
    email: "member@example.com",
    name: "Member User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: { origin: "http://localhost:3000" },
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

function createAnonymousContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: { origin: "http://localhost:3000" },
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("Assessment Module", () => {
  const memberCaller = appRouter.createCaller(createMemberContext());
  const anonCaller = appRouter.createCaller(createAnonymousContext());

  describe("assessment.getItems", () => {
    it("should return items for quick mode", async () => {
      const items = await memberCaller.assessment.getItems({ mode: "quick" });
      expect(items).toBeDefined();
      expect(Array.isArray(items)).toBe(true);
    });

    it("should return items for complete mode", async () => {
      const items = await memberCaller.assessment.getItems({ mode: "complete" });
      expect(items).toBeDefined();
      expect(Array.isArray(items)).toBe(true);
    });

    it("should return items with selected modules", async () => {
      const items = await memberCaller.assessment.getItems({
        mode: "complete",
        selectedModules: ["communication"],
      });
      expect(items).toBeDefined();
      expect(Array.isArray(items)).toBe(true);
    });
  });

  describe("assessment.startSession", () => {
    it("should create a new assessment session", async () => {
      const result = await memberCaller.assessment.startSession({
        mode: "quick",
        currentRole: "Analista de Dados",
        experienceYears: 5,
      });
      expect(result).toBeDefined();
      expect(result.sessionId).toBeDefined();
      expect(typeof result.sessionId).toBe("number");
    });

    it("should create session with context info", async () => {
      const result = await memberCaller.assessment.startSession({
        mode: "complete",
        currentRole: "Gerente de CX",
        experienceYears: 10,
        industry: "Tecnologia",
        teamSize: "6-15",
        primaryObjective: "leadership",
        contextDescription: "Transição de carreira para gestão",
        selectedModules: ["leadership", "communication"],
      });
      expect(result).toBeDefined();
      expect(result.sessionId).toBeDefined();
    });

    it("should reject unauthenticated users", async () => {
      await expect(
        anonCaller.assessment.startSession({
          mode: "quick",
          currentRole: "Analista",
          experienceYears: 3,
        })
      ).rejects.toThrow();
    });
  });

  describe("assessment.saveResponses", () => {
    it("should save responses for a session", async () => {
      const session = await memberCaller.assessment.startSession({
        mode: "quick",
        currentRole: "Dev",
        experienceYears: 2,
      });

      const result = await memberCaller.assessment.saveResponses({
        sessionId: session.sessionId,
        responses: [
          { itemId: 1, responseValue: "4", responseTimeMs: 3000 },
          { itemId: 2, responseValue: "3", responseTimeMs: 2500 },
        ],
      });
      expect(result).toBeDefined();
      expect(result.saved).toBeGreaterThan(0);
    });
  });

  describe("assessment.myHistory", () => {
    it("should return user's assessment history", async () => {
      const history = await memberCaller.assessment.myHistory();
      expect(history).toBeDefined();
      expect(Array.isArray(history)).toBe(true);
    });

    it("should reject unauthenticated users", async () => {
      await expect(anonCaller.assessment.myHistory()).rejects.toThrow();
    });
  });

  describe("assessment.getResults", () => {
    it("should reject for non-existent session", async () => {
      await expect(
        memberCaller.assessment.getResults({ sessionId: 999999 })
      ).rejects.toThrow();
    });
  });
});


// ============ COMPARATIVO TESTS ============

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: { origin: "http://localhost:3000" },
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("Assessment Comparativo & Admin Stats", () => {
  const memberCaller = appRouter.createCaller(createMemberContext());
  const adminCaller = appRouter.createCaller(createAdminContext());

  describe("assessment.getCompletedSessions", () => {
    it("should return completed sessions for the user", async () => {
      const sessions = await memberCaller.assessment.getCompletedSessions();
      expect(sessions).toBeDefined();
      expect(Array.isArray(sessions)).toBe(true);
    });

    it("should reject unauthenticated users", async () => {
      const anonCaller = appRouter.createCaller(createAnonymousContext());
      await expect(anonCaller.assessment.getCompletedSessions()).rejects.toThrow();
    });
  });

  describe("assessment.compareScores", () => {
    it("should reject with non-existent session IDs", async () => {
      await expect(
        memberCaller.assessment.compareScores({ sessionIds: [999998, 999999] })
      ).rejects.toThrow();
    });

    it("should reject with empty session IDs", async () => {
      await expect(
        memberCaller.assessment.compareScores({ sessionIds: [] })
      ).rejects.toThrow();
    });
  });

  describe("assessment.adminStats", () => {
    it("should return aggregated statistics for admin", async () => {
      const stats = await adminCaller.assessment.adminStats();
      expect(stats).toBeDefined();
      expect(stats.summary).toBeDefined();
      expect(stats.summary.totalSessions).toBeGreaterThanOrEqual(0);
      expect(stats.summary.completedSessions).toBeGreaterThanOrEqual(0);
      expect(stats.summary.abandonedSessions).toBeGreaterThanOrEqual(0);
      expect(stats.summary.inProgressSessions).toBeGreaterThanOrEqual(0);
      expect(Array.isArray(stats.constructAverages)).toBe(true);
      expect(Array.isArray(stats.qualityAlerts)).toBe(true);
      expect(Array.isArray(stats.recentSessions)).toBe(true);
    });

    it("should reject non-admin users", async () => {
      await expect(memberCaller.assessment.adminStats()).rejects.toThrow();
    });
  });

  describe("assessment.linkPdiToJornada", () => {
    it("should reject with non-existent session", async () => {
      await expect(
        memberCaller.assessment.linkPdiToJornada({
          sessionId: 999999,
          projectId: 1,
          actions: [{ title: "Test action", horizon: "30" }],
        })
      ).rejects.toThrow();
    });

    it("should reject unauthenticated users", async () => {
      const anonCaller = appRouter.createCaller(createAnonymousContext());
      await expect(
        anonCaller.assessment.linkPdiToJornada({
          sessionId: 1,
          projectId: 1,
          actions: [{ title: "Test action", horizon: "30" }],
        })
      ).rejects.toThrow();
    });

    it("should validate input schema", async () => {
      await expect(
        memberCaller.assessment.linkPdiToJornada({
          sessionId: 1,
          projectId: 1,
          actions: [],
        })
      ).rejects.toThrow();
    });
  });
});
