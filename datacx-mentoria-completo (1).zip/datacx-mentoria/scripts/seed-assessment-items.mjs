/**
 * Seed script for Assessment Item Bank
 * Generates items for all assessment blocks:
 * - CORE: Big Five (IPIP), Communication (Circumplex), Leadership (SJT), Vitality (WHO-5)
 * - MODULES: Innovation, Data Literacy, Decision, Learning Agility, Execution, Motivation, Values, Career Fit, Collaboration
 * - QUALITY: Attention checks, consistency checks
 */

import mysql from "mysql2/promise";

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL not set");
  process.exit(1);
}

const connection = await mysql.createConnection(DATABASE_URL);

// Helper to insert items
async function insertItems(items) {
  for (const item of items) {
    await connection.execute(
      `INSERT INTO assessment_item_bank (block, construct, facet, itemType, polarity, text, optionsJson, keyJson, dimension, expectedTimeSec, isPublicDomain, sourceNote, sortOrder, isActive)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        item.block,
        item.construct,
        item.facet || null,
        item.itemType,
        item.polarity || "positive",
        item.text,
        item.optionsJson ? JSON.stringify(item.optionsJson) : null,
        item.keyJson ? JSON.stringify(item.keyJson) : null,
        item.dimension || null,
        item.expectedTimeSec || 15,
        item.isPublicDomain ?? true,
        item.sourceNote || null,
        item.sortOrder || 0,
        true,
      ]
    );
  }
}

// ============ CORE: BIG FIVE (IPIP-based, public domain) ============

const bigFiveItems = [
  // OPENNESS (Abertura à Experiência)
  { block: "core_personality", construct: "openness", facet: "imagination", itemType: "likert", polarity: "positive", text: "Tenho uma imaginação muito ativa e vívida.", sortOrder: 1, sourceNote: "IPIP" },
  { block: "core_personality", construct: "openness", facet: "imagination", itemType: "likert", polarity: "negative", text: "Raramente me perco em pensamentos ou devaneios.", sortOrder: 2, sourceNote: "IPIP" },
  { block: "core_personality", construct: "openness", facet: "intellect", itemType: "likert", polarity: "positive", text: "Gosto de explorar ideias abstratas e conceitos complexos.", sortOrder: 3, sourceNote: "IPIP" },
  { block: "core_personality", construct: "openness", facet: "intellect", itemType: "likert", polarity: "negative", text: "Prefiro tarefas práticas e concretas a discussões teóricas.", sortOrder: 4, sourceNote: "IPIP" },
  { block: "core_personality", construct: "openness", facet: "artistic_interest", itemType: "likert", polarity: "positive", text: "Aprecio arte, música ou literatura de forma profunda.", sortOrder: 5, sourceNote: "IPIP" },
  { block: "core_personality", construct: "openness", facet: "adventurousness", itemType: "likert", polarity: "positive", text: "Busco ativamente novas experiências e formas diferentes de fazer as coisas.", sortOrder: 6, sourceNote: "IPIP" },

  // CONSCIENTIOUSNESS (Conscienciosidade)
  { block: "core_personality", construct: "conscientiousness", facet: "self_discipline", itemType: "likert", polarity: "positive", text: "Consigo manter o foco em tarefas longas até concluí-las.", sortOrder: 7, sourceNote: "IPIP" },
  { block: "core_personality", construct: "conscientiousness", facet: "self_discipline", itemType: "likert", polarity: "negative", text: "Frequentemente procrastino e deixo tarefas para a última hora.", sortOrder: 8, sourceNote: "IPIP" },
  { block: "core_personality", construct: "conscientiousness", facet: "orderliness", itemType: "likert", polarity: "positive", text: "Mantenho meu ambiente de trabalho organizado e estruturado.", sortOrder: 9, sourceNote: "IPIP" },
  { block: "core_personality", construct: "conscientiousness", facet: "achievement_striving", itemType: "likert", polarity: "positive", text: "Estabeleço metas ambiciosas e trabalho duro para alcançá-las.", sortOrder: 10, sourceNote: "IPIP" },
  { block: "core_personality", construct: "conscientiousness", facet: "dutifulness", itemType: "likert", polarity: "positive", text: "Cumpro minhas promessas e compromissos com rigor.", sortOrder: 11, sourceNote: "IPIP" },
  { block: "core_personality", construct: "conscientiousness", facet: "cautiousness", itemType: "likert", polarity: "positive", text: "Penso cuidadosamente antes de tomar decisões importantes.", sortOrder: 12, sourceNote: "IPIP" },

  // EXTRAVERSION (Extroversão)
  { block: "core_personality", construct: "extraversion", facet: "gregariousness", itemType: "likert", polarity: "positive", text: "Sinto-me energizado quando estou em grupos de pessoas.", sortOrder: 13, sourceNote: "IPIP" },
  { block: "core_personality", construct: "extraversion", facet: "gregariousness", itemType: "likert", polarity: "negative", text: "Prefiro trabalhar sozinho do que em equipe na maior parte do tempo.", sortOrder: 14, sourceNote: "IPIP" },
  { block: "core_personality", construct: "extraversion", facet: "assertiveness", itemType: "likert", polarity: "positive", text: "Tomo a iniciativa em reuniões e discussões de grupo.", sortOrder: 15, sourceNote: "IPIP" },
  { block: "core_personality", construct: "extraversion", facet: "activity_level", itemType: "likert", polarity: "positive", text: "Tenho um ritmo de trabalho acelerado e gosto de estar sempre ocupado.", sortOrder: 16, sourceNote: "IPIP" },
  { block: "core_personality", construct: "extraversion", facet: "positive_emotions", itemType: "likert", polarity: "positive", text: "Costumo expressar entusiasmo e otimismo no ambiente de trabalho.", sortOrder: 17, sourceNote: "IPIP" },
  { block: "core_personality", construct: "extraversion", facet: "excitement_seeking", itemType: "likert", polarity: "positive", text: "Gosto de desafios novos e situações que exigem ação rápida.", sortOrder: 18, sourceNote: "IPIP" },

  // AGREEABLENESS (Amabilidade)
  { block: "core_personality", construct: "agreeableness", facet: "trust", itemType: "likert", polarity: "positive", text: "Acredito que a maioria das pessoas tem boas intenções.", sortOrder: 19, sourceNote: "IPIP" },
  { block: "core_personality", construct: "agreeableness", facet: "trust", itemType: "likert", polarity: "negative", text: "Desconfio das motivações das pessoas ao meu redor.", sortOrder: 20, sourceNote: "IPIP" },
  { block: "core_personality", construct: "agreeableness", facet: "altruism", itemType: "likert", polarity: "positive", text: "Faço questão de ajudar colegas mesmo quando não é minha responsabilidade.", sortOrder: 21, sourceNote: "IPIP" },
  { block: "core_personality", construct: "agreeableness", facet: "cooperation", itemType: "likert", polarity: "positive", text: "Busco o consenso e evito conflitos desnecessários.", sortOrder: 22, sourceNote: "IPIP" },
  { block: "core_personality", construct: "agreeableness", facet: "modesty", itemType: "likert", polarity: "positive", text: "Prefiro não chamar atenção para minhas conquistas.", sortOrder: 23, sourceNote: "IPIP" },
  { block: "core_personality", construct: "agreeableness", facet: "sympathy", itemType: "likert", polarity: "positive", text: "Sinto empatia genuína pelas dificuldades dos outros.", sortOrder: 24, sourceNote: "IPIP" },

  // NEUROTICISM (Neuroticismo / Estabilidade Emocional)
  { block: "core_personality", construct: "neuroticism", facet: "anxiety", itemType: "likert", polarity: "positive", text: "Preocupo-me frequentemente com situações que podem dar errado.", sortOrder: 25, sourceNote: "IPIP" },
  { block: "core_personality", construct: "neuroticism", facet: "anxiety", itemType: "likert", polarity: "negative", text: "Mantenho a calma mesmo em situações de alta pressão.", sortOrder: 26, sourceNote: "IPIP" },
  { block: "core_personality", construct: "neuroticism", facet: "anger", itemType: "likert", polarity: "positive", text: "Irrito-me com facilidade quando as coisas não saem como planejado.", sortOrder: 27, sourceNote: "IPIP" },
  { block: "core_personality", construct: "neuroticism", facet: "depression", itemType: "likert", polarity: "positive", text: "Às vezes me sinto desanimado ou sem motivação no trabalho.", sortOrder: 28, sourceNote: "IPIP" },
  { block: "core_personality", construct: "neuroticism", facet: "self_consciousness", itemType: "likert", polarity: "positive", text: "Fico constrangido quando cometo erros na frente dos outros.", sortOrder: 29, sourceNote: "IPIP" },
  { block: "core_personality", construct: "neuroticism", facet: "vulnerability", itemType: "likert", polarity: "positive", text: "Tenho dificuldade em lidar com críticas negativas.", sortOrder: 30, sourceNote: "IPIP" },
];

// ============ CORE: COMMUNICATION / CIRCUMPLEX ============

const communicationItems = [
  // Agency (assertividade, dominância, influência)
  { block: "core_communication", construct: "agency", facet: "assertiveness", itemType: "likert", polarity: "positive", text: "Expresso minhas opiniões de forma clara e direta, mesmo quando divergem da maioria.", sortOrder: 31, sourceNote: "autoral", isPublicDomain: false },
  { block: "core_communication", construct: "agency", facet: "influence", itemType: "likert", polarity: "positive", text: "Consigo convencer pessoas a adotarem minha perspectiva com argumentos sólidos.", sortOrder: 32, sourceNote: "autoral", isPublicDomain: false },
  { block: "core_communication", construct: "agency", facet: "dominance", itemType: "likert", polarity: "positive", text: "Naturalmente assumo a liderança em conversas e reuniões.", sortOrder: 33, sourceNote: "autoral", isPublicDomain: false },
  { block: "core_communication", construct: "agency", facet: "confidence", itemType: "likert", polarity: "positive", text: "Sinto-me confortável ao falar em público ou apresentar ideias para grandes grupos.", sortOrder: 34, sourceNote: "autoral", isPublicDomain: false },
  { block: "core_communication", construct: "agency", facet: "directness", itemType: "likert", polarity: "negative", text: "Evito confrontar pessoas diretamente, mesmo quando necessário.", sortOrder: 35, sourceNote: "autoral", isPublicDomain: false },

  // Communion (empatia, cooperação, conexão)
  { block: "core_communication", construct: "communion", facet: "empathy", itemType: "likert", polarity: "positive", text: "Presto atenção genuína ao que as pessoas estão sentindo durante uma conversa.", sortOrder: 36, sourceNote: "autoral", isPublicDomain: false },
  { block: "core_communication", construct: "communion", facet: "warmth", itemType: "likert", polarity: "positive", text: "As pessoas me descrevem como alguém acolhedor e acessível.", sortOrder: 37, sourceNote: "autoral", isPublicDomain: false },
  { block: "core_communication", construct: "communion", facet: "listening", itemType: "likert", polarity: "positive", text: "Ouço atentamente antes de responder, buscando entender o ponto de vista do outro.", sortOrder: 38, sourceNote: "autoral", isPublicDomain: false },
  { block: "core_communication", construct: "communion", facet: "support", itemType: "likert", polarity: "positive", text: "Ofereço suporte emocional aos colegas quando percebo que estão passando por dificuldades.", sortOrder: 39, sourceNote: "autoral", isPublicDomain: false },
  { block: "core_communication", construct: "communion", facet: "harmony", itemType: "likert", polarity: "negative", text: "Tenho dificuldade em criar conexões pessoais no ambiente de trabalho.", sortOrder: 40, sourceNote: "autoral", isPublicDomain: false },
];

// ============ CORE: LEADERSHIP (SJT) ============

const leadershipItems = [
  {
    block: "core_leadership", construct: "leadership", facet: null, itemType: "sjt",
    text: "Você é líder de um projeto e descobre que dois membros da equipe têm um conflito pessoal que está afetando a produtividade. O prazo está apertado. O que você faz?",
    optionsJson: [
      { label: "A", text: "Reúno os dois em particular para mediar a conversa e buscar uma solução conjunta." },
      { label: "B", text: "Separo as tarefas deles para que não precisem interagir até o final do projeto." },
      { label: "C", text: "Ignoro o conflito pessoal e foco apenas em cobrar as entregas." },
      { label: "D", text: "Escalo para o RH ou gestor superior resolver a situação." }
    ],
    keyJson: { A: 4, B: 2, C: 1, D: 3 },
    dimension: "conflict_resolution", sortOrder: 41, sourceNote: "autoral", isPublicDomain: false, expectedTimeSec: 45
  },
  {
    block: "core_leadership", construct: "leadership", facet: null, itemType: "sjt",
    text: "Um membro sênior da sua equipe entregou um trabalho abaixo do esperado pela terceira vez consecutiva. Ele é respeitado pelo time. Como você aborda a situação?",
    optionsJson: [
      { label: "A", text: "Converso em particular, mostro os dados de performance e pergunto se algo está acontecendo." },
      { label: "B", text: "Dou feedback público na reunião de equipe para que todos entendam o padrão esperado." },
      { label: "C", text: "Redistribuo as tarefas dele silenciosamente para evitar constrangimento." },
      { label: "D", text: "Documento as falhas e inicio um processo formal de melhoria de desempenho." }
    ],
    keyJson: { A: 4, B: 1, C: 2, D: 3 },
    dimension: "feedback", sortOrder: 42, sourceNote: "autoral", isPublicDomain: false, expectedTimeSec: 45
  },
  {
    block: "core_leadership", construct: "leadership", facet: null, itemType: "sjt",
    text: "Sua empresa precisa cortar 20% do orçamento do seu departamento. Você tem que decidir entre reduzir treinamentos, cortar um projeto inovador ou diminuir bônus da equipe. O que você prioriza?",
    optionsJson: [
      { label: "A", text: "Apresento as três opções ao time com dados e decidimos juntos o melhor caminho." },
      { label: "B", text: "Corto o projeto inovador para preservar as pessoas e seus benefícios." },
      { label: "C", text: "Reduzo bônus proporcionalmente — é mais justo e preserva capacidade futura." },
      { label: "D", text: "Nego com a diretoria para encontrar alternativas antes de cortar qualquer coisa." }
    ],
    keyJson: { A: 4, B: 2, C: 3, D: 3 },
    dimension: "decision_making", sortOrder: 43, sourceNote: "autoral", isPublicDomain: false, expectedTimeSec: 45
  },
  {
    block: "core_leadership", construct: "leadership", facet: null, itemType: "sjt",
    text: "Você descobre que um colega de mesmo nível hierárquico está tomando crédito pelo trabalho de um estagiário da sua equipe. O que você faz?",
    optionsJson: [
      { label: "A", text: "Converso diretamente com o colega, de forma privada, sobre o que observei." },
      { label: "B", text: "Na próxima reunião, faço questão de dar crédito público ao estagiário." },
      { label: "C", text: "Oriento o estagiário a se posicionar e defender seu próprio trabalho." },
      { label: "D", text: "Reporto a situação ao gestor do colega para que ele tome providências." }
    ],
    keyJson: { A: 4, B: 3, C: 3, D: 2 },
    dimension: "ethics", sortOrder: 44, sourceNote: "autoral", isPublicDomain: false, expectedTimeSec: 45
  },
  {
    block: "core_leadership", construct: "leadership", facet: null, itemType: "sjt",
    text: "Você tem duas demandas urgentes: uma entrega para o cliente com prazo amanhã e uma reunião estratégica com a diretoria que pode definir o futuro do seu departamento. Ambas são no mesmo horário. O que você faz?",
    optionsJson: [
      { label: "A", text: "Delego a entrega ao membro mais preparado da equipe e participo da reunião estratégica." },
      { label: "B", text: "Peço para reagendar a reunião estratégica e garanto pessoalmente a entrega ao cliente." },
      { label: "C", text: "Divido meu tempo: começo na reunião, saio mais cedo e finalizo a entrega." },
      { label: "D", text: "Preparo um resumo escrito para a diretoria e foco na entrega ao cliente." }
    ],
    keyJson: { A: 4, B: 2, C: 1, D: 3 },
    dimension: "prioritization", sortOrder: 45, sourceNote: "autoral", isPublicDomain: false, expectedTimeSec: 45
  },
  {
    block: "core_leadership", construct: "leadership", facet: null, itemType: "sjt",
    text: "Um novo membro da equipe está com dificuldades de adaptação. Ele é tecnicamente competente, mas não está se integrando com o time. Após 2 meses, a situação não melhorou. O que você faz?",
    optionsJson: [
      { label: "A", text: "Designo um mentor interno e crio oportunidades de interação informal com o time." },
      { label: "B", text: "Converso com ele para entender suas dificuldades e co-criar um plano de integração." },
      { label: "C", text: "Dou mais tempo — cada pessoa tem seu ritmo de adaptação." },
      { label: "D", text: "Avalio se o fit cultural é adequado e considero realocação para outra equipe." }
    ],
    keyJson: { A: 3, B: 4, C: 1, D: 2 },
    dimension: "people_development", sortOrder: 46, sourceNote: "autoral", isPublicDomain: false, expectedTimeSec: 45
  },
];

// ============ CORE: VITALITY / WELL-BEING (WHO-5 adapted) ============

const vitalityItems = [
  { block: "core_vitality", construct: "wellbeing", facet: "cheerfulness", itemType: "likert", polarity: "positive", text: "Nas últimas duas semanas, senti-me alegre e de bom humor.", sortOrder: 47, sourceNote: "WHO-5 adapted" },
  { block: "core_vitality", construct: "wellbeing", facet: "calm", itemType: "likert", polarity: "positive", text: "Nas últimas duas semanas, senti-me calmo e tranquilo.", sortOrder: 48, sourceNote: "WHO-5 adapted" },
  { block: "core_vitality", construct: "wellbeing", facet: "active", itemType: "likert", polarity: "positive", text: "Nas últimas duas semanas, senti-me ativo e vigoroso.", sortOrder: 49, sourceNote: "WHO-5 adapted" },
  { block: "core_vitality", construct: "wellbeing", facet: "rested", itemType: "likert", polarity: "positive", text: "Nas últimas duas semanas, acordei sentindo-me descansado e renovado.", sortOrder: 50, sourceNote: "WHO-5 adapted" },
  { block: "core_vitality", construct: "wellbeing", facet: "interest", itemType: "likert", polarity: "positive", text: "Nas últimas duas semanas, meu dia a dia foi preenchido com coisas que me interessam.", sortOrder: 51, sourceNote: "WHO-5 adapted" },
  // Vitality extras
  { block: "core_vitality", construct: "vitality", facet: "energy", itemType: "likert", polarity: "positive", text: "Tenho energia suficiente para lidar com as demandas do meu trabalho.", sortOrder: 52, sourceNote: "autoral", isPublicDomain: false },
  { block: "core_vitality", construct: "vitality", facet: "recovery", itemType: "likert", polarity: "negative", text: "Sinto que não consigo me recuperar adequadamente entre um dia de trabalho e outro.", sortOrder: 53, sourceNote: "autoral", isPublicDomain: false },
  { block: "core_vitality", construct: "vitality", facet: "meaning", itemType: "likert", polarity: "positive", text: "Sinto que meu trabalho tem propósito e significado para mim.", sortOrder: 54, sourceNote: "autoral", isPublicDomain: false },
];

// ============ MODULE: INNOVATION (IWB) ============

const innovationItems = [
  { block: "mod_innovation", construct: "innovation", facet: "ideation", itemType: "likert", polarity: "positive", text: "Frequentemente gero novas ideias para melhorar processos ou produtos.", sortOrder: 55, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_innovation", construct: "innovation", facet: "ideation", itemType: "likert", polarity: "positive", text: "Busco inspiração em áreas diferentes da minha para resolver problemas.", sortOrder: 56, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_innovation", construct: "innovation", facet: "promotion", itemType: "likert", polarity: "positive", text: "Consigo convencer stakeholders a apoiarem minhas ideias inovadoras.", sortOrder: 57, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_innovation", construct: "innovation", facet: "implementation", itemType: "likert", polarity: "positive", text: "Transformo ideias em planos de ação concretos e executáveis.", sortOrder: 58, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_innovation", construct: "innovation", facet: "risk_tolerance", itemType: "likert", polarity: "positive", text: "Estou disposto a experimentar abordagens novas mesmo com risco de falha.", sortOrder: 59, sourceNote: "autoral", isPublicDomain: false },
  {
    block: "mod_innovation", construct: "innovation", facet: null, itemType: "sjt",
    text: "Sua equipe tem uma rotina de processos que funciona bem, mas você identificou uma oportunidade de melhoria significativa que exigiria mudar a forma de trabalho. O time está resistente. O que você faz?",
    optionsJson: [
      { label: "A", text: "Proponho um piloto pequeno e controlado para demonstrar os benefícios antes de escalar." },
      { label: "B", text: "Apresento dados e benchmarks de mercado para convencer o time da necessidade de mudança." },
      { label: "C", text: "Respeito a resistência e mantenho o processo atual — se funciona, não mexo." },
      { label: "D", text: "Implemento a mudança na minha área primeiro e mostro os resultados como exemplo." }
    ],
    keyJson: { A: 4, B: 3, C: 1, D: 3 },
    dimension: "innovation", sortOrder: 60, sourceNote: "autoral", isPublicDomain: false, expectedTimeSec: 45
  },
];

// ============ MODULE: DATA LITERACY ============

const dataItems = [
  { block: "mod_data", construct: "data_literacy", facet: "reading", itemType: "likert", polarity: "positive", text: "Consigo interpretar gráficos e dashboards para extrair insights relevantes.", sortOrder: 61, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_data", construct: "data_literacy", facet: "quality", itemType: "likert", polarity: "positive", text: "Questiono a qualidade e a fonte dos dados antes de tomar decisões baseadas neles.", sortOrder: 62, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_data", construct: "data_literacy", facet: "causality", itemType: "likert", polarity: "positive", text: "Consigo distinguir entre correlação e causalidade ao analisar dados.", sortOrder: 63, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_data", construct: "data_literacy", facet: "storytelling", itemType: "likert", polarity: "positive", text: "Sei transformar dados complexos em narrativas claras para diferentes públicos.", sortOrder: 64, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_data", construct: "data_literacy", facet: "experimentation", itemType: "likert", polarity: "positive", text: "Utilizo testes A/B ou experimentos para validar hipóteses antes de escalar decisões.", sortOrder: 65, sourceNote: "autoral", isPublicDomain: false },
  {
    block: "mod_data", construct: "data_literacy", facet: null, itemType: "sjt",
    text: "Seu gestor pede uma análise urgente. Você tem acesso a um dataset, mas percebe que 15% dos registros têm dados faltantes. O prazo é amanhã. O que você faz?",
    optionsJson: [
      { label: "A", text: "Documento as limitações, faço a análise com os dados disponíveis e apresento com ressalvas claras." },
      { label: "B", text: "Peço mais tempo para limpar e completar os dados antes de qualquer análise." },
      { label: "C", text: "Excluo os registros incompletos e faço a análise com o restante." },
      { label: "D", text: "Uso médias ou valores padrão para preencher os dados faltantes e entrego no prazo." }
    ],
    keyJson: { A: 4, B: 2, C: 3, D: 1 },
    dimension: "data_quality", sortOrder: 66, sourceNote: "autoral", isPublicDomain: false, expectedTimeSec: 45
  },
];

// ============ MODULE: DECISION & JUDGMENT ============

const decisionItems = [
  { block: "mod_decision", construct: "decision", facet: "ambiguity_tolerance", itemType: "likert", polarity: "positive", text: "Consigo tomar decisões mesmo quando não tenho todas as informações disponíveis.", sortOrder: 67, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_decision", construct: "decision", facet: "risk_assessment", itemType: "likert", polarity: "positive", text: "Avalio sistematicamente riscos e benefícios antes de decidir.", sortOrder: 68, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_decision", construct: "decision", facet: "tradeoff", itemType: "likert", polarity: "positive", text: "Aceito que toda decisão envolve trade-offs e consigo comunicá-los com clareza.", sortOrder: 69, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_decision", construct: "decision", facet: "speed", itemType: "likert", polarity: "positive", text: "Tomo decisões com agilidade quando o contexto exige rapidez.", sortOrder: 70, sourceNote: "autoral", isPublicDomain: false },
  {
    block: "mod_decision", construct: "decision", facet: null, itemType: "sjt",
    text: "Você precisa escolher entre dois fornecedores: um é mais barato mas tem histórico de atrasos, outro é mais caro mas confiável. O orçamento está apertado e o prazo é crítico. O que você faz?",
    optionsJson: [
      { label: "A", text: "Escolho o fornecedor confiável e negocio condições de pagamento melhores." },
      { label: "B", text: "Escolho o mais barato e crio um plano de contingência para possíveis atrasos." },
      { label: "C", text: "Divido o pedido entre os dois para mitigar riscos." },
      { label: "D", text: "Busco um terceiro fornecedor que equilibre custo e confiabilidade." }
    ],
    keyJson: { A: 4, B: 2, C: 3, D: 3 },
    dimension: "tradeoff", sortOrder: 71, sourceNote: "autoral", isPublicDomain: false, expectedTimeSec: 45
  },
];

// ============ MODULE: LEARNING AGILITY ============

const learningItems = [
  { block: "mod_learning", construct: "learning_agility", facet: "feedback_seeking", itemType: "likert", polarity: "positive", text: "Busco ativamente feedback sobre meu desempenho, mesmo quando não é oferecido.", sortOrder: 72, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_learning", construct: "learning_agility", facet: "experimentation", itemType: "likert", polarity: "positive", text: "Experimento novas formas de trabalhar regularmente, mesmo que nem sempre funcionem.", sortOrder: 73, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_learning", construct: "learning_agility", facet: "reflection", itemType: "likert", polarity: "positive", text: "Reservo tempo para refletir sobre o que aprendi com experiências recentes.", sortOrder: 74, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_learning", construct: "learning_agility", facet: "transfer", itemType: "likert", polarity: "positive", text: "Consigo aplicar aprendizados de um contexto em situações completamente diferentes.", sortOrder: 75, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_learning", construct: "learning_agility", facet: "unlearning", itemType: "likert", polarity: "positive", text: "Estou disposto a abandonar práticas que funcionavam no passado quando o contexto muda.", sortOrder: 76, sourceNote: "autoral", isPublicDomain: false },
];

// ============ MODULE: EXECUTION & SELF-CONTROL ============

const executionItems = [
  { block: "mod_execution", construct: "execution", facet: "focus", itemType: "likert", polarity: "positive", text: "Consigo manter o foco em prioridades mesmo com múltiplas distrações.", sortOrder: 77, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_execution", construct: "execution", facet: "consistency", itemType: "likert", polarity: "positive", text: "Mantenho um ritmo constante de entregas, sem picos e vales de produtividade.", sortOrder: 78, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_execution", construct: "execution", facet: "organization", itemType: "likert", polarity: "positive", text: "Utilizo sistemas (listas, ferramentas, rotinas) para organizar meu trabalho.", sortOrder: 79, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_execution", construct: "execution", facet: "discipline", itemType: "likert", polarity: "positive", text: "Cumpro prazos consistentemente, mesmo quando a tarefa não é motivadora.", sortOrder: 80, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_execution", construct: "execution", facet: "follow_through", itemType: "likert", polarity: "negative", text: "Tenho dificuldade em finalizar projetos — começo muitas coisas mas termino poucas.", sortOrder: 81, sourceNote: "autoral", isPublicDomain: false },
];

// ============ MODULE: MOTIVATION (Self-Determination) ============

const motivationItems = [
  { block: "mod_motivation", construct: "motivation", facet: "autonomy", itemType: "likert", polarity: "positive", text: "Sinto-me mais motivado quando tenho liberdade para decidir como fazer meu trabalho.", sortOrder: 82, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_motivation", construct: "motivation", facet: "competence", itemType: "likert", polarity: "positive", text: "Sinto-me realizado quando domino novas habilidades ou supero desafios técnicos.", sortOrder: 83, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_motivation", construct: "motivation", facet: "relatedness", itemType: "likert", polarity: "positive", text: "Minha motivação aumenta quando me sinto parte de um time que se importa comigo.", sortOrder: 84, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_motivation", construct: "motivation", facet: "purpose", itemType: "likert", polarity: "positive", text: "Preciso sentir que meu trabalho contribui para algo maior do que metas financeiras.", sortOrder: 85, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_motivation", construct: "motivation", facet: "recognition", itemType: "likert", polarity: "positive", text: "Reconhecimento público pelo meu trabalho é um forte motivador para mim.", sortOrder: 86, sourceNote: "autoral", isPublicDomain: false },
];

// ============ MODULE: VALUES (Schwartz-like) ============

const valuesItems = [
  { block: "mod_values", construct: "values", facet: "achievement", itemType: "likert", polarity: "positive", text: "Valorizo muito o sucesso pessoal e o reconhecimento por competência.", sortOrder: 87, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_values", construct: "values", facet: "benevolence", itemType: "likert", polarity: "positive", text: "O bem-estar das pessoas ao meu redor é mais importante do que resultados financeiros.", sortOrder: 88, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_values", construct: "values", facet: "self_direction", itemType: "likert", polarity: "positive", text: "Independência de pensamento e ação é fundamental para mim.", sortOrder: 89, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_values", construct: "values", facet: "security", itemType: "likert", polarity: "positive", text: "Estabilidade e previsibilidade são mais importantes do que aventura e risco.", sortOrder: 90, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_values", construct: "values", facet: "universalism", itemType: "likert", polarity: "positive", text: "Acredito que justiça social e igualdade devem guiar decisões organizacionais.", sortOrder: 91, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_values", construct: "values", facet: "power", itemType: "likert", polarity: "positive", text: "Ter influência e controle sobre recursos e pessoas é importante para mim.", sortOrder: 92, sourceNote: "autoral", isPublicDomain: false },
];

// ============ MODULE: CAREER FIT (RIASEC) ============

const careerItems = [
  { block: "mod_career", construct: "career_fit", facet: "realistic", itemType: "likert", polarity: "positive", text: "Prefiro trabalhar com coisas concretas: ferramentas, máquinas, dados tangíveis.", sortOrder: 93, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_career", construct: "career_fit", facet: "investigative", itemType: "likert", polarity: "positive", text: "Gosto de investigar problemas complexos e encontrar respostas baseadas em evidências.", sortOrder: 94, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_career", construct: "career_fit", facet: "artistic", itemType: "likert", polarity: "positive", text: "Valorizo ambientes que permitem expressão criativa e originalidade.", sortOrder: 95, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_career", construct: "career_fit", facet: "social", itemType: "likert", polarity: "positive", text: "Sinto-me realizado quando ajudo pessoas a se desenvolverem profissionalmente.", sortOrder: 96, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_career", construct: "career_fit", facet: "enterprising", itemType: "likert", polarity: "positive", text: "Gosto de liderar projetos, negociar e influenciar resultados de negócio.", sortOrder: 97, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_career", construct: "career_fit", facet: "conventional", itemType: "likert", polarity: "positive", text: "Prefiro ambientes com processos claros, regras definidas e estrutura organizada.", sortOrder: 98, sourceNote: "autoral", isPublicDomain: false },
];

// ============ MODULE: COLLABORATION & PSYCHOLOGICAL SAFETY ============

const collaborationItems = [
  { block: "mod_collaboration", construct: "collaboration", facet: "risk_taking", itemType: "likert", polarity: "positive", text: "Sinto-me seguro para assumir riscos interpessoais no meu time (ex.: discordar, propor ideias ousadas).", sortOrder: 99, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_collaboration", construct: "collaboration", facet: "feedback_culture", itemType: "likert", polarity: "positive", text: "No meu time, dar e receber feedback é algo natural e construtivo.", sortOrder: 100, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_collaboration", construct: "collaboration", facet: "error_learning", itemType: "likert", polarity: "positive", text: "Erros são tratados como oportunidades de aprendizado, não como motivo de punição.", sortOrder: 101, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_collaboration", construct: "collaboration", facet: "inclusion", itemType: "likert", polarity: "positive", text: "Todas as vozes são ouvidas e valorizadas nas decisões do meu time.", sortOrder: 102, sourceNote: "autoral", isPublicDomain: false },
  { block: "mod_collaboration", construct: "collaboration", facet: "vulnerability", itemType: "likert", polarity: "negative", text: "Tenho medo de parecer incompetente se pedir ajuda no trabalho.", sortOrder: 103, sourceNote: "autoral", isPublicDomain: false },
];

// ============ QUALITY CHECKS ============

const qualityItems = [
  { block: "quality_check", construct: "attention", facet: "attention_check", itemType: "attention_check", polarity: "positive", text: "Para esta pergunta, selecione a opção 'Concordo' para confirmar que está prestando atenção.", sortOrder: 104, sourceNote: "quality", keyJson: { expected: "4" } },
  { block: "quality_check", construct: "attention", facet: "attention_check", itemType: "attention_check", polarity: "positive", text: "Selecione 'Discordo totalmente' para esta pergunta de verificação.", sortOrder: 105, sourceNote: "quality", keyJson: { expected: "1" } },
  { block: "quality_check", construct: "consistency", facet: "consistency_check", itemType: "likert", polarity: "positive", text: "Consigo manter o foco em tarefas importantes até finalizá-las.", sortOrder: 106, sourceNote: "quality" },
  { block: "quality_check", construct: "consistency", facet: "consistency_check", itemType: "likert", polarity: "positive", text: "Sinto-me animado e de bom humor na maioria dos dias.", sortOrder: 107, sourceNote: "quality" },
];

// ============ MICRO-WORK SAMPLES ============

const microWorkItems = [
  {
    block: "core_leadership", construct: "leadership", facet: "decision_narrative", itemType: "micro_work_sample",
    text: "Descreva brevemente uma decisão difícil que você tomou no trabalho nos últimos 6 meses. O que estava em jogo? Como você decidiu? O que aconteceu?",
    sortOrder: 108, sourceNote: "autoral", isPublicDomain: false, expectedTimeSec: 120
  },
  {
    block: "mod_data", construct: "data_literacy", facet: "data_narrative", itemType: "micro_work_sample",
    text: "Conte uma situação em que você usou dados para tomar ou influenciar uma decisão. Que dados usou? Como apresentou? Qual foi o resultado?",
    sortOrder: 109, sourceNote: "autoral", isPublicDomain: false, expectedTimeSec: 120
  },
  {
    block: "core_communication", construct: "communication", facet: "conflict_narrative", itemType: "micro_work_sample",
    text: "Descreva um conflito ou desacordo profissional recente. Como você lidou com a situação? O que faria diferente hoje?",
    sortOrder: 110, sourceNote: "autoral", isPublicDomain: false, expectedTimeSec: 120
  },
];

// ============ RUN SEED ============

console.log("🌱 Seeding assessment item bank...");

const allItems = [
  ...bigFiveItems,
  ...communicationItems,
  ...leadershipItems,
  ...vitalityItems,
  ...innovationItems,
  ...dataItems,
  ...decisionItems,
  ...learningItems,
  ...executionItems,
  ...motivationItems,
  ...valuesItems,
  ...careerItems,
  ...collaborationItems,
  ...qualityItems,
  ...microWorkItems,
];

try {
  // Clear existing items first
  await connection.execute("DELETE FROM assessment_item_bank");
  console.log("  Cleared existing items.");

  await insertItems(allItems);
  console.log(`  ✅ Inserted ${allItems.length} items successfully.`);

  // Summary
  const blocks = {};
  for (const item of allItems) {
    blocks[item.block] = (blocks[item.block] || 0) + 1;
  }
  console.log("\n📊 Item distribution:");
  for (const [block, count] of Object.entries(blocks)) {
    console.log(`  ${block}: ${count} items`);
  }
} catch (error) {
  console.error("❌ Error seeding items:", error);
} finally {
  await connection.end();
  console.log("\n✅ Seed complete.");
}
