CREATE TABLE `assessment_item_bank` (
	`id` int AUTO_INCREMENT NOT NULL,
	`block` varchar(50) NOT NULL,
	`construct` varchar(100) NOT NULL,
	`facet` varchar(100),
	`itemType` enum('likert','sjt','micro_work_sample','attention_check') NOT NULL,
	`polarity` enum('positive','negative') NOT NULL DEFAULT 'positive',
	`text` text NOT NULL,
	`optionsJson` json,
	`keyJson` json,
	`dimension` varchar(100),
	`expectedTimeSec` int DEFAULT 15,
	`isPublicDomain` boolean DEFAULT true,
	`sourceNote` varchar(255),
	`sortOrder` int NOT NULL DEFAULT 0,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `assessment_item_bank_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `assessment_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`promptVersion` varchar(20) NOT NULL DEFAULT '1.0',
	`reportJson` json NOT NULL,
	`pdfUrl` text,
	`pdfKey` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `assessment_reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `assessment_responses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`itemId` int NOT NULL,
	`responseValue` text NOT NULL,
	`responseTimeMs` int,
	`respondedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `assessment_responses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `assessment_scores` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`block` varchar(50) NOT NULL,
	`construct` varchar(100) NOT NULL,
	`facet` varchar(100),
	`scoreRaw` decimal(6,3),
	`score0to100` decimal(5,2),
	`confidence` decimal(3,2),
	`flagsJson` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `assessment_scores_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `assessment_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`mode` enum('quick','complete') NOT NULL,
	`status` enum('in_progress','scoring','generating_report','completed','abandoned') NOT NULL DEFAULT 'in_progress',
	`version` varchar(20) NOT NULL DEFAULT '1.0',
	`currentRole` varchar(255),
	`seniority` varchar(100),
	`area` varchar(255),
	`segment` varchar(255),
	`primaryObjective` enum('promotion','transition','performance','leadership','data','innovation'),
	`contextDescription` text,
	`constraints` text,
	`selectedModules` json,
	`totalItems` int DEFAULT 0,
	`completedItems` int DEFAULT 0,
	`overallConfidence` decimal(3,2),
	`qualityFlags` json,
	`deviceMeta` json,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `assessment_sessions_id` PRIMARY KEY(`id`)
);
