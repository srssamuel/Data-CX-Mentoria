import { Link, useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import {
  BookOpen, GraduationCap, Award, BarChart3, Brain, Star,
  Lightbulb, HelpCircle, MessageCircle, Download, FileText,
  Home, ChevronLeft, ChevronRight, Sparkles, Users, Settings,
  Zap, Trophy, X, Menu, Radar, Route, Fingerprint
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface SidebarProps {
  stats: {
    totalModules: number;
    completedModules: number;
    totalTemplates: number;
    totalQuizzes: number;
    totalCertificates: number;
    radarCount: number;
    newCount: number;
  };
  trails: Array<{
    pilar: string;
    config: { shortName: string; color: string; gradient: string; icon: React.ReactNode };
    modules: any[];
    completedCount: number;
  }>;
  selectedSection: string;
  onSectionChange: (section: string) => void;
  userName?: string;
}

const SECTION_GROUPS: Array<{
  label: string;
  items: Array<{
    id: string;
    label: string;
    icon: any;
    countKey?: keyof SidebarProps['stats'];
    isNew?: boolean;
  }>;
}> = [
  {
    label: "APRENDIZADO",
    items: [
      { id: "dashboard", label: "Início", icon: Home },
      { id: "trilhas", label: "Trilhas", icon: BookOpen, countKey: "totalModules" as const },
      { id: "solucoes", label: "Soluções", icon: Zap, countKey: "totalTemplates" as const, isNew: true },
      { id: "quizzes", label: "Quizzes", icon: Trophy, countKey: "totalQuizzes" as const },
    ],
  },
  {
    label: "CONQUISTAS",
    items: [
      { id: "certificados", label: "Certificados", icon: GraduationCap, countKey: "totalCertificates" as const },
      { id: "progresso", label: "Meu Progresso", icon: BarChart3 },
      { id: "jornada-consultoria", label: "Minha Jornada", icon: Route, isNew: true },
      { id: "historico-radar", label: "Histórico Radar", icon: Radar, countKey: "radarCount" as const },
      { id: "avaliacao-perfil", label: "Avaliação de Perfil", icon: Fingerprint, isNew: true },
    ],
  },
  {
    label: "COMUNIDADE",
    items: [
      { id: "comunidade", label: "Comunidade", icon: Users },
      { id: "suporte", label: "Ajuda & Suporte", icon: HelpCircle },
    ],
  },
];

export default function MembersSidebar({ stats, trails, selectedSection, onSectionChange, userName }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const sidebarContent = (
    <div className={cn(
      "flex flex-col h-full bg-card/80 backdrop-blur-xl border-r border-border/50",
      collapsed ? "w-[68px]" : "w-[260px]"
    )}>
      {/* Header */}
      <div className="p-4 border-b border-border/50">
        <div className="flex items-center justify-between">
          {!collapsed && (
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-sm font-bold leading-tight">Protocolo Vértice</p>
                <p className="text-[10px] text-muted-foreground">Área de Membros</p>
              </div>
            </div>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 hidden md:flex"
            onClick={() => setCollapsed(!collapsed)}
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </Button>
          {/* Mobile close */}
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 md:hidden"
            onClick={() => setMobileOpen(false)}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Navigation Groups */}
      <div className="flex-1 overflow-y-auto py-3 px-2 space-y-5">
        {SECTION_GROUPS.map(group => (
          <div key={group.label}>
            {!collapsed && (
              <p className="text-[10px] font-semibold text-muted-foreground tracking-wider px-3 mb-2">
                {group.label}
              </p>
            )}
            <div className="space-y-0.5">
              {group.items.map(item => {
                const Icon = item.icon;
                const count = item.countKey ? stats[item.countKey] : undefined;
                const isActive = selectedSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSectionChange(item.id);
                      setMobileOpen(false);
                    }}
                    className={cn(
                      "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-200",
                      "hover:bg-muted/50",
                      isActive && "bg-primary/10 text-primary font-medium",
                      !isActive && "text-muted-foreground hover:text-foreground",
                      collapsed && "justify-center px-2"
                    )}
                    title={collapsed ? item.label : undefined}
                  >
                    <Icon className={cn("w-4 h-4 flex-shrink-0", isActive && "text-primary")} />
                    {!collapsed && (
                      <>
                        <span className="flex-1 text-left">{item.label}</span>
                        <div className="flex items-center gap-1.5">
                          {item.isNew && (
                            <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 text-[9px] px-1.5 py-0 h-4">
                              Novo
                            </Badge>
                          )}
                          {count !== undefined && count > 0 && (
                            <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-4 min-w-[20px] justify-center">
                              {count}
                            </Badge>
                          )}
                        </div>
                      </>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        {/* Trail shortcuts */}
        {!collapsed && trails.length > 0 && (
          <div>
            <p className="text-[10px] font-semibold text-muted-foreground tracking-wider px-3 mb-2">
              TRILHAS
            </p>
            <div className="space-y-0.5">
              {trails.map(trail => (
                <button
                  key={trail.pilar}
                  onClick={() => {
                    onSectionChange(`trilha-${trail.pilar}`);
                    setMobileOpen(false);
                  }}
                  className={cn(
                    "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-200",
                    "hover:bg-muted/50 text-muted-foreground hover:text-foreground",
                    selectedSection === `trilha-${trail.pilar}` && "bg-primary/10 text-primary font-medium"
                  )}
                >
                  <div className={cn("w-4 h-4 flex-shrink-0 flex items-center justify-center", trail.config.color)}>
                    {trail.config.icon}
                  </div>
                  <span className="flex-1 text-left">{trail.config.shortName}</span>
                  <span className="text-[10px] text-muted-foreground">
                    {trail.completedCount}/{trail.modules.length}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      {!collapsed && (
        <div className="p-3 border-t border-border/50">
          <Link href="/">
            <button className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors">
              <ChevronLeft className="w-3.5 h-3.5" />
              Voltar ao site
            </button>
          </Link>
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Mobile trigger */}
      <Button
        variant="outline"
        size="icon"
        className="fixed top-20 left-4 z-50 md:hidden h-10 w-10 rounded-full shadow-lg bg-card/90 backdrop-blur-sm"
        onClick={() => setMobileOpen(true)}
      >
        <Menu className="w-5 h-5" />
      </Button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="relative h-full">
            {sidebarContent}
          </div>
        </div>
      )}

      {/* Desktop sidebar */}
      <div className="hidden md:block sticky top-0 h-screen flex-shrink-0">
        {sidebarContent}
      </div>
    </>
  );
}
