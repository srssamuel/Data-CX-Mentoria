import { useState, useMemo, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  CheckCircle2,
  Clock,
  FileText,
  ListTodo,
  MessageSquare,
  Plus,
  Calendar,
  Upload,
  Send,
  Eye,
  Download,
  ChevronDown,
  ChevronUp,
  Video,
  ExternalLink,
  Trash2,
  Edit,
  Play,
  Lock,
  Link2,
  FileAudio,
  Type,
  Loader2,
  X,
  AlertCircle,
  GripVertical,
  Unlock,
} from "lucide-react";
import { Streamdown } from "streamdown";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

interface StageData {
  id: number;
  projectId: number;
  title: string;
  description: string | null;
  content: string | null;
  videoUrl: string | null;
  status: "locked" | "available" | "in_progress" | "completed";
  sortOrder: number;
  dueDate: Date | string | null;
  completedAt: Date | string | null;
  unlockedAt: Date | string | null;
  createdAt: Date | string;
  updatedAt: Date | string;
}

interface JornadaManagerProps {
  projectId: number;
  stages: StageData[];
  isAdmin: boolean;
}

export default function JornadaManager({ projectId, stages, isAdmin }: JornadaManagerProps) {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const [viewAsMember, setViewAsMember] = useState(false);
  const [expandedStage, setExpandedStage] = useState<number | null>(null);
  const [showAddStage, setShowAddStage] = useState(false);
  const [editingStage, setEditingStage] = useState<StageData | null>(null);

  const effectiveIsAdmin = isAdmin && !viewAsMember;

  // Stage mutations
  const createStage = trpc.consulting.createStage.useMutation({
    onSuccess: () => {
      utils.consulting.getStages.invalidate();
      utils.consulting.getProject.invalidate();
      setShowAddStage(false);
      toast.success("Etapa criada com sucesso!");
    },
  });

  const updateStage = trpc.consulting.updateStage.useMutation({
    onSuccess: () => {
      utils.consulting.getStages.invalidate();
      utils.consulting.getProject.invalidate();
      setEditingStage(null);
      toast.success("Etapa atualizada!");
    },
  });

  const deleteStage = trpc.consulting.deleteStage.useMutation({
    onSuccess: () => {
      utils.consulting.getStages.invalidate();
      utils.consulting.getProject.invalidate();
      toast.success("Etapa exclu\u00edda!");
    },
  });

  const reorderStages = trpc.consulting.reorderStages.useMutation({
    onSuccess: () => {
      utils.consulting.getStages.invalidate();
      utils.consulting.getProject.invalidate();
      toast.success("Ordem atualizada!");
    },
  });

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIndex = stages.findIndex(s => s.id === active.id);
    const newIndex = stages.findIndex(s => s.id === over.id);
    if (oldIndex === -1 || newIndex === -1) return;
    const reordered = arrayMove([...stages], oldIndex, newIndex);
    const stageOrders = reordered.map((s, i) => ({ id: s.id, sortOrder: i }));
    reorderStages.mutate({ stageOrders });
  };

  const completedStages = stages.filter(s => s.status === "completed").length;
  const progressPercent = stages.length > 0 ? Math.round((completedStages / stages.length) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Header with toggle */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Jornada de Acompanhamento</h3>
          <p className="text-sm text-muted-foreground">
            {completedStages} de {stages.length} etapas concluídas
          </p>
        </div>
        <div className="flex items-center gap-4">
          {isAdmin && (
            <div className="flex items-center gap-2 bg-secondary/50 rounded-lg px-3 py-2">
              <Eye className="h-4 w-4 text-muted-foreground" />
              <Label htmlFor="view-toggle" className="text-sm text-muted-foreground cursor-pointer">
                Ver como Membro
              </Label>
              <Switch
                id="view-toggle"
                checked={viewAsMember}
                onCheckedChange={setViewAsMember}
              />
            </div>
          )}
          {effectiveIsAdmin && (
            <Button size="sm" onClick={() => setShowAddStage(true)}>
              <Plus className="h-4 w-4 mr-1" /> Nova Etapa
            </Button>
          )}
        </div>
      </div>

      {/* Progress bar */}
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Progresso geral</span>
          <span className="font-medium text-foreground">{progressPercent}%</span>
        </div>
        <Progress value={progressPercent} className="h-2" />
      </div>

      {/* Assessment link */}
      {!effectiveIsAdmin && (
        <a href="/assessment" className="block">
          <div className="bg-gradient-to-r from-pink-500/10 to-primary/10 border border-pink-500/20 rounded-xl p-4 hover:border-pink-500/40 transition-all cursor-pointer group">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-pink-500/10 flex items-center justify-center">
                  <span className="text-lg">🧠</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground group-hover:text-pink-400 transition-colors">Avaliação de Perfil Profissional</p>
                  <p className="text-xs text-muted-foreground">Descubra seu perfil com análise científica + IA</p>
                </div>
              </div>
              <ExternalLink className="h-4 w-4 text-muted-foreground group-hover:text-pink-400 transition-colors" />
            </div>
          </div>
        </a>
      )}

      {/* View mode indicator */}
      {isAdmin && viewAsMember && (
        <div className="bg-primary/10 border border-primary/20 rounded-lg px-4 py-3 flex items-center gap-2">
          <Eye className="h-4 w-4 text-primary" />
          <span className="text-sm text-primary font-medium">
            Visualizando como membro — clique no toggle para voltar à visão Admin
          </span>
        </div>
      )}

      {/* Stages list */}
      {stages.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <ListTodo className="h-12 w-12 text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground">Nenhuma etapa criada ainda.</p>
            {effectiveIsAdmin && (
              <Button className="mt-4" size="sm" onClick={() => setShowAddStage(true)}>
                <Plus className="h-4 w-4 mr-1" /> Criar Primeira Etapa
              </Button>
            )}
          </CardContent>
        </Card>
      ) : effectiveIsAdmin ? (
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
          <SortableContext items={stages.map(s => s.id)} strategy={verticalListSortingStrategy}>
            <div className="space-y-3">
              {stages.map((stage, index) => (
                <SortableStageCard
                  key={stage.id}
                  stage={stage}
                  index={index}
                  projectId={projectId}
                  isAdmin={effectiveIsAdmin}
                  isExpanded={expandedStage === stage.id}
                  onToggle={() => setExpandedStage(expandedStage === stage.id ? null : stage.id)}
                  onEdit={() => setEditingStage(stage)}
                  onDelete={() => {
                    if (confirm("Tem certeza que deseja excluir esta etapa?")) {
                      deleteStage.mutate({ id: stage.id });
                    }
                  }}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      ) : (
        <div className="space-y-3">
          {stages.map((stage, index) => (
            <StageCard
              key={stage.id}
              stage={stage}
              index={index}
              projectId={projectId}
              isAdmin={effectiveIsAdmin}
              isExpanded={expandedStage === stage.id}
              onToggle={() => setExpandedStage(expandedStage === stage.id ? null : stage.id)}
              onEdit={() => setEditingStage(stage)}
              onDelete={() => {
                if (confirm("Tem certeza que deseja excluir esta etapa?")) {
                  deleteStage.mutate({ id: stage.id });
                }
              }}
            />
          ))}
        </div>
      )}

      {/* Add Stage Dialog */}
      <StageFormDialog
        open={showAddStage}
        onOpenChange={setShowAddStage}
        projectId={projectId}
        onSubmit={(data) => createStage.mutate(data)}
        isLoading={createStage.isPending}
        title="Nova Etapa"
      />

      {/* Edit Stage Dialog */}
      {editingStage && (
        <StageFormDialog
          open={!!editingStage}
          onOpenChange={(open) => !open && setEditingStage(null)}
          projectId={projectId}
          stage={editingStage}
          onSubmit={(data) => updateStage.mutate({ id: editingStage.id, data })}
          isLoading={updateStage.isPending}
          title="Editar Etapa"
        />
      )}
    </div>
  );
}

// ============ SORTABLE STAGE CARD (Admin drag-and-drop) ============

function SortableStageCard(props: {
  stage: StageData;
  index: number;
  projectId: number;
  isAdmin: boolean;
  isExpanded: boolean;
  onToggle: () => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: props.stage.id,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    zIndex: isDragging ? 50 : undefined,
  };

  return (
    <div ref={setNodeRef} style={style}>
      <StageCard
        {...props}
        dragHandleProps={{ ...attributes, ...listeners }}
      />
    </div>
  );
}

// ============ STAGE CARD ============

function StageCard({
  stage,
  index,
  projectId,
  isAdmin,
  isExpanded,
  onToggle,
  onEdit,
  onDelete,
  dragHandleProps,
}: {
  stage: StageData;
  index: number;
  projectId: number;
  isAdmin: boolean;
  isExpanded: boolean;
  onToggle: () => void;
  onEdit: () => void;
  onDelete: () => void;
  dragHandleProps?: Record<string, any>;
}) {
  const statusConfig = {
    locked: { icon: Lock, color: "text-muted-foreground", bg: "bg-muted", label: "Bloqueada" },
    available: { icon: Play, color: "text-blue-400", bg: "bg-blue-500/10", label: "Disponível" },
    in_progress: { icon: Clock, color: "text-yellow-400", bg: "bg-yellow-500/10", label: "Em Andamento" },
    completed: { icon: CheckCircle2, color: "text-green-400", bg: "bg-green-500/10", label: "Concluída" },
  };

  const config = statusConfig[stage.status] || statusConfig.available;
  const StatusIcon = config.icon;

  return (
    <Card className={`transition-all ${isExpanded ? "ring-1 ring-primary/30" : ""}`}>
      <div
        className="flex items-center gap-4 p-4 cursor-pointer hover:bg-secondary/30 transition-colors rounded-t-lg"
        onClick={onToggle}
      >
        {/* Drag handle (admin only) */}
        {isAdmin && dragHandleProps && (
          <div
            className="cursor-grab active:cursor-grabbing p-1 rounded hover:bg-secondary/50 text-muted-foreground"
            {...dragHandleProps}
            onClick={(e) => e.stopPropagation()}
          >
            <GripVertical className="h-5 w-5" />
          </div>
        )}

        {/* Step number */}
        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold ${config.bg} ${config.color}`}>
          {stage.status === "completed" ? <CheckCircle2 className="h-5 w-5" /> : index + 1}
        </div>

        {/* Title and meta */}
        <div className="flex-1 min-w-0">
          <h4 className="font-semibold text-foreground truncate">{stage.title}</h4>
          <div className="flex items-center gap-3 mt-1">
            <Badge variant="outline" className={`${config.color} text-xs`}>
              {config.label}
            </Badge>
            {stage.dueDate && (
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                {new Date(stage.dueDate).toLocaleDateString("pt-BR")}
              </span>
            )}
          </div>
        </div>

        {/* Admin actions */}
        {isAdmin && (
          <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
            <Button variant="ghost" size="sm" onClick={onEdit}>
              <Edit className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={onDelete}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        )}

        {/* Expand icon */}
        {isExpanded ? <ChevronUp className="h-5 w-5 text-muted-foreground" /> : <ChevronDown className="h-5 w-5 text-muted-foreground" />}
      </div>

      {/* Expanded content */}
      {isExpanded && (
        <div className="border-t border-border">
          <StageExpandedContent stage={stage} projectId={projectId} isAdmin={isAdmin} />
        </div>
      )}
    </Card>
  );
}

// ============ STAGE EXPANDED CONTENT ============

function StageExpandedContent({ stage, projectId, isAdmin }: { stage: StageData; projectId: number; isAdmin: boolean }) {
  const { user } = useAuth();
  const utils = trpc.useUtils();

  // Fetch full stage detail
  const { data: detail, isLoading } = trpc.consulting.getFullStageDetail.useQuery(
    { stageId: stage.id },
    { enabled: !!stage.id }
  );

  const updateProgress = trpc.consulting.updateMemberProgress.useMutation({
    onSuccess: (_data, variables) => {
      utils.consulting.getFullStageDetail.invalidate({ stageId: stage.id });
      utils.consulting.getStages.invalidate();
      utils.consulting.getProject.invalidate();
      if (variables.status === 'completed') {
        toast.success("Etapa conclu\u00edda! A pr\u00f3xima etapa foi desbloqueada automaticamente.", {
          icon: <Unlock className="h-4 w-4 text-green-400" />,
          duration: 4000,
        });
      } else {
        toast.success("Progresso atualizado!");
      }
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const memberStatus = detail?.memberProgress?.status || "not_started";

  return (
    <div className="p-4 space-y-6">
      {/* Stage description */}
      {stage.description && (
        <div className="text-sm text-muted-foreground">
          <Streamdown>{stage.description}</Streamdown>
        </div>
      )}

      {/* Stage content (markdown) */}
      {stage.content && (
        <div className="prose prose-invert prose-sm max-w-none">
          <Streamdown>{stage.content}</Streamdown>
        </div>
      )}

      {/* Video embed */}
      {stage.videoUrl && (
        <div className="rounded-lg overflow-hidden bg-black/30">
          <div className="aspect-video">
            <iframe
              src={stage.videoUrl.replace("watch?v=", "embed/")}
              className="w-full h-full"
              allowFullScreen
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            />
          </div>
        </div>
      )}

      {/* Contents section */}
      <StageContentsSection stageId={stage.id} projectId={projectId} isAdmin={isAdmin} />

      {/* Checklist section */}
      <StageChecklistSection stageId={stage.id} projectId={projectId} isAdmin={isAdmin} />

      {/* Deliverables section */}
      <StageDeliverablesSection stageId={stage.id} projectId={projectId} isAdmin={isAdmin} />

      {/* Comments section */}
      <StageCommentsSection stageId={stage.id} projectId={projectId} />

      {/* Member progress actions */}
      {!isAdmin && (
        <div className="flex items-center gap-3 pt-4 border-t border-border">
          {memberStatus === "not_started" && (
            <Button
              onClick={() => updateProgress.mutate({ stageId: stage.id, status: "in_progress" })}
              disabled={updateProgress.isPending}
            >
              <Play className="h-4 w-4 mr-2" /> Iniciar Etapa
            </Button>
          )}
          {memberStatus === "in_progress" && (
            <Button
              onClick={() => updateProgress.mutate({ stageId: stage.id, status: "completed" })}
              disabled={updateProgress.isPending}
              className="bg-green-600 hover:bg-green-700"
            >
              <CheckCircle2 className="h-4 w-4 mr-2" /> Marcar como Concluída
            </Button>
          )}
          {memberStatus === "completed" && (
            <div className="flex items-center gap-3">
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                <CheckCircle2 className="h-3 w-3 mr-1" /> Concluída
              </Badge>
              <Button
                variant="outline"
                size="sm"
                onClick={() => updateProgress.mutate({ stageId: stage.id, status: "in_progress" })}
                disabled={updateProgress.isPending}
              >
                Reabrir
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ============ STAGE CONTENTS SECTION ============

function StageContentsSection({ stageId, projectId, isAdmin }: { stageId: number; projectId: number; isAdmin: boolean }) {
  const utils = trpc.useUtils();
  const [showAddContent, setShowAddContent] = useState(false);
  const [contentType, setContentType] = useState<"document" | "video" | "link" | "text" | "audio">("document");
  const [contentTitle, setContentTitle] = useState("");
  const [contentDescription, setContentDescription] = useState("");
  const [contentUrl, setContentUrl] = useState("");
  const [textContent, setTextContent] = useState("");
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: contents = [] } = trpc.consulting.getStageContents.useQuery({ stageId });

  const createContent = trpc.consulting.createStageContent.useMutation({
    onSuccess: () => {
      utils.consulting.getStageContents.invalidate({ stageId });
      utils.consulting.getFullStageDetail.invalidate({ stageId });
      resetForm();
      toast.success("Conteúdo adicionado!");
    },
  });

  const deleteContent = trpc.consulting.deleteStageContent.useMutation({
    onSuccess: () => {
      utils.consulting.getStageContents.invalidate({ stageId });
      utils.consulting.getFullStageDetail.invalidate({ stageId });
      toast.success("Conteúdo removido!");
    },
  });

  const uploadFile = trpc.consulting.uploadStageFile.useMutation();

  const resetForm = () => {
    setShowAddContent(false);
    setContentTitle("");
    setContentDescription("");
    setContentUrl("");
    setTextContent("");
    setContentType("document");
  };

  const handleFileUpload = async (file: File) => {
    setUploading(true);
    try {
      const reader = new FileReader();
      const base64 = await new Promise<string>((resolve) => {
        reader.onload = () => {
          const result = reader.result as string;
          resolve(result.split(",")[1]);
        };
        reader.readAsDataURL(file);
      });

      const result = await uploadFile.mutateAsync({
        fileName: file.name,
        fileData: base64,
        mimeType: file.type,
      });

      createContent.mutate({
        stageId,
        projectId,
        title: contentTitle || file.name,
        description: contentDescription || undefined,
        type: "document",
        fileUrl: result.url,
        fileKey: result.fileKey,
        mimeType: file.type,
        fileSize: result.fileSize,
        sortOrder: contents.length,
      });
    } catch (error) {
      toast.error("Erro ao fazer upload do arquivo");
    } finally {
      setUploading(false);
    }
  };

  const handleAddContent = () => {
    if (!contentTitle.trim()) {
      toast.error("Título é obrigatório");
      return;
    }

    const data: any = {
      stageId,
      projectId,
      title: contentTitle,
      description: contentDescription || undefined,
      type: contentType,
      sortOrder: contents.length,
    };

    if (contentType === "video") data.videoUrl = contentUrl;
    if (contentType === "link") data.linkUrl = contentUrl;
    if (contentType === "text") data.textContent = textContent;
    if (contentType === "audio") data.audioUrl = contentUrl;

    createContent.mutate(data);
  };

  const contentTypeConfig = {
    document: { icon: FileText, label: "Documento", color: "text-blue-400" },
    video: { icon: Video, label: "Vídeo", color: "text-red-400" },
    link: { icon: Link2, label: "Link", color: "text-purple-400" },
    text: { icon: Type, label: "Texto", color: "text-green-400" },
    audio: { icon: FileAudio, label: "Áudio", color: "text-orange-400" },
  };

  if (contents.length === 0 && !isAdmin) return null;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h5 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <FileText className="h-4 w-4 text-primary" /> Conteúdos
          {contents.length > 0 && (
            <Badge variant="secondary" className="text-xs">{contents.length}</Badge>
          )}
        </h5>
        {isAdmin && (
          <Button variant="outline" size="sm" onClick={() => setShowAddContent(true)}>
            <Plus className="h-3 w-3 mr-1" /> Adicionar
          </Button>
        )}
      </div>

      {/* Content list */}
      {contents.map((content: any) => {
        const config = contentTypeConfig[content.type as keyof typeof contentTypeConfig] || contentTypeConfig.text;
        const Icon = config.icon;

        return (
          <div key={content.id} className="flex items-center gap-3 p-3 bg-secondary/30 rounded-lg group">
            <div className={`p-2 rounded-lg bg-secondary ${config.color}`}>
              <Icon className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">{content.title}</p>
              {content.description && (
                <p className="text-xs text-muted-foreground truncate">{content.description}</p>
              )}
            </div>

            {/* Action buttons based on type */}
            <div className="flex items-center gap-1">
              {content.type === "document" && content.fileUrl && (
                <Button variant="ghost" size="sm" asChild>
                  <a href={content.fileUrl} target="_blank" rel="noopener noreferrer" download>
                    <Download className="h-4 w-4" />
                  </a>
                </Button>
              )}
              {content.type === "video" && content.videoUrl && (
                <Button variant="ghost" size="sm" asChild>
                  <a href={content.videoUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </Button>
              )}
              {content.type === "link" && content.linkUrl && (
                <Button variant="ghost" size="sm" asChild>
                  <a href={content.linkUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </Button>
              )}
              {content.type === "audio" && content.audioUrl && (
                <audio controls className="h-8 max-w-[200px]">
                  <source src={content.audioUrl} />
                </audio>
              )}
              {isAdmin && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-destructive hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => {
                    if (confirm("Remover este conteúdo?")) {
                      deleteContent.mutate({ id: content.id });
                    }
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        );
      })}

      {/* Inline text content display */}
      {contents
        .filter((c: any) => c.type === "text" && c.textContent)
        .map((c: any) => (
          <div key={`text-${c.id}`} className="p-3 bg-secondary/20 rounded-lg border border-border/50">
            <p className="text-xs font-medium text-muted-foreground mb-1">{c.title}</p>
            <div className="prose prose-invert prose-sm max-w-none">
              <Streamdown>{c.textContent}</Streamdown>
            </div>
          </div>
        ))}

      {/* Add content form */}
      {isAdmin && showAddContent && (
        <Card className="border-primary/30">
          <CardContent className="p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h6 className="text-sm font-semibold">Novo Conteúdo</h6>
              <Button variant="ghost" size="sm" onClick={resetForm}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="grid grid-cols-5 gap-2">
              {(Object.entries(contentTypeConfig) as [string, any][]).map(([type, cfg]) => {
                const TypeIcon = cfg.icon;
                return (
                  <Button
                    key={type}
                    variant={contentType === type ? "default" : "outline"}
                    size="sm"
                    className="flex flex-col gap-1 h-auto py-2"
                    onClick={() => setContentType(type as any)}
                  >
                    <TypeIcon className="h-4 w-4" />
                    <span className="text-[10px]">{cfg.label}</span>
                  </Button>
                );
              })}
            </div>

            <Input
              placeholder="Título do conteúdo"
              value={contentTitle}
              onChange={(e) => setContentTitle(e.target.value)}
            />

            <Input
              placeholder="Descrição (opcional)"
              value={contentDescription}
              onChange={(e) => setContentDescription(e.target.value)}
            />

            {contentType === "document" && (
              <div>
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileUpload(file);
                  }}
                />
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                >
                  {uploading ? (
                    <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Enviando...</>
                  ) : (
                    <><Upload className="h-4 w-4 mr-2" /> Selecionar Arquivo</>
                  )}
                </Button>
              </div>
            )}

            {(contentType === "video" || contentType === "link" || contentType === "audio") && (
              <Input
                placeholder={
                  contentType === "video" ? "URL do vídeo (YouTube, Vimeo...)" :
                  contentType === "audio" ? "URL do áudio" :
                  "URL do link"
                }
                value={contentUrl}
                onChange={(e) => setContentUrl(e.target.value)}
              />
            )}

            {contentType === "text" && (
              <Textarea
                placeholder="Conteúdo em texto (suporta Markdown)"
                value={textContent}
                onChange={(e) => setTextContent(e.target.value)}
                rows={5}
              />
            )}

            {contentType !== "document" && (
              <Button
                onClick={handleAddContent}
                disabled={createContent.isPending || !contentTitle.trim()}
                className="w-full"
              >
                {createContent.isPending ? (
                  <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Salvando...</>
                ) : (
                  <><Plus className="h-4 w-4 mr-2" /> Adicionar Conteúdo</>
                )}
              </Button>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ============ STAGE CHECKLIST SECTION ============

function StageChecklistSection({ stageId, projectId, isAdmin }: { stageId: number; projectId: number; isAdmin: boolean }) {
  const utils = trpc.useUtils();
  const [showAddItem, setShowAddItem] = useState(false);
  const [newItemTitle, setNewItemTitle] = useState("");
  const [newItemDescription, setNewItemDescription] = useState("");

  const { data: detail } = trpc.consulting.getFullStageDetail.useQuery({ stageId });
  const checklist = detail?.checklist || [];
  const checklistProgress = detail?.checklistProgress || { total: 0, completed: 0 };

  const createItem = trpc.consulting.createChecklistItem.useMutation({
    onSuccess: () => {
      utils.consulting.getChecklistItems.invalidate({ stageId });
      utils.consulting.getFullStageDetail.invalidate({ stageId });
      setNewItemTitle("");
      setNewItemDescription("");
      setShowAddItem(false);
      toast.success("Item adicionado!");
    },
  });

  const deleteItem = trpc.consulting.deleteChecklistItem.useMutation({
    onSuccess: () => {
      utils.consulting.getChecklistItems.invalidate({ stageId });
      utils.consulting.getFullStageDetail.invalidate({ stageId });
      toast.success("Item removido!");
    },
  });

  const toggleItem = trpc.consulting.toggleChecklist.useMutation({
    onSuccess: () => {
      utils.consulting.getFullStageDetail.invalidate({ stageId });
    },
  });

  if (checklist.length === 0 && !isAdmin) return null;

  const progressPercent = checklistProgress.total > 0
    ? Math.round((checklistProgress.completed / checklistProgress.total) * 100)
    : 0;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h5 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <ListTodo className="h-4 w-4 text-primary" /> Checklist
          {checklist.length > 0 && (
            <span className="text-xs text-muted-foreground">
              ({checklistProgress.completed}/{checklistProgress.total})
            </span>
          )}
        </h5>
        {isAdmin && (
          <Button variant="outline" size="sm" onClick={() => setShowAddItem(true)}>
            <Plus className="h-3 w-3 mr-1" /> Adicionar
          </Button>
        )}
      </div>

      {checklist.length > 0 && (
        <Progress value={progressPercent} className="h-1.5" />
      )}

      {checklist.map((item: any) => (
        <div key={item.id} className="flex items-start gap-3 p-2 rounded-lg hover:bg-secondary/30 transition-colors group">
          <Checkbox
            checked={item.completed}
            onCheckedChange={(checked) => {
              toggleItem.mutate({ checklistItemId: item.id, completed: !!checked });
            }}
            disabled={isAdmin}
            className="mt-0.5"
          />
          <div className="flex-1 min-w-0">
            <p className={`text-sm ${item.completed ? "line-through text-muted-foreground" : "text-foreground"}`}>
              {item.title}
            </p>
            {item.description && (
              <p className="text-xs text-muted-foreground mt-0.5">{item.description}</p>
            )}
          </div>
          {isAdmin && (
            <Button
              variant="ghost"
              size="sm"
              className="text-destructive hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
              onClick={() => {
                if (confirm("Remover este item?")) {
                  deleteItem.mutate({ id: item.id });
                }
              }}
            >
              <Trash2 className="h-3 w-3" />
            </Button>
          )}
        </div>
      ))}

      {/* Add item form */}
      {isAdmin && showAddItem && (
        <div className="flex flex-col gap-2 p-3 bg-secondary/30 rounded-lg">
          <Input
            placeholder="Título do item"
            value={newItemTitle}
            onChange={(e) => setNewItemTitle(e.target.value)}
            autoFocus
          />
          <Input
            placeholder="Descrição (opcional)"
            value={newItemDescription}
            onChange={(e) => setNewItemDescription(e.target.value)}
          />
          <div className="flex gap-2">
            <Button
              size="sm"
              onClick={() => {
                if (newItemTitle.trim()) {
                  createItem.mutate({
                    stageId,
                    projectId,
                    title: newItemTitle,
                    description: newItemDescription || undefined,
                    sortOrder: checklist.length,
                  });
                }
              }}
              disabled={createItem.isPending || !newItemTitle.trim()}
            >
              {createItem.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : "Adicionar"}
            </Button>
            <Button variant="outline" size="sm" onClick={() => setShowAddItem(false)}>
              Cancelar
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============ STAGE DELIVERABLES SECTION ============

function StageDeliverablesSection({ stageId, projectId, isAdmin }: { stageId: number; projectId: number; isAdmin: boolean }) {
  const utils = trpc.useUtils();
  const [showUpload, setShowUpload] = useState(false);
  const [deliverableTitle, setDeliverableTitle] = useState("");
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: deliverables = [] } = trpc.consulting.getDeliverables.useQuery({ stageId });

  const createDeliverable = trpc.consulting.createDeliverable.useMutation({
    onSuccess: () => {
      utils.consulting.getDeliverables.invalidate({ stageId });
      utils.consulting.getFullStageDetail.invalidate({ stageId });
      setDeliverableTitle("");
      setShowUpload(false);
      toast.success("Entrega adicionada!");
    },
  });

  const deleteDeliverable = trpc.consulting.deleteDeliverable.useMutation({
    onSuccess: () => {
      utils.consulting.getDeliverables.invalidate({ stageId });
      utils.consulting.getFullStageDetail.invalidate({ stageId });
      toast.success("Entrega removida!");
    },
  });

  const uploadFile = trpc.consulting.uploadStageFile.useMutation();

  const handleFileUpload = async (file: File) => {
    setUploading(true);
    try {
      const reader = new FileReader();
      const base64 = await new Promise<string>((resolve) => {
        reader.onload = () => {
          const result = reader.result as string;
          resolve(result.split(",")[1]);
        };
        reader.readAsDataURL(file);
      });

      const result = await uploadFile.mutateAsync({
        fileName: file.name,
        fileData: base64,
        mimeType: file.type,
      });

      createDeliverable.mutate({
        stageId,
        projectId,
        title: deliverableTitle || file.name,
        description: file.name,
        fileUrl: result.url,
        fileKey: result.fileKey,
        mimeType: file.type,
        fileSize: result.fileSize,
      });
    } catch (error) {
      toast.error("Erro ao fazer upload");
    } finally {
      setUploading(false);
    }
  };

  if (deliverables.length === 0 && !isAdmin) return null;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h5 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <Upload className="h-4 w-4 text-primary" /> Entregas
          {deliverables.length > 0 && (
            <Badge variant="secondary" className="text-xs">{deliverables.length}</Badge>
          )}
        </h5>
        {isAdmin && (
          <Button variant="outline" size="sm" onClick={() => setShowUpload(true)}>
            <Plus className="h-3 w-3 mr-1" /> Adicionar
          </Button>
        )}
      </div>

      {deliverables.map((d: any) => (
        <div key={d.id} className="flex items-center gap-3 p-3 bg-secondary/30 rounded-lg group">
          <FileText className="h-4 w-4 text-blue-400 shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate">{d.title || d.fileName}</p>
            {d.fileName && (
              <p className="text-xs text-muted-foreground">{d.fileName}</p>
            )}
          </div>
          <div className="flex items-center gap-1">
            {d.fileUrl && (
              <Button variant="ghost" size="sm" asChild>
                <a href={d.fileUrl} target="_blank" rel="noopener noreferrer" download>
                  <Download className="h-4 w-4" />
                </a>
              </Button>
            )}
            {isAdmin && (
              <Button
                variant="ghost"
                size="sm"
                className="text-destructive hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => {
                  if (confirm("Remover esta entrega?")) {
                    deleteDeliverable.mutate({ id: d.id });
                  }
                }}
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            )}
          </div>
        </div>
      ))}

      {/* Upload form */}
      {isAdmin && showUpload && (
        <div className="flex flex-col gap-2 p-3 bg-secondary/30 rounded-lg">
          <Input
            placeholder="Título da entrega"
            value={deliverableTitle}
            onChange={(e) => setDeliverableTitle(e.target.value)}
          />
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) handleFileUpload(file);
            }}
          />
          <Button
            variant="outline"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
          >
            {uploading ? (
              <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Enviando...</>
            ) : (
              <><Upload className="h-4 w-4 mr-2" /> Selecionar Arquivo</>
            )}
          </Button>
          <Button variant="outline" size="sm" onClick={() => setShowUpload(false)}>
            Cancelar
          </Button>
        </div>
      )}
    </div>
  );
}

// ============ STAGE COMMENTS SECTION ============

function StageCommentsSection({ stageId, projectId }: { stageId: number; projectId: number }) {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const [message, setMessage] = useState("");

  const { data: comments = [] } = trpc.consulting.getComments.useQuery({ stageId });

  const addComment = trpc.consulting.addComment.useMutation({
    onSuccess: () => {
      utils.consulting.getComments.invalidate({ stageId });
      utils.consulting.getFullStageDetail.invalidate({ stageId });
      setMessage("");
      toast.success("Comentário adicionado!");
    },
  });

  const deleteComment = trpc.consulting.deleteComment.useMutation({
    onSuccess: () => {
      utils.consulting.getComments.invalidate({ stageId });
      utils.consulting.getFullStageDetail.invalidate({ stageId });
      toast.success("Comentário removido!");
    },
  });

  return (
    <div className="space-y-3">
      <h5 className="text-sm font-semibold text-foreground flex items-center gap-2">
        <MessageSquare className="h-4 w-4 text-primary" /> Comentários e Dúvidas
        {comments.length > 0 && (
          <Badge variant="secondary" className="text-xs">{comments.length}</Badge>
        )}
      </h5>

      {/* Comments list */}
      {comments.map((comment: any) => (
        <div key={comment.id} className={`p-3 rounded-lg ${comment.isAdminReply ? "bg-primary/10 border border-primary/20" : "bg-secondary/30"}`}>
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-foreground">
                {comment.userName || "Usuário"}
              </span>
              {comment.isAdminReply && (
                <Badge variant="outline" className="text-xs text-primary border-primary/30">Admin</Badge>
              )}
              {comment.userRole === "admin" && !comment.isAdminReply && (
                <Badge variant="outline" className="text-xs text-primary border-primary/30">Admin</Badge>
              )}
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">
                {new Date(comment.createdAt).toLocaleDateString("pt-BR", {
                  day: "2-digit",
                  month: "short",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </span>
              {(user?.role === "admin" || comment.userId === user?.id) && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 text-destructive hover:text-destructive"
                  onClick={() => {
                    if (confirm("Remover este comentário?")) {
                      deleteComment.mutate({ id: comment.id });
                    }
                  }}
                >
                  <X className="h-3 w-3" />
                </Button>
              )}
            </div>
          </div>
          <p className="text-sm text-muted-foreground">{comment.message}</p>
        </div>
      ))}

      {/* Add comment form */}
      <div className="flex gap-2">
        <Textarea
          placeholder="Escreva um comentário ou dúvida..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          rows={2}
          className="flex-1"
        />
        <Button
          size="sm"
          className="self-end"
          onClick={() => {
            if (message.trim()) {
              addComment.mutate({ stageId, projectId, message: message.trim() });
            }
          }}
          disabled={addComment.isPending || !message.trim()}
        >
          {addComment.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </Button>
      </div>
    </div>
  );
}

// ============ STAGE FORM DIALOG ============

function StageFormDialog({
  open,
  onOpenChange,
  projectId,
  stage,
  onSubmit,
  isLoading,
  title,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  projectId: number;
  stage?: StageData;
  onSubmit: (data: any) => void;
  isLoading: boolean;
  title: string;
}) {
  const [formTitle, setFormTitle] = useState(stage?.title || "");
  const [formDescription, setFormDescription] = useState(stage?.description || "");
  const [formContent, setFormContent] = useState(stage?.content || "");
  const [formVideoUrl, setFormVideoUrl] = useState(stage?.videoUrl || "");
  const [formStatus, setFormStatus] = useState<string>(stage?.status || "available");
  const [formDueDate, setFormDueDate] = useState(
    stage?.dueDate ? new Date(stage.dueDate).toISOString().split("T")[0] : ""
  );

  const handleSubmit = () => {
    if (!formTitle.trim()) {
      toast.error("Título é obrigatório");
      return;
    }

    const data: any = {
      projectId,
      title: formTitle,
      description: formDescription || undefined,
      content: formContent || undefined,
      videoUrl: formVideoUrl || undefined,
      status: formStatus,
      dueDate: formDueDate || undefined,
    };

    onSubmit(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Título *</Label>
            <Input
              placeholder="Ex: Diagnóstico Inicial"
              value={formTitle}
              onChange={(e) => setFormTitle(e.target.value)}
            />
          </div>

          <div>
            <Label>Descrição</Label>
            <Textarea
              placeholder="Descrição breve da etapa..."
              value={formDescription}
              onChange={(e) => setFormDescription(e.target.value)}
              rows={3}
            />
          </div>

          <div>
            <Label>Conteúdo (Markdown)</Label>
            <Textarea
              placeholder="Conteúdo detalhado da etapa (suporta Markdown)..."
              value={formContent}
              onChange={(e) => setFormContent(e.target.value)}
              rows={5}
            />
          </div>

          <div>
            <Label>URL do Vídeo</Label>
            <Input
              placeholder="https://youtube.com/watch?v=..."
              value={formVideoUrl}
              onChange={(e) => setFormVideoUrl(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Status</Label>
              <Select value={formStatus} onValueChange={setFormStatus}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="locked">Bloqueada</SelectItem>
                  <SelectItem value="available">Disponível</SelectItem>
                  <SelectItem value="in_progress">Em Andamento</SelectItem>
                  <SelectItem value="completed">Concluída</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Prazo</Label>
              <Input
                type="date"
                value={formDueDate}
                onChange={(e) => setFormDueDate(e.target.value)}
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSubmit} disabled={isLoading || !formTitle.trim()}>
              {isLoading ? (
                <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Salvando...</>
              ) : (
                stage ? "Salvar Alterações" : "Criar Etapa"
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
