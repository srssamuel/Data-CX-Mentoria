import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, BarChart3, TrendingUp, TrendingDown, Minus, ArrowLeft, CheckCircle2 } from "lucide-react";

const BLOCK_INFO: Record<string, { label: string; icon: string }> = {
  core_personality: { label: "Personalidade", icon: "🧠" },
  core_communication: { label: "Comunicação", icon: "💬" },
  core_leadership: { label: "Liderança", icon: "👑" },
  core_vitality: { label: "Vitalidade", icon: "💚" },
  mod_innovation: { label: "Inovação", icon: "💡" },
  mod_data: { label: "Data Literacy", icon: "📊" },
  mod_decision: { label: "Decisão", icon: "⚖️" },
  mod_learning: { label: "Learning Agility", icon: "🔄" },
  mod_execution: { label: "Execução", icon: "🎯" },
  mod_motivation: { label: "Motivadores", icon: "🔥" },
  mod_values: { label: "Valores", icon: "🧭" },
  mod_career: { label: "Career Fit", icon: "🎓" },
  mod_collaboration: { label: "Colaboração", icon: "🤝" },
};

const SESSION_COLORS = [
  { bg: "bg-primary", text: "text-primary", border: "border-primary", hex: "#6366f1" },
  { bg: "bg-emerald-500", text: "text-emerald-500", border: "border-emerald-500", hex: "#10b981" },
  { bg: "bg-amber-500", text: "text-amber-500", border: "border-amber-500", hex: "#f59e0b" },
];

export default function AssessmentComparison({ onBack }: { onBack: () => void }) {
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const { data: sessions, isLoading: loadingSessions } = trpc.assessment.getCompletedSessions.useQuery();
  const { data: comparison, isLoading: loadingComparison } = trpc.assessment.compareScores.useQuery(
    { sessionIds: selectedIds },
    { enabled: selectedIds.length >= 1 }
  );

  const toggleSession = (id: number) => {
    setSelectedIds(prev => {
      if (prev.includes(id)) return prev.filter(x => x !== id);
      if (prev.length >= 3) return prev;
      return [...prev, id];
    });
  };

  if (loadingSessions) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!sessions || sessions.length < 2) {
    return (
      <div className="container max-w-4xl py-8">
        <Button variant="ghost" onClick={onBack} className="mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
        </Button>
        <Card>
          <CardContent className="p-8 text-center">
            <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">Comparativo não disponível</h3>
            <p className="text-sm text-muted-foreground">
              Você precisa ter pelo menos 2 avaliações concluídas para comparar resultados.
              Complete mais avaliações para acompanhar sua evolução.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Build comparison data
  const comparisonData = useMemo(() => {
    if (!comparison) return null;

    // Get all unique constructs across all sessions
    const allConstructs = new Set<string>();
    for (const scores of Object.values(comparison.scoresBySession)) {
      for (const s of scores) {
        allConstructs.add(`${s.block}::${s.construct}${s.facet ? `::${s.facet}` : ""}`);
      }
    }

    // Build rows
    const rows: Array<{
      block: string;
      construct: string;
      facet: string | null;
      label: string;
      scores: Record<number, number>;
      delta: number | null;
    }> = [];

    for (const key of Array.from(allConstructs).sort()) {
      const parts = key.split("::");
      const block = parts[0];
      const construct = parts[1];
      const facet = parts[2] || null;

      const scores: Record<number, number> = {};
      for (const [sid, sessionScores] of Object.entries(comparison.scoresBySession)) {
        const match = sessionScores.find(
          s => s.block === block && s.construct === construct && (facet ? s.facet === facet : !s.facet)
        );
        if (match) scores[parseInt(sid)] = parseFloat(match.score0to100 || "0");
      }

      // Calculate delta between first and last selected session
      const orderedIds = selectedIds.filter(id => scores[id] !== undefined);
      let delta: number | null = null;
      if (orderedIds.length >= 2) {
        delta = scores[orderedIds[orderedIds.length - 1]] - scores[orderedIds[0]];
      }

      rows.push({
        block,
        construct,
        facet,
        label: facet ? facet.replace(/_/g, " ") : construct.replace(/_/g, " "),
        scores,
        delta,
      });
    }

    // Group by block
    const grouped = new Map<string, typeof rows>();
    for (const row of rows) {
      const existing = grouped.get(row.block) || [];
      existing.push(row);
      grouped.set(row.block, existing);
    }

    return { grouped, sessions: comparison.sessions };
  }, [comparison, selectedIds]);

  return (
    <div className="container max-w-5xl py-8">
      <Button variant="ghost" onClick={onBack} className="mb-6">
        <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
      </Button>

      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
          <BarChart3 className="h-4 w-4" /> Comparativo de Avaliações
        </div>
        <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
          Evolução do Perfil
        </h1>
        <p className="text-sm text-muted-foreground">
          Selecione até 3 avaliações para comparar lado a lado
        </p>
      </div>

      {/* Session Selector */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="text-base">Selecione as avaliações</CardTitle>
          <CardDescription>Clique para selecionar/desmarcar (máximo 3)</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {sessions.map((s, idx) => {
              const isSelected = selectedIds.includes(s.id);
              const colorIdx = isSelected ? selectedIds.indexOf(s.id) : -1;
              return (
                <button
                  key={s.id}
                  onClick={() => toggleSession(s.id)}
                  className={`text-left p-4 rounded-xl border-2 transition-all ${
                    isSelected
                      ? `${SESSION_COLORS[colorIdx]?.border || "border-primary"} bg-primary/5`
                      : "border-border/50 hover:border-border"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant={isSelected ? "default" : "outline"} className="text-xs">
                      {s.mode === "quick" ? "Rápido" : "Completo"}
                    </Badge>
                    {isSelected && (
                      <div className={`w-6 h-6 rounded-full ${SESSION_COLORS[colorIdx]?.bg || "bg-primary"} flex items-center justify-center`}>
                        <CheckCircle2 className="h-4 w-4 text-white" />
                      </div>
                    )}
                  </div>
                  <p className="text-sm font-medium text-foreground">
                    {new Date(s.createdAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" })}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {s.currentRole || "Sem cargo informado"}
                  </p>
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Comparison Results */}
      {loadingComparison && selectedIds.length > 0 && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}

      {comparisonData && selectedIds.length >= 2 && (
        <>
          {/* Legend */}
          <div className="flex flex-wrap gap-4 mb-6 justify-center">
            {comparisonData.sessions.map((s, i) => (
              <div key={s.id} className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${SESSION_COLORS[i]?.bg || "bg-muted"}`} />
                <span className="text-xs text-muted-foreground">
                  {new Date(s.createdAt).toLocaleDateString("pt-BR")} — {s.currentRole || "N/A"}
                </span>
              </div>
            ))}
          </div>

          {/* Score Comparison by Block */}
          {Array.from(comparisonData.grouped.entries()).map(([block, rows]) => {
            const info = BLOCK_INFO[block];
            if (!info) return null;
            return (
              <Card key={block} className="mb-4">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <span>{info.icon}</span> {info.label}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {rows.map((row, ri) => (
                      <div key={ri}>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs text-muted-foreground capitalize w-32 truncate">
                            {row.label}
                          </span>
                          {row.delta !== null && (
                            <div className={`flex items-center gap-1 text-xs font-medium ${
                              row.delta > 0 ? "text-emerald-500" : row.delta < 0 ? "text-red-400" : "text-muted-foreground"
                            }`}>
                              {row.delta > 0 ? <TrendingUp className="h-3 w-3" /> : row.delta < 0 ? <TrendingDown className="h-3 w-3" /> : <Minus className="h-3 w-3" />}
                              {row.delta > 0 ? "+" : ""}{Math.round(row.delta)}
                            </div>
                          )}
                        </div>
                        {/* Stacked bars */}
                        <div className="space-y-1.5">
                          {selectedIds.map((sid, si) => {
                            const score = row.scores[sid];
                            if (score === undefined) return null;
                            const color = SESSION_COLORS[si]?.bg || "bg-muted";
                            return (
                              <div key={sid} className="flex items-center gap-2">
                                <div className={`w-2 h-2 rounded-full ${color} shrink-0`} />
                                <div className="flex-1 bg-muted rounded-full h-2 overflow-hidden">
                                  <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${Math.max(2, score)}%` }} />
                                </div>
                                <span className="text-xs font-medium text-foreground w-8 text-right">{Math.round(score)}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}

          {/* Summary Card */}
          <Card className="mt-6 mb-8">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" /> Resumo da Evolução
              </CardTitle>
            </CardHeader>
            <CardContent>
              {(() => {
                const allDeltas = Array.from(comparisonData.grouped.values())
                  .flat()
                  .filter(r => r.delta !== null);
                const improvements = allDeltas.filter(r => (r.delta || 0) > 5);
                const declines = allDeltas.filter(r => (r.delta || 0) < -5);
                const stable = allDeltas.filter(r => Math.abs(r.delta || 0) <= 5);

                return (
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-lg p-4">
                      <h4 className="font-medium text-emerald-400 text-sm mb-2">Melhorias ({improvements.length})</h4>
                      {improvements.length > 0 ? (
                        <ul className="space-y-1">
                          {improvements.slice(0, 5).map((r, i) => (
                            <li key={i} className="text-xs text-muted-foreground flex items-center gap-1">
                              <TrendingUp className="h-3 w-3 text-emerald-500 shrink-0" />
                              <span className="capitalize truncate">{r.label}</span>
                              <span className="text-emerald-500 font-medium ml-auto">+{Math.round(r.delta!)}</span>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-xs text-muted-foreground">Nenhuma melhoria significativa</p>
                      )}
                    </div>
                    <div className="bg-muted/30 border border-border/50 rounded-lg p-4">
                      <h4 className="font-medium text-muted-foreground text-sm mb-2">Estáveis ({stable.length})</h4>
                      <p className="text-xs text-muted-foreground">
                        {stable.length} constructos mantiveram-se estáveis (variação ≤ 5 pontos)
                      </p>
                    </div>
                    <div className="bg-red-500/5 border border-red-500/20 rounded-lg p-4">
                      <h4 className="font-medium text-red-400 text-sm mb-2">Atenção ({declines.length})</h4>
                      {declines.length > 0 ? (
                        <ul className="space-y-1">
                          {declines.slice(0, 5).map((r, i) => (
                            <li key={i} className="text-xs text-muted-foreground flex items-center gap-1">
                              <TrendingDown className="h-3 w-3 text-red-400 shrink-0" />
                              <span className="capitalize truncate">{r.label}</span>
                              <span className="text-red-400 font-medium ml-auto">{Math.round(r.delta!)}</span>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-xs text-muted-foreground">Nenhum declínio significativo</p>
                      )}
                    </div>
                  </div>
                );
              })()}
            </CardContent>
          </Card>
        </>
      )}

      {selectedIds.length === 1 && !loadingComparison && (
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-sm text-muted-foreground">
              Selecione mais uma avaliação para visualizar o comparativo lado a lado.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
