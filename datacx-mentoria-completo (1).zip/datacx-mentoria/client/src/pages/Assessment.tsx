import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { useRoute, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { 
  Brain, Clock, ChevronRight, ChevronLeft, CheckCircle2, 
  AlertTriangle, Download, ArrowLeft, Zap, Target, 
  BarChart3, Shield, Sparkles, FileText, Loader2, Link2, GitCompare
} from "lucide-react";
import AssessmentComparison from "@/components/AssessmentComparison";

// ============ TYPES ============

interface AssessmentItem {
  id: number;
  block: string;
  construct: string;
  facet: string | null;
  itemType: "likert" | "sjt" | "micro_work_sample" | "attention_check";
  polarity: string;
  text: string;
  optionsJson: any;
  keyJson: any;
  dimension: string | null;
  expectedTimeSec: number | null;
  sortOrder: number;
}

interface ItemResponse {
  itemId: number;
  responseValue: string;
  responseTimeMs: number;
}

// ============ BLOCK METADATA ============

const BLOCK_INFO: Record<string, { label: string; icon: string; description: string }> = {
  core_personality: { label: "Personalidade", icon: "🧠", description: "Big Five — traços fundamentais de personalidade" },
  core_communication: { label: "Comunicação", icon: "💬", description: "Estilo de interação — Agency x Communion" },
  core_leadership: { label: "Liderança", icon: "👑", description: "Cenários de tomada de decisão e gestão" },
  core_vitality: { label: "Vitalidade", icon: "💚", description: "Bem-estar e energia no trabalho" },
  mod_innovation: { label: "Inovação", icon: "💡", description: "Capacidade de gerar e implementar ideias" },
  mod_data: { label: "Data Literacy", icon: "📊", description: "Pensamento analítico e uso de dados" },
  mod_decision: { label: "Decisão", icon: "⚖️", description: "Julgamento e trade-offs" },
  mod_learning: { label: "Learning Agility", icon: "🔄", description: "Velocidade de aprendizado e adaptação" },
  mod_execution: { label: "Execução", icon: "🎯", description: "Foco, disciplina e autocontrole" },
  mod_motivation: { label: "Motivadores", icon: "🔥", description: "O que impulsiona sua energia" },
  mod_values: { label: "Valores", icon: "🧭", description: "Princípios e prioridades pessoais" },
  mod_career: { label: "Fit de Carreira", icon: "🗺️", description: "Interesses profissionais (RIASEC)" },
  mod_collaboration: { label: "Colaboração", icon: "🤝", description: "Segurança psicológica e trabalho em equipe" },
  quality_check: { label: "Verificação", icon: "✅", description: "Itens de atenção e consistência" },
};

const LIKERT_OPTIONS = [
  { value: "1", label: "Discordo totalmente" },
  { value: "2", label: "Discordo" },
  { value: "3", label: "Neutro" },
  { value: "4", label: "Concordo" },
  { value: "5", label: "Concordo totalmente" },
];

const OBJECTIVES = [
  { value: "promotion", label: "Promoção / Crescimento" },
  { value: "transition", label: "Transição de Carreira" },
  { value: "performance", label: "Alta Performance" },
  { value: "leadership", label: "Liderança" },
  { value: "data", label: "Dados & Analytics" },
  { value: "innovation", label: "Inovação" },
];

// ============ MAIN COMPONENT ============

export default function Assessment() {
  const [, matchSession] = useRoute("/assessment/:sessionId");
  const sessionIdParam = matchSession?.sessionId;
  const [, navigate] = useLocation();
  const { user, loading: authLoading } = useAuth();
  const [view, setView] = useState<"start" | "context" | "run" | "processing" | "results" | "compare">("start");
  const [mode, setMode] = useState<"quick" | "complete">("quick");
  const [sessionId, setSessionId] = useState<number | null>(sessionIdParam ? parseInt(sessionIdParam) : null);

  // Context form
  const [contextForm, setContextForm] = useState({
    currentRole: "",
    seniority: "",
    area: "",
    segment: "",
    primaryObjective: "" as string,
    contextDescription: "",
    constraints: "",
  });

  // If navigating to a session, load results
  useEffect(() => {
    if (sessionIdParam) {
      setSessionId(parseInt(sessionIdParam));
      setView("results");
    }
  }, [sessionIdParam]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardHeader className="text-center">
            <Brain className="h-12 w-12 text-primary mx-auto mb-4" />
            <CardTitle>Avaliação de Perfil Profissional</CardTitle>
            <CardDescription>Faça login para acessar a avaliação científica</CardDescription>
          </CardHeader>
          <CardContent>
            <Button className="w-full" onClick={() => window.location.href = getLoginUrl("/assessment")}>
              Fazer Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (view === "compare") return <AssessmentComparison onBack={() => setView("start")} />;
  if (view === "start") return <StartView mode={mode} setMode={setMode} onStart={() => setView("context")} onViewHistory={() => navigate("/membros")} onCompare={() => setView("compare")} />;
  if (view === "context") return <ContextView form={contextForm} setForm={setContextForm} mode={mode} onBack={() => setView("start")} onStart={(sid) => { setSessionId(sid); setView("run"); }} />;
  if (view === "run" && sessionId) return <RunView sessionId={sessionId} mode={mode} selectedModules={contextForm.primaryObjective ? getModulesForObjective(contextForm.primaryObjective) : undefined} onComplete={() => setView("processing")} />;
  if (view === "processing" && sessionId) return <ProcessingView sessionId={sessionId} onComplete={() => { setView("results"); navigate(`/assessment/${sessionId}`); }} />;
  if (view === "results" && sessionId) return <ResultsView sessionId={sessionId} onBack={() => navigate("/membros")} />;

  return null;
}

function getModulesForObjective(objective: string): string[] {
  const base = ["mod_execution", "mod_motivation"];
  switch (objective) {
    case "promotion": return [...base, "mod_learning", "mod_values"];
    case "transition": return [...base, "mod_career", "mod_values"];
    case "performance": return [...base, "mod_execution", "mod_decision"];
    case "leadership": return [...base, "mod_collaboration", "mod_decision"];
    case "data": return [...base, "mod_data", "mod_decision"];
    case "innovation": return [...base, "mod_innovation", "mod_learning"];
    default: return base;
  }
}

// ============ START VIEW ============

function StartView({ mode, setMode, onStart, onViewHistory, onCompare }: { mode: "quick" | "complete"; setMode: (m: "quick" | "complete") => void; onStart: () => void; onViewHistory: () => void; onCompare: () => void }) {
  return (
    <div className="min-h-screen bg-background">
      <div className="container max-w-4xl py-12">
        <Button variant="ghost" onClick={onViewHistory} className="mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
        </Button>

        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Brain className="h-4 w-4" /> Avaliação Científica de Perfil
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Descubra seu Perfil Profissional
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Uma avaliação baseada em instrumentos científicos validados (Big Five, Circumplex Interpessoal, WHO-5) 
            combinada com cenários práticos de liderança e tomada de decisão.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-10">
          <Card 
            className={`cursor-pointer transition-all border-2 ${mode === "quick" ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"}`}
            onClick={() => setMode("quick")}
          >
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-lg">Modo Rápido</CardTitle>
                  <CardDescription>10–15 minutos</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">
                Avaliação focada nos 4 pilares fundamentais: Personalidade, Comunicação, Liderança e Vitalidade.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">Big Five</Badge>
                <Badge variant="secondary">Comunicação</Badge>
                <Badge variant="secondary">Liderança (SJT)</Badge>
                <Badge variant="secondary">Bem-estar</Badge>
              </div>
            </CardContent>
          </Card>

          <Card 
            className={`cursor-pointer transition-all border-2 ${mode === "complete" ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"}`}
            onClick={() => setMode("complete")}
          >
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-coral/10">
                  <Target className="h-6 w-6 text-coral" />
                </div>
                <div>
                  <CardTitle className="text-lg">Modo Completo</CardTitle>
                  <CardDescription>25–40 minutos</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">
                Avaliação completa com módulos adicionais personalizados ao seu objetivo profissional.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">Tudo do Rápido</Badge>
                <Badge variant="outline">Inovação</Badge>
                <Badge variant="outline">Data Literacy</Badge>
                <Badge variant="outline">Decisão</Badge>
                <Badge variant="outline">+ mais</Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="bg-card border border-border rounded-xl p-6 mb-8">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" /> O que você receberá
          </h3>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="flex items-start gap-3">
              <BarChart3 className="h-5 w-5 text-chart-1 mt-0.5 shrink-0" />
              <div>
                <p className="font-medium text-sm text-foreground">Radar de Competências</p>
                <p className="text-xs text-muted-foreground">Visualização gráfica dos seus escores em cada dimensão</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Sparkles className="h-5 w-5 text-chart-2 mt-0.5 shrink-0" />
              <div>
                <p className="font-medium text-sm text-foreground">Insights com IA</p>
                <p className="text-xs text-muted-foreground">Interpretação personalizada baseada nos seus escores</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <FileText className="h-5 w-5 text-chart-3 mt-0.5 shrink-0" />
              <div>
                <p className="font-medium text-sm text-foreground">PDI 30/60/90</p>
                <p className="text-xs text-muted-foreground">Plano de desenvolvimento com ações, métricas e rituais</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-muted/50 border border-border rounded-xl p-4 mb-8 text-sm text-muted-foreground">
          <p className="flex items-start gap-2">
            <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0 text-yellow-500" />
            <span>
              <strong className="text-foreground">Nota importante:</strong> Esta avaliação é para fins de desenvolvimento e mentoria. 
              Não constitui diagnóstico clínico ou laudo psicológico. Seus dados são tratados com total privacidade.
            </span>
          </p>
        </div>

        <div className="text-center space-y-3">
          <Button size="lg" onClick={onStart} className="px-8">
            Iniciar Avaliação <ChevronRight className="h-5 w-5 ml-2" />
          </Button>
          <div>
            <Button variant="outline" size="sm" onClick={onCompare} className="gap-2">
              <GitCompare className="h-4 w-4" /> Comparar Avaliações Anteriores
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============ CONTEXT VIEW ============

function ContextView({ form, setForm, mode, onBack, onStart }: { 
  form: any; setForm: (f: any) => void; mode: "quick" | "complete"; 
  onBack: () => void; onStart: (sessionId: number) => void 
}) {
  const startSession = trpc.assessment.startSession.useMutation();

  const handleStart = async () => {
    try {
      const selectedModules = mode === "complete" && form.primaryObjective 
        ? getModulesForObjective(form.primaryObjective) 
        : undefined;

      const result = await startSession.mutateAsync({
        mode,
        currentRole: form.currentRole || undefined,
        seniority: form.seniority || undefined,
        area: form.area || undefined,
        segment: form.segment || undefined,
        primaryObjective: form.primaryObjective || undefined,
        contextDescription: form.contextDescription || undefined,
        constraints: form.constraints || undefined,
        selectedModules,
      });
      if (result.sessionId != null) onStart(result.sessionId);
    } catch (e) {
      toast.error("Erro ao iniciar. Tente novamente.");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container max-w-2xl py-12">
        <Button variant="ghost" onClick={onBack} className="mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
        </Button>

        <h2 className="text-2xl font-bold text-foreground mb-2">Contexto Profissional</h2>
        <p className="text-muted-foreground mb-8">
          Essas informações ajudam a personalizar a interpretação dos seus resultados. Preencha o que puder.
        </p>

        <div className="space-y-6">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Cargo Atual</label>
              <Input placeholder="Ex: Gerente de Produto" value={form.currentRole} onChange={e => setForm({...form, currentRole: e.target.value})} />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Senioridade</label>
              <Select value={form.seniority} onValueChange={v => setForm({...form, seniority: v})}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="junior">Júnior</SelectItem>
                  <SelectItem value="pleno">Pleno</SelectItem>
                  <SelectItem value="senior">Sênior</SelectItem>
                  <SelectItem value="lead">Lead / Coordenador</SelectItem>
                  <SelectItem value="manager">Gerente</SelectItem>
                  <SelectItem value="director">Diretor</SelectItem>
                  <SelectItem value="c-level">C-Level</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Área</label>
              <Input placeholder="Ex: Tecnologia, Marketing, RH" value={form.area} onChange={e => setForm({...form, area: e.target.value})} />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Segmento</label>
              <Input placeholder="Ex: SaaS, Varejo, Saúde" value={form.segment} onChange={e => setForm({...form, segment: e.target.value})} />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">Objetivo Principal</label>
            <Select value={form.primaryObjective} onValueChange={v => setForm({...form, primaryObjective: v})}>
              <SelectTrigger><SelectValue placeholder="O que você busca?" /></SelectTrigger>
              <SelectContent>
                {OBJECTIVES.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">Contexto (opcional)</label>
            <Textarea 
              placeholder="Descreva brevemente seu contexto atual: time, produto, metas, desafios..." 
              value={form.contextDescription} 
              onChange={e => setForm({...form, contextDescription: e.target.value})}
              rows={3}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">Restrições (opcional)</label>
            <Input placeholder="Ex: tempo limitado, agenda cheia, saúde" value={form.constraints} onChange={e => setForm({...form, constraints: e.target.value})} />
          </div>
        </div>

        <div className="mt-8 flex justify-end">
          <Button size="lg" onClick={handleStart} disabled={startSession.isPending}>
            {startSession.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            Começar Avaliação <ChevronRight className="h-5 w-5 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}

// ============ RUN VIEW (QUESTIONNAIRE) ============

function RunView({ sessionId, mode, selectedModules, onComplete }: { 
  sessionId: number; mode: "quick" | "complete"; selectedModules?: string[]; onComplete: () => void 
}) {
  const { data: items, isLoading } = trpc.assessment.getItems.useQuery({ mode, selectedModules });
  const saveResponses = trpc.assessment.saveResponses.useMutation();
  const completeAssessment = trpc.assessment.complete.useMutation();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [responses, setResponses] = useState<Map<number, ItemResponse>>(new Map());
  const [itemStartTime, setItemStartTime] = useState(Date.now());
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Group items by block for navigation
  const blocks = useMemo(() => {
    if (!items) return [];
    const blockMap = new Map<string, AssessmentItem[]>();
    for (const item of items) {
      const existing = blockMap.get(item.block) || [];
      existing.push(item as AssessmentItem);
      blockMap.set(item.block, existing);
    }
    return Array.from(blockMap.entries()).map(([block, blockItems]) => ({ block, items: blockItems }));
  }, [items]);

  const flatItems = useMemo(() => blocks.flatMap(b => b.items), [blocks]);
  const currentItem = flatItems[currentIndex];
  const currentBlock = currentItem ? BLOCK_INFO[currentItem.block] : null;
  const progress = flatItems.length > 0 ? ((currentIndex + 1) / flatItems.length) * 100 : 0;

  // Reset timer on item change
  useEffect(() => {
    setItemStartTime(Date.now());
  }, [currentIndex]);

  // Auto-advance ref to track if we should auto-advance after response
  const autoAdvanceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleResponse = useCallback((value: string) => {
    if (!currentItem) return;
    const timeMs = Date.now() - itemStartTime;
    const hadPreviousResponse = responses.has(currentItem.id);
    setResponses(prev => {
      const next = new Map(prev);
      next.set(currentItem.id, { itemId: currentItem.id, responseValue: value, responseTimeMs: timeMs });
      return next;
    });
    // Auto-advance for likert/SJT/attention_check items when selecting for the first time
    if (!hadPreviousResponse && (currentItem.itemType === 'likert' || currentItem.itemType === 'sjt' || currentItem.itemType === 'attention_check') && currentIndex < flatItems.length - 1) {
      if (autoAdvanceTimerRef.current) clearTimeout(autoAdvanceTimerRef.current);
      autoAdvanceTimerRef.current = setTimeout(() => {
        setCurrentIndex(prev => prev + 1);
      }, 350);
    }
  }, [currentItem, itemStartTime, responses, currentIndex, flatItems.length]);

  // Cleanup auto-advance timer
  useEffect(() => {
    return () => {
      if (autoAdvanceTimerRef.current) clearTimeout(autoAdvanceTimerRef.current);
    };
  }, []);

  const currentResponse = currentItem ? responses.get(currentItem.id) : undefined;
  const isLastItem = currentIndex === flatItems.length - 1;

  // Keyboard navigation: 1-5 for likert, left/right arrows
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'Enter') {
        if (currentResponse?.responseValue) {
          if (autoAdvanceTimerRef.current) clearTimeout(autoAdvanceTimerRef.current);
          if (currentIndex < flatItems.length - 1) {
            setCurrentIndex(prev => prev + 1);
          }
        }
      } else if (e.key === 'ArrowLeft') {
        if (currentIndex > 0) setCurrentIndex(prev => prev - 1);
      } else if (['1','2','3','4','5'].includes(e.key) && (currentItem?.itemType === 'likert' || currentItem?.itemType === 'attention_check')) {
        handleResponse(e.key);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, flatItems.length, currentResponse, currentItem, handleResponse]);

  const goNext = useCallback(async () => {
    if (currentIndex < flatItems.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      // Save all responses and complete
      setIsSubmitting(true);
      try {
        const allResponses = Array.from(responses.values());
        // Save in batches of 50
        for (let i = 0; i < allResponses.length; i += 50) {
          const batch = allResponses.slice(i, i + 50);
          await saveResponses.mutateAsync({ sessionId, responses: batch });
        }
        onComplete();
      } catch (e) {
        toast.error("Erro ao salvar. Tente novamente.");
        setIsSubmitting(false);
      }
    }
  }, [currentIndex, flatItems.length, responses, sessionId, saveResponses, onComplete, toast]);

  const goPrev = useCallback(() => {
    if (currentIndex > 0) setCurrentIndex(prev => prev - 1);
  }, [currentIndex]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Carregando questionário...</p>
        </div>
      </div>
    );
  }

  if (!currentItem) return null;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header with progress */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur border-b border-border px-4 py-3">
        <div className="container max-w-3xl">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="text-lg">{currentBlock?.icon}</span>
              <span className="text-sm font-medium text-foreground">{currentBlock?.label}</span>
            </div>
            <span className="text-sm text-muted-foreground">
              {currentIndex + 1} / {flatItems.length}
            </span>
          </div>
          <Progress value={progress} className="h-1.5" />
        </div>
      </div>

      {/* Question area */}
      <div className="flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-3xl">
          <Card className="border-border/50">
            <CardContent className="p-6 md:p-8">
              {/* Block description (show on first item of block) */}
              {(currentIndex === 0 || flatItems[currentIndex - 1]?.block !== currentItem.block) && (
                <p className="text-xs text-muted-foreground mb-4 bg-muted/50 rounded-lg px-3 py-2">
                  {currentBlock?.description}
                </p>
              )}

              {/* Question text */}
              <p className="text-lg md:text-xl font-medium text-foreground mb-8 leading-relaxed">
                {currentItem.text}
              </p>

              {/* Response options */}
              {currentItem.itemType === "likert" || currentItem.itemType === "attention_check" ? (
                <div className="space-y-3">
                  {LIKERT_OPTIONS.map(opt => (
                    <button
                      key={opt.value}
                      onClick={() => handleResponse(opt.value)}
                      className={`w-full text-left px-4 py-3 rounded-lg border transition-all text-sm md:text-base ${
                        currentResponse?.responseValue === opt.value
                          ? "border-primary bg-primary/10 text-foreground"
                          : "border-border hover:border-primary/50 text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      <span className="font-medium mr-3 text-muted-foreground">{opt.value}.</span>
                      {opt.label}
                    </button>
                  ))}
                </div>
              ) : currentItem.itemType === "sjt" ? (
                <div className="space-y-3">
                  {(currentItem.optionsJson as any[])?.map((opt: any) => (
                    <button
                      key={opt.label}
                      onClick={() => handleResponse(opt.label)}
                      className={`w-full text-left px-4 py-3 rounded-lg border transition-all text-sm md:text-base ${
                        currentResponse?.responseValue === opt.label
                          ? "border-primary bg-primary/10 text-foreground"
                          : "border-border hover:border-primary/50 text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      <span className="font-semibold mr-3 text-primary">{opt.label}.</span>
                      {opt.text}
                    </button>
                  ))}
                </div>
              ) : currentItem.itemType === "micro_work_sample" ? (
                <Textarea
                  placeholder="Descreva sua experiência aqui..."
                  value={currentResponse?.responseValue || ""}
                  onChange={e => handleResponse(e.target.value)}
                  rows={5}
                  className="text-base"
                />
              ) : null}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Navigation footer */}
      <div className="sticky bottom-0 bg-background/95 backdrop-blur border-t border-border px-4 py-4 pb-6">
        <div className="container max-w-3xl flex items-center justify-between">
          <Button variant="ghost" onClick={goPrev} disabled={currentIndex === 0}>
            <ChevronLeft className="h-4 w-4 mr-1" /> Anterior
          </Button>
          <Button 
            onClick={goNext} 
            disabled={!currentResponse?.responseValue || isSubmitting}
          >
            {isSubmitting ? (
              <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Salvando...</>
            ) : isLastItem ? (
              <><CheckCircle2 className="h-4 w-4 mr-2" /> Finalizar</>
            ) : (
              <>Próximo <ChevronRight className="h-4 w-4 ml-1" /></>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ============ PROCESSING VIEW ============

function ProcessingView({ sessionId, onComplete }: { sessionId: number; onComplete: () => void }) {
  const completeAssessment = trpc.assessment.complete.useMutation();
  const [step, setStep] = useState(0);

  const steps = [
    { label: "Calculando escores...", icon: BarChart3 },
    { label: "Analisando padrões...", icon: Brain },
    { label: "Gerando insights com IA...", icon: Sparkles },
    { label: "Preparando relatório...", icon: FileText },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setStep(prev => Math.min(prev + 1, steps.length - 1));
    }, 3000);

    completeAssessment.mutateAsync({ sessionId })
      .then(() => {
        clearInterval(interval);
        setStep(steps.length - 1);
        setTimeout(onComplete, 1500);
      })
      .catch(err => {
        clearInterval(interval);
        toast.error(err.message || "Erro ao processar. Tente novamente.");
      });

    return () => clearInterval(interval);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center max-w-md mx-4">
        <div className="relative mb-8">
          <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto animate-pulse">
            <Brain className="h-10 w-10 text-primary" />
          </div>
        </div>
        <h2 className="text-2xl font-bold text-foreground mb-6">Processando sua avaliação</h2>
        <div className="space-y-4">
          {steps.map((s, i) => {
            const Icon = s.icon;
            return (
              <div key={i} className={`flex items-center gap-3 transition-all ${i <= step ? "opacity-100" : "opacity-30"}`}>
                <div className={`h-8 w-8 rounded-full flex items-center justify-center shrink-0 ${
                  i < step ? "bg-green-500/20 text-green-500" : i === step ? "bg-primary/20 text-primary animate-pulse" : "bg-muted text-muted-foreground"
                }`}>
                  {i < step ? <CheckCircle2 className="h-4 w-4" /> : <Icon className="h-4 w-4" />}
                </div>
                <span className={`text-sm ${i <= step ? "text-foreground" : "text-muted-foreground"}`}>{s.label}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ============ RESULTS VIEW ============

function ResultsView({ sessionId, onBack }: { sessionId: number; onBack: () => void }) {
  const { data, isLoading } = trpc.assessment.getReport.useQuery({ sessionId });
  const [, navigate] = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!data?.report) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">Relatório não encontrado</h3>
            <p className="text-sm text-muted-foreground mb-4">O relatório ainda está sendo gerado ou não foi encontrado.</p>
            <Button onClick={onBack}>Voltar</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const report = data.report.reportJson as any;
  const session = data.session;
  const scores = data.scores;

  return (
    <div className="min-h-screen bg-background">
      <div id="report-content" className="container max-w-4xl py-8">
        <Button variant="ghost" onClick={onBack} className="mb-6 print:hidden">
          <ArrowLeft className="h-4 w-4 mr-2" /> Voltar à Área de Membros
        </Button>

        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Brain className="h-4 w-4" /> Relatório de Perfil Profissional
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
            {report.executive_summary?.headline || "Seu Perfil Profissional"}
          </h1>
          <p className="text-sm text-muted-foreground">
            {session?.mode === "quick" ? "Modo Rápido" : "Modo Completo"} — {new Date(session?.completedAt || session?.createdAt || "").toLocaleDateString("pt-BR")}
          </p>
          {report.meta?.confidence_overall_0_1 !== undefined && (
            <Badge variant={report.meta.confidence_overall_0_1 >= 0.65 ? "default" : "destructive"} className="mt-2">
              Confiança: {Math.round(report.meta.confidence_overall_0_1 * 100)}%
            </Badge>
          )}
        </div>

        {/* Quality warnings */}
        {report.meta?.quality_flags?.length > 0 && (
          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4 mb-6">
            <p className="text-sm text-yellow-200 flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
              <span>
                <strong>Atenção:</strong> Foram detectados indicadores de qualidade que podem afetar a precisão: {report.meta.quality_flags.join(", ")}. 
                Os insights abaixo devem ser interpretados como hipóteses.
              </span>
            </p>
          </div>
        )}

        {/* Executive Summary */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" /> Resumo Executivo
            </CardTitle>
          </CardHeader>
          <CardContent>
            {report.executive_summary?.bullets && (
              <ul className="space-y-2 mb-6">
                {report.executive_summary.bullets.map((b: string, i: number) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <span className="text-primary mt-1">•</span> {b}
                  </li>
                ))}
              </ul>
            )}
            <div className="grid md:grid-cols-2 gap-4">
              {report.executive_summary?.top_strengths?.length > 0 && (
                <div className="bg-green-500/5 border border-green-500/20 rounded-lg p-4">
                  <h4 className="font-medium text-green-400 text-sm mb-2">Forças Principais</h4>
                  <ul className="space-y-1">
                    {report.executive_summary.top_strengths.map((s: string, i: number) => (
                      <li key={i} className="text-sm text-muted-foreground flex items-start gap-1.5">
                        <CheckCircle2 className="h-3.5 w-3.5 text-green-500 mt-0.5 shrink-0" /> {s}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {report.executive_summary?.top_watchouts?.length > 0 && (
                <div className="bg-yellow-500/5 border border-yellow-500/20 rounded-lg p-4">
                  <h4 className="font-medium text-yellow-400 text-sm mb-2">Pontos de Atenção</h4>
                  <ul className="space-y-1">
                    {report.executive_summary.top_watchouts.map((w: string, i: number) => (
                      <li key={i} className="text-sm text-muted-foreground flex items-start gap-1.5">
                        <AlertTriangle className="h-3.5 w-3.5 text-yellow-500 mt-0.5 shrink-0" /> {w}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Radar Scores by Block */}
        {scores && scores.length > 0 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" /> Escores por Dimensão
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScoresBars scores={scores} />
            </CardContent>
          </Card>
        )}

        {/* Fit & Context */}
        {report.fit_and_context && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-primary" /> Fit & Contexto
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {report.fit_and_context.best_fit_environments?.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-2">Ambientes Ideais</h4>
                    <ul className="space-y-1">
                      {report.fit_and_context.best_fit_environments.map((e: string, i: number) => (
                        <li key={i} className="text-sm text-muted-foreground">• {e}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {report.fit_and_context.motivators?.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-2">Motivadores</h4>
                    <ul className="space-y-1">
                      {report.fit_and_context.motivators.map((m: string, i: number) => (
                        <li key={i} className="text-sm text-muted-foreground">• {m}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {report.fit_and_context.risk_contexts?.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-2">Contextos de Risco</h4>
                    <ul className="space-y-1">
                      {report.fit_and_context.risk_contexts.map((r: string, i: number) => (
                        <li key={i} className="text-sm text-muted-foreground">• {r}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {report.fit_and_context.derailers?.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-2">Descarriladores</h4>
                    <ul className="space-y-1">
                      {report.fit_and_context.derailers.map((d: string, i: number) => (
                        <li key={i} className="text-sm text-muted-foreground">• {d}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* PDI 30/60/90 */}
        {report.pdi_30_60_90 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" /> PDI 30/60/90 Dias
              </CardTitle>
            </CardHeader>
            <CardContent>
              {report.pdi_30_60_90.principles?.length > 0 && (
                <div className="mb-6">
                  <h4 className="text-sm font-medium text-foreground mb-2">Princípios Norteadores</h4>
                  <ul className="space-y-1">
                    {report.pdi_30_60_90.principles.map((p: string, i: number) => (
                      <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                        <span className="text-primary font-bold">{i + 1}.</span> {p}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {report.pdi_30_60_90.plan?.map((horizon: any, i: number) => (
                <div key={i} className="mb-6 bg-muted/30 rounded-lg p-4">
                  <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                    <Badge variant="outline">{horizon.horizon} dias</Badge>
                  </h4>
                  {horizon.goals?.map((g: any, j: number) => (
                    <div key={j} className="mb-3 pl-4 border-l-2 border-primary/30">
                      <p className="text-sm font-medium text-foreground">{g.goal}</p>
                      <p className="text-xs text-muted-foreground">Métrica: {g.metric} | Baseline: {g.baseline} → Target: {g.target}</p>
                    </div>
                  ))}
                  {horizon.actions?.map((a: any, j: number) => (
                    <div key={j} className="mb-2 text-sm text-muted-foreground">
                      <span className="text-primary">→</span> {a.action} <span className="text-xs">({a.frequency})</span>
                    </div>
                  ))}
                </div>
              ))}

              {report.pdi_30_60_90.weekly_rhythm && (
                <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                  <h4 className="text-sm font-medium text-foreground mb-2">Ritmo Semanal Sugerido</h4>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    {report.pdi_30_60_90.weekly_rhythm["15min_daily"] && (
                      <p><strong className="text-foreground">15min diários:</strong> {report.pdi_30_60_90.weekly_rhythm["15min_daily"]}</p>
                    )}
                    {report.pdi_30_60_90.weekly_rhythm["45min_weekly_review"] && (
                      <p><strong className="text-foreground">45min revisão semanal:</strong> {report.pdi_30_60_90.weekly_rhythm["45min_weekly_review"]}</p>
                    )}
                    {report.pdi_30_60_90.weekly_rhythm.mentor_session_script && (
                      <p><strong className="text-foreground">Sessão com mentor:</strong> {report.pdi_30_60_90.weekly_rhythm.mentor_session_script}</p>
                    )}
                  </div>
                </div>
              )}
              {/* Link PDI to Jornada */}
              <PdiLinkButton sessionId={sessionId} report={report} />
            </CardContent>
          </Card>
        )}

        {/* Questions for Debrief */}
        {report.questions_for_debrief?.length > 0 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-base">Perguntas para Devolutiva com Mentor</CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="space-y-2">
                {report.questions_for_debrief.map((q: string, i: number) => (
                  <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                    <span className="text-primary font-bold shrink-0">{i + 1}.</span> {q}
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>
        )}

        {/* Disclaimer */}
        <div className="bg-muted/50 border border-border rounded-xl p-4 mb-8 text-xs text-muted-foreground">
          <p>{report.disclaimer || "Este relatório é para fins de desenvolvimento e mentoria. Não constitui diagnóstico clínico ou laudo psicológico."}</p>
        </div>

        {/* Download PDF */}
        <div className="text-center mb-8">
          <Button
            variant="outline"
            onClick={async () => {
              toast.info("Gerando PDF...");
              try {
                const html2pdf = (await import("html2pdf.js")).default;
                const el = document.getElementById("report-content");
                if (!el) { toast.error("Erro ao gerar PDF"); return; }
                await html2pdf()
                  .set({
                    margin: [10, 10, 10, 10],
                    filename: `relatorio-perfil-${sessionId}.pdf`,
                    image: { type: "jpeg", quality: 0.95 },
                    html2canvas: { scale: 2, useCORS: true, backgroundColor: "#0f172a" },
                    jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
                  } as any)
                  .from(el)
                  .save();
                toast.success("PDF baixado com sucesso!");
              } catch (err) {
                console.error("PDF generation error:", err);
                toast.error("Erro ao gerar PDF. Tente usar Ctrl+P para imprimir.");
              }
            }}
          >
            <Download className="h-4 w-4 mr-2" /> Baixar PDF
          </Button>
        </div>
      </div>
    </div>
  );
}

// ============ SCORES BARS COMPONENT ============

function ScoresBars({ scores }: { scores: any[] }) {
  // Group by block, then show construct scores
  const grouped = useMemo(() => {
    const map = new Map<string, any[]>();
    for (const s of scores) {
      const existing = map.get(s.block) || [];
      existing.push(s);
      map.set(s.block, existing);
    }
    return Array.from(map.entries());
  }, [scores]);

  return (
    <div className="space-y-6">
      {grouped.map(([block, blockScores]) => {
        const info = BLOCK_INFO[block];
        if (!info) return null;
        return (
          <div key={block}>
            <h4 className="text-sm font-medium text-foreground mb-3 flex items-center gap-2">
              <span>{info.icon}</span> {info.label}
            </h4>
            <div className="space-y-2">
              {blockScores.map((s: any, i: number) => {
                const score = parseFloat(s.score0to100) || 0;
                const label = s.facet || s.construct;
                const color = score >= 70 ? "bg-green-500" : score >= 40 ? "bg-primary" : "bg-yellow-500";
                return (
                  <div key={i} className="flex items-center gap-3">
                    <span className="text-xs text-muted-foreground w-32 truncate capitalize">
                      {label.replace(/_/g, " ")}
                    </span>
                    <div className="flex-1 bg-muted rounded-full h-2.5 overflow-hidden">
                      <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${Math.max(2, score)}%` }} />
                    </div>
                    <span className="text-xs font-medium text-foreground w-10 text-right">{Math.round(score)}</span>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ============ PDI LINK TO JORNADA BUTTON ============

function PdiLinkButton({ sessionId, report }: { sessionId: number; report: any }) {
  const [linked, setLinked] = useState(false);
  const [linking, setLinking] = useState(false);
  const { data: projects } = trpc.consulting.listProjects.useQuery();
  const linkPdi = trpc.assessment.linkPdiToJornada.useMutation();
  const utils = trpc.useUtils();

  const handleLink = async () => {
    if (!projects || projects.length === 0) {
      toast.error("Você precisa ter um projeto de mentoria ativo para vincular o PDI à Jornada.");
      return;
    }

    const projectId = projects[0].id;

    // Extract actions from PDI
    const actions: Array<{ title: string; description?: string; horizon: "30" | "60" | "90" }> = [];
    if (report.pdi_30_60_90?.plan) {
      for (const horizon of report.pdi_30_60_90.plan) {
        const h = String(horizon.horizon) as "30" | "60" | "90";
        if (horizon.actions) {
          for (const a of horizon.actions) {
            actions.push({
              title: a.action || a.title || "Ação PDI",
              description: a.frequency ? `Frequência: ${a.frequency}` : undefined,
              horizon: h,
            });
          }
        }
        if (horizon.goals) {
          for (const g of horizon.goals) {
            actions.push({
              title: g.goal || "Meta PDI",
              description: g.metric ? `Métrica: ${g.metric} | ${g.baseline} → ${g.target}` : undefined,
              horizon: h,
            });
          }
        }
      }
    }

    if (actions.length === 0) {
      toast.error("Nenhuma ação encontrada no PDI para vincular.");
      return;
    }

    setLinking(true);
    try {
      const result = await linkPdi.mutateAsync({
        sessionId,
        projectId,
        actions,
      });
      setLinked(true);
      utils.consulting.listProjects.invalidate();
      toast.success(`PDI vinculado à Jornada! ${result.checklistCount} ações criadas como checklist na etapa "${result.stageTitle}".`);
    } catch (err: any) {
      toast.error(err.message || "Erro ao vincular PDI à Jornada.");
    } finally {
      setLinking(false);
    }
  };

  if (linked) {
    return (
      <div className="mt-6 bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4 flex items-center gap-3">
        <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0" />
        <div>
          <p className="text-sm font-medium text-foreground">PDI vinculado à Jornada</p>
          <p className="text-xs text-muted-foreground">As ações do PDI foram adicionadas como checklist na sua Jornada de Mentoria.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mt-6 bg-primary/5 border border-primary/20 rounded-lg p-4">
      <div className="flex items-start gap-3">
        <Link2 className="h-5 w-5 text-primary mt-0.5 shrink-0" />
        <div className="flex-1">
          <p className="text-sm font-medium text-foreground mb-1">Vincular PDI à Jornada de Mentoria</p>
          <p className="text-xs text-muted-foreground mb-3">
            Transforme as ações do seu PDI em itens de checklist dentro da sua Jornada, 
            para acompanhar o progresso junto com seu mentor.
          </p>
          <Button size="sm" onClick={handleLink} disabled={linking}>
            {linking ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Link2 className="h-4 w-4 mr-2" />}
            Vincular ao Meu Projeto
          </Button>
        </div>
      </div>
    </div>
  );
}
