import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO from "@/components/SEO";
import {
  ArrowRight,
  Brain,
  Target,
  BarChart3,
  Shield,
  Sparkles,
  CheckCircle2,
  Clock,
  FileText,
  Users,
  Zap,
  ChevronDown,
  MessageSquare,
  TrendingUp,
  Award,
  Lightbulb,
  Heart,
  Compass,
  Layers,
  Star,
} from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";

const fadeInUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
};

const stagger = {
  animate: {
    transition: { staggerChildren: 0.1 },
  },
};

// ============ DIMENSIONS DATA ============

const DIMENSIONS = [
  {
    icon: Brain,
    title: "Personalidade",
    description: "Big Five — traços fundamentais que definem como você pensa, sente e age no ambiente profissional.",
    color: "from-blue-500/20 to-indigo-500/20",
    border: "border-blue-500/30",
    iconColor: "text-blue-400",
  },
  {
    icon: MessageSquare,
    title: "Comunicação",
    description: "Estilo de interação — Agency vs Communion. Como você influencia e se conecta com os outros.",
    color: "from-teal-500/20 to-cyan-500/20",
    border: "border-teal-500/30",
    iconColor: "text-teal-400",
  },
  {
    icon: Award,
    title: "Liderança",
    description: "Cenários de tomada de decisão e gestão de equipes. Seu estilo natural de liderar.",
    color: "from-amber-500/20 to-orange-500/20",
    border: "border-amber-500/30",
    iconColor: "text-amber-400",
  },
  {
    icon: Heart,
    title: "Vitalidade",
    description: "Bem-estar, energia e sustentabilidade no trabalho. Sua capacidade de manter alta performance.",
    color: "from-rose-500/20 to-pink-500/20",
    border: "border-rose-500/30",
    iconColor: "text-rose-400",
  },
  {
    icon: Lightbulb,
    title: "Inovação & Data Literacy",
    description: "Pensamento analítico, uso de dados e capacidade de gerar e implementar ideias criativas.",
    color: "from-violet-500/20 to-purple-500/20",
    border: "border-violet-500/30",
    iconColor: "text-violet-400",
  },
  {
    icon: Compass,
    title: "Fit de Carreira",
    description: "Interesses profissionais (RIASEC), motivadores e valores que direcionam sua trajetória.",
    color: "from-emerald-500/20 to-green-500/20",
    border: "border-emerald-500/30",
    iconColor: "text-emerald-400",
  },
];

// ============ BENEFITS DATA ============

const BENEFITS = [
  {
    icon: Target,
    title: "Autoconhecimento Profundo",
    description: "Descubra seus pontos fortes, áreas de desenvolvimento e padrões comportamentais que impactam sua carreira.",
  },
  {
    icon: BarChart3,
    title: "Relatório Personalizado",
    description: "Receba um relatório detalhado com scores por dimensão, gráficos radar e análise contextualizada por IA.",
  },
  {
    icon: FileText,
    title: "PDI 30/60/90 Dias",
    description: "Plano de Desenvolvimento Individual com ações concretas para os próximos 30, 60 e 90 dias.",
  },
  {
    icon: Zap,
    title: "Insights de IA",
    description: "Resumo executivo gerado por inteligência artificial com recomendações personalizadas para seu contexto.",
  },
  {
    icon: TrendingUp,
    title: "Acompanhamento de Evolução",
    description: "Compare avaliações ao longo do tempo e visualize sua evolução em cada dimensão.",
  },
  {
    icon: Shield,
    title: "Base Científica",
    description: "Fundamentado em modelos validados: Big Five, RIASEC, Agency-Communion e psicologia organizacional.",
  },
];

// ============ PROCESS STEPS ============

const STEPS = [
  {
    number: "01",
    title: "Crie sua conta gratuita",
    description: "Cadastre-se em menos de 1 minuto. Sem cartão de crédito, sem compromisso.",
    icon: Users,
  },
  {
    number: "02",
    title: "Inicie a avaliação",
    description: "Escolha entre o modo Rápido (15 min) ou Completo (25 min) e informe seu contexto profissional.",
    icon: Clock,
  },
  {
    number: "03",
    title: "Responda as perguntas",
    description: "60 itens entre escalas Likert, cenários de julgamento e micro-amostras de trabalho.",
    icon: Brain,
  },
  {
    number: "04",
    title: "Receba seu relatório",
    description: "Relatório completo com scores, gráficos, PDI e recomendações geradas por IA — tudo em PDF.",
    icon: FileText,
  },
];

// ============ FAQ DATA ============

const FAQ_ITEMS = [
  {
    question: "A avaliação é gratuita?",
    answer: "Sim, a avaliação de perfil é totalmente gratuita para todos os membros cadastrados na plataforma. Basta criar sua conta e iniciar.",
  },
  {
    question: "Quanto tempo leva para completar?",
    answer: "No modo Rápido, cerca de 15 minutos. No modo Completo, aproximadamente 25 minutos. Você pode pausar e retomar a qualquer momento.",
  },
  {
    question: "Qual a base científica da avaliação?",
    answer: "A avaliação é fundamentada em modelos validados pela psicologia organizacional: Big Five (personalidade), RIASEC (interesses profissionais), Agency-Communion (comunicação) e escalas de bem-estar ocupacional.",
  },
  {
    question: "Posso refazer a avaliação?",
    answer: "Sim! Você pode realizar múltiplas avaliações ao longo do tempo e comparar seus resultados para acompanhar sua evolução profissional.",
  },
  {
    question: "O relatório é confidencial?",
    answer: "Absolutamente. Seus dados são protegidos e o relatório é acessível apenas por você. Seguimos todas as diretrizes da LGPD.",
  },
  {
    question: "Preciso de conhecimento prévio?",
    answer: "Não. A avaliação é intuitiva e autoexplicativa. Basta responder com honestidade — não existem respostas certas ou erradas.",
  },
];

// ============ FAQ ITEM COMPONENT ============

function FAQItem({ question, answer }: { question: string; answer: string }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div
      className={`border rounded-xl transition-all duration-300 ${
        isOpen ? "border-primary/40 bg-primary/5" : "border-border/50 bg-card/30 hover:border-border"
      }`}
    >
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-5 text-left"
      >
        <span className="font-semibold text-foreground pr-4">{question}</span>
        <ChevronDown
          className={`w-5 h-5 text-muted-foreground shrink-0 transition-transform duration-300 ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </button>
      <div
        className={`overflow-hidden transition-all duration-300 ${
          isOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <p className="px-5 pb-5 text-muted-foreground leading-relaxed">{answer}</p>
      </div>
    </div>
  );
}

// ============ MAIN COMPONENT ============

export default function AssessmentLanding() {
  const { isAuthenticated } = useAuth();

  const ctaHref = isAuthenticated ? "/assessment" : "/login";
  const ctaLabel = isAuthenticated ? "Iniciar Avaliação" : "Criar Conta Gratuita";

  return (
    <div className="min-h-screen bg-background bg-navy-gradient">
      <SEO
        title="Avaliação de Perfil Profissional | Data CX Mentoria"
        description="Descubra seu perfil profissional com nossa avaliação científica gratuita. Relatório personalizado com IA, PDI 30/60/90 e insights para acelerar sua carreira em CX, Dados e IA."
        path="/avaliacao-de-perfil"
      />
      <Navbar />

      {/* ============ HERO ============ */}
      <section className="relative min-h-[85vh] flex items-center overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 bg-radial" />
        <div className="absolute inset-0 bg-radial-coral" />
        <div className="absolute inset-0 bg-grid opacity-30" />
        {/* Floating orbs */}
        <div className="absolute top-20 right-[15%] w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 left-[10%] w-56 h-56 bg-coral/8 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "2s" }} />

        <div className="container relative z-10 py-24">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left - Copy */}
            <div>
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-coral mb-6"
              >
                <Sparkles className="w-4 h-4" />
                <span className="text-sm font-medium">100% Gratuito — Base Científica</span>
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-[1.1] mb-6"
              >
                Descubra seu{" "}
                <span className="gradient-text">Perfil Profissional</span>
                <br />
                em 15 minutos
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="text-lg md:text-xl text-muted-foreground max-w-xl mb-8"
              >
                Avaliação psicométrica com <strong className="text-foreground">60 itens científicos</strong> que mapeia personalidade, comunicação, liderança, inovação e fit de carreira — com relatório personalizado gerado por IA.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="flex flex-col sm:flex-row gap-4 mb-8"
              >
                <Link href={ctaHref}>
                  <Button size="lg" className="btn-coral rounded-xl px-8 py-6 text-lg gap-2 w-full sm:w-auto">
                    <Brain className="w-5 h-5" />
                    {ctaLabel}
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                </Link>
                <a href="#como-funciona">
                  <Button variant="outline" size="lg" className="rounded-xl px-8 py-6 text-lg gap-2 border-border/60 w-full sm:w-auto">
                    Como funciona
                    <ChevronDown className="w-5 h-5" />
                  </Button>
                </a>
              </motion.div>

              {/* Trust signals */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="flex flex-wrap gap-6 text-sm text-muted-foreground"
              >
                <span className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Sem cartão de crédito
                </span>
                <span className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-blue-400" />
                  Dados protegidos (LGPD)
                </span>
                <span className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400" />
                  15-25 minutos
                </span>
              </motion.div>
            </div>

            {/* Right - Visual Preview */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="hidden lg:block"
            >
              <div className="relative">
                {/* Main card - Report preview */}
                <div className="glass rounded-2xl p-6 glow">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                      <Brain className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">Relatório de Perfil</p>
                      <p className="text-xs text-muted-foreground">Protocolo Vértice</p>
                    </div>
                    <Badge className="ml-auto badge-coral text-xs">IA</Badge>
                  </div>

                  {/* Radar chart mockup */}
                  <div className="relative w-full aspect-square max-w-[280px] mx-auto mb-6">
                    <svg viewBox="0 0 200 200" className="w-full h-full">
                      {/* Grid circles */}
                      {[80, 60, 40, 20].map((r) => (
                        <circle
                          key={r}
                          cx="100"
                          cy="100"
                          r={r}
                          fill="none"
                          stroke="oklch(0.30 0.03 260)"
                          strokeWidth="0.5"
                        />
                      ))}
                      {/* Axes */}
                      {[0, 60, 120, 180, 240, 300].map((angle) => {
                        const rad = (angle * Math.PI) / 180;
                        return (
                          <line
                            key={angle}
                            x1="100"
                            y1="100"
                            x2={100 + 80 * Math.cos(rad - Math.PI / 2)}
                            y2={100 + 80 * Math.sin(rad - Math.PI / 2)}
                            stroke="oklch(0.30 0.03 260)"
                            strokeWidth="0.5"
                          />
                        );
                      })}
                      {/* Data polygon */}
                      <polygon
                        points={[
                          [100 + 65 * Math.cos(-Math.PI / 2), 100 + 65 * Math.sin(-Math.PI / 2)],
                          [100 + 55 * Math.cos(Math.PI / 6 - Math.PI / 2), 100 + 55 * Math.sin(Math.PI / 6 - Math.PI / 2)],
                          [100 + 70 * Math.cos(2 * Math.PI / 6 - Math.PI / 2), 100 + 70 * Math.sin(2 * Math.PI / 6 - Math.PI / 2)],
                          [100 + 50 * Math.cos(3 * Math.PI / 6 - Math.PI / 2), 100 + 50 * Math.sin(3 * Math.PI / 6 - Math.PI / 2)],
                          [100 + 60 * Math.cos(4 * Math.PI / 6 - Math.PI / 2), 100 + 60 * Math.sin(4 * Math.PI / 6 - Math.PI / 2)],
                          [100 + 72 * Math.cos(5 * Math.PI / 6 - Math.PI / 2), 100 + 72 * Math.sin(5 * Math.PI / 6 - Math.PI / 2)],
                        ]
                          .map(([x, y]) => `${x},${y}`)
                          .join(" ")}
                        fill="oklch(0.45 0.20 260 / 0.2)"
                        stroke="oklch(0.55 0.20 260)"
                        strokeWidth="2"
                      />
                      {/* Labels */}
                      {[
                        { label: "Personalidade", angle: 0 },
                        { label: "Comunicação", angle: 60 },
                        { label: "Liderança", angle: 120 },
                        { label: "Vitalidade", angle: 180 },
                        { label: "Inovação", angle: 240 },
                        { label: "Carreira", angle: 300 },
                      ].map(({ label, angle }) => {
                        const rad = (angle * Math.PI) / 180;
                        const x = 100 + 95 * Math.cos(rad - Math.PI / 2);
                        const y = 100 + 95 * Math.sin(rad - Math.PI / 2);
                        return (
                          <text
                            key={label}
                            x={x}
                            y={y}
                            textAnchor="middle"
                            dominantBaseline="middle"
                            className="fill-muted-foreground"
                            fontSize="7"
                            fontWeight="500"
                          >
                            {label}
                          </text>
                        );
                      })}
                    </svg>
                  </div>

                  {/* Score bars */}
                  <div className="space-y-3">
                    {[
                      { label: "Abertura", score: 82, color: "bg-blue-500" },
                      { label: "Liderança", score: 75, color: "bg-amber-500" },
                      { label: "Data Literacy", score: 88, color: "bg-violet-500" },
                    ].map((item) => (
                      <div key={item.label} className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground w-20 shrink-0">{item.label}</span>
                        <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${item.score}%` }}
                            transition={{ duration: 1.5, delay: 0.8, ease: "easeOut" }}
                            className={`h-full rounded-full ${item.color}`}
                          />
                        </div>
                        <span className="text-xs font-semibold w-8 text-right">{item.score}%</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Floating badge */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 1 }}
                  className="absolute -bottom-4 -left-4 glass rounded-xl px-4 py-3 flex items-center gap-3 glow-coral"
                >
                  <div className="w-8 h-8 rounded-lg bg-coral/20 flex items-center justify-center">
                    <FileText className="w-4 h-4 text-coral" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold">PDF Disponível</p>
                    <p className="text-[10px] text-muted-foreground">Baixe seu relatório completo</p>
                  </div>
                </motion.div>

                {/* Floating badge 2 */}
                <motion.div
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 1.2 }}
                  className="absolute -top-4 -right-4 glass rounded-xl px-4 py-3 flex items-center gap-3"
                >
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold">PDI Gerado por IA</p>
                    <p className="text-[10px] text-muted-foreground">30 / 60 / 90 dias</p>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ============ SOCIAL PROOF NUMBERS ============ */}
      <section className="py-12 border-y border-border/30">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { value: "60", label: "Itens científicos", suffix: "" },
              { value: "6", label: "Dimensões avaliadas", suffix: "" },
              { value: "15", label: "Minutos (modo rápido)", suffix: "min" },
              { value: "100", label: "Gratuito", suffix: "%" },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <p className="text-3xl md:text-4xl font-extrabold gradient-text stat-number">
                  {stat.value}
                  {stat.suffix && <span className="text-lg">{stat.suffix}</span>}
                </p>
                <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ BENEFITS ============ */}
      <section className="py-20 md:py-28 relative">
        <div className="absolute inset-0 bg-radial opacity-50" />
        <div className="container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <Badge className="badge-dcx mb-4">Por que fazer a avaliação?</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Tudo que você recebe — <span className="gradient-text">gratuitamente</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
              Uma avaliação completa que normalmente custa centenas de reais em consultorias de carreira, disponível para você sem custo.
            </p>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {BENEFITS.map((benefit, i) => (
              <motion.div key={benefit.title} variants={fadeInUp} transition={{ delay: i * 0.08 }}>
                <Card className="bg-card/40 border-border/40 hover:border-primary/30 transition-all duration-300 card-hover h-full">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-xl bg-primary/15 flex items-center justify-center mb-4">
                      <benefit.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2">{benefit.title}</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">{benefit.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ============ HOW IT WORKS ============ */}
      <section id="como-funciona" className="py-20 md:py-28 relative">
        <div className="absolute inset-0 bg-radial-coral opacity-40" />
        <div className="container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <Badge className="badge-coral mb-4">Simples e rápido</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Como funciona
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
              Em 4 passos simples, você terá um mapa completo do seu perfil profissional.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {STEPS.map((step, i) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="relative"
              >
                {/* Connector line */}
                {i < STEPS.length - 1 && (
                  <div className="hidden lg:block absolute top-12 left-[calc(50%+40px)] w-[calc(100%-80px)] h-px bg-gradient-to-r from-border to-border/30" />
                )}

                <div className="text-center">
                  {/* Step number */}
                  <div className="relative inline-flex items-center justify-center w-24 h-24 rounded-2xl bg-card/60 border border-border/50 mb-6 mx-auto">
                    <span className="text-3xl font-extrabold gradient-text">{step.number}</span>
                    <div className="absolute -top-2 -right-2 w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                      <step.icon className="w-4 h-4 text-primary" />
                    </div>
                  </div>

                  <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ DIMENSIONS ============ */}
      <section className="py-20 md:py-28 relative">
        <div className="absolute inset-0 bg-radial opacity-40" />
        <div className="container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <Badge className="badge-dcx mb-4">Avaliação multidimensional</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              6 dimensões que definem seu <span className="gradient-text">perfil</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
              Cada dimensão é avaliada com itens específicos, combinando escalas Likert, cenários de julgamento situacional e micro-amostras de trabalho.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {DIMENSIONS.map((dim, i) => (
              <motion.div
                key={dim.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <Card className={`bg-gradient-to-br ${dim.color} ${dim.border} border hover:scale-[1.02] transition-all duration-300 h-full`}>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 rounded-xl bg-background/40 flex items-center justify-center shrink-0`}>
                        <dim.icon className={`w-6 h-6 ${dim.iconColor}`} />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold mb-1">{dim.title}</h3>
                        <p className="text-sm text-muted-foreground leading-relaxed">{dim.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ REPORT PREVIEW ============ */}
      <section className="py-20 md:py-28 relative overflow-hidden">
        <div className="absolute inset-0 bg-radial-coral opacity-30" />
        <div className="container relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left - Description */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <Badge className="badge-coral mb-4">Exemplo de relatório</Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Um relatório que <span className="gradient-text">realmente</span> faz diferença
              </h2>
              <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
                Não é um teste genérico com respostas vagas. Você recebe um relatório detalhado, contextualizado para sua realidade profissional, com ações práticas para evolução imediata.
              </p>

              <div className="space-y-4">
                {[
                  { icon: BarChart3, text: "Scores detalhados por dimensão e faceta" },
                  { icon: Target, text: "Gráfico radar com visão 360° do seu perfil" },
                  { icon: Brain, text: "Resumo executivo gerado por IA contextualizada" },
                  { icon: Layers, text: "PDI com ações para 30, 60 e 90 dias" },
                  { icon: MessageSquare, text: "Perguntas para devolutiva com mentor" },
                  { icon: FileText, text: "Download em PDF para consulta offline" },
                ].map((item) => (
                  <div key={item.text} className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center shrink-0">
                      <item.icon className="w-4 h-4 text-primary" />
                    </div>
                    <span className="text-sm">{item.text}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Right - Report mockup */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="glass rounded-2xl p-8 glow relative">
                {/* Header */}
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-border/30">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl gradient-dcx flex items-center justify-center">
                      <Brain className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="font-bold text-sm">Relatório de Perfil Profissional</p>
                      <p className="text-xs text-muted-foreground">Data CX — Protocolo Vértice</p>
                    </div>
                  </div>
                  <Badge className="badge-coral text-xs">Exemplo</Badge>
                </div>

                {/* Executive Summary */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-primary" />
                    Resumo Executivo
                  </h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Profissional com forte orientação analítica e alta abertura a novas experiências. Destaca-se pela capacidade de liderança situacional e comunicação assertiva. Área de desenvolvimento principal: equilíbrio entre execução e delegação...
                  </p>
                </div>

                {/* Score bars */}
                <div className="space-y-3 mb-6">
                  <h4 className="text-sm font-semibold mb-3">Scores por Dimensão</h4>
                  {[
                    { label: "Personalidade", score: 82, color: "bg-blue-500" },
                    { label: "Comunicação", score: 68, color: "bg-teal-500" },
                    { label: "Liderança", score: 75, color: "bg-amber-500" },
                    { label: "Vitalidade", score: 62, color: "bg-rose-500" },
                    { label: "Inovação", score: 88, color: "bg-violet-500" },
                    { label: "Fit de Carreira", score: 90, color: "bg-emerald-500" },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center gap-3">
                      <span className="text-xs text-muted-foreground w-24 shrink-0">{item.label}</span>
                      <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${item.score}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 1.2, ease: "easeOut" }}
                          className={`h-full rounded-full ${item.color}`}
                        />
                      </div>
                      <span className="text-xs font-semibold w-8 text-right">{item.score}%</span>
                    </div>
                  ))}
                </div>

                {/* PDI Preview */}
                <div className="bg-background/40 rounded-xl p-4">
                  <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <Target className="w-4 h-4 text-coral" />
                    PDI — Primeiros 30 dias
                  </h4>
                  <div className="space-y-2">
                    {[
                      "Praticar escuta ativa em 3 reuniões semanais",
                      "Iniciar journaling diário de decisões",
                      "Ler 'Thinking, Fast and Slow' (caps. 1-8)",
                    ].map((action, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
                        <span className="text-xs text-muted-foreground">{action}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ============ TESTIMONIAL / SOCIAL PROOF ============ */}
      <section className="py-20 md:py-28 relative">
        <div className="container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <Badge className="badge-dcx mb-4">Quem já fez recomenda</Badge>
            <h2 className="text-3xl md:text-4xl font-bold">
              Profissionais que <span className="gradient-text">transformaram</span> suas carreiras
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              {
                quote: "A avaliação me mostrou padrões que eu não percebia. O PDI foi um divisor de águas na minha transição para liderança.",
                name: "Carolina M.",
                role: "Coordenadora de CX",
              },
              {
                quote: "Nunca vi um assessment tão completo e gratuito. O relatório com IA trouxe insights que eu pagaria caro em uma consultoria.",
                name: "Rafael S.",
                role: "Analista de Dados",
              },
              {
                quote: "O mapeamento de comunicação Agency x Communion mudou a forma como eu lidero minha equipe. Recomendo demais.",
                name: "Patrícia L.",
                role: "Gerente de Operações",
              },
            ].map((testimonial, i) => (
              <motion.div
                key={testimonial.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="testimonial-card h-full">
                  <CardContent className="p-6">
                    <div className="flex gap-1 mb-4">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star key={s} className="w-4 h-4 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed mb-4 italic">
                      "{testimonial.quote}"
                    </p>
                    <div>
                      <p className="font-semibold text-sm">{testimonial.name}</p>
                      <p className="text-xs text-muted-foreground">{testimonial.role}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ FAQ ============ */}
      <section className="py-20 md:py-28 relative">
        <div className="absolute inset-0 bg-radial opacity-30" />
        <div className="container relative z-10 max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <Badge className="badge-dcx mb-4">Dúvidas frequentes</Badge>
            <h2 className="text-3xl md:text-4xl font-bold">
              Perguntas frequentes
            </h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="space-y-3"
          >
            {FAQ_ITEMS.map((item) => (
              <FAQItem key={item.question} question={item.question} answer={item.answer} />
            ))}
          </motion.div>
        </div>
      </section>

      {/* ============ FINAL CTA ============ */}
      <section className="py-20 md:py-28 relative overflow-hidden">
        <div className="absolute inset-0 bg-radial-coral opacity-40" />
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="container relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto text-center"
          >
            <div className="glass rounded-3xl p-10 md:p-16 glow">
              <div className="w-16 h-16 rounded-2xl gradient-dcx flex items-center justify-center mx-auto mb-6">
                <Brain className="w-8 h-8 text-white" />
              </div>

              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Pronto para descobrir seu{" "}
                <span className="gradient-text">perfil profissional</span>?
              </h2>
              <p className="text-muted-foreground text-lg mb-8 max-w-xl mx-auto">
                Faça a avaliação agora e receba seu relatório personalizado com insights de IA, PDI e recomendações práticas — tudo gratuito.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-6">
                <Link href={ctaHref}>
                  <Button size="lg" className="btn-coral rounded-xl px-10 py-6 text-lg gap-2">
                    <Brain className="w-5 h-5" />
                    {ctaLabel}
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                </Link>
              </div>

              <div className="flex flex-wrap gap-6 justify-center text-sm text-muted-foreground">
                <span className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Gratuito para sempre
                </span>
                <span className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400" />
                  15 minutos
                </span>
                <span className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-blue-400" />
                  LGPD compliant
                </span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
