import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import { useEffect, lazy, Suspense } from "react";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

// Carregamento imediato - páginas críticas
import Home from "./pages/Home";
import Login from "./pages/Login";

// Lazy loading - páginas secundárias (carregadas sob demanda)
const About = lazy(() => import("./pages/About"));
const Offers = lazy(() => import("./pages/Offers"));
const Contact = lazy(() => import("./pages/Contact"));
const Members = lazy(() => import("./pages/Members"));
const Admin = lazy(() => import("./pages/Admin"));
const Profile = lazy(() => import("./pages/Profile"));
const RadarVertice = lazy(() => import("./pages/RadarVertice"));
const MentoriaJovens = lazy(() => import("./pages/MentoriaJovens"));
const MentoriaGestores = lazy(() => import("./pages/MentoriaGestores"));
const MentoriaExecutivos = lazy(() => import("./pages/MentoriaExecutivos"));
const Empresas = lazy(() => import("./pages/Empresas"));
const PaymentSuccess = lazy(() => import("./pages/PaymentSuccess"));
const Jornada = lazy(() => import("./pages/Jornada"));
const Privacidade = lazy(() => import("./pages/Privacidade"));
const Conteudos = lazy(() => import("./pages/Conteudos"));
const Comunidade = lazy(() => import("./pages/Comunidade"));
const Workspace = lazy(() => import("./pages/Workspace"));
const Eventos = lazy(() => import("./pages/Eventos"));
const Mensagens = lazy(() => import("./pages/Mensagens"));
const CaseFCO = lazy(() => import("./pages/CaseFCO"));
const Quiz = lazy(() => import("./pages/Quiz"));
const Certificates = lazy(() => import("./pages/Certificates"));
const ContentView = lazy(() => import("./pages/ContentView"));
const ResetPassword = lazy(() => import("./pages/ResetPassword"));
const Upgrade = lazy(() => import("./pages/Upgrade"));
const VerifyCertificate = lazy(() => import("./pages/VerifyCertificate"));
const AIAssistant = lazy(() => import("./components/AIAssistant"));
const Help = lazy(() => import("./pages/Help"));
const Assessment = lazy(() => import("./pages/Assessment"));
const AssessmentLanding = lazy(() => import("./pages/AssessmentLanding"));

// Loading fallback
function PageLoader() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="w-10 h-10 border-3 border-primary/30 border-t-primary rounded-full animate-spin" />
        <p className="text-muted-foreground text-sm">Carregando...</p>
      </div>
    </div>
  );
}

// Componente para scroll to top ao mudar de página
function ScrollToTop() {
  const [location] = useLocation();
  
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [location]);
  
  return null;
}

function Router() {
  return (
    <Suspense fallback={<PageLoader />}>
      <ScrollToTop />
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/sobre" component={About} />
        <Route path="/ofertas" component={Offers} />
        <Route path="/contato" component={Contact} />
        <Route path="/membros" component={Members} />
        <Route path="/admin" component={Admin} />
        <Route path="/perfil" component={Profile} />
        <Route path="/radar" component={RadarVertice} />
        <Route path="/radar-vertice" component={RadarVertice} />
        <Route path="/mentoria-jovens" component={MentoriaJovens} />
        <Route path="/mentoria-gestores" component={MentoriaGestores} />
        <Route path="/mentoria-executivos" component={MentoriaExecutivos} />
        <Route path="/empresas" component={Empresas} />
        <Route path="/login" component={Login} />
        <Route path="/reset-password" component={ResetPassword} />
        <Route path="/pagamento-sucesso" component={PaymentSuccess} />
        <Route path="/jornada" component={Jornada} />
        <Route path="/privacidade" component={Privacidade} />
        <Route path="/conteudos" component={Conteudos} />
        <Route path="/comunidade" component={Comunidade} />
        <Route path="/workspace" component={Workspace} />
        <Route path="/workspace/:projectId" component={Workspace} />
        <Route path="/eventos" component={Eventos} />
        <Route path="/mensagens" component={Mensagens} />
        <Route path="/mensagens/:recipientId" component={Mensagens} />
        <Route path="/cases/120-matriculas" component={CaseFCO} />
        <Route path="/cases/fco" component={CaseFCO} />
        <Route path="/case-fco" component={CaseFCO} />
        <Route path="/case" component={CaseFCO} />
        <Route path="/ajuda" component={Help} />
        <Route path="/avaliacao-de-perfil" component={AssessmentLanding} />
        <Route path="/assessment" component={Assessment} />
        <Route path="/assessment/:sessionId" component={Assessment} />
        <Route path="/programas" component={Offers} />
        <Route path="/planos" component={Offers} />
        <Route path="/precos" component={Offers} />
        <Route path="/quiz/:contentId" component={Quiz} />
        <Route path="/certificados" component={Certificates} />
        <Route path="/verificar-certificado" component={VerifyCertificate} />
        <Route path="/membros/conteudo/:id" component={ContentView} />
        <Route path="/upgrade" component={Upgrade} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <a href="#main-content" className="skip-to-content">Pular para o conteúdo principal</a>
          <Toaster />
          <Router />
          <Suspense fallback={null}>
            <AIAssistant />
          </Suspense>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
