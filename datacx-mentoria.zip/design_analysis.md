# Análise de Design - G4 Educação e FIAP

## G4 Educação - Elementos de Design

### Paleta de Cores
- **Azul marinho escuro** (#1a1f36 / #0f1629): Background principal
- **Coral/Salmão** (#ff6b6b / #e85d5d): Cor de destaque/accent
- **Branco**: Texto principal e elementos de destaque
- **Cinza claro**: Texto secundário

### Tipografia
- Títulos: Sans-serif bold, grande e impactante
- Corpo: Sans-serif regular, boa legibilidade
- Estilo: Moderno, limpo, executivo

### Layout
- Hero section com imagem dos fundadores/mentores
- Cards de programas com hover effects
- Seções bem definidas com espaçamento generoso
- Grid de 3 colunas para programas
- Depoimentos em carousel
- Footer com múltiplas colunas

### Elementos de UX
- CTAs em coral/vermelho que se destacam do fundo escuro
- Badges de "Programa presencial" / "Com mentoria"
- Avaliações com estrelas (NPS 4.5 de 5.0)
- Contadores de alunos formados
- Navegação sticky no topo

## FIAP - Elementos de Design

### Paleta de Cores
- **Preto/Cinza muito escuro**: Background principal
- **Magenta/Rosa** (#e91e63 / #ff1493): Cor de destaque
- **Branco**: Texto principal
- **Gradientes**: Efeitos de luz e partículas

### Tipografia
- Títulos: Sans-serif ultra bold, futurista
- Estilo: Tech, inovador, futurista

### Layout
- Hero fullscreen com animação/vídeo
- Navegação horizontal com mega menu
- Countdown para vestibular
- Elementos geométricos (hexágonos)
- Efeitos de partículas e luz

### Elementos de UX
- Animações de entrada
- Slider de banners
- CTAs em destaque com urgência
- Login separado para aluno/professor

## Recomendação para Data CX Mentoria

### Combinar o melhor dos dois:

1. **Paleta de Cores** (inspirado em G4):
   - Background: Azul marinho escuro (#0a0f1c)
   - Accent primário: Teal/Cyan (#14b8a6) - mantém identidade atual
   - Accent secundário: Coral (#ff6b6b) para CTAs urgentes
   - Branco para texto principal

2. **Tipografia** (inspirado em G4):
   - Títulos grandes e impactantes
   - Fonte: Inter ou similar sans-serif moderna

3. **Layout** (inspirado em G4):
   - Hero com foto do mentor + headline forte
   - Cards de programas em grid
   - Seção de prova social com números
   - Depoimentos em carousel
   - Badges de "Vagas limitadas" / "Próxima turma"

4. **Elementos de UX** (mix):
   - CTAs que se destacam (coral/vermelho)
   - Countdown para próxima turma
   - Avaliações e NPS visíveis
   - Navegação sticky
   - Animações sutis (não exageradas como FIAP)

5. **Diferencial Data CX**:
   - Manter o conceito do Protocolo Vértice
   - Radar Vértice como ferramenta de engajamento
   - Foco em CX, Dados e IA como pilares visuais
