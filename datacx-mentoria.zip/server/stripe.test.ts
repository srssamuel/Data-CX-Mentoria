import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { products, getProductById, formatPrice } from "./products";

// Test products configuration
describe("Products", () => {
  it("should have all required products defined", () => {
    const requiredProductIds = [
      "playbook_vertice",
      "mentoria_grupo",
      "mentoria_sprint",
      "mentoria_90dias",
      "mentoria_executive",
      "diagnostico_360",
      "assessoria_mensal",
    ];

    for (const id of requiredProductIds) {
      const product = getProductById(id);
      expect(product).toBeDefined();
      expect(product?.name).toBeTruthy();
      expect(product?.price).toBeGreaterThan(0);
    }
  });

  it("should format prices correctly in BRL", () => {
    const formatted = formatPrice(37700, "brl");
    expect(formatted).toContain("377");
    expect(formatted).toContain("R$");
  });

  it("should have valid product types", () => {
    for (const product of products) {
      expect(["one_time", "recurring"]).toContain(product.type);
      if (product.type === "recurring") {
        expect(product.interval).toBeDefined();
        expect(["month", "year"]).toContain(product.interval);
      }
    }
  });

  it("should have features for all products", () => {
    for (const product of products) {
      expect(product.features.length).toBeGreaterThan(0);
    }
  });
});

// Test stripe router (public procedures only)
describe("Stripe Router", () => {
  function createPublicContext(): TrpcContext {
    return {
      user: null,
      req: {
        protocol: "https",
        headers: { origin: "https://test.manus.space" },
      } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };
  }

  it("should return products list with formatted prices", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.stripe.getProducts();

    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);

    // Check first product has required fields
    const firstProduct = result[0];
    expect(firstProduct.id).toBeDefined();
    expect(firstProduct.name).toBeDefined();
    expect(firstProduct.price).toBeDefined();
    expect(firstProduct.formattedPrice).toBeDefined();
    expect(firstProduct.formattedPrice).toContain("R$");
  });

  it("should include playbook_vertice in products", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.stripe.getProducts();
    const playbook = result.find(p => p.id === "playbook_vertice");

    expect(playbook).toBeDefined();
    expect(playbook?.price).toBe(37700);
    expect(playbook?.type).toBe("one_time");
  });
});
