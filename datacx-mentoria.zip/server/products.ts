// Stripe Products and Prices for Data CX Mentoria
// Protocolo Vértice - Planos de Mentoria

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number; // em centavos
  currency: string;
  type: "one_time" | "recurring";
  interval?: "month" | "year";
  features: string[];
  badge?: string;
  popular?: boolean;
}

export const products: Product[] = [
  // Plano Introdutório
  {
    id: "playbook_vertice",
    name: "Playbook Vértice",
    description: "Playbook técnico e teórico completo sobre CX, Dados e IA",
    price: 37700, // R$ 377,00
    currency: "brl",
    type: "one_time",
    features: [
      "Playbook completo de CX (PDF)",
      "Playbook de Dados e Analytics (PDF)",
      "Playbook de IA Aplicada (PDF)",
      "Templates prontos para uso",
      "Acesso vitalício ao material",
    ],
    badge: "Entrada",
  },
  
  // Mentoria em Grupo
  {
    id: "mentoria_grupo",
    name: "Mentoria Vértice em Grupo",
    description: "8 semanas de mentoria em grupo com metodologia Protocolo Vértice",
    price: 199700, // R$ 1.997,00
    currency: "brl",
    type: "one_time",
    features: [
      "8 encontros semanais ao vivo",
      "Grupo exclusivo no WhatsApp",
      "Acesso aos playbooks completos",
      "Templates e frameworks",
      "Certificado de conclusão",
      "Networking com outros profissionais",
    ],
    badge: "Popular",
    popular: true,
  },
  
  // Mentoria Individual Sprint
  {
    id: "mentoria_sprint",
    name: "Mentoria Sprint 1:1",
    description: "4 sessões individuais intensivas para resultados rápidos",
    price: 297700, // R$ 2.977,00
    currency: "brl",
    type: "one_time",
    features: [
      "4 sessões individuais de 1h",
      "Diagnóstico personalizado",
      "Plano de ação customizado",
      "Suporte via WhatsApp",
      "Acesso aos playbooks",
      "Follow-up de 30 dias",
    ],
    badge: "Intensivo",
  },
  
  // Mentoria Individual 90 dias
  {
    id: "mentoria_90dias",
    name: "Mentoria Vértice 90 Dias",
    description: "Acompanhamento completo por 3 meses com sessões semanais",
    price: 597700, // R$ 5.977,00
    currency: "brl",
    type: "one_time",
    features: [
      "12 sessões individuais de 1h",
      "Diagnóstico completo 360º",
      "Plano estratégico personalizado",
      "Suporte prioritário via WhatsApp",
      "Acesso vitalício aos playbooks",
      "Revisão mensal de resultados",
      "Certificado de conclusão",
    ],
    badge: "Completo",
  },
  
  // Mentoria Executive
  {
    id: "mentoria_executive",
    name: "Mentoria Executive",
    description: "Programa premium para executivos e líderes seniores",
    price: 1497700, // R$ 14.977,00
    currency: "brl",
    type: "one_time",
    features: [
      "24 sessões individuais de 1h",
      "Diagnóstico empresarial completo",
      "Estratégia de transformação digital",
      "Suporte VIP 24/7",
      "Acesso a todos os materiais",
      "Consultoria para equipe",
      "Relatórios executivos mensais",
      "Networking exclusivo",
    ],
    badge: "Premium",
  },
  
  // Diagnóstico 360º
  {
    id: "diagnostico_360",
    name: "Diagnóstico Vértice 360º",
    description: "Análise completa da maturidade em CX, Dados e IA da sua empresa",
    price: 497700, // R$ 4.977,00
    currency: "brl",
    type: "one_time",
    features: [
      "Análise de 2-4 semanas",
      "Entrevistas com stakeholders",
      "Mapeamento de processos",
      "Relatório executivo completo",
      "Roadmap de implementação",
      "Apresentação para liderança",
      "Quick wins identificados",
    ],
    badge: "Empresas",
  },
  
  // Assessoria Mensal
  {
    id: "assessoria_mensal",
    name: "Assessoria Vértice",
    description: "Acompanhamento contínuo mensal para sua operação",
    price: 997700, // R$ 9.977,00/mês
    currency: "brl",
    type: "recurring",
    interval: "month",
    features: [
      "4 sessões mensais de consultoria",
      "Suporte contínuo via Slack/WhatsApp",
      "Revisão de métricas e KPIs",
      "Apoio em projetos estratégicos",
      "Treinamento da equipe",
      "Relatórios mensais de progresso",
      "Acesso a todos os materiais",
    ],
    badge: "Enterprise",
  },
  // Assessoria Semestral
  {
    id: "assessoria_semestral",
    name: "Assessoria Vértice 6 Meses",
    description: "Acompanhamento estratégico por 6 meses com desconto",
    price: 897700, // R$ 8.977,00/mês (desconto de 10%)
    currency: "brl",
    type: "recurring",
    interval: "month",
    features: [
      "4 sessões mensais de consultoria",
      "Suporte contínuo via Slack/WhatsApp",
      "Revisão de métricas e KPIs",
      "Apoio em projetos estratégicos",
      "Treinamento da equipe",
      "Relatórios mensais de progresso",
      "Acesso a todos os materiais",
      "Desconto de 10% (compromisso semestral)",
    ],
    badge: "6 Meses",
  },

  // Assessoria Anual
  {
    id: "assessoria_anual",
    name: "Assessoria Vértice 12 Meses",
    description: "Transformação completa com acompanhamento anual",
    price: 797700, // R$ 7.977,00/mês (desconto de 20%)
    currency: "brl",
    type: "recurring",
    interval: "month",
    features: [
      "4 sessões mensais de consultoria",
      "Suporte contínuo via Slack/WhatsApp",
      "Revisão de métricas e KPIs",
      "Apoio em projetos estratégicos",
      "Treinamento da equipe",
      "Relatórios mensais de progresso",
      "Acesso a todos os materiais",
      "Desconto de 20% (compromisso anual)",
      "Reunião trimestral com liderança",
    ],
    badge: "Melhor Valor",
  },
];

// Helper para encontrar produto por ID
export function getProductById(id: string): Product | undefined {
  return products.find(p => p.id === id);
}

// Helper para formatar preço
export function formatPrice(priceInCents: number, currency: string = "brl"): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: currency.toUpperCase(),
  }).format(priceInCents / 100);
}
