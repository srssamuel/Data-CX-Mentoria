/**
 * Certificate PDF Generator — Professional Design
 * Clean layout with proper spacing, no overlaps, centered elements.
 * Uses jsPDF to generate landscape A4 certificates.
 */
import { jsPDF, GState } from "jspdf";
import { storagePut } from "./storage";

interface CertificateData {
  recipientName: string;
  courseName: string;
  completionDate: Date;
  certificateNumber: string;
  verificationCode: string;
  category?: string | null;
  type: "category" | "program" | "general";
  mentorName?: string;
}

const CATEGORY_NAMES: Record<string, string> = {
  introducao: "Introdução ao Protocolo Vértice",
  cx: "Customer Experience (CX)",
  dados: "Gestão de Dados & Analytics",
  ia: "Inteligência Artificial Aplicada",
};

const CATEGORY_HOURS: Record<string, number> = {
  introducao: 12,
  cx: 36,
  dados: 36,
  ia: 36,
};

function formatDate(date: Date): string {
  return date.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
}

// ═══════════════════════════════════════════════════════════════
// SHARED HELPERS
// ═══════════════════════════════════════════════════════════════

/** Draw a thin horizontal rule centered on the page */
function drawCenteredRule(doc: jsPDF, y: number, halfWidth: number, cx: number, r: number, g: number, b: number) {
  doc.setDrawColor(r, g, b);
  doc.setLineWidth(0.4);
  doc.line(cx - halfWidth, y, cx + halfWidth, y);
}

/** Draw L-shaped corner brackets */
function drawCornerBrackets(
  doc: jsPDF,
  margin: number,
  pageW: number,
  pageH: number,
  size: number,
  r: number,
  g: number,
  b: number
) {
  doc.setDrawColor(r, g, b);
  doc.setLineWidth(1.2);
  // Top-left
  doc.line(margin, margin, margin + size, margin);
  doc.line(margin, margin, margin, margin + size);
  // Top-right
  doc.line(pageW - margin, margin, pageW - margin - size, margin);
  doc.line(pageW - margin, margin, pageW - margin, margin + size);
  // Bottom-left
  doc.line(margin, pageH - margin, margin + size, pageH - margin);
  doc.line(margin, pageH - margin, margin, pageH - margin - size);
  // Bottom-right
  doc.line(pageW - margin, pageH - margin, pageW - margin - size, pageH - margin);
  doc.line(pageW - margin, pageH - margin, pageW - margin, pageH - margin - size);
}

// ═══════════════════════════════════════════════════════════════
// CATEGORY / PROGRAM CERTIFICATE — Indigo Theme
// ═══════════════════════════════════════════════════════════════

export async function generateCertificatePDF(data: CertificateData): Promise<{ url: string; key: string }> {
  const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
  const W = 297, H = 210, M = 18, cx = W / 2;

  // ── Background ──
  doc.setFillColor(12, 12, 24);
  doc.rect(0, 0, W, H, "F");

  // Subtle top gradient band
  for (let i = 0; i < 8; i++) {
    doc.saveGraphicsState();
    doc.setGState(new GState({ opacity: 0.015 - i * 0.0015 }));
    doc.setFillColor(99, 102, 241);
    doc.rect(0, i * 6, W, 6, "F");
    doc.restoreGraphicsState();
  }

  // ── Border: single clean rect + corner brackets ──
  doc.setDrawColor(60, 63, 140);
  doc.setLineWidth(0.5);
  doc.rect(M, M, W - M * 2, H - M * 2);
  drawCornerBrackets(doc, M - 1, W, H, 14, 99, 102, 241);

  // ═══ VERTICAL LAYOUT (top → bottom, generous spacing) ═══

  // Y cursor — we'll place each element and advance
  let y = M + 16;

  // ── Institution ──
  doc.setFontSize(10);
  doc.setTextColor(99, 102, 241);
  doc.setFont("helvetica", "bold");
  doc.text("D C X", cx, y, { align: "center" });
  y += 5;

  doc.setFontSize(6.5);
  doc.setTextColor(140, 145, 200);
  doc.setFont("helvetica", "normal");
  doc.text("PROTOCOLO VÉRTICE", cx, y, { align: "center" });
  y += 5;

  drawCenteredRule(doc, y, 35, cx, 99, 102, 241);
  y += 10;

  // ── Title ──
  doc.setFontSize(34);
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.text("CERTIFICADO", cx, y, { align: "center" });
  y += 8;

  doc.setFontSize(11);
  doc.setTextColor(140, 145, 200);
  doc.setFont("helvetica", "normal");
  doc.text("de Conclusão", cx, y, { align: "center" });
  y += 12;

  // ── Recipient ──
  doc.setFontSize(9);
  doc.setTextColor(156, 163, 175);
  doc.text("Certificamos que", cx, y, { align: "center" });
  y += 10;

  doc.setFontSize(26);
  doc.setTextColor(99, 102, 241);
  doc.setFont("helvetica", "bold");
  doc.text(data.recipientName, cx, y, { align: "center" });
  y += 10;

  // ── Description ──
  const hours = data.category ? CATEGORY_HOURS[data.category] || 20 : 120;
  doc.setFontSize(9.5);
  doc.setTextColor(200, 200, 210);
  doc.setFont("helvetica", "normal");
  doc.text(
    "concluiu com êxito todos os módulos e atividades avaliativas do programa de formação,",
    cx, y, { align: "center" }
  );
  y += 5.5;
  doc.text(
    `com carga horária total de ${hours} horas.`,
    cx, y, { align: "center" }
  );
  y += 12;

  // ── Course Name Badge ──
  const courseName = data.category ? CATEGORY_NAMES[data.category] || data.courseName : data.courseName;
  const badgeW = Math.min(doc.getTextWidth(courseName) + 24, 200);
  const badgeH = 12;
  const badgeX = cx - badgeW / 2;

  doc.saveGraphicsState();
  doc.setGState(new GState({ opacity: 0.12 }));
  doc.setFillColor(99, 102, 241);
  doc.roundedRect(badgeX, y - 1, badgeW, badgeH, 2, 2, "F");
  doc.restoreGraphicsState();

  doc.setDrawColor(99, 102, 241);
  doc.setLineWidth(0.4);
  doc.roundedRect(badgeX, y - 1, badgeW, badgeH, 2, 2, "S");

  doc.setFontSize(12);
  doc.setTextColor(99, 102, 241);
  doc.setFont("helvetica", "bold");
  doc.text(courseName, cx, y + badgeH / 2 + 1, { align: "center" });
  y += badgeH + 12;

  // ── Seal + Signature (side by side to save vertical space) ──
  const sealCx = cx;
  const sealR = 10;

  // Seal
  doc.setDrawColor(130, 90, 220);
  doc.setLineWidth(0.8);
  doc.circle(sealCx, y + sealR, sealR, "S");
  doc.setDrawColor(99, 102, 241);
  doc.setLineWidth(0.3);
  doc.circle(sealCx, y + sealR, sealR - 2.5, "S");

  doc.setFontSize(5.5);
  doc.setTextColor(130, 90, 220);
  doc.setFont("helvetica", "bold");
  doc.text("DATA CX", sealCx, y + sealR - 2, { align: "center" });
  doc.setFontSize(4.5);
  doc.text("CERTIFICADO", sealCx, y + sealR + 1.5, { align: "center" });
  doc.text("OFICIAL", sealCx, y + sealR + 4.5, { align: "center" });

  y += sealR * 2 + 6;

  // Signature line
  drawCenteredRule(doc, y, 30, cx, 107, 114, 128);
  y += 4;

  const mentorName = data.mentorName || "Samuel Rosa";
  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.text(mentorName, cx, y, { align: "center" });
  y += 4;

  doc.setFontSize(6.5);
  doc.setTextColor(140, 145, 200);
  doc.setFont("helvetica", "normal");
  doc.text("Mentor & Fundador — Protocolo Vértice", cx, y, { align: "center" });

  // ── Footer (anchored to bottom) ──
  const fY = H - M - 8;

  // Left: date
  doc.setFontSize(6);
  doc.setTextColor(120, 120, 140);
  doc.setFont("helvetica", "normal");
  doc.text("DATA DE CONCLUSÃO", M + 8, fY);
  doc.setFontSize(8);
  doc.setTextColor(220, 220, 230);
  doc.text(formatDate(data.completionDate), M + 8, fY + 4.5);

  // Center: certificate number
  doc.setFontSize(6);
  doc.setTextColor(120, 120, 140);
  doc.text("Nº DO CERTIFICADO", cx, fY, { align: "center" });
  doc.setFontSize(7.5);
  doc.setTextColor(99, 102, 241);
  doc.setFont("courier", "normal");
  doc.text(data.certificateNumber, cx, fY + 4.5, { align: "center" });

  // Right: verification code
  doc.setFontSize(6);
  doc.setTextColor(120, 120, 140);
  doc.setFont("helvetica", "normal");
  doc.text("CÓDIGO DE VERIFICAÇÃO", W - M - 8, fY, { align: "right" });
  doc.setFontSize(7.5);
  doc.setTextColor(99, 102, 241);
  doc.setFont("courier", "normal");
  doc.text(data.verificationCode, W - M - 8, fY + 4.5, { align: "right" });

  // Verification URL (very bottom)
  doc.setFontSize(5.5);
  doc.setTextColor(80, 80, 100);
  doc.setFont("helvetica", "normal");
  doc.text(
    "Verifique em: datacx.manus.space/verificar-certificado/" + data.verificationCode,
    cx, H - M - 1, { align: "center" }
  );

  // ── Generate & Upload ──
  const pdfBuffer = Buffer.from(doc.output("arraybuffer"));
  const randomSuffix = Math.random().toString(36).substring(2, 8);
  const fileKey = `certificates/${data.certificateNumber}-${randomSuffix}.pdf`;
  const { url, key } = await storagePut(fileKey, pdfBuffer, "application/pdf");
  return { url, key };
}

// ═══════════════════════════════════════════════════════════════
// GENERAL CERTIFICATE — Premium Gold Design
// Awarded when student completes ALL 4 trails
// ═══════════════════════════════════════════════════════════════

export async function generateGeneralCertificatePDF(data: CertificateData): Promise<{ url: string; key: string }> {
  const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
  const W = 297, H = 210, M = 16, cx = W / 2;

  // Gold palette
  const GOLD = { r: 212, g: 175, b: 55 };
  const GOLD_DARK = { r: 160, g: 130, b: 40 };
  const GOLD_LIGHT = { r: 240, g: 210, b: 100 };

  // ── Background ──
  doc.setFillColor(10, 10, 18);
  doc.rect(0, 0, W, H, "F");

  // Subtle radial gold glow in center
  for (let i = 0; i < 15; i++) {
    const alpha = 0.018 - i * 0.001;
    if (alpha > 0) {
      doc.saveGraphicsState();
      doc.setGState(new GState({ opacity: alpha }));
      doc.setFillColor(GOLD.r, GOLD.g, GOLD.b);
      const r = 40 + i * 10;
      doc.circle(cx, H / 2, r, "F");
      doc.restoreGraphicsState();
    }
  }

  // ── Double Border ──
  doc.setDrawColor(GOLD.r, GOLD.g, GOLD.b);
  doc.setLineWidth(1.2);
  doc.rect(M, M, W - M * 2, H - M * 2);

  doc.setDrawColor(GOLD_DARK.r, GOLD_DARK.g, GOLD_DARK.b);
  doc.setLineWidth(0.4);
  doc.rect(M + 4, M + 4, W - (M + 4) * 2, H - (M + 4) * 2);

  // Corner brackets (gold)
  drawCornerBrackets(doc, M - 1, W, H, 16, GOLD.r, GOLD.g, GOLD.b);

  // ═══ VERTICAL LAYOUT ═══
  let y = M + 18;

  // ── Institution ──
  doc.setFontSize(12);
  doc.setTextColor(GOLD.r, GOLD.g, GOLD.b);
  doc.setFont("helvetica", "bold");
  doc.text("D A T A   C X", cx, y, { align: "center" });
  y += 5.5;

  doc.setFontSize(6.5);
  doc.setTextColor(GOLD_DARK.r, GOLD_DARK.g, GOLD_DARK.b);
  doc.setFont("helvetica", "normal");
  doc.text("PROTOCOLO VÉRTICE  ·  FORMAÇÃO EXECUTIVA", cx, y, { align: "center" });
  y += 6;

  // Gold decorative line
  drawCenteredRule(doc, y, 45, cx, GOLD.r, GOLD.g, GOLD.b);
  y += 12;

  // ── Title ──
  doc.setFontSize(36);
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.text("CERTIFICADO", cx, y, { align: "center" });
  y += 9;

  doc.setFontSize(14);
  doc.setTextColor(GOLD.r, GOLD.g, GOLD.b);
  doc.setFont("helvetica", "bold");
  doc.text("DE EXCELÊNCIA", cx, y, { align: "center" });
  y += 7;

  doc.setFontSize(8);
  doc.setTextColor(GOLD_DARK.r, GOLD_DARK.g, GOLD_DARK.b);
  doc.setFont("helvetica", "normal");
  doc.text("Conclusão Integral do Programa de Formação", cx, y, { align: "center" });
  y += 11;

  // ── Recipient ──
  doc.setFontSize(9);
  doc.setTextColor(180, 180, 190);
  doc.text("Conferido a", cx, y, { align: "center" });
  y += 10;

  doc.setFontSize(28);
  doc.setTextColor(GOLD.r, GOLD.g, GOLD.b);
  doc.setFont("helvetica", "bold");
  doc.text(data.recipientName, cx, y, { align: "center" });
  y += 4;

  // Underline
  const nameW = doc.getTextWidth(data.recipientName);
  drawCenteredRule(doc, y, nameW / 2 + 8, cx, GOLD.r, GOLD.g, GOLD.b);
  y += 9;

  // ── Description ──
  doc.setFontSize(9);
  doc.setTextColor(200, 200, 210);
  doc.setFont("helvetica", "normal");
  doc.text(
    "por concluir com distinção todas as trilhas de formação do Protocolo Vértice,",
    cx, y, { align: "center" }
  );
  y += 5;
  doc.text(
    "totalizando 120 horas de conteúdo em 4 áreas de especialização:",
    cx, y, { align: "center" }
  );
  y += 10;

  // ── 4 Trail Badges (evenly spaced, centered) ──
  const trails = ["Introdução", "CX", "Dados", "IA"];
  const totalBadgeArea = 220;
  const singleBadgeW = 46;
  const gap = (totalBadgeArea - singleBadgeW * 4) / 3;
  const startX = cx - totalBadgeArea / 2;

  trails.forEach((trail, i) => {
    const bx = startX + i * (singleBadgeW + gap);

    // Badge bg
    doc.saveGraphicsState();
    doc.setGState(new GState({ opacity: 0.12 }));
    doc.setFillColor(GOLD.r, GOLD.g, GOLD.b);
    doc.roundedRect(bx, y, singleBadgeW, 10, 2, 2, "F");
    doc.restoreGraphicsState();

    // Badge border
    doc.setDrawColor(GOLD.r, GOLD.g, GOLD.b);
    doc.setLineWidth(0.3);
    doc.roundedRect(bx, y, singleBadgeW, 10, 2, 2, "S");

    // Trail name centered in badge
    doc.setFontSize(8.5);
    doc.setTextColor(GOLD.r, GOLD.g, GOLD.b);
    doc.setFont("helvetica", "bold");
    doc.text(trail, bx + singleBadgeW / 2, y + 6.5, { align: "center" });
  });
  y += 18;

  // ── Seal + Signature ──
  const sealR = 11;
  const sealCy = y + sealR;

  // Seal outer
  doc.setDrawColor(GOLD.r, GOLD.g, GOLD.b);
  doc.setLineWidth(1);
  doc.circle(cx, sealCy, sealR, "S");
  // Seal inner
  doc.setDrawColor(GOLD_DARK.r, GOLD_DARK.g, GOLD_DARK.b);
  doc.setLineWidth(0.4);
  doc.circle(cx, sealCy, sealR - 2.5, "S");

  // Seal text
  doc.setFontSize(5);
  doc.setTextColor(GOLD.r, GOLD.g, GOLD.b);
  doc.setFont("helvetica", "bold");
  doc.text("PROTOCOLO", cx, sealCy - 2.5, { align: "center" });
  doc.setFontSize(7);
  doc.text("VÉRTICE", cx, sealCy + 1, { align: "center" });
  doc.setFontSize(4.5);
  doc.text("COMPLETO", cx, sealCy + 4, { align: "center" });

  y = sealCy + sealR + 5;

  // Signature line
  drawCenteredRule(doc, y, 32, cx, GOLD_DARK.r, GOLD_DARK.g, GOLD_DARK.b);
  y += 4;

  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.text(data.mentorName || "Samuel Rosa", cx, y, { align: "center" });
  y += 4;

  doc.setFontSize(6.5);
  doc.setTextColor(GOLD_DARK.r, GOLD_DARK.g, GOLD_DARK.b);
  doc.setFont("helvetica", "normal");
  doc.text("Mentor & Fundador — Protocolo Vértice", cx, y, { align: "center" });

  // ── Footer (anchored to bottom) ──
  const fY = H - M - 9;

  doc.setFontSize(6);
  doc.setTextColor(120, 120, 140);
  doc.setFont("helvetica", "normal");
  doc.text("DATA DE CONCLUSÃO", M + 10, fY);
  doc.setFontSize(8);
  doc.setTextColor(GOLD.r, GOLD.g, GOLD.b);
  doc.text(formatDate(data.completionDate), M + 10, fY + 4.5);

  doc.setFontSize(6);
  doc.setTextColor(120, 120, 140);
  doc.text("Nº DO CERTIFICADO", cx, fY, { align: "center" });
  doc.setFontSize(7.5);
  doc.setTextColor(GOLD.r, GOLD.g, GOLD.b);
  doc.setFont("courier", "normal");
  doc.text(data.certificateNumber, cx, fY + 4.5, { align: "center" });

  doc.setFontSize(6);
  doc.setTextColor(120, 120, 140);
  doc.setFont("helvetica", "normal");
  doc.text("CÓDIGO DE VERIFICAÇÃO", W - M - 10, fY, { align: "right" });
  doc.setFontSize(7.5);
  doc.setTextColor(GOLD.r, GOLD.g, GOLD.b);
  doc.setFont("courier", "normal");
  doc.text(data.verificationCode, W - M - 10, fY + 4.5, { align: "right" });

  // Verification URL
  doc.setFontSize(5.5);
  doc.setTextColor(80, 80, 100);
  doc.setFont("helvetica", "normal");
  doc.text(
    "Verifique em: datacx.manus.space/verificar-certificado/" + data.verificationCode,
    cx, H - M - 1.5, { align: "center" }
  );

  // ── Generate & Upload ──
  const pdfBuffer = Buffer.from(doc.output("arraybuffer"));
  const randomSuffix = Math.random().toString(36).substring(2, 8);
  const fileKey = `certificates/general-${data.certificateNumber}-${randomSuffix}.pdf`;
  const { url, key } = await storagePut(fileKey, pdfBuffer, "application/pdf");
  return { url, key };
}

// ═══════════════════════════════════════════════════════════════
// Builder Functions
// ═══════════════════════════════════════════════════════════════

export function buildCertificateData(
  userName: string,
  certificate: {
    certificateNumber: string;
    verificationCode: string;
    completionDate: Date;
    category?: string | null;
    type: string;
    programId?: number | null;
  },
  programName?: string
): CertificateData {
  const courseName = certificate.category
    ? CATEGORY_NAMES[certificate.category] || certificate.category
    : programName || "Protocolo Vértice — Formação Completa";

  return {
    recipientName: userName,
    courseName,
    completionDate: certificate.completionDate,
    certificateNumber: certificate.certificateNumber,
    verificationCode: certificate.verificationCode,
    category: certificate.category,
    type: certificate.type as "category" | "program",
    mentorName: "Samuel Rosa",
  };
}

export function buildGeneralCertificateData(
  userName: string,
  certificate: {
    certificateNumber: string;
    verificationCode: string;
    completionDate: Date;
  }
): CertificateData {
  return {
    recipientName: userName,
    courseName: "Protocolo Vértice — Formação Completa",
    completionDate: certificate.completionDate,
    certificateNumber: certificate.certificateNumber,
    verificationCode: certificate.verificationCode,
    category: null,
    type: "general",
    mentorName: "Samuel Rosa",
  };
}
