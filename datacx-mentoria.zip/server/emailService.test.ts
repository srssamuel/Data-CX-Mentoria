import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock the resend module
vi.mock("resend", () => {
  const mockSend = vi.fn().mockResolvedValue({
    data: { id: "test-email-id-123" },
    error: null,
  });
  return {
    Resend: vi.fn().mockImplementation(() => ({
      emails: { send: mockSend },
    })),
  };
});

describe("Email Service", () => {
  beforeEach(() => {
    vi.resetModules();
    vi.unstubAllEnvs();
  });

  describe("sendPasswordResetEmail", () => {
    it("should send password reset email when RESEND_API_KEY is configured", async () => {
      vi.stubEnv("RESEND_API_KEY", "re_test_123456");
      vi.stubEnv("EMAIL_FROM", "Test <test@example.com>");

      const { sendPasswordResetEmail } = await import("./emailService");
      const result = await sendPasswordResetEmail(
        "user@example.com",
        "Test User",
        "https://example.com/reset?token=abc123"
      );

      expect(result.success).toBe(true);
      expect(result.messageId).toBeDefined();
    });

    it("should log email when RESEND_API_KEY is not configured", async () => {
      vi.stubEnv("RESEND_API_KEY", "");

      const { sendPasswordResetEmail } = await import("./emailService");
      const result = await sendPasswordResetEmail(
        "user@example.com",
        "Test User",
        "https://example.com/reset?token=abc123"
      );

      expect(result.success).toBe(true);
      expect(result.messageId).toBe("logged-only");
    });
  });

  describe("sendWelcomeEmail", () => {
    it("should send welcome email when RESEND_API_KEY is configured", async () => {
      vi.stubEnv("RESEND_API_KEY", "re_test_123456");
      vi.stubEnv("EMAIL_FROM", "Test <test@example.com>");

      const { sendWelcomeEmail } = await import("./emailService");
      const result = await sendWelcomeEmail(
        "newuser@example.com",
        "New User",
        "https://example.com"
      );

      expect(result.success).toBe(true);
      expect(result.messageId).toBeDefined();
    });

    it("should log welcome email when RESEND_API_KEY is not configured", async () => {
      vi.stubEnv("RESEND_API_KEY", "");

      const { sendWelcomeEmail } = await import("./emailService");
      const result = await sendWelcomeEmail(
        "newuser@example.com",
        "New User",
        "https://example.com"
      );

      expect(result.success).toBe(true);
      expect(result.messageId).toBe("logged-only");
    });
  });

  describe("sendPurchaseConfirmationEmail", () => {
    it("should send purchase confirmation email when RESEND_API_KEY is configured", async () => {
      vi.stubEnv("RESEND_API_KEY", "re_test_123456");
      vi.stubEnv("EMAIL_FROM", "Test <test@example.com>");

      const { sendPurchaseConfirmationEmail } = await import("./emailService");
      const result = await sendPurchaseConfirmationEmail(
        "buyer@example.com",
        "Buyer Name",
        "Mentoria Vértice em Grupo",
        "R$ 2.997,00",
        "https://example.com"
      );

      expect(result.success).toBe(true);
      expect(result.messageId).toBeDefined();
    });

    it("should log purchase email when RESEND_API_KEY is not configured", async () => {
      vi.stubEnv("RESEND_API_KEY", "");

      const { sendPurchaseConfirmationEmail } = await import("./emailService");
      const result = await sendPurchaseConfirmationEmail(
        "buyer@example.com",
        "Buyer Name",
        "Mentoria Vértice em Grupo",
        "R$ 2.997,00",
        "https://example.com"
      );

      expect(result.success).toBe(true);
      expect(result.messageId).toBe("logged-only");
    });
  });

  describe("Resend error handling", () => {
    it("should return error when Resend API returns an error", async () => {
      vi.stubEnv("RESEND_API_KEY", "re_test_invalid");
      vi.stubEnv("EMAIL_FROM", "Test <test@example.com>");

      // Re-mock with error response
      vi.doMock("resend", () => {
        const mockSend = vi.fn().mockResolvedValue({
          data: null,
          error: { message: "Invalid API key", name: "validation_error" },
        });
        return {
          Resend: vi.fn().mockImplementation(() => ({
            emails: { send: mockSend },
          })),
        };
      });

      const { sendWelcomeEmail } = await import("./emailService");
      const result = await sendWelcomeEmail(
        "user@example.com",
        "User",
        "https://example.com"
      );

      expect(result.success).toBe(false);
      expect(result.error).toBeDefined();
    });
  });
});
