import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createUserContext(role: "user" | "admin" = "user"): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: { origin: "https://test.example.com" },
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

function createAnonymousContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("userPersona", () => {
  it("returns persona for authenticated user", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.userPersona.get();

    // Should return an object with persona field (null if no radar result)
    expect(result).toHaveProperty("persona");
    expect(typeof result.persona === "string" || result.persona === null).toBe(true);
  });

  it("rejects anonymous users", async () => {
    const ctx = createAnonymousContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.userPersona.get()).rejects.toThrow();
  });
});

describe("personaVersions", () => {
  it("returns null for non-existent persona version", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.personaVersions.get({
      contentId: 999999,
      persona: "jovem",
    });

    expect(result).toBeNull();
  });

  it("does not expose audioScriptAdmin to regular users", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);

    // Even if a version existed, audioScriptAdmin should be stripped
    const result = await caller.personaVersions.get({
      contentId: 1,
      persona: "gestor",
    });

    // Result is null (no version yet) or should not have audioScriptAdmin
    if (result !== null) {
      expect(result).not.toHaveProperty("audioScriptAdmin");
    } else {
      expect(result).toBeNull();
    }
  });

  it("returns empty array for non-existent content versions", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.personaVersions.byContent({
      contentId: 999999,
    });

    expect(Array.isArray(result)).toBe(true);
    expect(result).toHaveLength(0);
  });

  it("rejects anonymous users from accessing persona versions", async () => {
    const ctx = createAnonymousContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.personaVersions.get({ contentId: 1, persona: "jovem" })
    ).rejects.toThrow();
  });

  it("statusOverview requires admin role", async () => {
    const userCtx = createUserContext("user");
    const userCaller = appRouter.createCaller(userCtx);

    await expect(
      userCaller.personaVersions.statusOverview()
    ).rejects.toThrow();

    // Admin should succeed
    const adminCtx = createUserContext("admin");
    const adminCaller = appRouter.createCaller(adminCtx);

    const result = await adminCaller.personaVersions.statusOverview();
    expect(Array.isArray(result)).toBe(true);
  });

  it("generateApostila requires admin role", async () => {
    const userCtx = createUserContext("user");
    const userCaller = appRouter.createCaller(userCtx);

    await expect(
      userCaller.personaVersions.generateApostila({
        contentId: 1,
        persona: "jovem",
      })
    ).rejects.toThrow();
  });

  it("batchGenerate requires admin role", async () => {
    const userCtx = createUserContext("user");
    const userCaller = appRouter.createCaller(userCtx);

    await expect(
      userCaller.personaVersions.batchGenerate({})
    ).rejects.toThrow();
  });
});
