import bcrypt from "bcryptjs";
import { SignJWT } from "jose";
import crypto from "crypto";
import { ENV } from "./_core/env";
import * as db from "./db";
import { users } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";

const SALT_ROUNDS = 12;
const RESET_TOKEN_EXPIRY_MS = 60 * 60 * 1000; // 1 hour

// ============ PASSWORD HELPERS ============

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// ============ JWT HELPERS ============

function getSessionSecret() {
  return new TextEncoder().encode(ENV.cookieSecret);
}

export async function createEmailAuthToken(
  userId: number,
  openId: string,
  name: string,
  expiresInMs: number = 365 * 24 * 60 * 60 * 1000
): Promise<string> {
  const secretKey = getSessionSecret();
  const expirationSeconds = Math.floor((Date.now() + expiresInMs) / 1000);

  return new SignJWT({
    openId,
    appId: ENV.appId,
    name: name || "",
  })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setExpirationTime(expirationSeconds)
    .sign(secretKey);
}

// ============ USER REGISTRATION ============

export async function registerUser(data: {
  name: string;
  email: string;
  password: string;
  phone?: string;
  company?: string;
  position?: string;
}): Promise<{ success: boolean; error?: string; user?: any }> {
  const database = await db.getDb();
  if (!database) {
    return { success: false, error: "Banco de dados indisponível" };
  }

  // Check if email already exists
  const existing = await database
    .select()
    .from(users)
    .where(eq(users.email, data.email.toLowerCase().trim()))
    .limit(1);

  if (existing.length > 0) {
    // If user exists with OAuth but no password, allow setting password
    if (existing[0].passwordHash) {
      return { success: false, error: "Este e-mail já está cadastrado. Faça login ou recupere sua senha." };
    }
    // Update existing OAuth user with password
    const passwordHash = await hashPassword(data.password);
    await database
      .update(users)
      .set({
        passwordHash,
        name: data.name || existing[0].name,
        phone: data.phone || existing[0].phone,
        company: data.company || existing[0].company,
        position: data.position || existing[0].position,
        loginMethod: "email",
        updatedAt: new Date(),
      })
      .where(eq(users.id, existing[0].id));

    const updatedUser = await db.getUserById(existing[0].id);
    return { success: true, user: updatedUser };
  }

  // Create new user with email/password
  const passwordHash = await hashPassword(data.password);
  const openId = `email_${crypto.randomUUID()}`; // Generate unique openId for email users

  await database.insert(users).values({
    openId,
    name: data.name,
    email: data.email.toLowerCase().trim(),
    passwordHash,
    loginMethod: "email",
    role: "user",
    phone: data.phone || null,
    company: data.company || null,
    position: data.position || null,
    lastSignedIn: new Date(),
  });

  const newUser = await database
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return { success: true, user: newUser[0] };
}

// ============ USER LOGIN ============

export async function loginUser(
  email: string,
  password: string
): Promise<{ success: boolean; error?: string; user?: any; token?: string }> {
  const database = await db.getDb();
  if (!database) {
    return { success: false, error: "Banco de dados indisponível" };
  }

  const result = await database
    .select()
    .from(users)
    .where(eq(users.email, email.toLowerCase().trim()))
    .limit(1);

  if (result.length === 0) {
    return { success: false, error: "E-mail ou senha incorretos" };
  }

  const user = result[0];

  if (!user.passwordHash) {
    return {
      success: false,
      error: "Esta conta usa login social. Use o botão de login com Google/Apple.",
    };
  }

  const isValid = await verifyPassword(password, user.passwordHash);
  if (!isValid) {
    return { success: false, error: "E-mail ou senha incorretos" };
  }

  // Update last sign in
  await database
    .update(users)
    .set({ lastSignedIn: new Date() })
    .where(eq(users.id, user.id));

  // Create session token (same format as OAuth)
  const token = await createEmailAuthToken(user.id, user.openId, user.name || "");

  return { success: true, user, token };
}

// ============ PASSWORD RESET ============

export async function requestPasswordReset(
  email: string
): Promise<{ success: boolean; error?: string; resetToken?: string }> {
  const database = await db.getDb();
  if (!database) {
    return { success: false, error: "Banco de dados indisponível" };
  }

  const result = await database
    .select()
    .from(users)
    .where(eq(users.email, email.toLowerCase().trim()))
    .limit(1);

  if (result.length === 0) {
    // Don't reveal if email exists - return success anyway
    return { success: true };
  }

  const user = result[0];
  const resetToken = crypto.randomBytes(32).toString("hex");
  const resetTokenExpiry = new Date(Date.now() + RESET_TOKEN_EXPIRY_MS);

  await database
    .update(users)
    .set({
      resetToken,
      resetTokenExpiry,
      updatedAt: new Date(),
    })
    .where(eq(users.id, user.id));

  return { success: true, resetToken };
}

export async function resetPassword(
  token: string,
  newPassword: string
): Promise<{ success: boolean; error?: string }> {
  const database = await db.getDb();
  if (!database) {
    return { success: false, error: "Banco de dados indisponível" };
  }

  const result = await database
    .select()
    .from(users)
    .where(eq(users.resetToken, token))
    .limit(1);

  if (result.length === 0) {
    return { success: false, error: "Token inválido ou expirado" };
  }

  const user = result[0];

  if (!user.resetTokenExpiry || user.resetTokenExpiry < new Date()) {
    return { success: false, error: "Token expirado. Solicite uma nova recuperação de senha." };
  }

  const passwordHash = await hashPassword(newPassword);

  await database
    .update(users)
    .set({
      passwordHash,
      resetToken: null,
      resetTokenExpiry: null,
      loginMethod: "email",
      updatedAt: new Date(),
    })
    .where(eq(users.id, user.id));

  return { success: true };
}

// ============ GET USER BY EMAIL ============

export async function getUserByEmail(email: string) {
  const database = await db.getDb();
  if (!database) return undefined;
  const result = await database
    .select()
    .from(users)
    .where(eq(users.email, email.toLowerCase().trim()))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}
