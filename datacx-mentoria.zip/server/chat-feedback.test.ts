import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock db helpers
const mockSubmitChatFeedback = vi.fn();
const mockGetChatFeedback = vi.fn();

vi.mock("./db", () => ({
  submitChatFeedback: (...args: any[]) => mockSubmitChatFeedback(...args),
  getChatFeedback: (...args: any[]) => mockGetChatFeedback(...args),
}));

describe("Chat Feedback System", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("submitChatFeedback", () => {
    it("should save a rating without comment", async () => {
      mockSubmitChatFeedback.mockResolvedValue({ id: 1 });

      const result = await mockSubmitChatFeedback(1, 100, 200, 5, null);

      expect(mockSubmitChatFeedback).toHaveBeenCalledWith(1, 100, 200, 5, null);
      expect(result).toEqual({ id: 1 });
    });

    it("should save a rating with comment", async () => {
      mockSubmitChatFeedback.mockResolvedValue({ id: 2 });

      const result = await mockSubmitChatFeedback(1, 100, 200, 4, "Ótima resposta!");

      expect(mockSubmitChatFeedback).toHaveBeenCalledWith(1, 100, 200, 4, "Ótima resposta!");
      expect(result).toEqual({ id: 2 });
    });

    it("should update existing feedback (upsert)", async () => {
      mockSubmitChatFeedback.mockResolvedValue({ id: 1 });

      // First submission
      await mockSubmitChatFeedback(1, 100, 200, 3, null);
      // Update with new rating and comment
      await mockSubmitChatFeedback(1, 100, 200, 5, "Mudei de ideia, excelente!");

      expect(mockSubmitChatFeedback).toHaveBeenCalledTimes(2);
      expect(mockSubmitChatFeedback).toHaveBeenLastCalledWith(1, 100, 200, 5, "Mudei de ideia, excelente!");
    });

    it("should reject rating outside 1-5 range", () => {
      // Validate that the rating input is between 1 and 5
      const rating = 0;
      expect(rating >= 1 && rating <= 5).toBe(false);

      const rating2 = 6;
      expect(rating2 >= 1 && rating2 <= 5).toBe(false);

      const validRating = 3;
      expect(validRating >= 1 && validRating <= 5).toBe(true);
    });
  });

  describe("getChatFeedback", () => {
    it("should return feedback list for a user and content", async () => {
      mockGetChatFeedback.mockResolvedValue([
        { id: 1, chatMessageId: 100, rating: 4, comment: "Bom exemplo" },
        { id: 2, chatMessageId: 200, rating: 5, comment: null },
      ]);

      const result = await mockGetChatFeedback(1, 300);

      expect(mockGetChatFeedback).toHaveBeenCalledWith(1, 300);
      expect(result).toHaveLength(2);
      expect(result[0].rating).toBe(4);
      expect(result[0].comment).toBe("Bom exemplo");
      expect(result[1].comment).toBeNull();
    });

    it("should return empty array when no feedback exists", async () => {
      mockGetChatFeedback.mockResolvedValue([]);

      const result = await mockGetChatFeedback(1, 999);

      expect(result).toEqual([]);
    });
  });

  describe("Feedback Map Construction", () => {
    it("should build a map from chatMessageId to feedback", () => {
      const feedbackList = [
        { chatMessageId: 100, rating: 4, comment: "Bom" },
        { chatMessageId: 200, rating: 5, comment: null },
        { chatMessageId: 300, rating: 3, comment: "Pode melhorar" },
      ];

      const map = new Map<number, { rating: number; comment: string | null }>();
      feedbackList.forEach((f) => {
        map.set(f.chatMessageId, { rating: f.rating, comment: f.comment });
      });

      expect(map.size).toBe(3);
      expect(map.get(100)).toEqual({ rating: 4, comment: "Bom" });
      expect(map.get(200)).toEqual({ rating: 5, comment: null });
      expect(map.get(300)).toEqual({ rating: 3, comment: "Pode melhorar" });
      expect(map.get(999)).toBeUndefined();
    });
  });

  describe("Star Rating Validation", () => {
    it("should accept valid ratings 1-5", () => {
      for (let i = 1; i <= 5; i++) {
        expect(i >= 1 && i <= 5).toBe(true);
      }
    });

    it("should highlight correct number of stars for each rating", () => {
      // Simulates the star rendering logic: stars up to `rating` are filled
      const rating = 4;
      const stars = [1, 2, 3, 4, 5].map((i) => ({
        index: i,
        filled: i <= rating,
      }));

      expect(stars.filter((s) => s.filled)).toHaveLength(4);
      expect(stars[3].filled).toBe(true);
      expect(stars[4].filled).toBe(false);
    });
  });
});
