import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user-123",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

function createAdminContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user-123",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

function createPublicContext(): { ctx: TrpcContext } {
  const ctx: TrpcContext = {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("radar router", () => {
  it("should submit radar lead successfully", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const testEmail = `test-${Date.now()}@example.com`;
    
    const result = await caller.radar.submit({
      name: "Test User",
      email: testEmail,
      phone: "11999999999",
      persona: "gestor",
      sector: "Tecnologia",
      teamSize: "11-50",
      mainGoal: "Melhorar CX",
      answers: { q1: 3, q2: 2, q3: 4, q4: 3 },
      scoreCX: "3.0",
      scoreData: "2.5",
      scoreIA: "2.0",
      scoreGovernance: "2.5",
      scoreTotal: "2.5",
      recommendedLevel: "aplicacao",
      recommendedProduct: "Mentoria em Grupo",
      mainCost: "Tempo",
      urgency: "60",
      preferredFormat: "grupo",
      budgetRange: "R$ 2.000 - R$ 5.000",
      challenges: "Estou tentando implementar uma área de CX na empresa mas não sei por onde começar. Temos muitos dados mas não conseguimos transformar em ação.",
      consentMarketing: true,
      consentPrivacy: true,
    });

    expect(result).toBeDefined();
    expect(result.success).toBe(true);
  });

  it("should submit radar lead without challenges (optional field)", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const testEmail = `test-nochallenge-${Date.now()}@example.com`;
    
    const result = await caller.radar.submit({
      name: "No Challenge User",
      email: testEmail,
      persona: "jovem",
      answers: { q1: 3, q2: 2 },
      scoreCX: "3.0",
      scoreData: "2.5",
      scoreIA: "2.0",
      scoreGovernance: "2.5",
      scoreTotal: "2.5",
      recommendedLevel: "fundamentos",
      recommendedProduct: "Mentoria Fundamentos",
      consentMarketing: false,
      consentPrivacy: true,
    });

    expect(result).toBeDefined();
    expect(result.success).toBe(true);
  });

  it("should get radar result by email", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // First submit a lead
    const testEmail = `test-result-${Date.now()}@example.com`;
    
    await caller.radar.submit({
      name: "Result Test User",
      email: testEmail,
      persona: "executivo",
      answers: { q1: 4, q2: 4, q3: 3, q4: 4 },
      scoreCX: "4.0",
      scoreData: "3.5",
      scoreIA: "3.0",
      scoreGovernance: "3.5",
      scoreTotal: "3.5",
      recommendedLevel: "escala",
      recommendedProduct: "Mentoria 1:1",
      consentMarketing: true,
      consentPrivacy: true,
    });

    // Then retrieve it
    const result = await caller.radar.getResult({ email: testEmail });

    expect(result).toBeDefined();
    if (result) {
      expect(result.email).toBe(testEmail);
      expect(result.persona).toBe("executivo");
      expect(result.recommendedLevel).toBe("escala");
    }
  });

  it("should list all radar leads for admin", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.radar.listAll();

    expect(result).toBeDefined();
    expect(Array.isArray(result)).toBe(true);
  });

  it("should get radar metrics for admin", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.radar.metrics();

    expect(result).toBeDefined();
    expect(result).toHaveProperty("total");
    expect(result).toHaveProperty("converted");
    expect(result).toHaveProperty("segments");
    expect(typeof (result as any).segments).toBe("object");
  });

  it("should auto-segment lead based on challenges (dados segment)", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const testEmail = `test-seg-dados-${Date.now()}@example.com`;
    
    const result = await caller.radar.submit({
      name: "Segment Test Dados",
      email: testEmail,
      persona: "gestor",
      answers: { q1: 3, q2: 2 },
      scoreCX: "3.0",
      scoreData: "2.0",
      scoreIA: "2.0",
      scoreGovernance: "2.5",
      scoreTotal: "2.4",
      recommendedLevel: "aplicacao",
      recommendedProduct: "Mentoria em Grupo",
      challenges: "[Falta de dados estruturados] [Sistemas legados sem integra\u00e7\u00e3o] Nossos dados est\u00e3o espalhados em v\u00e1rios sistemas.",
      consentMarketing: true,
      consentPrivacy: true,
    });

    expect(result).toBeDefined();
    expect(result.success).toBe(true);
  });

  it("should auto-segment lead based on challenges (cx segment)", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const testEmail = `test-seg-cx-${Date.now()}@example.com`;
    
    const result = await caller.radar.submit({
      name: "Segment Test CX",
      email: testEmail,
      persona: "executivo",
      answers: { q1: 3, q2: 2 },
      scoreCX: "2.0",
      scoreData: "3.0",
      scoreIA: "2.5",
      scoreGovernance: "3.0",
      scoreTotal: "2.6",
      recommendedLevel: "aplicacao",
      recommendedProduct: "Mentoria em Grupo",
      challenges: "[Dificuldade em medir ROI de CX] [Jornada do cliente n\u00e3o mapeada] Precisamos melhorar a experi\u00eancia do cliente.",
      consentMarketing: true,
      consentPrivacy: true,
    });

    expect(result).toBeDefined();
    expect(result.success).toBe(true);
  });

  it("should list leads by segment for admin", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.radar.leadsBySegment({ segment: "dados" });

    expect(result).toBeDefined();
    expect(Array.isArray(result)).toBe(true);
  });

  it("should list leads with no segment for admin", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.radar.leadsBySegment({ segment: "none" });

    expect(result).toBeDefined();
    expect(Array.isArray(result)).toBe(true);
  });

  it("should reject non-admin from listing leads", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.radar.listAll()).rejects.toThrow();
  });

  it("should submit radar lead with consentWhatsapp", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const testEmail = `test-whatsapp-${Date.now()}@example.com`;
    
    const result = await caller.radar.submit({
      name: "WhatsApp Test User",
      email: testEmail,
      phone: "+5511999999999",
      persona: "gestor",
      answers: { q1: 3, q2: 2 },
      scoreCX: "3.0",
      scoreData: "2.5",
      scoreIA: "2.0",
      scoreGovernance: "2.5",
      scoreTotal: "2.5",
      recommendedLevel: "aplicacao",
      recommendedProduct: "Mentoria em Grupo",
      challenges: "[Falta de dados estruturados] Preciso organizar meus dados.",
      consentMarketing: true,
      consentPrivacy: true,
      consentWhatsapp: true,
    });

    expect(result).toBeDefined();
    expect(result.success).toBe(true);
  });

  it("should get segment trends for admin", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.radar.segmentTrends();

    expect(result).toBeDefined();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("challengeSegments shared module", () => {
  it("should return challenges filtered by persona", async () => {
    const { getChallengesForPersona } = await import("../shared/challengeSegments");

    const gestorChallenges = getChallengesForPersona("gestor");
    expect(gestorChallenges.length).toBeGreaterThan(0);
    expect(gestorChallenges[0].id).toBe("dados");

    const executivoChallenges = getChallengesForPersona("executivo");
    expect(executivoChallenges.length).toBeGreaterThan(0);
    expect(executivoChallenges[0].id).toBe("roi");

    const jovemChallenges = getChallengesForPersona("jovem");
    expect(jovemChallenges.length).toBeGreaterThan(0);
    expect(jovemChallenges[0].id).toBe("cx");
  });

  it("should fallback to gestor for unknown persona", async () => {
    const { getChallengesForPersona } = await import("../shared/challengeSegments");

    const unknownChallenges = getChallengesForPersona("unknown");
    const gestorChallenges = getChallengesForPersona("gestor");
    expect(unknownChallenges.length).toBe(gestorChallenges.length);
    expect(unknownChallenges[0].id).toBe(gestorChallenges[0].id);
  });

  it("should determine primary segment correctly", async () => {
    const { determinePrimarySegment } = await import("../shared/challengeSegments");

    const segment = determinePrimarySegment("[Falta de dados estruturados] [Ferramentas desconectadas]");
    expect(segment).toBe("dados");

    const cxSegment = determinePrimarySegment("[Dificuldade em medir ROI de CX] [Jornada do cliente não mapeada] [Equipe sem capacitação em CX]");
    expect(cxSegment).toBe("cx");
  });

  it("should return null for empty challenges", async () => {
    const { determinePrimarySegment } = await import("../shared/challengeSegments");

    expect(determinePrimarySegment("")).toBeNull();
    expect(determinePrimarySegment("random text without tags")).toBeNull();
  });
});

describe("testimonials router", () => {
  it("should list active testimonials", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.testimonials.listActive();

    expect(result).toBeDefined();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("programs router", () => {
  it("should list active programs publicly", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.programs.list();

    expect(result).toBeDefined();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("contact router", () => {
  it("should submit contact form", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.contact.submit({
      name: "Contact Test",
      email: `contact-${Date.now()}@example.com`,
      message: "Test message for contact form",
      type: "contact",
    });

    expect(result).toBeDefined();
    expect(result.success).toBe(true);
  });

  it("should submit diagnostic request", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.contact.submit({
      name: "Diagnostic Test",
      email: `diagnostic-${Date.now()}@example.com`,
      company: "Test Company",
      message: "I want a diagnostic session",
      type: "diagnostic",
    });

    expect(result).toBeDefined();
    expect(result.success).toBe(true);
  });
});
