import { describe, it, expect } from "vitest";
import { PAGE_SEO } from "../client/src/components/SEO";
import { ORGANIZATION_LD, COURSE_LD, FAQ_LD, createBreadcrumbLD } from "../client/src/components/JsonLd";

describe("SEO Configuration", () => {
  it("should have SEO data for all main pages", () => {
    const requiredPages = [
      "home", "sobre", "ofertas", "contato", "radar", "case",
      "membros", "certificados", "privacidade", "mentoriaJovens",
      "mentoriaGestores", "mentoriaExecutivos", "empresas",
      "login", "upgrade", "jornada",
    ];

    for (const page of requiredPages) {
      expect(PAGE_SEO[page], `Missing SEO data for page: ${page}`).toBeDefined();
      expect(PAGE_SEO[page].title, `Missing title for page: ${page}`).toBeTruthy();
      expect(PAGE_SEO[page].description, `Missing description for page: ${page}`).toBeTruthy();
    }
  });

  it("should have unique titles for each page", () => {
    const titles = Object.values(PAGE_SEO).map((seo) => seo.title);
    const uniqueTitles = new Set(titles);
    expect(uniqueTitles.size).toBe(titles.length);
  });

  it("should have descriptions between 50 and 200 characters", () => {
    for (const [page, seo] of Object.entries(PAGE_SEO)) {
      expect(
        seo.description.length,
        `Description for ${page} is too short (${seo.description.length} chars)`
      ).toBeGreaterThanOrEqual(50);
      expect(
        seo.description.length,
        `Description for ${page} is too long (${seo.description.length} chars)`
      ).toBeLessThanOrEqual(200);
    }
  });

  it("should have titles under 70 characters", () => {
    for (const [page, seo] of Object.entries(PAGE_SEO)) {
      expect(
        seo.title.length,
        `Title for ${page} is too long (${seo.title.length} chars)`
      ).toBeLessThanOrEqual(70);
    }
  });
});

describe("JSON-LD Structured Data", () => {
  it("should have valid Organization structured data", () => {
    expect(ORGANIZATION_LD["@context"]).toBe("https://schema.org");
    expect(ORGANIZATION_LD["@type"]).toBe("Organization");
    expect(ORGANIZATION_LD.name).toContain("Data CX");
    expect(ORGANIZATION_LD.founder).toBeDefined();
    expect(ORGANIZATION_LD.founder.name).toBe("Samuel Rosa");
    expect(ORGANIZATION_LD.contactPoint).toBeDefined();
    expect(ORGANIZATION_LD.contactPoint.email).toBe("contato@datacx.com.br");
    expect(ORGANIZATION_LD.sameAs).toBeInstanceOf(Array);
    expect(ORGANIZATION_LD.sameAs.length).toBeGreaterThan(0);
  });

  it("should have valid Course structured data", () => {
    expect(COURSE_LD["@context"]).toBe("https://schema.org");
    expect(COURSE_LD["@type"]).toBe("Course");
    expect(COURSE_LD.name).toContain("Protocolo Vértice");
    expect(COURSE_LD.inLanguage).toBe("pt-BR");
    expect(COURSE_LD.offers).toBeInstanceOf(Array);
    expect(COURSE_LD.offers.length).toBeGreaterThan(0);
    expect(COURSE_LD.hasCourseInstance).toBeInstanceOf(Array);
    expect(COURSE_LD.hasCourseInstance.length).toBe(4); // 4 trilhas
  });

  it("should have valid FAQ structured data", () => {
    expect(FAQ_LD["@context"]).toBe("https://schema.org");
    expect(FAQ_LD["@type"]).toBe("FAQPage");
    expect(FAQ_LD.mainEntity).toBeInstanceOf(Array);
    expect(FAQ_LD.mainEntity.length).toBeGreaterThan(0);

    for (const question of FAQ_LD.mainEntity) {
      expect(question["@type"]).toBe("Question");
      expect(question.name).toBeTruthy();
      expect(question.acceptedAnswer).toBeDefined();
      expect(question.acceptedAnswer["@type"]).toBe("Answer");
      expect(question.acceptedAnswer.text).toBeTruthy();
    }
  });

  it("should create valid BreadcrumbList structured data", () => {
    const breadcrumb = createBreadcrumbLD([
      { name: "Início", url: "https://example.com" },
      { name: "Programas", url: "https://example.com/ofertas" },
    ]);

    expect(breadcrumb["@context"]).toBe("https://schema.org");
    expect(breadcrumb["@type"]).toBe("BreadcrumbList");
    expect(breadcrumb.itemListElement).toHaveLength(2);
    expect(breadcrumb.itemListElement[0].position).toBe(1);
    expect(breadcrumb.itemListElement[1].position).toBe(2);
    expect(breadcrumb.itemListElement[0].name).toBe("Início");
    expect(breadcrumb.itemListElement[1].name).toBe("Programas");
  });

  it("should have Course offers with valid prices", () => {
    for (const offer of COURSE_LD.offers) {
      expect(offer["@type"]).toBe("Offer");
      expect(offer.priceCurrency).toBe("BRL");
      expect(parseFloat(offer.price)).toBeGreaterThan(0);
      expect(offer.availability).toBe("https://schema.org/InStock");
    }
  });
});
