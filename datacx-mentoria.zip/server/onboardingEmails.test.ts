import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock the email service
vi.mock("./emailService", () => ({
  sendOnboardingEmail: vi.fn().mockResolvedValue(true),
}));

// Mock the db
vi.mock("./db", () => ({
  default: {
    getScheduledEmailsDue: vi.fn().mockResolvedValue([]),
    markScheduledEmailSent: vi.fn().mockResolvedValue(undefined),
    createScheduledEmail: vi.fn().mockResolvedValue(undefined),
  },
}));

describe("Onboarding Emails", () => {
  describe("Email sequence configuration", () => {
    it("should define the correct onboarding email sequence (day 1, 3, 7)", async () => {
      // Import the module to check the sequence
      const { ONBOARDING_SEQUENCE } = await import("./onboardingEmails");
      
      expect(ONBOARDING_SEQUENCE).toBeDefined();
      expect(ONBOARDING_SEQUENCE.length).toBe(3);
      expect(ONBOARDING_SEQUENCE[0].dayOffset).toBe(1);
      expect(ONBOARDING_SEQUENCE[1].dayOffset).toBe(3);
      expect(ONBOARDING_SEQUENCE[2].dayOffset).toBe(7);
    });

    it("should have unique template keys for each email", async () => {
      const { ONBOARDING_SEQUENCE } = await import("./onboardingEmails");
      
      const keys = ONBOARDING_SEQUENCE.map((s: any) => s.templateKey);
      const uniqueKeys = new Set(keys);
      expect(uniqueKeys.size).toBe(keys.length);
    });

    it("should have subjects defined for each email in the sequence", async () => {
      const { ONBOARDING_SEQUENCE } = await import("./onboardingEmails");
      
      ONBOARDING_SEQUENCE.forEach((email: any) => {
        expect(email.subject).toBeDefined();
        expect(email.subject.length).toBeGreaterThan(0);
      });
    });
  });

  describe("Schedule creation", () => {
    it("should calculate correct send dates based on enrollment date", async () => {
      const { calculateSendDates } = await import("./onboardingEmails");
      
      const enrollmentDate = new Date("2026-01-15T10:00:00Z");
      const dates = calculateSendDates(enrollmentDate);
      
      expect(dates.length).toBe(3);
      // Day 1
      expect(dates[0].getDate()).toBe(16);
      // Day 3
      expect(dates[1].getDate()).toBe(18);
      // Day 7
      expect(dates[2].getDate()).toBe(22);
    });
  });
});

describe("Upgrade Page - Testimonials", () => {
  it("should have static testimonials as fallback", () => {
    // Verify the static testimonials structure
    const staticTestimonials = [
      { id: 1, name: "Mariana Costa", rating: 5 },
      { id: 2, name: "Rafael Oliveira", rating: 5 },
      { id: 3, name: "Camila Santos", rating: 5 },
      { id: 4, name: "Pedro Henrique Lima", rating: 5 },
      { id: 5, name: "Ana Beatriz Ferreira", rating: 5 },
    ];

    expect(staticTestimonials.length).toBe(5);
    staticTestimonials.forEach((t) => {
      expect(t.name).toBeDefined();
      expect(t.rating).toBeGreaterThanOrEqual(1);
      expect(t.rating).toBeLessThanOrEqual(5);
    });
  });
});

describe("Release Schedule", () => {
  it("should generate correct weekly schedule dates", () => {
    const startDate = new Date("2026-03-01T00:00:00");
    const intervalDays = 7;
    const moduleCount = 5;

    const dates: Date[] = [];
    for (let i = 0; i < moduleCount; i++) {
      const releaseDate = new Date(startDate);
      releaseDate.setDate(releaseDate.getDate() + i * intervalDays);
      dates.push(releaseDate);
    }

    expect(dates.length).toBe(5);
    expect(dates[0].toISOString().split("T")[0]).toBe("2026-03-01");
    expect(dates[1].toISOString().split("T")[0]).toBe("2026-03-08");
    expect(dates[2].toISOString().split("T")[0]).toBe("2026-03-15");
    expect(dates[3].toISOString().split("T")[0]).toBe("2026-03-22");
    expect(dates[4].toISOString().split("T")[0]).toBe("2026-03-29");
  });

  it("should handle daily interval correctly", () => {
    const startDate = new Date("2026-03-01T00:00:00");
    const intervalDays = 1;
    const moduleCount = 3;

    const dates: Date[] = [];
    for (let i = 0; i < moduleCount; i++) {
      const releaseDate = new Date(startDate);
      releaseDate.setDate(releaseDate.getDate() + i * intervalDays);
      dates.push(releaseDate);
    }

    expect(dates[0].toISOString().split("T")[0]).toBe("2026-03-01");
    expect(dates[1].toISOString().split("T")[0]).toBe("2026-03-02");
    expect(dates[2].toISOString().split("T")[0]).toBe("2026-03-03");
  });

  it("should correctly determine if a module is released", () => {
    const now = new Date();
    const pastDate = new Date(now);
    pastDate.setDate(pastDate.getDate() - 1);
    const futureDate = new Date(now);
    futureDate.setDate(futureDate.getDate() + 1);

    expect(pastDate <= now).toBe(true); // released
    expect(futureDate <= now).toBe(false); // not released
    expect(null === null).toBe(true); // no date = immediate release
  });
});
