import { describe, it, expect } from "vitest";

describe("Email Integration (Resend)", () => {
  it("should have RESEND_API_KEY configured", () => {
    const apiKey = process.env.RESEND_API_KEY;
    expect(apiKey).toBeDefined();
    expect(apiKey).not.toBe("");
    expect(typeof apiKey).toBe("string");
    // Resend API keys start with "re_"
    expect(apiKey?.startsWith("re_")).toBe(true);
  });

  it("should have EMAIL_FROM configured", () => {
    const emailFrom = process.env.EMAIL_FROM;
    expect(emailFrom).toBeDefined();
    expect(emailFrom).not.toBe("");
  });

  it("should validate Resend API key format", () => {
    const apiKey = process.env.RESEND_API_KEY;
    expect(apiKey).toBeDefined();
    // Resend keys follow format: re_XXXXXXXX
    expect(apiKey?.length).toBeGreaterThan(5);
    expect(apiKey?.startsWith("re_")).toBe(true);
  });
});
