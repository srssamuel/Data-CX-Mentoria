import { describe, it, expect, vi } from "vitest";

// Mock the db module
vi.mock("./db", () => ({
  getEngagementMetrics: vi.fn().mockResolvedValue({
    chatThisWeek: 5,
    chatPrevWeek: 3,
    quizThisWeek: 2,
    quizPrevWeek: 1,
    completionsThisWeek: 1,
    completionsPrevWeek: 0,
    totalModules: 60,
    avgCompletionRate: 0,
    quizPerformance: [
      { quizId: 1, contentId: 1, moduleCode: "INT-01", title: "Prova: Mapa do Jogo", category: "introducao", attempts: 0, passed: 0, avgScore: null, uniqueUsers: 0 },
    ],
    moduleEngagement: [
      { contentId: 1, moduleCode: "INT-01", title: "Mapa do Jogo", category: "introducao", views: 5, completions: 1, chatMessages: 3, quizAttempts: 0, avgTimeSpent: 120 },
    ],
  }),
  getStudentProgress: vi.fn().mockResolvedValue([
    { userId: 1, name: "John Dyego", email: "john@test.com", company: null, completedModules: 0, totalModules: 60, chatMessages: 1, quizAttempts: 0, avgQuizScore: null, lastActivity: new Date("2026-02-09") },
  ]),
  getChatFeedbackStats: vi.fn().mockResolvedValue({
    totalFeedbacks: 1,
    averageRating: 4.0,
    feedbacksByModule: [
      { contentId: 30017, moduleCode: "CX-P05", title: "Rechamada/FCR/retrabalho", category: "cx", totalFeedbacks: 1, avgRating: 4.0, totalComments: 1 },
    ],
    recentFeedbacks: [
      { id: 1, rating: 4, comment: "Excelente exemplo prático!", userName: "Samuel Rosa Silva", moduleCode: "CX-P05", contentTitle: "Rechamada/FCR/retrabalho", createdAt: new Date("2026-02-10") },
    ],
  }),
}));

describe("Admin Metrics", () => {
  it("should return engagement metrics with correct structure", async () => {
    const { getEngagementMetrics } = await import("./db");
    const metrics = await getEngagementMetrics();
    
    expect(metrics).toBeDefined();
    expect(metrics.chatThisWeek).toBe(5);
    expect(metrics.chatPrevWeek).toBe(3);
    expect(metrics.quizThisWeek).toBe(2);
    expect(metrics.completionsThisWeek).toBe(1);
    expect(metrics.totalModules).toBe(60);
    expect(metrics.quizPerformance).toHaveLength(1);
    expect(metrics.moduleEngagement).toHaveLength(1);
  });

  it("should return quiz performance with correct fields", async () => {
    const { getEngagementMetrics } = await import("./db");
    const metrics = await getEngagementMetrics();
    const quiz = metrics.quizPerformance[0];
    
    expect(quiz).toHaveProperty("quizId");
    expect(quiz).toHaveProperty("moduleCode");
    expect(quiz).toHaveProperty("title");
    expect(quiz).toHaveProperty("category");
    expect(quiz).toHaveProperty("attempts");
    expect(quiz).toHaveProperty("passed");
    expect(quiz).toHaveProperty("avgScore");
    expect(quiz).toHaveProperty("uniqueUsers");
  });

  it("should return module engagement with correct fields", async () => {
    const { getEngagementMetrics } = await import("./db");
    const metrics = await getEngagementMetrics();
    const mod = metrics.moduleEngagement[0];
    
    expect(mod).toHaveProperty("contentId");
    expect(mod).toHaveProperty("moduleCode");
    expect(mod).toHaveProperty("title");
    expect(mod).toHaveProperty("category");
    expect(mod).toHaveProperty("views");
    expect(mod).toHaveProperty("completions");
    expect(mod).toHaveProperty("chatMessages");
  });

  it("should return student progress with correct structure", async () => {
    const { getStudentProgress } = await import("./db");
    const students = await getStudentProgress();
    
    expect(students).toHaveLength(1);
    expect(students[0].name).toBe("John Dyego");
    expect(students[0].completedModules).toBe(0);
    expect(students[0].totalModules).toBe(60);
    expect(students[0].chatMessages).toBe(1);
  });

  it("should return student progress with all required fields", async () => {
    const { getStudentProgress } = await import("./db");
    const students = await getStudentProgress();
    const student = students[0];
    
    expect(student).toHaveProperty("userId");
    expect(student).toHaveProperty("name");
    expect(student).toHaveProperty("email");
    expect(student).toHaveProperty("completedModules");
    expect(student).toHaveProperty("totalModules");
    expect(student).toHaveProperty("chatMessages");
    expect(student).toHaveProperty("quizAttempts");
    expect(student).toHaveProperty("lastActivity");
  });

  it("should return chat feedback stats with correct structure", async () => {
    const { getChatFeedbackStats } = await import("./db");
    const stats = await getChatFeedbackStats();
    
    expect(stats.totalFeedbacks).toBe(1);
    expect(stats.averageRating).toBe(4.0);
    expect(stats.feedbacksByModule).toHaveLength(1);
    expect(stats.recentFeedbacks).toHaveLength(1);
  });

  it("should return feedback by module with correct fields", async () => {
    const { getChatFeedbackStats } = await import("./db");
    const stats = await getChatFeedbackStats();
    const moduleFeedback = stats.feedbacksByModule[0];
    
    expect(moduleFeedback.moduleCode).toBe("CX-P05");
    expect(moduleFeedback.totalFeedbacks).toBe(1);
    expect(moduleFeedback.avgRating).toBe(4.0);
    expect(moduleFeedback.totalComments).toBe(1);
  });

  it("should return recent feedbacks with user name and comment", async () => {
    const { getChatFeedbackStats } = await import("./db");
    const stats = await getChatFeedbackStats();
    const feedback = stats.recentFeedbacks[0];
    
    expect(feedback.userName).toBe("Samuel Rosa Silva");
    expect(feedback.comment).toBe("Excelente exemplo prático!");
    expect(feedback.rating).toBe(4);
    expect(feedback.moduleCode).toBe("CX-P05");
  });

  it("should calculate engagement trends correctly", async () => {
    const { getEngagementMetrics } = await import("./db");
    const metrics = await getEngagementMetrics();
    
    // Chat trend: (5 - 3) / 3 = 66.7% increase
    const chatTrend = metrics.chatPrevWeek > 0
      ? ((metrics.chatThisWeek - metrics.chatPrevWeek) / metrics.chatPrevWeek) * 100
      : 100;
    expect(chatTrend).toBeCloseTo(66.67, 0);
    
    // Quiz trend: (2 - 1) / 1 = 100% increase
    const quizTrend = metrics.quizPrevWeek > 0
      ? ((metrics.quizThisWeek - metrics.quizPrevWeek) / metrics.quizPrevWeek) * 100
      : 100;
    expect(quizTrend).toBe(100);
  });
});
