import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock the database module
vi.mock("./db", () => ({
  getUserActivePlanSlugs: vi.fn(),
  getUserAccessibleModuleCodes: vi.fn(),
  checkModuleAccess: vi.fn(),
  getUserAccessDetails: vi.fn(),
  setUserModuleOverride: vi.fn(),
  removeUserModuleOverride: vi.fn(),
}));

import * as db from "./db";

const mockedDb = vi.mocked(db);

describe("Access Control System", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("getUserActivePlanSlugs", () => {
    it("should return empty array when user has no plans", async () => {
      mockedDb.getUserActivePlanSlugs.mockResolvedValue([]);
      const result = await db.getUserActivePlanSlugs(1);
      expect(result).toEqual([]);
    });

    it("should return plan slugs for enrolled user", async () => {
      mockedDb.getUserActivePlanSlugs.mockResolvedValue(["playbook-vertice", "mentoria-individual"]);
      const result = await db.getUserActivePlanSlugs(1);
      expect(result).toContain("playbook-vertice");
      expect(result).toContain("mentoria-individual");
      expect(result).toHaveLength(2);
    });
  });

  describe("getUserAccessibleModuleCodes", () => {
    it("should return empty array when user has no plans and no overrides", async () => {
      mockedDb.getUserAccessibleModuleCodes.mockResolvedValue([]);
      const result = await db.getUserAccessibleModuleCodes(1);
      expect(result).toEqual([]);
    });

    it("should return all modules for admin user", async () => {
      const allModules = [
        "INT-01", "INT-02", "INT-03", "INT-04", "INT-05", "INT-06",
        "CX-F01", "CX-F02", "CX-F03",
        "DAD-01", "DAD-02",
        "IA-01", "IA-02",
      ];
      mockedDb.getUserAccessibleModuleCodes.mockResolvedValue(allModules);
      const result = await db.getUserAccessibleModuleCodes(99);
      expect(result).toEqual(allModules);
      expect(result.length).toBeGreaterThan(10);
    });

    it("should return only playbook modules for playbook plan", async () => {
      const playbookModules = [
        "INT-01", "INT-02", "INT-03", "INT-04", "INT-05", "INT-06",
        "CX-F01", "CX-F02", "CX-F03", "CX-F04", "CX-F05", "CX-F06",
        "DAD-01", "DAD-02", "DAD-03", "DAD-04", "DAD-05", "DAD-06",
        "IA-01", "IA-02", "IA-03", "IA-04", "IA-05", "IA-06",
      ];
      mockedDb.getUserAccessibleModuleCodes.mockResolvedValue(playbookModules);
      const result = await db.getUserAccessibleModuleCodes(2);
      expect(result).toContain("INT-01");
      expect(result).toContain("CX-F01");
      expect(result).toContain("DAD-01");
      expect(result).toContain("IA-01");
      // Playbook should not include advanced modules
      expect(result).not.toContain("CX-A01");
    });
  });

  describe("checkModuleAccess", () => {
    it("should return true for accessible module", async () => {
      mockedDb.checkModuleAccess.mockResolvedValue(true);
      const result = await db.checkModuleAccess(1, "INT-01");
      expect(result).toBe(true);
    });

    it("should return false for locked module", async () => {
      mockedDb.checkModuleAccess.mockResolvedValue(false);
      const result = await db.checkModuleAccess(1, "CX-A01");
      expect(result).toBe(false);
    });
  });

  describe("getUserAccessDetails", () => {
    it("should return complete access details for a user", async () => {
      const mockDetails = {
        planSlugs: ["playbook-vertice"],
        planModules: ["INT-01", "INT-02", "CX-F01"],
        overrides: [],
        effectiveModules: ["INT-01", "INT-02", "CX-F01"],
      };
      mockedDb.getUserAccessDetails.mockResolvedValue(mockDetails);
      const result = await db.getUserAccessDetails(1);
      expect(result.planSlugs).toContain("playbook-vertice");
      expect(result.effectiveModules).toContain("INT-01");
      expect(result.overrides).toEqual([]);
    });

    it("should include overrides in access details", async () => {
      const mockDetails = {
        planSlugs: ["playbook-vertice"],
        planModules: ["INT-01", "INT-02"],
        overrides: [
          { id: 1, userId: 1, moduleCode: "CX-A01", action: "grant", reason: "Cortesia" },
        ],
        effectiveModules: ["INT-01", "INT-02", "CX-A01"],
      };
      mockedDb.getUserAccessDetails.mockResolvedValue(mockDetails);
      const result = await db.getUserAccessDetails(1);
      expect(result.overrides).toHaveLength(1);
      expect(result.overrides[0].action).toBe("grant");
      expect(result.effectiveModules).toContain("CX-A01");
    });

    it("should handle revoke overrides correctly", async () => {
      const mockDetails = {
        planSlugs: ["mentoria-individual"],
        planModules: ["INT-01", "INT-02", "CX-F01", "CX-A01"],
        overrides: [
          { id: 2, userId: 1, moduleCode: "CX-A01", action: "revoke", reason: "Acesso temporário expirado" },
        ],
        effectiveModules: ["INT-01", "INT-02", "CX-F01"],
      };
      mockedDb.getUserAccessDetails.mockResolvedValue(mockDetails);
      const result = await db.getUserAccessDetails(1);
      expect(result.effectiveModules).not.toContain("CX-A01");
      expect(result.overrides[0].action).toBe("revoke");
    });
  });

  describe("Frontend Lock Logic", () => {
    // Simulating the frontend isLocked logic
    const FREE_PREVIEW_MODULES = ["INT-01"];

    function isModuleLocked(
      moduleCode: string,
      accessData: { moduleCodes: string[]; isAdmin: boolean; hasActivePlan: boolean } | null
    ): boolean {
      if (!accessData) return false;
      if (accessData.isAdmin) return false;
      if (accessData.hasActivePlan) {
        return !accessData.moduleCodes.includes(moduleCode);
      }
      // No plan: lock everything except free preview
      return !FREE_PREVIEW_MODULES.includes(moduleCode);
    }

    it("should not lock any module for admin", () => {
      const accessData = { moduleCodes: [], isAdmin: true, hasActivePlan: true };
      expect(isModuleLocked("INT-01", accessData)).toBe(false);
      expect(isModuleLocked("CX-A01", accessData)).toBe(false);
      expect(isModuleLocked("IA-06", accessData)).toBe(false);
    });

    it("should lock all except INT-01 when user has no plan", () => {
      const accessData = { moduleCodes: [], isAdmin: false, hasActivePlan: false };
      expect(isModuleLocked("INT-01", accessData)).toBe(false); // Free preview
      expect(isModuleLocked("INT-02", accessData)).toBe(true);
      expect(isModuleLocked("CX-F01", accessData)).toBe(true);
      expect(isModuleLocked("DAD-01", accessData)).toBe(true);
      expect(isModuleLocked("IA-01", accessData)).toBe(true);
    });

    it("should lock only modules outside the plan when user has active plan", () => {
      const accessData = {
        moduleCodes: ["INT-01", "INT-02", "INT-03", "CX-F01", "CX-F02"],
        isAdmin: false,
        hasActivePlan: true,
      };
      expect(isModuleLocked("INT-01", accessData)).toBe(false);
      expect(isModuleLocked("INT-02", accessData)).toBe(false);
      expect(isModuleLocked("CX-F01", accessData)).toBe(false);
      expect(isModuleLocked("CX-A01", accessData)).toBe(true); // Not in plan
      expect(isModuleLocked("DAD-01", accessData)).toBe(true); // Not in plan
    });

    it("should not lock when accessData is null (loading state)", () => {
      expect(isModuleLocked("INT-01", null)).toBe(false);
      expect(isModuleLocked("CX-A01", null)).toBe(false);
    });
  });

  describe("Module Override Operations", () => {
    it("should set a grant override", async () => {
      mockedDb.setUserModuleOverride.mockResolvedValue(undefined);
      await db.setUserModuleOverride({
        userId: 1,
        moduleCode: "CX-A01",
        action: "grant",
        reason: "Cortesia admin",
        grantedBy: 99,
      });
      expect(mockedDb.setUserModuleOverride).toHaveBeenCalledWith({
        userId: 1,
        moduleCode: "CX-A01",
        action: "grant",
        reason: "Cortesia admin",
        grantedBy: 99,
      });
    });

    it("should set a revoke override", async () => {
      mockedDb.setUserModuleOverride.mockResolvedValue(undefined);
      await db.setUserModuleOverride({
        userId: 1,
        moduleCode: "INT-02",
        action: "revoke",
        reason: "Acesso temporário expirado",
      });
      expect(mockedDb.setUserModuleOverride).toHaveBeenCalledWith({
        userId: 1,
        moduleCode: "INT-02",
        action: "revoke",
        reason: "Acesso temporário expirado",
      });
    });

    it("should remove an override", async () => {
      mockedDb.removeUserModuleOverride.mockResolvedValue(undefined);
      await db.removeUserModuleOverride(1, "CX-A01");
      expect(mockedDb.removeUserModuleOverride).toHaveBeenCalledWith(1, "CX-A01");
    });
  });
});
