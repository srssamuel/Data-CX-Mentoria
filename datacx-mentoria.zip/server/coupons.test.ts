import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@datacx.com.br",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: { origin: "https://example.com" },
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: { origin: "https://example.com" },
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("coupons", () => {
  describe("coupons.validate", () => {
    it("returns invalid for non-existent coupon code", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.coupons.validate({
        code: "NONEXISTENT",
      });

      expect(result.valid).toBe(false);
    });
  });

  describe("coupons.listAll", () => {
    it("returns list of coupons for admin user", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.coupons.listAll();

      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("coupons.metrics", () => {
    it("returns coupon metrics for admin user", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.coupons.metrics();

      expect(result).toHaveProperty("totalCoupons");
      expect(result).toHaveProperty("activeCoupons");
      expect(result).toHaveProperty("totalUsages");
      expect(result).toHaveProperty("totalDiscount");
      expect(typeof result.totalCoupons).toBe("number");
      expect(typeof result.activeCoupons).toBe("number");
      expect(typeof result.totalUsages).toBe("number");
      expect(typeof result.totalDiscount).toBe("number");
    });
  });
});
