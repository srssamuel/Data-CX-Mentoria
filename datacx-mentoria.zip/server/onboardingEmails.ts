import { Resend } from "resend";
import { getDb } from "./db";
import { scheduledEmails, users, enrollments, mentorshipPrograms } from "../drizzle/schema";
import { eq, and, lte, isNull } from "drizzle-orm";

// ============ ONBOARDING EMAIL TEMPLATES ============

function getResend(): Resend | null {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) return null;
  return new Resend(apiKey);
}

function getFromAddress(): string {
  const envFrom = process.env.EMAIL_FROM;
  if (envFrom && envFrom.includes("@")) {
    if (!envFrom.includes("<")) return `Data CX <${envFrom}>`;
    return envFrom;
  }
  return "Data CX <noreply@datacx.com.br>";
}

function baseTemplate(content: string): string {
  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { margin: 0; padding: 0; background-color: #0a0e1a; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
    .container { max-width: 600px; margin: 0 auto; background-color: #111827; border-radius: 12px; overflow: hidden; }
    .header { background: linear-gradient(135deg, #1e3a5f 0%, #0a0e1a 100%); padding: 32px 24px; text-align: center; }
    .header h2 { color: #e2e8f0; font-size: 14px; margin: 8px 0 0; font-weight: 400; letter-spacing: 2px; text-transform: uppercase; }
    .body { padding: 32px 24px; color: #cbd5e1; line-height: 1.6; }
    .body h1 { color: #f1f5f9; font-size: 24px; margin: 0 0 16px; }
    .body p { margin: 0 0 16px; font-size: 15px; }
    .btn { display: inline-block; background: linear-gradient(135deg, #e85d4a 0%, #d4432e 100%); color: #ffffff !important; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-weight: 600; font-size: 15px; margin: 8px 0 24px; }
    .divider { border: none; border-top: 1px solid #1f2937; margin: 24px 0; }
    .footer { padding: 24px; text-align: center; color: #6b7280; font-size: 12px; }
    .footer a { color: #6b7280; text-decoration: underline; }
    .highlight { color: #60a5fa; font-weight: 600; }
    .card { background: #1a2332; border: 1px solid #1f2937; border-radius: 8px; padding: 16px; margin: 16px 0; }
    .badge { display: inline-block; background: rgba(232, 93, 74, 0.15); color: #e85d4a; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
    .step { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 16px; }
    .step-num { background: linear-gradient(135deg, #e85d4a, #d4432e); color: white; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 14px; flex-shrink: 0; }
    .step-text { flex: 1; }
    .step-text strong { color: #f1f5f9; }
  </style>
</head>
<body>
  <div style="padding: 24px;">
    <div class="container">
      <div class="header">
        <h2 style="font-size: 20px; font-weight: 700; letter-spacing: 3px; color: #60a5fa;">DCX</h2>
        <h2>PROTOCOLO VÉRTICE</h2>
      </div>
      <div class="body">
        ${content}
      </div>
      <div class="footer">
        <p>Data CX — Protocolo Vértice</p>
        <p>Mentoria em CX, Dados e IA</p>
        <p style="margin-top: 8px;">
          <a href="https://datacx-mentoria.manus.space">Acessar Portal</a> · 
          <a href="https://datacx-mentoria.manus.space/privacidade">Política de Privacidade</a>
        </p>
      </div>
    </div>
  </div>
</body>
</html>`;
}

// Day 1: Welcome & first steps
function getDay1Template(userName: string, programName: string, portalUrl: string): { subject: string; html: string } {
  return {
    subject: `${userName}, sua jornada começa agora! — Data CX`,
    html: baseTemplate(`
      <h1>Sua Jornada Começa Agora!</h1>
      <p>Olá, <span class="highlight">${userName}</span>!</p>
      <p>Parabéns pela decisão de investir no seu desenvolvimento profissional com o programa <strong>${programName}</strong>!</p>
      <p>Para aproveitar ao máximo sua experiência, preparamos um roteiro de primeiros passos:</p>
      
      <div class="step">
        <div class="step-num">1</div>
        <div class="step-text"><strong>Acesse a Área de Membros</strong><br/>Explore os módulos disponíveis e comece pelo primeiro da trilha de Introdução.</div>
      </div>
      <div class="step">
        <div class="step-num">2</div>
        <div class="step-text"><strong>Faça o Radar Vértice</strong><br/>Se ainda não fez, descubra seu nível atual em CX, Dados e IA.</div>
      </div>
      <div class="step">
        <div class="step-num">3</div>
        <div class="step-text"><strong>Participe da Comunidade</strong><br/>Conecte-se com outros alunos, tire dúvidas e compartilhe experiências.</div>
      </div>

      <div style="text-align: center;">
        <a href="${portalUrl}/membros" class="btn">Acessar Meus Módulos</a>
      </div>
      
      <div class="card">
        <p style="margin: 0; font-size: 13px;">💡 <strong>Dica:</strong> Reserve pelo menos 30 minutos por dia para estudar. A consistência é a chave para resultados reais.</p>
      </div>
      
      <p>Estamos juntos nessa jornada!</p>
      <p>Abraços,<br/><strong>Samuel Rosa</strong><br/>Mentor — Protocolo Vértice</p>
    `),
  };
}

// Day 3: Tips & engagement
function getDay3Template(userName: string, programName: string, portalUrl: string): { subject: string; html: string } {
  return {
    subject: `3 dicas para acelerar seus resultados — Data CX`,
    html: baseTemplate(`
      <h1>3 Dicas Para Acelerar Seus Resultados</h1>
      <p>Olá, <span class="highlight">${userName}</span>!</p>
      <p>Já se passaram 3 dias desde que você iniciou o programa <strong>${programName}</strong>. Como está indo?</p>
      <p>Separei 3 dicas que vão turbinar seu aprendizado:</p>
      
      <div class="card">
        <p style="margin: 0 0 12px;"><span class="badge">Dica 1</span></p>
        <p style="margin: 0;"><strong style="color: #f1f5f9;">Use o Tutor IA</strong><br/>Cada módulo tem um assistente de IA que pode responder suas dúvidas em tempo real. Não hesite em perguntar!</p>
      </div>
      
      <div class="card">
        <p style="margin: 0 0 12px;"><span class="badge">Dica 2</span></p>
        <p style="margin: 0;"><strong style="color: #f1f5f9;">Aplique no Trabalho</strong><br/>A cada módulo concluído, tente aplicar pelo menos um conceito no seu dia a dia profissional. Isso acelera a fixação.</p>
      </div>
      
      <div class="card">
        <p style="margin: 0 0 12px;"><span class="badge">Dica 3</span></p>
        <p style="margin: 0;"><strong style="color: #f1f5f9;">Complete os Quizzes</strong><br/>Os quizzes ao final de cada módulo ajudam a consolidar o aprendizado e ganhar pontos na gamificação.</p>
      </div>

      <div style="text-align: center;">
        <a href="${portalUrl}/membros" class="btn">Continuar Estudando</a>
      </div>
      
      <p>Qualquer dúvida, estou à disposição!</p>
      <p>Abraços,<br/><strong>Samuel Rosa</strong><br/>Mentor — Protocolo Vértice</p>
    `),
  };
}

// Day 7: Engagement check & community
function getDay7Template(userName: string, programName: string, portalUrl: string): { subject: string; html: string } {
  return {
    subject: `Sua primeira semana na Data CX — como foi? 🎯`,
    html: baseTemplate(`
      <h1>Uma Semana de Jornada!</h1>
      <p>Olá, <span class="highlight">${userName}</span>!</p>
      <p>Já faz uma semana que você começou o programa <strong>${programName}</strong>. Esse é um marco importante!</p>
      
      <div class="card">
        <p style="margin: 0; font-size: 18px; font-weight: 700; color: #f1f5f9; text-align: center;">🎉 Parabéns pela primeira semana!</p>
        <p style="margin: 8px 0 0; text-align: center; font-size: 14px;">Você já está à frente de 90% dos profissionais que não investem em desenvolvimento contínuo.</p>
      </div>

      <p>Nesta etapa, recomendo que você:</p>
      
      <div class="step">
        <div class="step-num">1</div>
        <div class="step-text"><strong>Revise seus módulos concluídos</strong><br/>Volte aos módulos que já estudou e reforce os conceitos principais.</div>
      </div>
      <div class="step">
        <div class="step-num">2</div>
        <div class="step-text"><strong>Compartilhe na comunidade</strong><br/>Conte para os outros alunos o que você já aprendeu e aplicou.</div>
      </div>
      <div class="step">
        <div class="step-num">3</div>
        <div class="step-text"><strong>Defina metas para a próxima semana</strong><br/>Escolha quantos módulos quer concluir e mantenha o ritmo.</div>
      </div>

      <div style="text-align: center;">
        <a href="${portalUrl}/membros" class="btn">Ver Meu Progresso</a>
      </div>
      
      <hr class="divider" />
      <p style="font-size: 13px; color: #6b7280;">Lembre-se: a transformação digital não acontece da noite para o dia, mas cada módulo concluído é um passo firme na direção certa.</p>
      <p>Conte comigo!</p>
      <p>Abraços,<br/><strong>Samuel Rosa</strong><br/>Mentor — Protocolo Vértice</p>
    `),
  };
}

// ============ EXPORTED CONSTANTS & HELPERS ============

export const ONBOARDING_SEQUENCE = [
  { dayOffset: 1, templateKey: "onboarding_day1", subject: "Sua jornada começa agora!" },
  { dayOffset: 3, templateKey: "onboarding_day3", subject: "3 dicas para acelerar seus resultados" },
  { dayOffset: 7, templateKey: "onboarding_day7", subject: "Sua primeira semana na Data CX" },
];

export function calculateSendDates(enrollmentDate: Date): Date[] {
  return ONBOARDING_SEQUENCE.map(seq => {
    const date = new Date(enrollmentDate);
    date.setDate(date.getDate() + seq.dayOffset);
    return date;
  });
}

// ============ SCHEDULING FUNCTIONS ============

/**
 * Schedule onboarding emails for a new enrollment
 */
export async function scheduleOnboardingEmails(
  userId: number,
  enrollmentId: number,
  programName: string
): Promise<void> {
  const db = await getDb();
  if (!db) return;

  const now = new Date();
  
  // Day 1: Immediate (or 1 hour later to avoid overlap with purchase confirmation)
  const day1 = new Date(now.getTime() + 1 * 60 * 60 * 1000); // +1 hour
  // Day 3
  const day3 = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);
  // Day 7
  const day7 = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

  const emailsToSchedule = [
    { emailType: "onboarding_day1" as const, scheduledFor: day1, subject: "Sua jornada começa agora!" },
    { emailType: "onboarding_day3" as const, scheduledFor: day3, subject: "3 dicas para acelerar seus resultados" },
    { emailType: "onboarding_day7" as const, scheduledFor: day7, subject: "Sua primeira semana na Data CX" },
  ];

  for (const email of emailsToSchedule) {
    await db.insert(scheduledEmails).values({
      userId,
      enrollmentId,
      emailType: email.emailType,
      scheduledFor: email.scheduledFor,
      subject: email.subject,
      status: "pending",
      metadata: { programName },
    });
  }

  console.log(`[Onboarding] Scheduled 3 onboarding emails for user ${userId}, enrollment ${enrollmentId}`);
}

/**
 * Process pending scheduled emails (called by cron/interval)
 */
export async function processPendingEmails(): Promise<{ sent: number; failed: number }> {
  const db = await getDb();
  if (!db) return { sent: 0, failed: 0 };

  const resend = getResend();
  const from = getFromAddress();
  const now = new Date();

  // Get pending emails that are due
  const pendingEmails = await db.select()
    .from(scheduledEmails)
    .where(
      and(
        eq(scheduledEmails.status, "pending"),
        lte(scheduledEmails.scheduledFor, now)
      )
    )
    .limit(20); // Process in batches

  let sent = 0;
  let failed = 0;
  const portalUrl = "https://datacx-mentoria.manus.space";

  for (const email of pendingEmails) {
    try {
      // Get user info
      const [user] = await db.select().from(users).where(eq(users.id, email.userId)).limit(1);
      if (!user || !user.email) {
        await db.update(scheduledEmails)
          .set({ status: "failed", errorMessage: "User or email not found" })
          .where(eq(scheduledEmails.id, email.id));
        failed++;
        continue;
      }

      const programName = (email.metadata as Record<string, string>)?.programName || "Data CX";
      const userName = user.name || "Aluno(a)";

      // Get the right template
      let template: { subject: string; html: string };
      switch (email.emailType) {
        case "onboarding_day1":
          template = getDay1Template(userName, programName, portalUrl);
          break;
        case "onboarding_day3":
          template = getDay3Template(userName, programName, portalUrl);
          break;
        case "onboarding_day7":
          template = getDay7Template(userName, programName, portalUrl);
          break;
        default:
          template = { subject: email.subject || "Data CX", html: baseTemplate(`<p>Olá, ${userName}!</p>`) };
      }

      // Send email
      if (resend) {
        const result = await resend.emails.send({
          from,
          to: user.email,
          subject: template.subject,
          html: template.html,
        });

        if (result.error) {
          throw new Error(result.error.message);
        }
      }

      // Mark as sent
      await db.update(scheduledEmails)
        .set({ status: "sent", sentAt: new Date() })
        .where(eq(scheduledEmails.id, email.id));
      
      console.log(`[Onboarding] Sent ${email.emailType} to ${user.email}`);
      sent++;
    } catch (error: any) {
      await db.update(scheduledEmails)
        .set({ status: "failed", errorMessage: error.message || "Unknown error" })
        .where(eq(scheduledEmails.id, email.id));
      console.error(`[Onboarding] Failed to send email ${email.id}:`, error.message);
      failed++;
    }
  }

  if (sent > 0 || failed > 0) {
    console.log(`[Onboarding] Processed: ${sent} sent, ${failed} failed`);
  }

  return { sent, failed };
}
