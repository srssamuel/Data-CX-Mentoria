import * as dbHelpers from "./db";
import { radarLeads, users, consultingProjects, communityPosts } from "../drizzle/schema";
import { count, gte, eq, sql, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { notifyOwner } from "./_core/notification";

// Use the same db connection pattern as db.ts
const db = drizzle(process.env.DATABASE_URL!);

interface WeeklyMetrics {
  newLeads: number;
  totalLeads: number;
  newUsers: number;
  totalUsers: number;
  activeProjects: number;
  communityPosts: number;
  segmentDistribution: { segment: string; count: number }[];
  topChallenges: string[];
  recentLeads: { name: string; email: string; persona: string; segment: string | null; createdAt: Date }[];
}

async function getWeeklyMetrics(): Promise<WeeklyMetrics> {
  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

  // New leads this week
  const [newLeadsResult] = await db
    .select({ count: count() })
    .from(radarLeads)
    .where(gte(radarLeads.createdAt, oneWeekAgo));

  // Total leads
  const [totalLeadsResult] = await db.select({ count: count() }).from(radarLeads);

  // New users this week
  const [newUsersResult] = await db
    .select({ count: count() })
    .from(users)
    .where(gte(users.createdAt, oneWeekAgo));

  // Total users
  const [totalUsersResult] = await db.select({ count: count() }).from(users);

  // Active consulting projects
  const [activeProjectsResult] = await db
    .select({ count: count() })
    .from(consultingProjects)
    .where(
      sql`${consultingProjects.status} NOT IN ('completed', 'on_hold')`
    );

  // Community posts this week
  const [postsResult] = await db
    .select({ count: count() })
    .from(communityPosts)
    .where(gte(communityPosts.createdAt, oneWeekAgo));

  // Segment distribution of new leads this week
  const segmentRows = await db
    .select({
      segment: radarLeads.challengeSegment,
      count: count(),
    })
    .from(radarLeads)
    .where(gte(radarLeads.createdAt, oneWeekAgo))
    .groupBy(radarLeads.challengeSegment);

  const segmentDistribution = segmentRows.map((r: { segment: string | null; count: number }) => ({
    segment: r.segment || "Não classificado",
    count: r.count,
  }));

  // Top challenges from new leads
  const recentLeadsWithChallenges = await db
    .select({
      challenges: radarLeads.challenges,
    })
    .from(radarLeads)
    .where(gte(radarLeads.createdAt, oneWeekAgo))
    .orderBy(desc(radarLeads.createdAt))
    .limit(20);

  // Extract challenge tags from brackets
  const challengeCount: Record<string, number> = {};
  for (const lead of recentLeadsWithChallenges) {
    if (lead.challenges) {
      const tags = lead.challenges.match(/\[([^\]]+)\]/g);
      if (tags) {
        for (const tag of tags) {
          const clean = tag.replace(/[\[\]]/g, "");
          challengeCount[clean] = (challengeCount[clean] || 0) + 1;
        }
      }
    }
  }
  const topChallenges = Object.entries(challengeCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([name, cnt]) => `${name} (${cnt}x)`);

  // Recent leads (last 5)
  const recentLeads = await db
    .select({
      name: radarLeads.name,
      email: radarLeads.email,
      persona: radarLeads.persona,
      segment: radarLeads.challengeSegment,
      createdAt: radarLeads.createdAt,
    })
    .from(radarLeads)
    .orderBy(desc(radarLeads.createdAt))
    .limit(5);

  return {
    newLeads: newLeadsResult.count,
    totalLeads: totalLeadsResult.count,
    newUsers: newUsersResult.count,
    totalUsers: totalUsersResult.count,
    activeProjects: activeProjectsResult.count,
    communityPosts: postsResult.count,
    segmentDistribution,
    topChallenges,
    recentLeads,
  };
}

function formatSegmentName(segment: string): string {
  const names: Record<string, string> = {
    dados: "📊 Dados & Analytics",
    cx: "🎯 Experiência do Cliente",
    ia: "🤖 IA & Automação",
    governanca: "🏛️ Governança & Compliance",
    cultura: "👥 Cultura & Pessoas",
  };
  return names[segment] || segment;
}

function buildReportContent(metrics: WeeklyMetrics): string {
  const now = new Date();
  const weekStart = new Date(now);
  weekStart.setDate(weekStart.getDate() - 7);

  const formatDate = (d: Date) => d.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" });

  let content = `📈 **Relatório Semanal Data CX Mentoria**\n`;
  content += `Período: ${formatDate(weekStart)} a ${formatDate(now)}\n\n`;

  content += `**Resumo Geral**\n`;
  content += `• Novos leads: ${metrics.newLeads} (total: ${metrics.totalLeads})\n`;
  content += `• Novos usuários: ${metrics.newUsers} (total: ${metrics.totalUsers})\n`;
  content += `• Projetos ativos: ${metrics.activeProjects}\n`;
  content += `• Posts na comunidade: ${metrics.communityPosts}\n\n`;

  if (metrics.segmentDistribution.length > 0) {
    content += `**Distribuição por Segmento (novos leads)**\n`;
    for (const seg of metrics.segmentDistribution) {
      content += `• ${formatSegmentName(seg.segment)}: ${seg.count}\n`;
    }
    content += `\n`;
  }

  if (metrics.topChallenges.length > 0) {
    content += `**Desafios Mais Citados**\n`;
    for (const challenge of metrics.topChallenges) {
      content += `• ${challenge}\n`;
    }
    content += `\n`;
  }

  if (metrics.recentLeads.length > 0) {
    content += `**Últimos Leads**\n`;
    for (const lead of metrics.recentLeads) {
      const persona = lead.persona || "N/A";
      const segment = lead.segment ? formatSegmentName(lead.segment) : "N/A";
      content += `• ${lead.name} (${lead.email}) — ${persona} — ${segment}\n`;
    }
  }

  return content;
}

export async function sendWeeklyReport(): Promise<boolean> {
  try {
    console.log("[WeeklyReport] Generating weekly report...");
    const metrics = await getWeeklyMetrics();
    const content = buildReportContent(metrics);

    const success = await notifyOwner({
      title: `📊 Relatório Semanal — ${metrics.newLeads} novos leads`,
      content,
    });

    if (success) {
      console.log("[WeeklyReport] Weekly report sent successfully");
    } else {
      console.warn("[WeeklyReport] Failed to send weekly report via notification");
    }

    return success;
  } catch (err) {
    console.error("[WeeklyReport] Error generating weekly report:", err);
    return false;
  }
}

// Track last run to avoid duplicate sends
let lastWeeklyReportDate: string | null = null;

export async function checkAndSendWeeklyReport(): Promise<void> {
  const now = new Date();
  // Send every Monday at ~9am (check if it's Monday and hasn't been sent today)
  if (now.getDay() === 1) {
    const today = now.toISOString().split("T")[0];
    if (lastWeeklyReportDate !== today && now.getHours() >= 9) {
      lastWeeklyReportDate = today;
      await sendWeeklyReport();
    }
  }
}
