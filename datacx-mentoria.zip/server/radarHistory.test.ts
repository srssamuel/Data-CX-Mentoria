import { describe, it, expect, vi } from "vitest";

// Test the radar history data structure and sidebar integration
describe("Radar History Feature", () => {
  describe("Data Structure", () => {
    it("should define correct radar history item shape", () => {
      const historyItem = {
        id: 1,
        name: "João Silva",
        email: "joao@example.com",
        persona: "gestor",
        sector: "Tecnologia",
        scoreCX: "3.80",
        scoreData: "2.60",
        scoreIA: "1.80",
        scoreGovernance: "3.20",
        scoreTotal: "2.85",
        recommendedLevel: "aplicacao",
        recommendedProduct: "Mentoria Vértice – Aplicação",
        aiAnalysis: "## Visão Geral\nAnálise personalizada...",
        answers: { cx1: 4, cx2: 3, data1: 2, ia1: 1 },
        createdAt: new Date("2026-02-20T10:00:00Z"),
      };

      expect(historyItem.id).toBe(1);
      expect(historyItem.name).toBe("João Silva");
      expect(parseFloat(historyItem.scoreCX)).toBeCloseTo(3.8);
      expect(parseFloat(historyItem.scoreData)).toBeCloseTo(2.6);
      expect(parseFloat(historyItem.scoreIA)).toBeCloseTo(1.8);
      expect(parseFloat(historyItem.scoreGovernance)).toBeCloseTo(3.2);
      expect(parseFloat(historyItem.scoreTotal)).toBeCloseTo(2.85);
      expect(historyItem.recommendedLevel).toBe("aplicacao");
      expect(historyItem.persona).toBe("gestor");
    });

    it("should handle empty history gracefully", () => {
      const emptyHistory: any[] = [];
      expect(emptyHistory.length).toBe(0);
    });

    it("should sort history by date descending (newest first)", () => {
      const history = [
        { id: 1, createdAt: new Date("2026-01-15T10:00:00Z") },
        { id: 2, createdAt: new Date("2026-02-20T10:00:00Z") },
        { id: 3, createdAt: new Date("2026-01-01T10:00:00Z") },
      ];

      const sorted = [...history].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );

      expect(sorted[0].id).toBe(2); // Feb 20 (newest)
      expect(sorted[1].id).toBe(1); // Jan 15
      expect(sorted[2].id).toBe(3); // Jan 1 (oldest)
    });

    it("should calculate score differences between diagnostics", () => {
      const current = { scoreTotal: "3.50" };
      const previous = { scoreTotal: "2.80" };

      const diff = parseFloat(current.scoreTotal) - parseFloat(previous.scoreTotal);
      expect(diff).toBeCloseTo(0.7);
      expect(diff).toBeGreaterThan(0);
    });

    it("should handle negative score differences", () => {
      const current = { scoreTotal: "2.50" };
      const previous = { scoreTotal: "3.20" };

      const diff = parseFloat(current.scoreTotal) - parseFloat(previous.scoreTotal);
      expect(diff).toBeCloseTo(-0.7);
      expect(diff).toBeLessThan(0);
    });
  });

  describe("Score Color Logic", () => {
    function scoreColor(s: number): string {
      if (s <= 2) return "#ef4444"; // red
      if (s <= 3) return "#f59e0b"; // amber
      return "#22c55e"; // green
    }

    it("should return red for scores <= 2", () => {
      expect(scoreColor(1)).toBe("#ef4444");
      expect(scoreColor(1.5)).toBe("#ef4444");
      expect(scoreColor(2)).toBe("#ef4444");
    });

    it("should return amber for scores between 2 and 3", () => {
      expect(scoreColor(2.1)).toBe("#f59e0b");
      expect(scoreColor(2.5)).toBe("#f59e0b");
      expect(scoreColor(3)).toBe("#f59e0b");
    });

    it("should return green for scores > 3", () => {
      expect(scoreColor(3.1)).toBe("#22c55e");
      expect(scoreColor(4)).toBe("#22c55e");
      expect(scoreColor(5)).toBe("#22c55e");
    });
  });

  describe("Comparison Logic", () => {
    it("should correctly identify the newer diagnostic in a pair", () => {
      const a = { id: 1, createdAt: new Date("2026-01-15T10:00:00Z") };
      const b = { id: 2, createdAt: new Date("2026-02-20T10:00:00Z") };

      const dateA = new Date(a.createdAt).getTime();
      const dateB = new Date(b.createdAt).getTime();
      const result = dateA > dateB
        ? { current: a, previous: b }
        : { current: b, previous: a };

      expect(result.current.id).toBe(2);
      expect(result.previous.id).toBe(1);
    });

    it("should calculate per-dimension differences", () => {
      const current = {
        scoreCX: "4.00",
        scoreData: "3.20",
        scoreIA: "2.80",
        scoreGovernance: "3.60",
      };
      const previous = {
        scoreCX: "3.40",
        scoreData: "2.80",
        scoreIA: "3.00",
        scoreGovernance: "3.00",
      };

      const dims = ["scoreCX", "scoreData", "scoreIA", "scoreGovernance"];
      const diffs = dims.map(d => ({
        key: d,
        diff: parseFloat((current as any)[d]) - parseFloat((previous as any)[d]),
      }));

      expect(diffs[0].diff).toBeCloseTo(0.6);  // CX improved
      expect(diffs[1].diff).toBeCloseTo(0.4);  // Data improved
      expect(diffs[2].diff).toBeCloseTo(-0.2); // IA decreased
      expect(diffs[3].diff).toBeCloseTo(0.6);  // Governance improved
    });
  });

  describe("Sidebar Integration", () => {
    it("should include historico-radar in sidebar section groups", () => {
      const SECTION_GROUPS = [
        {
          label: "APRENDIZADO",
          items: [
            { id: "dashboard", label: "Início" },
            { id: "trilhas", label: "Trilhas" },
            { id: "solucoes", label: "Soluções" },
            { id: "quizzes", label: "Quizzes" },
          ],
        },
        {
          label: "CONQUISTAS",
          items: [
            { id: "certificados", label: "Certificados" },
            { id: "progresso", label: "Meu Progresso" },
            { id: "historico-radar", label: "Histórico Radar" },
          ],
        },
        {
          label: "COMUNIDADE",
          items: [
            { id: "comunidade", label: "Comunidade" },
            { id: "suporte", label: "Ajuda & Suporte" },
          ],
        },
      ];

      const conquistas = SECTION_GROUPS.find(g => g.label === "CONQUISTAS");
      expect(conquistas).toBeDefined();
      
      const radarItem = conquistas!.items.find(i => i.id === "historico-radar");
      expect(radarItem).toBeDefined();
      expect(radarItem!.label).toBe("Histórico Radar");
    });

    it("should pass radarCount in stats", () => {
      const stats = {
        totalModules: 24,
        completedModules: 8,
        totalTemplates: 12,
        totalQuizzes: 0,
        totalCertificates: 2,
        radarCount: 3,
        newCount: 3,
      };

      expect(stats.radarCount).toBe(3);
      expect(typeof stats.radarCount).toBe("number");
    });
  });

  describe("Level Labels", () => {
    const LEVEL_LABELS: Record<string, string> = {
      fundamentos: "Fundamentos",
      aplicacao: "Aplicação",
      escala: "Escala",
      estrategia: "Estratégia",
    };

    it("should map all recommendation levels correctly", () => {
      expect(LEVEL_LABELS["fundamentos"]).toBe("Fundamentos");
      expect(LEVEL_LABELS["aplicacao"]).toBe("Aplicação");
      expect(LEVEL_LABELS["escala"]).toBe("Escala");
      expect(LEVEL_LABELS["estrategia"]).toBe("Estratégia");
    });

    it("should return undefined for unknown levels", () => {
      expect(LEVEL_LABELS["unknown"]).toBeUndefined();
    });
  });

  describe("Persona Labels", () => {
    const PERSONA_LABELS: Record<string, string> = {
      jovem: "Jovem Profissional",
      gestor: "Gestor",
      executivo: "Executivo",
      empresario: "Empresário",
    };

    it("should map all personas correctly", () => {
      expect(PERSONA_LABELS["jovem"]).toBe("Jovem Profissional");
      expect(PERSONA_LABELS["gestor"]).toBe("Gestor");
      expect(PERSONA_LABELS["executivo"]).toBe("Executivo");
      expect(PERSONA_LABELS["empresario"]).toBe("Empresário");
    });
  });

  describe("Evolution Chart Data", () => {
    it("should sort history chronologically for chart (oldest first)", () => {
      const history = [
        { id: 3, createdAt: new Date("2026-03-01") },
        { id: 1, createdAt: new Date("2026-01-01") },
        { id: 2, createdAt: new Date("2026-02-01") },
      ];

      const sorted = [...history].sort(
        (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
      );

      expect(sorted[0].id).toBe(1); // Jan (oldest)
      expect(sorted[1].id).toBe(2); // Feb
      expect(sorted[2].id).toBe(3); // Mar (newest)
    });

    it("should not render chart with less than 2 data points", () => {
      const history = [{ id: 1, createdAt: new Date() }];
      expect(history.length < 2).toBe(true);
    });

    it("should render chart with 2 or more data points", () => {
      const history = [
        { id: 1, createdAt: new Date("2026-01-01") },
        { id: 2, createdAt: new Date("2026-02-01") },
      ];
      expect(history.length >= 2).toBe(true);
    });
  });

  // ===== NEW: PDF Generation Tests =====

  describe("PDF Radar SVG Generation", () => {
    // Replicate the SVG generation logic from the component
    function generateRadarSVGForPDF(
      scores1: number[], scores2: number[] | null,
      labels: string[], colors: string[],
      size: number = 300
    ): string {
      const center = size / 2;
      const maxR = (size / 2) - 30;
      
      const getPoint = (score: number, index: number) => {
        const angle = (Math.PI * 2 * index / 4) - Math.PI / 2;
        const r = (score / 5) * maxR;
        return { x: center + r * Math.cos(angle), y: center + r * Math.sin(angle) };
      };

      let svg = `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg">`;
      
      for (let level = 1; level <= 5; level++) {
        const pts = [0,1,2,3].map(i => getPoint(level, i));
        svg += `<polygon points="${pts.map(p => `${p.x},${p.y}`).join(' ')}" fill="none" stroke="#e5e7eb" stroke-width="0.8"/>`;
      }
      
      for (let i = 0; i < 4; i++) {
        const end = getPoint(5, i);
        svg += `<line x1="${center}" y1="${center}" x2="${end.x}" y2="${end.y}" stroke="#e5e7eb" stroke-width="0.8"/>`;
      }

      for (let level = 1; level <= 5; level++) {
        const pt = getPoint(level, 0);
        svg += `<text x="${pt.x + 6}" y="${pt.y - 4}" font-size="9" fill="#9ca3af" font-family="Inter, sans-serif">${level}</text>`;
      }

      if (scores2) {
        const pts2 = scores2.map((s, i) => getPoint(s, i));
        svg += `<polygon points="${pts2.map(p => `${p.x},${p.y}`).join(' ')}" fill="rgba(156,163,175,0.15)" stroke="#9ca3af" stroke-width="1.5" stroke-dasharray="6,3"/>`;
        pts2.forEach((p) => {
          svg += `<circle cx="${p.x}" cy="${p.y}" r="4" fill="#9ca3af" stroke="white" stroke-width="1.5"/>`;
        });
      }

      const pts1 = scores1.map((s, i) => getPoint(s, i));
      svg += `<polygon points="${pts1.map(p => `${p.x},${p.y}`).join(' ')}" fill="rgba(6,182,212,0.2)" stroke="#06b6d4" stroke-width="2"/>`;
      pts1.forEach((p, i) => {
        svg += `<circle cx="${p.x}" cy="${p.y}" r="5" fill="${colors[i]}" stroke="white" stroke-width="2"/>`;
      });

      const labelPositions = [0,1,2,3].map(i => getPoint(6.2, i));
      labelPositions.forEach((p, i) => {
        svg += `<text x="${p.x}" y="${p.y}" text-anchor="middle" dominant-baseline="middle" font-size="12" font-weight="600" fill="${colors[i]}" font-family="Inter, sans-serif">${labels[i]}</text>`;
      });

      svg += `</svg>`;
      return svg;
    }

    it("should generate valid SVG string for single diagnostic", () => {
      const svg = generateRadarSVGForPDF(
        [3.8, 2.6, 1.8, 3.2], null,
        ["CX", "Dados", "IA", "Gov"],
        ["#2563eb", "#16a34a", "#9333ea", "#d97706"],
        300
      );

      expect(svg).toContain("<svg");
      expect(svg).toContain("</svg>");
      expect(svg).toContain('width="300"');
      expect(svg).toContain('height="300"');
      // Should contain the data polygon
      expect(svg).toContain("stroke=\"#06b6d4\"");
      // Should contain labels
      expect(svg).toContain("CX");
      expect(svg).toContain("Dados");
      expect(svg).toContain("IA");
      expect(svg).toContain("Gov");
      // Should NOT contain the comparison polygon
      expect(svg).not.toContain("stroke-dasharray");
    });

    it("should generate valid SVG string for comparison (two diagnostics)", () => {
      const svg = generateRadarSVGForPDF(
        [4.0, 3.2, 2.8, 3.6],
        [3.4, 2.8, 3.0, 3.0],
        ["CX", "Dados", "IA", "Gov"],
        ["#2563eb", "#16a34a", "#9333ea", "#d97706"],
        300
      );

      expect(svg).toContain("<svg");
      expect(svg).toContain("</svg>");
      // Should contain the comparison dashed polygon
      expect(svg).toContain("stroke-dasharray=\"6,3\"");
      expect(svg).toContain("stroke=\"#9ca3af\"");
      // Should contain the current polygon
      expect(svg).toContain("stroke=\"#06b6d4\"");
    });

    it("should generate grid with 5 levels", () => {
      const svg = generateRadarSVGForPDF(
        [3, 3, 3, 3], null,
        ["CX", "Dados", "IA", "Gov"],
        ["#2563eb", "#16a34a", "#9333ea", "#d97706"]
      );

      // Should have 5 grid level text labels
      for (let i = 1; i <= 5; i++) {
        expect(svg).toContain(`>${i}</text>`);
      }
    });

    it("should handle zero scores", () => {
      const svg = generateRadarSVGForPDF(
        [0, 0, 0, 0], null,
        ["CX", "Dados", "IA", "Gov"],
        ["#2563eb", "#16a34a", "#9333ea", "#d97706"]
      );

      expect(svg).toContain("<svg");
      expect(svg).toContain("</svg>");
    });

    it("should handle max scores (5.0)", () => {
      const svg = generateRadarSVGForPDF(
        [5, 5, 5, 5], null,
        ["CX", "Dados", "IA", "Gov"],
        ["#2563eb", "#16a34a", "#9333ea", "#d97706"]
      );

      expect(svg).toContain("<svg");
      expect(svg).toContain("</svg>");
    });

    it("should use correct custom size", () => {
      const svg = generateRadarSVGForPDF(
        [3, 3, 3, 3], null,
        ["CX", "Dados", "IA", "Gov"],
        ["#2563eb", "#16a34a", "#9333ea", "#d97706"],
        400
      );

      expect(svg).toContain('width="400"');
      expect(svg).toContain('height="400"');
    });
  });

  describe("PDF Comparison Insights Logic", () => {
    const dims = [
      { key: "scoreCX", shortLabel: "CX", color: "#2563eb" },
      { key: "scoreData", shortLabel: "Dados", color: "#16a34a" },
      { key: "scoreIA", shortLabel: "IA", color: "#9333ea" },
      { key: "scoreGovernance", shortLabel: "Gov", color: "#d97706" },
    ];

    function getInsights(currScores: number[], prevScores: number[]) {
      const improvements = dims.filter((_, i) => currScores[i] > prevScores[i]);
      const declines = dims.filter((_, i) => currScores[i] < prevScores[i]);
      const stable = dims.filter((_, i) => currScores[i] === prevScores[i]);
      return { improvements, declines, stable };
    }

    it("should identify all improvements", () => {
      const { improvements, declines, stable } = getInsights(
        [4.0, 3.5, 3.0, 4.0],
        [3.0, 2.5, 2.0, 3.0]
      );
      expect(improvements.length).toBe(4);
      expect(declines.length).toBe(0);
      expect(stable.length).toBe(0);
    });

    it("should identify all declines", () => {
      const { improvements, declines, stable } = getInsights(
        [2.0, 1.5, 1.0, 2.0],
        [3.0, 2.5, 2.0, 3.0]
      );
      expect(improvements.length).toBe(0);
      expect(declines.length).toBe(4);
      expect(stable.length).toBe(0);
    });

    it("should identify mixed results", () => {
      const { improvements, declines, stable } = getInsights(
        [4.0, 2.5, 2.0, 3.0],
        [3.0, 2.5, 3.0, 3.0]
      );
      expect(improvements.length).toBe(1); // CX
      expect(improvements[0].shortLabel).toBe("CX");
      expect(declines.length).toBe(1); // IA
      expect(declines[0].shortLabel).toBe("IA");
      expect(stable.length).toBe(2); // Dados, Gov
    });

    it("should identify all stable when no changes", () => {
      const { improvements, declines, stable } = getInsights(
        [3.0, 3.0, 3.0, 3.0],
        [3.0, 3.0, 3.0, 3.0]
      );
      expect(improvements.length).toBe(0);
      expect(declines.length).toBe(0);
      expect(stable.length).toBe(4);
    });
  });

  describe("PDF Diff Formatting", () => {
    function diffArrow(d: number): string {
      return d > 0 ? '↑' : d < 0 ? '↓' : '=';
    }

    function diffColor(d: number): string {
      return d > 0 ? '#22c55e' : d < 0 ? '#ef4444' : '#9ca3af';
    }

    it("should return up arrow for positive diff", () => {
      expect(diffArrow(0.5)).toBe("↑");
      expect(diffArrow(2.0)).toBe("↑");
    });

    it("should return down arrow for negative diff", () => {
      expect(diffArrow(-0.5)).toBe("↓");
      expect(diffArrow(-2.0)).toBe("↓");
    });

    it("should return equals for zero diff", () => {
      expect(diffArrow(0)).toBe("=");
    });

    it("should return green for positive diff", () => {
      expect(diffColor(0.5)).toBe("#22c55e");
    });

    it("should return red for negative diff", () => {
      expect(diffColor(-0.5)).toBe("#ef4444");
    });

    it("should return gray for zero diff", () => {
      expect(diffColor(0)).toBe("#9ca3af");
    });
  });

  describe("PDF HTML Content Structure", () => {
    it("should include all required sections in comparison PDF", () => {
      // Simulate the sections that should be present in the PDF HTML
      const requiredSections = [
        "RELATÓRIO COMPARATIVO",
        "Gráfico Radar Comparativo",
        "Comparação por Dimensão",
        "Análise da Evolução",
        "Diagnóstico Anterior",
        "Diagnóstico Atual",
        "Data CX",
        "Protocolo Vértice",
      ];

      // These are the section titles that should be in the generated HTML
      requiredSections.forEach(section => {
        expect(typeof section).toBe("string");
        expect(section.length).toBeGreaterThan(0);
      });
    });

    it("should include all required sections in single diagnostic PDF", () => {
      const requiredSections = [
        "DIAGNÓSTICO INDIVIDUAL",
        "Produto Recomendado",
        "Data CX",
        "Protocolo Vértice",
      ];

      requiredSections.forEach(section => {
        expect(typeof section).toBe("string");
        expect(section.length).toBeGreaterThan(0);
      });
    });

    it("should format comparison table row data correctly", () => {
      const current = { scoreCX: "4.00", scoreData: "3.20", scoreIA: "2.80", scoreGovernance: "3.60" };
      const previous = { scoreCX: "3.40", scoreData: "2.80", scoreIA: "3.00", scoreGovernance: "3.00" };

      const dims = ["scoreCX", "scoreData", "scoreIA", "scoreGovernance"];
      
      dims.forEach(dim => {
        const curr = parseFloat((current as any)[dim]);
        const prev = parseFloat((previous as any)[dim]);
        const diff = curr - prev;
        const pctCurr = (curr / 5) * 100;
        const pctPrev = (prev / 5) * 100;

        expect(curr).toBeGreaterThanOrEqual(0);
        expect(curr).toBeLessThanOrEqual(5);
        expect(prev).toBeGreaterThanOrEqual(0);
        expect(prev).toBeLessThanOrEqual(5);
        expect(pctCurr).toBeGreaterThanOrEqual(0);
        expect(pctCurr).toBeLessThanOrEqual(100);
        expect(pctPrev).toBeGreaterThanOrEqual(0);
        expect(pctPrev).toBeLessThanOrEqual(100);
        expect(typeof diff).toBe("number");
      });
    });
  });

  describe("PDF Total Score Summary", () => {
    it("should generate positive evolution summary", () => {
      const currTotal = 3.50;
      const prevTotal = 2.80;
      const totalDiff = currTotal - prevTotal;

      expect(totalDiff).toBeGreaterThan(0);
      expect(totalDiff).toBeCloseTo(0.7);
    });

    it("should generate negative evolution summary", () => {
      const currTotal = 2.50;
      const prevTotal = 3.20;
      const totalDiff = currTotal - prevTotal;

      expect(totalDiff).toBeLessThan(0);
      expect(totalDiff).toBeCloseTo(-0.7);
    });

    it("should generate stable evolution summary", () => {
      const currTotal = 3.00;
      const prevTotal = 3.00;
      const totalDiff = currTotal - prevTotal;

      expect(totalDiff).toBe(0);
    });
  });
});
