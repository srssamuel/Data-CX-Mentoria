import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock the database module
vi.mock("./db", () => ({
  getContents: vi.fn(),
  getContentById: vi.fn(),
  getUserActivePlanSlugs: vi.fn(),
  getUserAccessibleModuleCodes: vi.fn(),
  checkModuleAccess: vi.fn(),
  getQuizByContentId: vi.fn(),
  getQuizQuestions: vi.fn(),
  checkAndAwardBadges: vi.fn(),
  checkAndAwardCertificates: vi.fn(),
  markContentComplete: vi.fn(),
}));

import {
  getContents,
  getContentById,
  getUserActivePlanSlugs,
  getUserAccessibleModuleCodes,
  checkModuleAccess,
  getQuizByContentId,
  getQuizQuestions,
} from "./db";

const mockedGetContents = vi.mocked(getContents);
const mockedGetContentById = vi.mocked(getContentById);
const mockedGetUserActivePlanSlugs = vi.mocked(getUserActivePlanSlugs);
const mockedGetUserAccessibleModuleCodes = vi.mocked(getUserAccessibleModuleCodes);
const mockedCheckModuleAccess = vi.mocked(checkModuleAccess);
const mockedGetQuizByContentId = vi.mocked(getQuizByContentId);
const mockedGetQuizQuestions = vi.mocked(getQuizQuestions);

describe("V2 Content System", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Module Structure", () => {
    it("should return modules with V2 fields (moduleCode, pilar, nivel, duracao)", async () => {
      const mockModules = [
        {
          id: 30001,
          title: "Fundamentos de CX",
          moduleCode: "CX-01",
          pilar: "CX",
          nivel: "fundamento",
          duracao: "45 min",
          isPublished: true,
          type: "text",
        },
        {
          id: 30002,
          title: "Introdução a Dados",
          moduleCode: "DAD-01",
          pilar: "DADOS",
          nivel: "fundamento",
          duracao: "30 min",
          isPublished: true,
          type: "text",
        },
      ];

      mockedGetContents.mockResolvedValue(mockModules as any);
      const result = await getContents();

      expect(result).toHaveLength(2);
      expect(result[0]).toHaveProperty("moduleCode", "CX-01");
      expect(result[0]).toHaveProperty("pilar", "CX");
      expect(result[0]).toHaveProperty("nivel", "fundamento");
      expect(result[0]).toHaveProperty("duracao", "45 min");
    });

    it("should return module with markdownContent for web reading", async () => {
      const mockModule = {
        id: 30001,
        title: "Fundamentos de CX",
        moduleCode: "CX-01",
        markdownContent: "# Fundamentos de CX\n\n## Capítulo 1\n\nConteúdo...",
        pilar: "CX",
        nivel: "fundamento",
      };

      mockedGetContentById.mockResolvedValue(mockModule as any);
      const result = await getContentById(30001);

      expect(result).toBeDefined();
      expect(result?.markdownContent).toContain("# Fundamentos de CX");
      expect(result?.markdownContent).toContain("## Capítulo 1");
    });
  });

  describe("Trail Organization (Netflix-style)", () => {
    it("should group modules by pilar into trails", async () => {
      const mockModules = [
        { id: 1, pilar: "INTRO", moduleCode: "INT-01" },
        { id: 2, pilar: "INTRO", moduleCode: "INT-02" },
        { id: 3, pilar: "CX", moduleCode: "CX-01" },
        { id: 4, pilar: "DADOS", moduleCode: "DAD-01" },
        { id: 5, pilar: "IA", moduleCode: "IA-01" },
      ];

      mockedGetContents.mockResolvedValue(mockModules as any);
      const modules = await getContents();

      // Group by pilar
      const trails: Record<string, typeof modules> = {};
      for (const mod of modules) {
        const pilar = (mod as any).pilar || "INTRO";
        if (!trails[pilar]) trails[pilar] = [];
        trails[pilar].push(mod);
      }

      expect(Object.keys(trails)).toEqual(
        expect.arrayContaining(["INTRO", "CX", "DADOS", "IA"])
      );
      expect(trails["INTRO"]).toHaveLength(2);
      expect(trails["CX"]).toHaveLength(1);
      expect(trails["DADOS"]).toHaveLength(1);
      expect(trails["IA"]).toHaveLength(1);
    });

    it("should filter modules by pilar and nivel", async () => {
      const mockModules = [
        { id: 1, pilar: "CX", nivel: "fundamento", moduleCode: "CX-01" },
        { id: 2, pilar: "CX", nivel: "intermediario", moduleCode: "CX-02" },
        { id: 3, pilar: "CX", nivel: "avancado", moduleCode: "CX-03" },
        { id: 4, pilar: "DADOS", nivel: "fundamento", moduleCode: "DAD-01" },
      ];

      mockedGetContents.mockResolvedValue(mockModules as any);
      const modules = await getContents();

      const cxFundamento = modules.filter(
        (m: any) => m.pilar === "CX" && m.nivel === "fundamento"
      );
      expect(cxFundamento).toHaveLength(1);
      expect((cxFundamento[0] as any).moduleCode).toBe("CX-01");

      const cxAll = modules.filter((m: any) => m.pilar === "CX");
      expect(cxAll).toHaveLength(3);
    });
  });

  describe("Plan-based Access Control", () => {
    it("should return user active plan slugs", async () => {
      mockedGetUserActivePlanSlugs.mockResolvedValue(["essencial", "avancado"]);
      const slugs = await getUserActivePlanSlugs(1);

      expect(slugs).toContain("essencial");
      expect(slugs).toContain("avancado");
    });

    it("should return accessible module codes for user plans", async () => {
      mockedGetUserAccessibleModuleCodes.mockResolvedValue([
        "INT-01", "INT-02", "INT-03", "CX-01", "CX-02",
      ]);
      const codes = await getUserAccessibleModuleCodes(["essencial"]);

      expect(codes).toContain("INT-01");
      expect(codes).toContain("CX-01");
      expect(codes).toHaveLength(5);
    });

    it("should grant access to modules included in user plan", async () => {
      mockedCheckModuleAccess.mockResolvedValue(true);
      const hasAccess = await checkModuleAccess(1, "CX-01");

      expect(hasAccess).toBe(true);
    });

    it("should deny access to modules not included in user plan", async () => {
      mockedCheckModuleAccess.mockResolvedValue(false);
      const hasAccess = await checkModuleAccess(1, "IA-18");

      expect(hasAccess).toBe(false);
    });

    it("should return empty module codes when user has no active plan", async () => {
      mockedGetUserActivePlanSlugs.mockResolvedValue([]);
      const slugs = await getUserActivePlanSlugs(999);

      expect(slugs).toEqual([]);
    });
  });

  describe("Quiz System", () => {
    it("should return quiz with 10 questions for a module", async () => {
      const mockQuiz = {
        id: 1,
        contentId: 30001,
        title: "Prova: Fundamentos de CX",
        passingScore: 70,
        attemptsAllowed: 3,
      };

      const mockQuestions = Array.from({ length: 10 }, (_, i) => ({
        id: i + 1,
        quizId: 1,
        question: `Questão ${i + 1}`,
        options: [
          { id: "a", text: "Opção A", isCorrect: i === 0 },
          { id: "b", text: "Opção B", isCorrect: false },
          { id: "c", text: "Opção C", isCorrect: false },
          { id: "d", text: "Opção D", isCorrect: false },
        ],
      }));

      mockedGetQuizByContentId.mockResolvedValue(mockQuiz as any);
      mockedGetQuizQuestions.mockResolvedValue(mockQuestions as any);

      const quiz = await getQuizByContentId(30001);
      expect(quiz).toBeDefined();
      expect(quiz?.passingScore).toBe(70);
      expect(quiz?.attemptsAllowed).toBe(3);

      const questions = await getQuizQuestions(1);
      expect(questions).toHaveLength(10);
      expect(questions[0]).toHaveProperty("question");
      expect(questions[0]).toHaveProperty("options");
    });

    it("should have 4 options per question with exactly one correct", async () => {
      const mockQuestions = [
        {
          id: 1,
          question: "O que é CX?",
          options: [
            { id: "a", text: "Customer Experience", isCorrect: true },
            { id: "b", text: "Customer Extension", isCorrect: false },
            { id: "c", text: "Custom Exchange", isCorrect: false },
            { id: "d", text: "Central Exchange", isCorrect: false },
          ],
        },
      ];

      mockedGetQuizQuestions.mockResolvedValue(mockQuestions as any);
      const questions = await getQuizQuestions(1);

      for (const q of questions) {
        const opts = q.options as any[];
        expect(opts).toHaveLength(4);
        const correctCount = opts.filter((o: any) => o.isCorrect).length;
        expect(correctCount).toBe(1);
      }
    });
  });

  describe("Module Content Structure", () => {
    it("should have video and audio placeholders when no media is set", async () => {
      const mockModule = {
        id: 30001,
        title: "Módulo Teste",
        videoUrl: null,
        audioUrl: null,
        markdownContent: "# Conteúdo",
      };

      mockedGetContentById.mockResolvedValue(mockModule as any);
      const module = await getContentById(30001);

      expect(module?.videoUrl).toBeNull();
      expect(module?.audioUrl).toBeNull();
      expect(module?.markdownContent).toBeDefined();
    });

    it("should support YouTube video URLs", async () => {
      const mockModule = {
        id: 30001,
        title: "Módulo com Vídeo",
        videoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
        markdownContent: "# Conteúdo",
      };

      mockedGetContentById.mockResolvedValue(mockModule as any);
      const module = await getContentById(30001);

      expect(module?.videoUrl).toContain("youtube.com");
    });
  });

  describe("Plan Module Mapping", () => {
    it("should map plans to correct number of modules", async () => {
      // Based on the 00_plans.json structure:
      // gratuito: 6 modules (INT-01 to INT-06)
      // essencial: 24 modules (INT + CX)
      // avancado: 42 modules (INT + CX + DADOS)
      // premium: 60 modules (all)
      // enterprise: 60 modules (all)

      const planExpectations = [
        { plan: "gratuito", expectedMin: 6 },
        { plan: "essencial", expectedMin: 24 },
        { plan: "avancado", expectedMin: 42 },
        { plan: "premium", expectedMin: 60 },
        { plan: "enterprise", expectedMin: 60 },
      ];

      for (const { plan, expectedMin } of planExpectations) {
        mockedGetUserAccessibleModuleCodes.mockResolvedValue(
          Array.from({ length: expectedMin }, (_, i) => `MOD-${i + 1}`)
        );
        const codes = await getUserAccessibleModuleCodes([plan]);
        expect(codes.length).toBeGreaterThanOrEqual(expectedMin);
      }
    });
  });
});
