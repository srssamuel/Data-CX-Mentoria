import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import { COOKIE_NAME } from "../shared/const";
import type { TrpcContext } from "./_core/context";

type CookieCall = {
  name: string;
  value: string;
  options: Record<string, unknown>;
};

function createPublicContext(): {
  ctx: TrpcContext;
  setCookies: CookieCall[];
} {
  const setCookies: CookieCall[] = [];

  const ctx: TrpcContext = {
    user: null,
    req: {
      protocol: "https",
      headers: {
        origin: "https://test.example.com",
      },
    } as unknown as TrpcContext["req"],
    res: {
      cookie: (name: string, value: string, options: Record<string, unknown>) => {
        setCookies.push({ name, value, options });
      },
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };

  return { ctx, setCookies };
}

// Generate unique email for each test to avoid conflicts
function uniqueEmail() {
  return `test_${Date.now()}_${Math.random().toString(36).slice(2, 8)}@example.com`;
}

describe("Email Auth - Registration", () => {
  it("registers a new user with email and password", async () => {
    const { ctx, setCookies } = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const email = uniqueEmail();

    const result = await caller.auth.register({
      name: "Test User",
      email,
      password: "test123456",
    });

    expect(result.success).toBe(true);
    expect(result.user).toBeDefined();
    expect(result.user?.email).toBe(email.toLowerCase());
    expect(result.user?.name).toBe("Test User");
    // Should set session cookie
    expect(setCookies).toHaveLength(1);
    expect(setCookies[0]?.name).toBe(COOKIE_NAME);
    expect(setCookies[0]?.value).toBeTruthy();
  });

  it("rejects duplicate email registration", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const email = uniqueEmail();

    // First registration
    await caller.auth.register({
      name: "First User",
      email,
      password: "test123456",
    });

    // Second registration with same email
    const { ctx: ctx2 } = createPublicContext();
    const caller2 = appRouter.createCaller(ctx2);

    await expect(
      caller2.auth.register({
        name: "Second User",
        email,
        password: "test654321",
      })
    ).rejects.toThrow();
  });

  it("validates email format", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.auth.register({
        name: "Test User",
        email: "invalid-email",
        password: "test123456",
      })
    ).rejects.toThrow();
  });

  it("validates minimum password length", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.auth.register({
        name: "Test User",
        email: uniqueEmail(),
        password: "12345",
      })
    ).rejects.toThrow();
  });
});

describe("Email Auth - Login", () => {
  it("logs in with correct credentials", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const email = uniqueEmail();

    // Register first
    await caller.auth.register({
      name: "Login Test User",
      email,
      password: "mypassword123",
    });

    // Login
    const { ctx: loginCtx, setCookies } = createPublicContext();
    const loginCaller = appRouter.createCaller(loginCtx);

    const result = await loginCaller.auth.login({
      email,
      password: "mypassword123",
    });

    expect(result.success).toBe(true);
    expect(result.user).toBeDefined();
    expect(result.user?.email).toBe(email.toLowerCase());
    expect(setCookies).toHaveLength(1);
    expect(setCookies[0]?.name).toBe(COOKIE_NAME);
  });

  it("rejects wrong password", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const email = uniqueEmail();

    // Register first
    await caller.auth.register({
      name: "Wrong Pass User",
      email,
      password: "correctpassword",
    });

    // Login with wrong password
    const { ctx: loginCtx } = createPublicContext();
    const loginCaller = appRouter.createCaller(loginCtx);

    await expect(
      loginCaller.auth.login({
        email,
        password: "wrongpassword",
      })
    ).rejects.toThrow();
  });

  it("rejects non-existent email", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.auth.login({
        email: "nonexistent@example.com",
        password: "somepassword",
      })
    ).rejects.toThrow();
  });
});

describe("Email Auth - Password Reset", () => {
  it("handles password reset request for existing email", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const email = uniqueEmail();

    // Register first
    await caller.auth.register({
      name: "Reset Test User",
      email,
      password: "oldpassword123",
    });

    // Request reset
    const { ctx: resetCtx } = createPublicContext();
    const resetCaller = appRouter.createCaller(resetCtx);

    const result = await resetCaller.auth.requestPasswordReset({
      email,
      origin: "https://test.example.com",
    });

    expect(result.success).toBe(true);
    expect(result.message).toBeTruthy();
  });

  it("handles password reset request for non-existent email gracefully", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // Should not reveal that email doesn't exist
    const result = await caller.auth.requestPasswordReset({
      email: "nonexistent@example.com",
      origin: "https://test.example.com",
    });

    expect(result.success).toBe(true);
    expect(result.message).toBeTruthy();
  });

  it("rejects reset with invalid token", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.auth.resetPassword({
        token: "invalid-token-12345",
        password: "newpassword123",
      })
    ).rejects.toThrow();
  });
});
