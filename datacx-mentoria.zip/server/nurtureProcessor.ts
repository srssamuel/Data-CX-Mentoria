import * as db from "./db";
import { Resend } from "resend";

function getResend(): Resend | null {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) return null;
  return new Resend(apiKey);
}

function getFromAddress(): string {
  const envFrom = process.env.EMAIL_FROM;
  if (envFrom && envFrom.includes("@")) {
    if (!envFrom.includes("<")) return `Data CX <${envFrom}>`;
    return envFrom;
  }
  return "Data CX <noreply@datacx.com.br>";
}

export async function processNurtureEmails() {
  const pendingMessages = await db.getPendingNurtureMessages();
  
  if (pendingMessages.length === 0) return;
  
  console.log(`[Nurture] Processing ${pendingMessages.length} pending nurture messages`);
  
  for (const msg of pendingMessages) {
    try {
      // Get the lead data to find the email
      const lead = await db.getRadarLeadById(msg.leadId);
      if (!lead || !lead.email) {
        console.error(`[Nurture] Lead not found for message ${msg.id}`);
        await db.updateNurtureMessage(msg.id, { status: "failed" });
        continue;
      }
      
      // Send the email
      const resend = getResend();
      if (!resend) {
        console.log(`[Nurture] Resend not configured, skipping message ${msg.id}`);
        continue;
      }
      
      const { error } = await resend.emails.send({
        from: getFromAddress(),
        to: lead.email,
        subject: msg.subject || "Data CX - Protocolo Vértice",
        html: buildNurtureEmailHtml(msg.messageType, msg.content || "", lead.name || ""),
      });
      
      if (!error) {
        await db.updateNurtureMessage(msg.id, { 
          status: "sent",
          sentAt: new Date(),
        });
        console.log(`[Nurture] Sent message ${msg.id} (step ${msg.sequenceStep}) to ${lead.email}`);
      } else {
        await db.updateNurtureMessage(msg.id, { status: "failed" });
        console.error(`[Nurture] Failed to send message ${msg.id} to ${lead.email}`);
      }
    } catch (err) {
      console.error(`[Nurture] Error processing message ${msg.id}:`, err);
      await db.updateNurtureMessage(msg.id, { status: "failed" });
    }
  }
}

function buildNurtureEmailHtml(messageType: string, content: string, name: string): string {
  const typeColors: Record<string, string> = {
    diagnosis: "#00D4AA",
    content: "#6366F1",
    invite: "#F59E0B",
    social_proof: "#10B981",
    offer: "#EF4444",
  };
  
  const accentColor = typeColors[messageType] || "#00D4AA";
  
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body style="margin:0;padding:0;background-color:#0B1120;font-family:Arial,sans-serif;">
      <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#0B1120;padding:40px 20px;">
        <tr>
          <td align="center">
            <table width="600" cellpadding="0" cellspacing="0" style="background-color:#111827;border-radius:12px;overflow:hidden;">
              <!-- Header -->
              <tr>
                <td style="background:linear-gradient(135deg,${accentColor}22,${accentColor}11);padding:32px 40px;border-bottom:1px solid ${accentColor}33;">
                  <h1 style="margin:0;color:#FFFFFF;font-size:20px;font-weight:700;">
                    Data CX <span style="color:${accentColor};">Mentoria</span>
                  </h1>
                </td>
              </tr>
              <!-- Content -->
              <tr>
                <td style="padding:40px;">
                  <p style="color:#E5E7EB;font-size:16px;line-height:1.6;margin:0 0 20px 0;">
                    ${content}
                  </p>
                  <table cellpadding="0" cellspacing="0" style="margin:24px 0;">
                    <tr>
                      <td style="background-color:${accentColor};border-radius:8px;padding:12px 24px;">
                        <a href="${process.env.VITE_APP_URL || 'https://datacx.manus.space'}" style="color:#FFFFFF;text-decoration:none;font-weight:600;font-size:14px;">
                          Acessar Portal Data CX
                        </a>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
              <!-- Footer -->
              <tr>
                <td style="padding:20px 40px;border-top:1px solid #1F2937;">
                  <p style="color:#6B7280;font-size:12px;margin:0;">
                    Você recebeu este email porque se cadastrou no Radar Vértice da Data CX.
                    <br>Para cancelar, responda este email com "cancelar".
                  </p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </body>
    </html>
  `;
}
