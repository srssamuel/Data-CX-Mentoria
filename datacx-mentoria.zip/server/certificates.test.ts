import { describe, it, expect, vi } from "vitest";

// Mock the database module
vi.mock("./db", () => ({
  checkCategoryCompletion: vi.fn(),
  getCertificateByUserAndCategory: vi.fn(),
  createCategoryCertificate: vi.fn(),
  createOrUpdateUserPoints: vi.fn(),
  getUserCertificates: vi.fn(),
  getCertificateById: vi.fn(),
  getCertificateByVerificationCode: vi.fn(),
  getGeneralCertificate: vi.fn(),
  createGeneralCertificate: vi.fn(),
}));

import * as db from "./db";

describe("Certificate System", () => {
  describe("checkCategoryCompletion", () => {
    it("should return completed categories and progress", async () => {
      const mockResult = {
        completedCategories: ["introducao", "cx"],
        progress: [
          { category: "introducao", total: 5, completed: 5, isComplete: true },
          { category: "cx", total: 6, completed: 6, isComplete: true },
          { category: "dados", total: 8, completed: 3, isComplete: false },
          { category: "ia", total: 4, completed: 0, isComplete: false },
        ],
      };
      
      vi.mocked(db.checkCategoryCompletion).mockResolvedValue(mockResult);
      
      const result = await db.checkCategoryCompletion(1);
      
      expect(result.completedCategories).toContain("introducao");
      expect(result.completedCategories).toContain("cx");
      expect(result.completedCategories).not.toContain("dados");
      expect(result.completedCategories).not.toContain("ia");
      expect(result.progress).toHaveLength(4);
    });

    it("should return empty when no categories completed", async () => {
      const mockResult = {
        completedCategories: [],
        progress: [
          { category: "introducao", total: 5, completed: 2, isComplete: false },
          { category: "cx", total: 6, completed: 0, isComplete: false },
          { category: "dados", total: 8, completed: 1, isComplete: false },
          { category: "ia", total: 4, completed: 0, isComplete: false },
        ],
      };
      
      vi.mocked(db.checkCategoryCompletion).mockResolvedValue(mockResult);
      
      const result = await db.checkCategoryCompletion(1);
      
      expect(result.completedCategories).toHaveLength(0);
    });
  });

  describe("createCategoryCertificate", () => {
    it("should create a certificate with valid data", async () => {
      const mockCert = {
        id: 1,
        userId: 1,
        programId: null,
        category: "introducao",
        type: "category",
        certificateNumber: "DCX-CAT-INTRO-ABC123-1",
        verificationCode: "ABC123DEF456",
        completionDate: new Date("2026-02-06"),
        pdfUrl: null,
        createdAt: new Date(),
      };
      
      vi.mocked(db.createCategoryCertificate).mockResolvedValue(mockCert);
      
      const result = await db.createCategoryCertificate(1, "introducao");
      
      expect(result).toBeDefined();
      expect(result!.category).toBe("introducao");
      expect(result!.type).toBe("category");
      expect(result!.certificateNumber).toContain("DCX-CAT");
      expect(result!.verificationCode).toBeTruthy();
    });

    it("should not create duplicate certificates", async () => {
      vi.mocked(db.getCertificateByUserAndCategory).mockResolvedValue({
        id: 1,
        userId: 1,
        programId: null,
        category: "cx",
        type: "category",
        certificateNumber: "DCX-CAT-CX-EXISTING",
        verificationCode: "EXISTING123",
        completionDate: new Date(),
        pdfUrl: null,
        createdAt: new Date(),
      });
      
      const existing = await db.getCertificateByUserAndCategory(1, "cx");
      expect(existing).toBeDefined();
      expect(existing!.category).toBe("cx");
    });
  });

  describe("getUserCertificates", () => {
    it("should return all certificates for a user", async () => {
      const mockCerts = [
        {
          id: 1,
          userId: 1,
          programId: null,
          category: "introducao",
          type: "category",
          certificateNumber: "DCX-CAT-INTRO-1",
          verificationCode: "VERIFY1",
          completionDate: new Date(),
          pdfUrl: null,
          createdAt: new Date(),
        },
        {
          id: 2,
          userId: 1,
          programId: null,
          category: "cx",
          type: "category",
          certificateNumber: "DCX-CAT-CX-1",
          verificationCode: "VERIFY2",
          completionDate: new Date(),
          pdfUrl: null,
          createdAt: new Date(),
        },
      ];
      
      vi.mocked(db.getUserCertificates).mockResolvedValue(mockCerts);
      
      const result = await db.getUserCertificates(1);
      
      expect(result).toHaveLength(2);
      expect(result[0].category).toBe("introducao");
      expect(result[1].category).toBe("cx");
    });

    it("should return empty array for user with no certificates", async () => {
      vi.mocked(db.getUserCertificates).mockResolvedValue([]);
      
      const result = await db.getUserCertificates(999);
      
      expect(result).toHaveLength(0);
    });
  });

  describe("getCertificateByVerificationCode", () => {
    it("should find certificate by verification code", async () => {
      const mockCert = {
        id: 1,
        userId: 1,
        programId: null,
        category: "dados",
        type: "category",
        certificateNumber: "DCX-CAT-DADOS-1",
        verificationCode: "UNIQUE-CODE-123",
        completionDate: new Date(),
        pdfUrl: null,
        createdAt: new Date(),
      };
      
      vi.mocked(db.getCertificateByVerificationCode).mockResolvedValue(mockCert);
      
      const result = await db.getCertificateByVerificationCode("UNIQUE-CODE-123");
      
      expect(result).toBeDefined();
      expect(result!.verificationCode).toBe("UNIQUE-CODE-123");
    });

    it("should return null for invalid code", async () => {
      vi.mocked(db.getCertificateByVerificationCode).mockResolvedValue(null);
      
      const result = await db.getCertificateByVerificationCode("INVALID");
      
      expect(result).toBeNull();
    });
  });

  describe("Certificate number format", () => {
    it("should follow DCX-CAT-{CATEGORY} format", () => {
      const categories = ["introducao", "cx", "dados", "ia"];
      const prefixes = ["INTRO", "CX", "DADOS", "IA"];
      
      categories.forEach((cat, i) => {
        const expectedPrefix = `DCX-CAT-${prefixes[i]}`;
        expect(expectedPrefix).toBeTruthy();
        expect(expectedPrefix).toContain("DCX-CAT");
      });
    });
  });

  describe("Category display names", () => {
    it("should map category keys to display names", () => {
      const categoryNames: Record<string, string> = {
        introducao: "Introdução",
        cx: "Customer Experience (CX)",
        dados: "Dados",
        ia: "Inteligência Artificial (IA)",
        general: "Protocolo Vértice — Formação Completa",
      };
      
      expect(categoryNames["introducao"]).toBe("Introdução");
      expect(categoryNames["cx"]).toBe("Customer Experience (CX)");
      expect(categoryNames["dados"]).toBe("Dados");
      expect(categoryNames["ia"]).toBe("Inteligência Artificial (IA)");
      expect(categoryNames["general"]).toBe("Protocolo Vértice — Formação Completa");
    });
  });

  describe("General Certificate (Protocolo Vértice Completo)", () => {
    it("should detect when all 4 categories are completed", async () => {
      const mockResult = {
        completedCategories: ["introducao", "cx", "dados", "ia"],
        progress: [
          { category: "introducao", total: 5, completed: 5, isComplete: true },
          { category: "cx", total: 6, completed: 6, isComplete: true },
          { category: "dados", total: 8, completed: 8, isComplete: true },
          { category: "ia", total: 4, completed: 4, isComplete: true },
        ],
      };
      
      vi.mocked(db.checkCategoryCompletion).mockResolvedValue(mockResult);
      
      const result = await db.checkCategoryCompletion(1);
      const ALL_CATEGORIES = ["introducao", "cx", "dados", "ia"];
      const hasAllFour = ALL_CATEGORIES.every(cat => result.completedCategories.includes(cat));
      
      expect(hasAllFour).toBe(true);
      expect(result.completedCategories).toHaveLength(4);
    });

    it("should not trigger general certificate when only 3 categories completed", async () => {
      const mockResult = {
        completedCategories: ["introducao", "cx", "dados"],
        progress: [
          { category: "introducao", total: 5, completed: 5, isComplete: true },
          { category: "cx", total: 6, completed: 6, isComplete: true },
          { category: "dados", total: 8, completed: 8, isComplete: true },
          { category: "ia", total: 4, completed: 2, isComplete: false },
        ],
      };
      
      vi.mocked(db.checkCategoryCompletion).mockResolvedValue(mockResult);
      
      const result = await db.checkCategoryCompletion(1);
      const ALL_CATEGORIES = ["introducao", "cx", "dados", "ia"];
      const hasAllFour = ALL_CATEGORIES.every(cat => result.completedCategories.includes(cat));
      
      expect(hasAllFour).toBe(false);
    });

    it("should create general certificate with PV prefix", async () => {
      const mockGeneralCert = {
        id: 10,
        userId: 1,
        programId: null,
        category: null,
        type: "general",
        certificateNumber: "PV-DCX2026ABC",
        verificationCode: "GENERAL-VERIFY-123",
        completionDate: new Date("2026-02-20"),
        expirationDate: null,
        pdfUrl: null,
        createdAt: new Date(),
      };
      
      vi.mocked(db.createGeneralCertificate).mockResolvedValue(mockGeneralCert);
      
      const result = await db.createGeneralCertificate(1);
      
      expect(result).toBeDefined();
      expect(result!.type).toBe("general");
      expect(result!.certificateNumber).toContain("PV-");
      expect(result!.category).toBeNull();
    });

    it("should not create duplicate general certificate", async () => {
      const existingCert = {
        id: 10,
        userId: 1,
        programId: null,
        category: null,
        type: "general",
        certificateNumber: "PV-EXISTING",
        verificationCode: "EXISTING-GEN",
        completionDate: new Date(),
        expirationDate: null,
        pdfUrl: "https://cdn.example.com/cert.pdf",
        createdAt: new Date(),
      };
      
      vi.mocked(db.getGeneralCertificate).mockResolvedValue(existingCert);
      
      const result = await db.getGeneralCertificate(1);
      expect(result).toBeDefined();
      expect(result!.type).toBe("general");
    });

    it("should include general certificate in user certificates list", async () => {
      const mockCerts = [
        {
          id: 1, userId: 1, programId: null, category: "introducao", type: "category",
          certificateNumber: "DCX-CAT-INTRO-1", verificationCode: "V1",
          completionDate: new Date(), pdfUrl: null, createdAt: new Date(),
        },
        {
          id: 2, userId: 1, programId: null, category: "cx", type: "category",
          certificateNumber: "DCX-CAT-CX-1", verificationCode: "V2",
          completionDate: new Date(), pdfUrl: null, createdAt: new Date(),
        },
        {
          id: 3, userId: 1, programId: null, category: "dados", type: "category",
          certificateNumber: "DCX-CAT-DADOS-1", verificationCode: "V3",
          completionDate: new Date(), pdfUrl: null, createdAt: new Date(),
        },
        {
          id: 4, userId: 1, programId: null, category: "ia", type: "category",
          certificateNumber: "DCX-CAT-IA-1", verificationCode: "V4",
          completionDate: new Date(), pdfUrl: null, createdAt: new Date(),
        },
        {
          id: 5, userId: 1, programId: null, category: null, type: "general",
          certificateNumber: "PV-GENERAL-1", verificationCode: "VG",
          completionDate: new Date(), pdfUrl: "https://cdn.example.com/general.pdf", createdAt: new Date(),
        },
      ];
      
      vi.mocked(db.getUserCertificates).mockResolvedValue(mockCerts);
      
      const result = await db.getUserCertificates(1);
      const generalCert = result.find(c => c.type === "general");
      const categoryCerts = result.filter(c => c.type === "category");
      
      expect(result).toHaveLength(5);
      expect(categoryCerts).toHaveLength(4);
      expect(generalCert).toBeDefined();
      expect(generalCert!.certificateNumber).toContain("PV-");
    });
  });
});
