import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import Stripe from "stripe";
import * as db from "../db";
import { sendPurchaseConfirmationEmail } from "../emailService";
import { sdk } from "./sdk";
import { scheduleOnboardingEmails, processPendingEmails } from "../onboardingEmails";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Stripe webhook - MUST be before express.json() for signature verification
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
    apiVersion: "2026-01-28.clover",
  });

  app.post("/api/stripe/webhook", express.raw({ type: "application/json" }), async (req, res) => {
    const sig = req.headers["stripe-signature"] as string;
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

    if (!webhookSecret) {
      console.error("[Stripe Webhook] STRIPE_WEBHOOK_SECRET not configured");
      return res.status(500).json({ error: "Webhook secret not configured" });
    }

    let event: Stripe.Event;

    try {
      event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    } catch (err: any) {
      console.error(`[Stripe Webhook] Signature verification failed: ${err.message}`);
      return res.status(400).json({ error: `Webhook Error: ${err.message}` });
    }

    // Handle test events
    if (event.id.startsWith("evt_test_")) {
      console.log("[Stripe Webhook] Test event detected, returning verification response");
      return res.json({ verified: true });
    }

    console.log(`[Stripe Webhook] Received event: ${event.type} (${event.id})`);

    try {
      switch (event.type) {
        case "checkout.session.completed": {
          const session = event.data.object as Stripe.Checkout.Session;
          console.log(`[Stripe] Checkout completed: ${session.id}`);
          
          const userId = session.metadata?.user_id;
          const productId = session.metadata?.product_id;
          
          // Map product_id to program slug in DB
          const productToProgramSlug: Record<string, string> = {
            playbook_vertice: "playbook_377",
            mentoria_grupo: "grupo_8_semanas",
            mentoria_sprint: "individual_90_dias",
            mentoria_90dias: "individual_90_dias",
            mentoria_executive: "executive_6m",
            diagnostico_360: "empresas_diagnostico",
            assessoria_mensal: "empresas_diagnostico",
          };
          
          if (userId && productId) {
            // Find the program by slug
            const programSlug = productToProgramSlug[productId];
            let programId = 30001; // default fallback
            
            if (programSlug) {
              const program = await db.getProgramBySlug(programSlug);
              if (program) {
                programId = program.id;
                console.log(`[Stripe] Mapped product ${productId} -> program ${programSlug} (ID: ${programId})`);
              } else {
                console.warn(`[Stripe] Program not found for slug: ${programSlug}, using default`);
              }
            } else {
              console.warn(`[Stripe] No slug mapping for product: ${productId}, using default`);
            }
            
            // Create enrollment
            await db.createEnrollment({
              userId: parseInt(userId),
              programId,
              status: "active",
              stripeSubscriptionId: session.subscription as string || undefined,
              stripePaymentIntentId: session.payment_intent as string || undefined,
            });
            console.log(`[Stripe] Enrollment created for user ${userId} in program ${programId}`);
            
            // Schedule onboarding drip emails
            const productName = session.metadata?.product_name || productId;
            scheduleOnboardingEmails(parseInt(userId), programId, productName).catch((err) => {
              console.error("[Stripe] Failed to schedule onboarding emails:", err);
            });
            
            // Send purchase confirmation email
            const customerEmail = session.customer_email || session.metadata?.customer_email;
            const customerName = session.metadata?.customer_name || "";
            const amountTotal = session.amount_total ? `R$ ${(session.amount_total / 100).toFixed(2).replace(".", ",")}` : "";
            const origin = session.metadata?.origin || "https://datacx-mentoria.manus.space";
            if (customerEmail) {
              sendPurchaseConfirmationEmail(
                customerEmail,
                customerName,
                productName,
                amountTotal,
                origin
              ).catch((err) => {
                console.error("[Stripe] Failed to send purchase confirmation email:", err);
              });
            }
          }
          break;
        }

        case "payment_intent.succeeded": {
          const paymentIntent = event.data.object as Stripe.PaymentIntent;
          console.log(`[Stripe] Payment succeeded: ${paymentIntent.id}`);
          
          // Verificar se foi pagamento via PIX
          const paymentMethod = paymentIntent.payment_method_types?.[0];
          if (paymentMethod === "pix") {
            console.log(`[Stripe] PIX payment confirmed: ${paymentIntent.id}`);
          }
          
          // Atualizar enrollment se existir metadata
          const piUserId = paymentIntent.metadata?.user_id;
          if (piUserId) {
            console.log(`[Stripe] Updating enrollment for user ${piUserId}`);
          }
          break;
        }

        case "customer.subscription.created":
        case "customer.subscription.updated": {
          const subscription = event.data.object as Stripe.Subscription;
          console.log(`[Stripe] Subscription ${event.type}: ${subscription.id}`);
          break;
        }

        case "customer.subscription.deleted": {
          const subscription = event.data.object as Stripe.Subscription;
          console.log(`[Stripe] Subscription cancelled: ${subscription.id}`);
          break;
        }

        case "invoice.paid": {
          const invoice = event.data.object as Stripe.Invoice;
          console.log(`[Stripe] Invoice paid: ${invoice.id}`);
          break;
        }

        default:
          console.log(`[Stripe Webhook] Unhandled event type: ${event.type}`);
      }

      res.json({ received: true });
    } catch (error) {
      console.error(`[Stripe Webhook] Error processing event: ${error}`);
      res.status(500).json({ error: "Webhook handler failed" });
    }
  });

  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  // OAuth callback under /api/oauth/callback
  registerOAuthRoutes(app);

  // Webhook endpoint para Make.com
  app.post("/api/webhook/make", async (req, res) => {
    try {
      const { type, data } = req.body;
      console.log(`[Webhook] Recebido evento: ${type}`, data);
      
      // Retorna sucesso para o Make.com
      res.json({ success: true, received: type });
    } catch (error) {
      console.error("[Webhook] Erro:", error);
      res.status(500).json({ success: false, error: "Internal server error" });
    }
  });

  // Endpoint para enviar notificações via Make.com (WhatsApp)
  app.post("/api/notify/whatsapp", async (req, res) => {
    try {
      const { message, phone } = req.body;
      const webhookUrl = process.env.MAKE_WEBHOOK_URL;
      
      if (!webhookUrl) {
        console.log("[WhatsApp] MAKE_WEBHOOK_URL não configurado, usando notificação interna");
        res.json({ success: true, method: "internal" });
        return;
      }
      
      // Envia para o webhook do Make.com
      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phone: phone || "+5584991278513",
          message,
          timestamp: new Date().toISOString(),
        }),
      });
      
      res.json({ success: true, method: "make" });
    } catch (error) {
      console.error("[WhatsApp] Erro:", error);
      res.status(500).json({ success: false, error: "Failed to send notification" });
    }
  });

  // Endpoint para gerar PDF com padrões ABNT
  app.get("/api/contents/:id/pdf", async (req, res) => {
    try {
      const contentId = parseInt(req.params.id);
      const content = await db.getContentById(contentId);
      
      if (!content) {
        return res.status(404).json({ error: "Conteúdo não encontrado" });
      }
      
      if (!content.markdownContent) {
        return res.status(400).json({ error: "Este conteúdo não possui texto para exportar" });
      }
      
      // Get authenticated user name
      let userName = "Aluno";
      try {
        const user = await sdk.authenticateRequest(req);
        if (user?.name) userName = user.name;
      } catch { /* fallback to "Aluno" */ }
      
      const logoUrl = process.env.VITE_APP_LOGO || "";
      const currentDate = new Date().toLocaleDateString("pt-BR", {
        day: "2-digit",
        month: "long",
        year: "numeric"
      });
      
      // Pilar colors
      const pilarColors: Record<string, string> = {
        introducao: "#6366f1",
        cx: "#f97316",
        dados: "#22c55e",
        ia: "#a855f7",
      };
      const pilarNames: Record<string, string> = {
        introducao: "Introdução ao Protocolo Vértice",
        cx: "Customer Experience",
        dados: "Dados & Analytics",
        ia: "Inteligência Artificial",
      };
      const accentColor = pilarColors[content.pilar || ""] || "#6366f1";
      const pilarName = pilarNames[content.pilar || ""] || "Protocolo Vértice";
      
      // Converter markdown para HTML
      const markdownToHtml = (md: string) => {
        let html = md
          .replace(/^### (.+)$/gm, '<h3>$1</h3>')
          .replace(/^## (.+)$/gm, '<h2>$1</h2>')
          .replace(/^# (.+)$/gm, '<h1>$1</h1>')
          .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
          .replace(/\*(.+?)\*/g, '<em>$1</em>')
          .replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>')
          .replace(/^- (.+)$/gm, '<li>$1</li>')
          .replace(/\n\n/g, '</p><p>')
          .replace(/^(?!<[hublop])(.*\S.*)$/gm, (match) => {
            if (match.startsWith('<')) return match;
            return `<p>${match}</p>`;
          });
        // Wrap consecutive <li> in <ul>
        html = html.replace(/(<li>[\s\S]*?<\/li>\s*)+/g, (m) => `<ul>${m}</ul>`);
        return html;
      };
      
      const htmlContent = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>${content.title} - DCX Protocolo Vértice</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
    @page {
      size: A4;
      margin: 2.5cm 2cm 2.5cm 2cm;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      font-size: 11pt;
      line-height: 1.7;
      color: #1a1a2e;
      background: #fff;
    }
    /* ── Cover Page ── */
    .cover {
      page-break-after: always;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      padding: 3cm 2cm;
      position: relative;
    }
    .cover::before {
      content: '';
      position: absolute;
      top: 0; left: 0; right: 0;
      height: 8px;
      background: linear-gradient(90deg, ${accentColor}, ${accentColor}88);
    }
    .cover-logo {
      width: 180px;
      margin-bottom: 1cm;
    }
    .cover-brand {
      font-size: 11pt;
      font-weight: 600;
      color: #64748b;
      letter-spacing: 3px;
      text-transform: uppercase;
      margin-bottom: 2cm;
    }
    .cover-pilar {
      display: inline-block;
      padding: 6px 20px;
      background: ${accentColor}15;
      color: ${accentColor};
      border: 1px solid ${accentColor}40;
      border-radius: 20px;
      font-size: 10pt;
      font-weight: 600;
      margin-bottom: 1cm;
    }
    .cover h1 {
      font-size: 24pt;
      font-weight: 800;
      color: #0f172a;
      line-height: 1.2;
      margin-bottom: 1.5cm;
      max-width: 80%;
    }
    .cover-meta {
      margin-top: 2cm;
      padding-top: 1cm;
      border-top: 1px solid #e2e8f0;
      color: #64748b;
      font-size: 10pt;
    }
    .cover-meta .student-name {
      font-size: 12pt;
      font-weight: 600;
      color: #334155;
      margin-bottom: 0.3cm;
    }
    /* ── Header/Footer ── */
    .page-header {
      position: fixed;
      top: -1.5cm;
      left: 0; right: 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-bottom: 8px;
      border-bottom: 2px solid ${accentColor}30;
      font-size: 8pt;
      color: #94a3b8;
    }
    .page-header .brand {
      font-weight: 700;
      color: #475569;
      letter-spacing: 1px;
    }
    .page-footer {
      position: fixed;
      bottom: -1.5cm;
      left: 0; right: 0;
      text-align: center;
      font-size: 8pt;
      color: #94a3b8;
      border-top: 1px solid #e2e8f0;
      padding-top: 6px;
    }
    /* ── Content ── */
    .content { margin-top: 0.5cm; }
    h1 {
      font-size: 16pt;
      font-weight: 800;
      color: #0f172a;
      margin-top: 1.5cm;
      margin-bottom: 0.5cm;
      padding-bottom: 0.3cm;
      border-bottom: 2px solid ${accentColor}30;
    }
    h2 {
      font-size: 13pt;
      font-weight: 700;
      color: #1e293b;
      margin-top: 1cm;
      margin-bottom: 0.4cm;
      padding-left: 12px;
      border-left: 3px solid ${accentColor};
    }
    h3 {
      font-size: 11pt;
      font-weight: 600;
      color: #334155;
      margin-top: 0.6cm;
      margin-bottom: 0.3cm;
    }
    p {
      margin-bottom: 0.4cm;
      text-align: justify;
    }
    strong { color: #0f172a; }
    blockquote {
      margin: 0.6cm 0;
      padding: 0.5cm 1cm;
      background: ${accentColor}08;
      border-left: 4px solid ${accentColor};
      border-radius: 0 6px 6px 0;
      font-style: italic;
      color: #475569;
    }
    ul, ol {
      margin-left: 1.2cm;
      margin-bottom: 0.5cm;
    }
    li {
      margin-bottom: 0.2cm;
    }
    li::marker {
      color: ${accentColor};
    }
    /* ── Print button ── */
    .print-bar {
      position: fixed;
      top: 0; left: 0; right: 0;
      background: #0f172a;
      color: #fff;
      padding: 12px 24px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      z-index: 1000;
      font-family: 'Inter', sans-serif;
    }
    .print-bar button {
      background: ${accentColor};
      color: #fff;
      border: none;
      padding: 8px 24px;
      border-radius: 6px;
      font-weight: 600;
      cursor: pointer;
      font-size: 13px;
    }
    .print-bar button:hover { opacity: 0.9; }
    @media print {
      .print-bar { display: none !important; }
      body { padding-top: 0; }
    }
    @media screen {
      body { padding-top: 56px; }
    }
  </style>
</head>
<body>
  <div class="print-bar">
    <span><strong>DCX</strong> &mdash; Protocolo Vértice &bull; Apostila: ${content.title.substring(0, 50)}</span>
    <button onclick="window.print()">Salvar como PDF</button>
  </div>

  <div class="page-header">
    <span class="brand">DCX &mdash; PROTOCOLO VÉRTICE</span>
    <span>${pilarName} &bull; ${content.moduleCode || ''}</span>
  </div>
  <div class="page-footer">
    DCX &mdash; Protocolo Vértice &bull; Material exclusivo para ${userName} &bull; ${currentDate}
  </div>

  <div class="cover">
    ${logoUrl ? `<img src="${logoUrl}" alt="DCX" class="cover-logo" />` : ''}
    <div class="cover-brand">DCX &mdash; Protocolo Vértice</div>
    <div class="cover-pilar">${pilarName}</div>
    <h1>${content.title}</h1>
    ${content.description ? `<p style="color:#64748b;font-size:11pt;max-width:80%;">${content.description}</p>` : ''}
    <div class="cover-meta">
      <div class="student-name">${userName}</div>
      <div>${currentDate}</div>
      ${content.moduleCode ? `<div style="margin-top:0.3cm;">Módulo ${content.moduleCode}</div>` : ''}
    </div>
  </div>

  <div class="content">
    ${markdownToHtml(content.markdownContent)}
  </div>
</body>
</html>
      `;
      
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      res.setHeader("Content-Disposition", `inline; filename="${content.title.replace(/[^a-zA-Z0-9]/g, '_')}.html"`);
      res.send(htmlContent);
      
    } catch (error) {
      console.error("[PDF] Erro ao gerar PDF:", error);
      res.status(500).json({ error: "Erro ao gerar PDF" });
    }
  });

  // Certificate PDF endpoint - generates real PDF and redirects to S3 URL
  app.get("/api/certificates/:id/pdf", async (req, res) => {
    try {
      const certificateId = parseInt(req.params.id);
      if (isNaN(certificateId)) {
        return res.status(400).json({ error: "ID de certificado inválido" });
      }
      
      const certificate = await db.getCertificateById(certificateId);
      if (!certificate) {
        return res.status(404).json({ error: "Certificado não encontrado" });
      }
      
      // If PDF already exists in S3, redirect to it
      if (certificate.pdfUrl) {
        return res.redirect(certificate.pdfUrl);
      }
      
      // Generate PDF
      const { generateCertificatePDF, generateGeneralCertificatePDF, buildCertificateData, buildGeneralCertificateData } = await import("../certificateGenerator");
      const user = await db.getUserById(certificate.userId);
      const userName = user?.name || "Aluno";
      
      let url: string;
      if (certificate.type === "general") {
        const certData = buildGeneralCertificateData(userName, certificate);
        const result = await generateGeneralCertificatePDF(certData);
        url = result.url;
      } else {
        const certData = buildCertificateData(userName, certificate);
        const result = await generateCertificatePDF(certData);
        url = result.url;
      }
      
      // Save PDF URL to database
      await db.updateCertificatePdfUrl(certificate.id, url);
      
      return res.redirect(url);
    } catch (error) {
      console.error("[Certificate PDF] Erro ao gerar certificado:", error);
      res.status(500).json({ error: "Erro ao gerar certificado" });
    }
  });

  // Certificate verification endpoint
  app.get("/api/certificates/verify/:code", async (req, res) => {
    try {
      const code = req.params.code;
      const certificate = await db.getCertificateByVerificationCode(code);
      
      if (!certificate) {
        return res.status(404).json({ valid: false, error: "Certificado não encontrado" });
      }
      
      const user = await db.getUserById(certificate.userId);
      
      const categoryNames: Record<string, string> = {
        introducao: "Introdução ao Protocolo Vértice",
        cx: "Customer Experience (CX)",
        dados: "Gestão de Dados",
        ia: "Inteligência Artificial",
        general: "Protocolo Vértice — Formação Completa",
      };
      
      const categoryKey = certificate.type === "general" ? "general" : (certificate.category || "programa");
      
      res.json({
        valid: true,
        certificate: {
          certificateNumber: certificate.certificateNumber,
          userName: user?.name || "Aluno",
          category: categoryKey,
          categoryName: categoryNames[categoryKey] || categoryKey,
          type: certificate.type,
          completionDate: certificate.completionDate,
          verificationCode: certificate.verificationCode,
          pdfUrl: certificate.pdfUrl || null,
        }
      });
      
    } catch (error) {
      console.error("[Certificate Verify] Erro:", error);
      res.status(500).json({ valid: false, error: "Erro ao verificar certificado" });
    }
  });

  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
    
    // Process pending onboarding emails every 15 minutes
    setInterval(async () => {
      try {
        await processPendingEmails();
      } catch (err) {
        console.error("[Cron] Error processing pending emails:", err);
      }
    }, 15 * 60 * 1000);
    
    // Process pending nurture messages every 15 minutes
    setInterval(async () => {
      try {
        const { processNurtureEmails } = await import("../nurtureProcessor");
        await processNurtureEmails();
      } catch (err) {
        console.error("[Cron] Error processing nurture emails:", err);
      }
    }, 15 * 60 * 1000);
    
    // Check and send weekly report every hour (sends on Mondays at 9am)
    setInterval(async () => {
      try {
        const { checkAndSendWeeklyReport } = await import("../weeklyReport");
        await checkAndSendWeeklyReport();
      } catch (err) {
        console.error("[Cron] Error checking weekly report:", err);
      }
    }, 60 * 60 * 1000);

    // Also run once on startup after a short delay
    setTimeout(async () => {
      try {
        await processPendingEmails();
      } catch (err) {
        console.error("[Cron] Error processing pending emails on startup:", err);
      }
    }, 30000);
  });
}

startServer().catch(console.error);
