/**
 * Text-to-Speech helper using the Forge API (OpenAI-compatible TTS endpoint)
 * Generates audio narration from text scripts
 */
import { ENV } from "./env";

export type TTSOptions = {
  text: string;
  voice?: "alloy" | "echo" | "fable" | "onyx" | "nova" | "shimmer";
  speed?: number; // 0.25 to 4.0, default 1.0
};

export type TTSResult = {
  audioBuffer: Buffer;
  contentType: string;
};

export type TTSError = {
  error: string;
  code: "SERVICE_ERROR" | "TEXT_TOO_LONG" | "GENERATION_FAILED";
  details?: string;
};

/**
 * Generate speech audio from text using the TTS API
 */
export async function generateSpeech(
  options: TTSOptions
): Promise<TTSResult | TTSError> {
  try {
    if (!ENV.forgeApiUrl || !ENV.forgeApiKey) {
      return {
        error: "TTS service is not configured",
        code: "SERVICE_ERROR",
        details: "BUILT_IN_FORGE_API_URL or BUILT_IN_FORGE_API_KEY is not set",
      };
    }

    // OpenAI TTS has a 4096 char limit per request
    // For longer texts, we chunk and concatenate
    const maxChunkSize = 4000;
    const text = options.text.trim();

    if (!text) {
      return {
        error: "Text is empty",
        code: "TEXT_TOO_LONG",
        details: "No text provided for speech generation",
      };
    }

    const baseUrl = ENV.forgeApiUrl.endsWith("/")
      ? ENV.forgeApiUrl
      : `${ENV.forgeApiUrl}/`;
    const ttsUrl = new URL("v1/audio/speech", baseUrl).toString();

    if (text.length <= maxChunkSize) {
      // Single request
      const result = await callTTS(ttsUrl, text, options);
      if ("error" in result) return result;
      return result;
    }

    // Split into chunks at sentence boundaries
    const chunks = splitTextIntoChunks(text, maxChunkSize);
    const audioBuffers: Buffer[] = [];

    for (const chunk of chunks) {
      const result = await callTTS(ttsUrl, chunk, options);
      if ("error" in result) return result;
      audioBuffers.push(result.audioBuffer);
    }

    // Concatenate all audio buffers (MP3 files can be concatenated)
    const combined = Buffer.concat(audioBuffers);
    return {
      audioBuffer: combined,
      contentType: "audio/mpeg",
    };
  } catch (error) {
    return {
      error: "TTS generation failed",
      code: "SERVICE_ERROR",
      details: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

async function callTTS(
  url: string,
  text: string,
  options: TTSOptions
): Promise<TTSResult | TTSError> {
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${ENV.forgeApiKey}`,
    },
    body: JSON.stringify({
      model: "tts-1",
      input: text,
      voice: options.voice || "nova",
      speed: options.speed || 1.0,
      response_format: "mp3",
    }),
  });

  if (!response.ok) {
    const errorText = await response.text().catch(() => "");
    return {
      error: "TTS API request failed",
      code: "GENERATION_FAILED",
      details: `${response.status} ${response.statusText}: ${errorText}`,
    };
  }

  const arrayBuffer = await response.arrayBuffer();
  return {
    audioBuffer: Buffer.from(arrayBuffer),
    contentType: "audio/mpeg",
  };
}

/**
 * Split text into chunks at sentence boundaries
 */
function splitTextIntoChunks(text: string, maxSize: number): string[] {
  const sentences = text.match(/[^.!?]+[.!?]+[\s]*/g) || [text];
  const chunks: string[] = [];
  let current = "";

  for (const sentence of sentences) {
    if ((current + sentence).length > maxSize && current.length > 0) {
      chunks.push(current.trim());
      current = sentence;
    } else {
      current += sentence;
    }
  }

  if (current.trim()) {
    chunks.push(current.trim());
  }

  return chunks;
}
