import { Resend } from "resend";

// Initialize Resend client
function getResend(): Resend | null {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.warn("[Email] RESEND_API_KEY not configured - emails will be logged only");
    return null;
  }
  return new Resend(apiKey);
}

function getFromAddress(): string {
  const envFrom = process.env.EMAIL_FROM;
  // Validate EMAIL_FROM format: must contain @ sign
  if (envFrom && envFrom.includes("@")) {
    // If it's just an email, wrap it with a name
    if (!envFrom.includes("<")) {
      return `Data CX <${envFrom}>`;
    }
    return envFrom;
  }
  // Fallback to default if not configured or invalid format
  if (envFrom && !envFrom.includes("@")) {
    console.warn(`[Email] EMAIL_FROM "${envFrom}" is invalid (missing @). Using default.`);
  }
  return "Data CX <noreply@datacx.com.br>";
}

// ============ EMAIL TEMPLATES ============

function baseTemplate(content: string): string {
  return `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { margin: 0; padding: 0; background-color: #0a0e1a; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
    .container { max-width: 600px; margin: 0 auto; background-color: #111827; border-radius: 12px; overflow: hidden; }
    .header { background: linear-gradient(135deg, #1e3a5f 0%, #0a0e1a 100%); padding: 32px 24px; text-align: center; }
    .header img { height: 40px; }
    .header h2 { color: #e2e8f0; font-size: 14px; margin: 8px 0 0; font-weight: 400; letter-spacing: 2px; text-transform: uppercase; }
    .body { padding: 32px 24px; color: #cbd5e1; line-height: 1.6; }
    .body h1 { color: #f1f5f9; font-size: 24px; margin: 0 0 16px; }
    .body p { margin: 0 0 16px; font-size: 15px; }
    .btn { display: inline-block; background: linear-gradient(135deg, #e85d4a 0%, #d4432e 100%); color: #ffffff !important; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-weight: 600; font-size: 15px; margin: 8px 0 24px; }
    .btn:hover { opacity: 0.9; }
    .divider { border: none; border-top: 1px solid #1f2937; margin: 24px 0; }
    .footer { padding: 24px; text-align: center; color: #6b7280; font-size: 12px; }
    .footer a { color: #6b7280; text-decoration: underline; }
    .highlight { color: #60a5fa; font-weight: 600; }
    .card { background: #1a2332; border: 1px solid #1f2937; border-radius: 8px; padding: 16px; margin: 16px 0; }
    .badge { display: inline-block; background: rgba(232, 93, 74, 0.15); color: #e85d4a; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
  </style>
</head>
<body>
  <div style="padding: 24px;">
    <div class="container">
      <div class="header">
        <h2 style="font-size: 20px; font-weight: 700; letter-spacing: 3px; color: #60a5fa;">DCX</h2>
        <h2>PROTOCOLO VÉRTICE</h2>
      </div>
      <div class="body">
        ${content}
      </div>
      <div class="footer">
        <p>Data CX — Protocolo Vértice</p>
        <p>Mentoria em CX, Dados e IA</p>
        <p style="margin-top: 8px;">
          <a href="https://datacx-mentoria.manus.space">Acessar Portal</a> · 
          <a href="https://datacx-mentoria.manus.space/privacidade">Política de Privacidade</a>
        </p>
      </div>
    </div>
  </div>
</body>
</html>`;
}

// ============ EMAIL SENDERS ============

export interface SendEmailResult {
  success: boolean;
  messageId?: string;
  error?: string;
}

/**
 * Send a password reset email
 */
export async function sendPasswordResetEmail(
  to: string,
  userName: string,
  resetUrl: string
): Promise<SendEmailResult> {
  const html = baseTemplate(`
    <h1>Recuperação de Senha</h1>
    <p>Olá, <span class="highlight">${userName || "aluno(a)"}</span>!</p>
    <p>Recebemos uma solicitação para redefinir sua senha na plataforma Data CX.</p>
    <p>Clique no botão abaixo para criar uma nova senha:</p>
    <div style="text-align: center;">
      <a href="${resetUrl}" class="btn">Redefinir Minha Senha</a>
    </div>
    <div class="card">
      <p style="margin: 0; font-size: 13px;">⏰ Este link expira em <strong>1 hora</strong>.</p>
      <p style="margin: 8px 0 0; font-size: 13px;">Se você não solicitou esta alteração, ignore este e-mail.</p>
    </div>
    <hr class="divider" />
    <p style="font-size: 13px; color: #6b7280;">Se o botão não funcionar, copie e cole este link no seu navegador:</p>
    <p style="font-size: 12px; color: #6b7280; word-break: break-all;">${resetUrl}</p>
  `);

  return sendEmail({
    to,
    subject: "Redefinir Senha — Data CX",
    html,
  });
}

/**
 * Send a welcome email after registration
 */
export async function sendWelcomeEmail(
  to: string,
  userName: string,
  portalUrl: string
): Promise<SendEmailResult> {
  const html = baseTemplate(`
    <h1>Bem-vindo(a) à Data CX! 🎉</h1>
    <p>Olá, <span class="highlight">${userName}</span>!</p>
    <p>Sua conta foi criada com sucesso na plataforma <strong>Data CX — Protocolo Vértice</strong>.</p>
    <p>Agora você tem acesso à nossa plataforma de mentoria em CX, Dados e IA.</p>
    
    <div class="card">
      <p style="margin: 0; font-weight: 600; color: #f1f5f9;">🚀 Próximos Passos:</p>
      <p style="margin: 8px 0 4px; font-size: 14px;">1. Faça o <strong>Radar Vértice</strong> para descobrir seu nível</p>
      <p style="margin: 4px 0; font-size: 14px;">2. Explore os <strong>conteúdos disponíveis</strong></p>
      <p style="margin: 4px 0; font-size: 14px;">3. Escolha o <strong>programa ideal</strong> para você</p>
    </div>

    <div style="text-align: center;">
      <a href="${portalUrl}/radar" class="btn">Fazer Radar Vértice</a>
    </div>
    
    <p>Qualquer dúvida, entre em contato conosco pelo portal ou WhatsApp.</p>
    <p>Abraços,<br/><strong>Samuel Rosa</strong><br/>Mentor — Protocolo Vértice</p>
  `);

  return sendEmail({
    to,
    subject: "Bem-vindo(a) à Data CX — Protocolo Vértice! 🎉",
    html,
  });
}

/**
 * Send a purchase confirmation email
 */
export async function sendPurchaseConfirmationEmail(
  to: string,
  userName: string,
  productName: string,
  amount: string,
  portalUrl: string
): Promise<SendEmailResult> {
  const html = baseTemplate(`
    <h1>Compra Confirmada! ✅</h1>
    <p>Olá, <span class="highlight">${userName}</span>!</p>
    <p>Seu pagamento foi confirmado com sucesso. Aqui estão os detalhes:</p>
    
    <div class="card">
      <p style="margin: 0;"><span class="badge">Confirmado</span></p>
      <p style="margin: 12px 0 4px; font-size: 18px; font-weight: 700; color: #f1f5f9;">${productName}</p>
      <p style="margin: 4px 0; font-size: 14px;">Valor: <strong>${amount}</strong></p>
    </div>

    <p>Seus módulos já foram liberados! Acesse a Área de Membros para começar:</p>

    <div style="text-align: center;">
      <a href="${portalUrl}/membros" class="btn">Acessar Área de Membros</a>
    </div>
    
    <hr class="divider" />
    <p style="font-size: 13px; color: #6b7280;">Lembre-se: você tem <strong>7 dias de garantia</strong> incondicional. Se não estiver satisfeito, devolvemos 100% do seu investimento.</p>
    <p>Abraços,<br/><strong>Samuel Rosa</strong><br/>Mentor — Protocolo Vértice</p>
  `);

  return sendEmail({
    to,
    subject: `Compra Confirmada: ${productName} — Data CX`,
    html,
  });
}

/**
 * Send a certificate awarded email
 */
export async function sendCertificateEmail(
  to: string,
  userName: string,
  certificateName: string,
  certificateNumber: string,
  verificationCode: string,
  downloadUrl: string,
  portalUrl: string
): Promise<SendEmailResult> {
  const html = baseTemplate(`
    <h1>Certificado Emitido! 🏆</h1>
    <p>Parabéns, <span class="highlight">${userName}</span>!</p>
    <p>Você concluiu com êxito todos os conteúdos e atividades do módulo:</p>
    
    <div class="card" style="text-align: center;">
      <p style="margin: 0;"><span class="badge">🎓 Certificado</span></p>
      <p style="margin: 12px 0 4px; font-size: 20px; font-weight: 700; color: #f1f5f9;">${certificateName}</p>
      <p style="margin: 8px 0; font-size: 13px; color: #9ca3af;">Nº ${certificateNumber}</p>
      <p style="margin: 4px 0; font-size: 13px; color: #9ca3af;">Código de Verificação: <code style="color: #60a5fa;">${verificationCode}</code></p>
    </div>

    <p>Seu certificado em PDF está pronto para download. Você também pode compartilhá-lo nas redes sociais!</p>

    <div style="text-align: center;">
      <a href="${downloadUrl}" class="btn">📄 Baixar Certificado PDF</a>
    </div>
    
    <div style="text-align: center; margin-top: 8px;">
      <a href="${portalUrl}/certificados" style="color: #60a5fa; font-size: 14px;">Ver Todos os Meus Certificados</a>
    </div>
    
    <hr class="divider" />
    <p style="font-size: 13px; color: #6b7280;">Continue sua jornada! Quanto mais módulos você completar, mais certificados poderá conquistar.</p>
    <p>Abraços,<br/><strong>Samuel Rosa</strong><br/>Mentor — Protocolo Vértice</p>
  `);

  return sendEmail({
    to,
    subject: `🏆 Certificado Emitido: ${certificateName} — Data CX`,
    html,
  });
}

export async function sendGeneralCertificateEmail(
  to: string,
  userName: string,
  certificateNumber: string,
  verificationCode: string,
  downloadUrl: string,
  portalUrl: string
): Promise<SendEmailResult> {
  const html = baseTemplate(`
    <h1>Parabéns! Você Completou o Protocolo Vértice! 🌟</h1>
    <p>Prezado(a) <span class="highlight">${userName}</span>,</p>
    <p>Este é um momento especial! Você concluiu <strong>todas as 4 trilhas</strong> do Protocolo Vértice e conquistou o certificado mais exclusivo da nossa formação:</p>
    
    <div class="card" style="text-align: center; border: 1px solid #d4af37; background: linear-gradient(135deg, rgba(212,175,55,0.1), rgba(184,148,42,0.05));">
      <p style="margin: 0;"><span class="badge" style="background: linear-gradient(135deg, #d4af37, #b8942a); color: #000;">\u2B50 Certificado de Excelência</span></p>
      <p style="margin: 12px 0 4px; font-size: 22px; font-weight: 700; color: #d4af37;">Protocolo Vértice — Formação Completa</p>
      <p style="margin: 8px 0; font-size: 14px; color: #d4af37;">120 horas · 4 Trilhas · Formação Integral</p>
      <p style="margin: 8px 0; font-size: 13px; color: #9ca3af;">Nº ${certificateNumber}</p>
      <p style="margin: 4px 0; font-size: 13px; color: #9ca3af;">Código de Verificação: <code style="color: #d4af37;">${verificationCode}</code></p>
    </div>

    <p style="font-size: 15px;">Trilhas concluídas:</p>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin: 12px 0;">
      <div style="padding: 8px 12px; background: rgba(80,200,120,0.1); border-radius: 6px; font-size: 13px; color: #50c878;">\u2713 Introdução</div>
      <div style="padding: 8px 12px; background: rgba(80,200,120,0.1); border-radius: 6px; font-size: 13px; color: #50c878;">\u2713 Customer Experience</div>
      <div style="padding: 8px 12px; background: rgba(80,200,120,0.1); border-radius: 6px; font-size: 13px; color: #50c878;">\u2713 Dados & Analytics</div>
      <div style="padding: 8px 12px; background: rgba(80,200,120,0.1); border-radius: 6px; font-size: 13px; color: #50c878;">\u2713 Inteligência Artificial</div>
    </div>

    <p>Seu certificado premium em PDF está pronto. Compartilhe essa conquista!</p>

    <div style="text-align: center;">
      <a href="${downloadUrl}" class="btn" style="background: linear-gradient(135deg, #d4af37, #b8942a); color: #000; font-weight: 700;">\ud83c\udfc6 Baixar Certificado Premium</a>
    </div>
    
    <div style="text-align: center; margin-top: 8px;">
      <a href="${portalUrl}/certificados" style="color: #d4af37; font-size: 14px;">Ver Todos os Meus Certificados</a>
    </div>
    
    <hr class="divider" />
    <p style="font-size: 13px; color: #6b7280;">Você faz parte de um grupo seleto de profissionais que completaram toda a formação. Parabéns pela dedicação!</p>
    <p>Com admiração,<br/><strong>Samuel Rosa</strong><br/>Mentor & Fundador — Protocolo Vértice</p>
  `);

  return sendEmail({
    to,
    subject: `\ud83c\udf1f Certificado de Excelência: Protocolo Vértice Completo — Data CX`,
    html,
  });
}

// ============ CORE SEND FUNCTION ============

async function sendEmail(params: {
  to: string;
  subject: string;
  html: string;
}): Promise<SendEmailResult> {
  const resend = getResend();
  const from = getFromAddress();

  // Always log the email attempt
  console.log(`[Email] Sending "${params.subject}" to ${params.to}`);

  if (!resend) {
    console.log(`[Email] Resend not configured - email logged but not sent`);
    console.log(`[Email] Subject: ${params.subject}`);
    console.log(`[Email] To: ${params.to}`);
    return { success: true, messageId: "logged-only" };
  }

  try {
    const result = await resend.emails.send({
      from,
      to: params.to,
      subject: params.subject,
      html: params.html,
    });

    if (result.error) {
      console.error(`[Email] Resend error:`, result.error);
      return { success: false, error: result.error.message };
    }

    console.log(`[Email] Sent successfully, ID: ${result.data?.id}`);
    return { success: true, messageId: result.data?.id };
  } catch (error: any) {
    console.error(`[Email] Failed to send:`, error);
    return { success: false, error: error.message || "Erro ao enviar e-mail" };
  }
}


// ============ RADAR DIAGNOSTIC EMAIL ============

interface RadarDiagnosticEmailParams {
  to: string;
  name: string;
  persona: string;
  sector?: string;
  scoreCX: number;
  scoreData: number;
  scoreIA: number;
  scoreGovernance: number;
  scoreTotal: number;
  recommendedLevel: string;
  recommendedProduct: string;
  aiAnalysis?: string;
}

export async function sendRadarDiagnosticEmail(params: RadarDiagnosticEmailParams) {
  const resend = getResend();
  const from = getFromAddress();

  const levelLabels: Record<string, string> = {
    fundamentos: "Fundamentos",
    aplicacao: "Aplicação",
    escala: "Escala",
    estrategia: "Estratégia & Execução",
  };

  const personaLabels: Record<string, string> = {
    jovem: "Jovem Profissional",
    gestor: "Gestor",
    executivo: "Executivo",
    empresario: "Empresário",
  };

  const getScoreColor = (s: number) => s >= 4 ? "#10b981" : s >= 3 ? "#f59e0b" : "#ef4444";
  const getScoreBar = (s: number) => `
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
      <div style="width:100px;font-size:13px;color:#94a3b8;">${s >= 4 ? "CX" : ""}</div>
      <div style="flex:1;background:#1e293b;border-radius:4px;height:8px;overflow:hidden;">
        <div style="width:${(s / 5) * 100}%;background:${getScoreColor(s)};height:100%;border-radius:4px;"></div>
      </div>
      <div style="width:40px;text-align:right;font-size:13px;font-weight:600;color:${getScoreColor(s)};">${s.toFixed(1)}</div>
    </div>
  `;

  const scoreRows = [
    { label: "CX - Cliente & Jornada", score: params.scoreCX },
    { label: "Dados - Métricas & Diagnóstico", score: params.scoreData },
    { label: "IA - Uso & Confiança", score: params.scoreIA },
    { label: "Governança & Execução", score: params.scoreGovernance },
  ];

  const scoreRowsHtml = scoreRows.map(r => `
    <tr>
      <td style="padding:8px 12px;font-size:14px;color:#cbd5e1;border-bottom:1px solid #1e293b;">${r.label}</td>
      <td style="padding:8px 12px;border-bottom:1px solid #1e293b;">
        <div style="display:flex;align-items:center;gap:8px;">
          <div style="flex:1;background:#1e293b;border-radius:4px;height:8px;overflow:hidden;">
            <div style="width:${(r.score / 5) * 100}%;background:${getScoreColor(r.score)};height:100%;border-radius:4px;"></div>
          </div>
          <span style="font-size:14px;font-weight:600;color:${getScoreColor(r.score)};min-width:32px;text-align:right;">${r.score.toFixed(1)}</span>
        </div>
      </td>
    </tr>
  `).join("");

  // Convert AI analysis markdown to simple HTML
  let aiAnalysisHtml = "";
  if (params.aiAnalysis) {
    aiAnalysisHtml = params.aiAnalysis
      .replace(/## (.*)/g, '<h2 style="font-size:18px;font-weight:700;color:#e2e8f0;margin:20px 0 8px;">$1</h2>')
      .replace(/### (.*)/g, '<h3 style="font-size:15px;font-weight:600;color:#cbd5e1;margin:16px 0 6px;">$1</h3>')
      .replace(/\*\*(.*?)\*\*/g, '<strong style="color:#e2e8f0;">$1</strong>')
      .replace(/^- (.*)/gm, '<li style="color:#94a3b8;margin:4px 0;padding-left:4px;">$1</li>')
      .replace(/\n\n/g, '<br/><br/>')
      .replace(/\n/g, '<br/>');
  }

  const html = `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width"></head>
<body style="margin:0;padding:0;background:#0f172a;font-family:'Inter',Arial,sans-serif;">
  <div style="max-width:640px;margin:0 auto;padding:24px;">
    <!-- Header -->
    <div style="background:linear-gradient(135deg,#6366f1,#8b5cf6);border-radius:12px;padding:32px;text-align:center;margin-bottom:24px;">
      <div style="font-size:28px;font-weight:800;color:#fff;letter-spacing:-0.5px;">DCX</div>
      <div style="font-size:11px;color:rgba(255,255,255,0.7);letter-spacing:2px;margin-top:4px;">PROTOCOLO VÉRTICE</div>
      <h1 style="font-size:22px;font-weight:700;color:#fff;margin:16px 0 4px;">Seu Diagnóstico Radar Vértice</h1>
      <p style="font-size:14px;color:rgba(255,255,255,0.8);margin:0;">Resultado personalizado para ${params.name}</p>
    </div>

    <!-- Profile -->
    <div style="background:#1e293b;border-radius:12px;padding:20px;margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:12px;">
        <div>
          <div style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:1px;">Perfil</div>
          <div style="font-size:15px;color:#e2e8f0;font-weight:600;margin-top:4px;">${personaLabels[params.persona] || params.persona}</div>
        </div>
        <div>
          <div style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:1px;">Setor</div>
          <div style="font-size:15px;color:#e2e8f0;font-weight:600;margin-top:4px;">${params.sector || "Não informado"}</div>
        </div>
        <div>
          <div style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:1px;">Nível</div>
          <div style="font-size:15px;color:#a78bfa;font-weight:600;margin-top:4px;">${levelLabels[params.recommendedLevel] || params.recommendedLevel}</div>
        </div>
      </div>
    </div>

    <!-- Score Total -->
    <div style="background:linear-gradient(135deg,#1e293b,#0f172a);border:1px solid #334155;border-radius:12px;padding:24px;text-align:center;margin-bottom:16px;">
      <div style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:1px;">Score Geral</div>
      <div style="font-size:48px;font-weight:800;color:${getScoreColor(params.scoreTotal)};margin:8px 0;">${params.scoreTotal.toFixed(1)}</div>
      <div style="font-size:13px;color:#64748b;">de 5.0 pontos</div>
    </div>

    <!-- Scores by Dimension -->
    <div style="background:#1e293b;border-radius:12px;padding:20px;margin-bottom:16px;">
      <h2 style="font-size:16px;font-weight:700;color:#e2e8f0;margin:0 0 16px;">Scores por Dimensão</h2>
      <table style="width:100%;border-collapse:collapse;">
        ${scoreRowsHtml}
      </table>
    </div>

    ${aiAnalysisHtml ? `
    <!-- AI Analysis -->
    <div style="background:linear-gradient(135deg,#1e293b,#1a1a2e);border:1px solid #6366f1;border-radius:12px;padding:24px;margin-bottom:16px;">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px;">
        <span style="font-size:20px;">🤖</span>
        <h2 style="font-size:18px;font-weight:700;color:#a78bfa;margin:0;">Diagnóstico Personalizado por IA</h2>
      </div>
      <div style="color:#94a3b8;font-size:14px;line-height:1.7;">
        ${aiAnalysisHtml}
      </div>
    </div>
    ` : ""}

    <!-- CTA -->
    <div style="text-align:center;margin:24px 0;">
      <p style="font-size:14px;color:#94a3b8;margin-bottom:16px;">Pronto para evoluir? Acesse sua trilha recomendada:</p>
      <a href="https://datacx.manus.space/ofertas" style="display:inline-block;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-weight:600;font-size:15px;padding:14px 32px;border-radius:8px;text-decoration:none;">Ver Programas →</a>
    </div>

    <!-- Footer -->
    <div style="text-align:center;padding:24px 0;border-top:1px solid #1e293b;margin-top:24px;">
      <p style="font-size:12px;color:#475569;margin:0;">Data CX — Protocolo Vértice</p>
      <p style="font-size:11px;color:#334155;margin:4px 0 0;">Você recebeu este email porque completou o Radar Vértice.</p>
    </div>
  </div>
</body>
</html>`;

  if (!resend) {
    console.log(`[Email] Would send Radar Diagnostic to ${params.to}`);
    return { success: true };
  }

  try {
    const result = await resend.emails.send({
      from,
      to: params.to,
      subject: `📊 Seu Diagnóstico Radar Vértice — Score ${params.scoreTotal.toFixed(1)}/5`,
      html,
    });
    console.log(`[Email] Radar Diagnostic sent to ${params.to}:`, result);
    return { success: true };
  } catch (error: any) {
    console.error(`[Email] Failed to send Radar Diagnostic:`, error);
    return { success: false, error: error.message || "Erro ao enviar e-mail" };
  }
}
