import { describe, it, expect, vi, beforeEach } from "vitest";

describe("Release Schedule Logic", () => {
  describe("isReleased calculation", () => {
    it("should return true when releaseDate is null (immediately available)", () => {
      const mod = { releaseDate: null };
      const isReleased = !mod.releaseDate || new Date(mod.releaseDate) <= new Date();
      expect(isReleased).toBe(true);
    });

    it("should return true when releaseDate is in the past", () => {
      const pastDate = new Date(Date.now() - 86400000); // 1 day ago
      const mod = { releaseDate: pastDate };
      const isReleased = !mod.releaseDate || new Date(mod.releaseDate) <= new Date();
      expect(isReleased).toBe(true);
    });

    it("should return false when releaseDate is in the future", () => {
      const futureDate = new Date(Date.now() + 86400000 * 7); // 7 days from now
      const mod = { releaseDate: futureDate };
      const isReleased = !mod.releaseDate || new Date(mod.releaseDate) <= new Date();
      expect(isReleased).toBe(false);
    });

    it("should return true when releaseDate is exactly now", () => {
      const now = new Date();
      const mod = { releaseDate: now };
      const isReleased = !mod.releaseDate || new Date(mod.releaseDate) <= new Date();
      expect(isReleased).toBe(true);
    });
  });

  describe("Module access logic", () => {
    it("should correctly identify locked modules based on plan access", () => {
      const accessibleModuleCodes = ["INT-01", "INT-02", "INT-03", "CX-F01"];
      const moduleCode = "CX-F02";
      const isLocked = !accessibleModuleCodes.includes(moduleCode);
      expect(isLocked).toBe(true);
    });

    it("should correctly identify accessible modules", () => {
      const accessibleModuleCodes = ["INT-01", "INT-02", "INT-03", "CX-F01"];
      const moduleCode = "INT-01";
      const isLocked = !accessibleModuleCodes.includes(moduleCode);
      expect(isLocked).toBe(false);
    });

    it("should handle empty access list (no plan)", () => {
      const accessibleModuleCodes: string[] = [];
      const hasActivePlan = accessibleModuleCodes.length > 0;
      const moduleCode = "INT-01";
      // When no plan, modules should not be locked
      const isLocked = hasActivePlan && !accessibleModuleCodes.includes(moduleCode);
      expect(isLocked).toBe(false);
    });
  });

  describe("Release date formatting", () => {
    it("should format release date in pt-BR format", () => {
      const date = new Date("2026-03-15T12:00:00Z");
      const formatted = date.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" });
      // Date formatting depends on timezone, just verify it produces a non-empty string
      expect(formatted.length).toBeGreaterThan(0);
      expect(formatted).toMatch(/\d{2}/);
    });

    it("should handle null release date gracefully", () => {
      const releaseDate = null;
      const formatted = releaseDate
        ? new Date(releaseDate).toLocaleDateString("pt-BR", { day: "2-digit", month: "short" })
        : null;
      expect(formatted).toBeNull();
    });
  });

  describe("Bulk release schedule validation", () => {
    it("should validate schedule input format", () => {
      const schedules = [
        { contentId: 1, releaseDate: "2026-03-01T00:00:00Z" },
        { contentId: 2, releaseDate: "2026-03-08T00:00:00Z" },
        { contentId: 3, releaseDate: null },
      ];

      expect(schedules).toHaveLength(3);
      expect(schedules[0].releaseDate).toBeTruthy();
      expect(schedules[2].releaseDate).toBeNull();

      // Verify dates are parseable
      const parsed = schedules
        .filter(s => s.releaseDate)
        .map(s => new Date(s.releaseDate!));
      expect(parsed.every(d => !isNaN(d.getTime()))).toBe(true);
    });

    it("should sort schedules chronologically", () => {
      const schedules = [
        { contentId: 3, releaseDate: "2026-03-15T00:00:00Z" },
        { contentId: 1, releaseDate: "2026-03-01T00:00:00Z" },
        { contentId: 2, releaseDate: "2026-03-08T00:00:00Z" },
      ];

      const sorted = [...schedules].sort((a, b) => {
        if (!a.releaseDate) return -1;
        if (!b.releaseDate) return 1;
        return new Date(a.releaseDate).getTime() - new Date(b.releaseDate).getTime();
      });

      expect(sorted[0].contentId).toBe(1);
      expect(sorted[1].contentId).toBe(2);
      expect(sorted[2].contentId).toBe(3);
    });
  });
});
