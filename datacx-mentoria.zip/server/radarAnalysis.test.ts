import { describe, it, expect, vi } from "vitest";

// Mock the OpenAI chat module
vi.mock("./openaiChat", () => ({
  invokeOpenAI: vi.fn().mockResolvedValue({
    choices: [
      {
        message: {
          content: "## 🔍 Visão Geral\n\nSeu perfil indica maturidade intermediária...\n\n## 📊 Análise por Pilar\n\n### CX\nVocê demonstra boa compreensão...\n\n### Dados\nSeus indicadores precisam de refinamento...\n\n### IA\nUso básico mas com potencial...\n\n### Governança\nBoa estrutura de gestão...\n\n## 🎯 Onde Focar Primeiro\n- Ação 1\n- Ação 2\n- Ação 3\n\n## 💡 Observação Final\nSeu perfil mostra potencial significativo.",
        },
      },
    ],
  }),
}));

// Mock notification
vi.mock("./_core/notification", () => ({
  notifyOwner: vi.fn().mockResolvedValue(true),
}));

describe("Radar Vértice AI Analysis", () => {
  const sampleInput = {
    name: "João Silva",
    persona: "gestor" as const,
    sector: "Tecnologia",
    teamSize: "11-50",
    mainGoal: "Aumentar eficiência",
    mainCost: "Tempo",
    urgency: "60",
    answers: {
      cx1: 3, cx2: 4, cx3: 2, cx4: 3, cx5: 2,
      data1: 4, data2: 3, data3: 2, data4: 3, data5: 2,
      ia1: 2, ia2: 3, ia3: 2, ia4: 1, ia5: 1,
      gov1: 3, gov2: 4, gov3: 2, gov4: 3, gov5: 2,
    },
    scoreCX: 2.8,
    scoreData: 2.8,
    scoreIA: 1.8,
    scoreGovernance: 2.8,
    scoreTotal: 2.55,
    recommendedLevel: "aplicacao",
    recommendedProduct: "Mentoria Vértice – Aplicação",
  };

  it("should build a valid prompt with all question texts mapped", () => {
    const questionTexts: Record<string, string> = {
      cx1: "Consigo explicar a jornada do cliente e onde estão os principais atritos",
      cx2: "Tenho clareza do que é 'boa experiência' no meu contexto",
      cx3: "Uso métricas de CX como ferramenta de decisão",
      cx4: "Sei diferenciar 'sintoma' (nota/indicador) de 'causa' (driver)",
      cx5: "Consigo transformar VOC/feedback em backlog priorizado",
      data1: "Confio nos números que uso para decidir",
      data2: "Tenho indicadores bem definidos (conceito, fórmula, dono, meta)",
      data3: "Sei fazer recortes que explicam variação (segmentação, coortes)",
      data4: "Consigo ligar indicador a impacto (custo, receita, churn)",
      data5: "Tenho rotina de acompanhamento com ação e responsável",
      ia1: "Uso IA no dia a dia para produtividade",
      ia2: "Sei escrever prompts objetivos e revisar criticamente as respostas",
      ia3: "Entendo onde IA ajuda mais: análise, classificação, automação, QA",
      ia4: "Sei os riscos básicos (privacidade, alucinação, compliance)",
      ia5: "Tenho processo de validação humana (human-in-the-loop)",
      gov1: "Tenho prioridades claras e não vivo apagando incêndio",
      gov2: "Tenho rituais de gestão que sustentam evolução",
      gov3: "Consigo transformar diagnóstico em plano 30/60/90",
      gov4: "Tenho padrão de qualidade/execução (checklists, playbooks)",
      gov5: "Sei medir se a melhoria 'pegou' ou se voltou ao normal",
    };
    const scaleLabels: Record<number, string> = {
      1: "Não faço / não sei",
      2: "Faço raramente",
      3: "Faço às vezes",
      4: "Faço bem",
      5: "Faço de forma consistente",
    };

    const answersDetail = Object.entries(sampleInput.answers)
      .map(([key, val]) => {
        const q = questionTexts[key] || key;
        const s = scaleLabels[val] || String(val);
        return `- ${q}: ${val}/5 (${s})`;
      })
      .join("\n");

    // All 20 questions should be mapped
    expect(answersDetail.split("\n").length).toBe(20);
    // No raw key should appear (all mapped to text)
    expect(answersDetail).not.toContain("- cx1:");
    expect(answersDetail).not.toContain("- data1:");
    expect(answersDetail).not.toContain("- ia1:");
    expect(answersDetail).not.toContain("- gov1:");
    // Scale labels should appear
    expect(answersDetail).toContain("Faço às vezes");
    expect(answersDetail).toContain("Faço bem");
    expect(answersDetail).toContain("Faço raramente");
    expect(answersDetail).toContain("Não faço / não sei");
  });

  it("should generate persona labels correctly", () => {
    const personaLabels: Record<string, string> = {
      jovem: "Jovem Profissional (18-26 anos)",
      gestor: "Gestor de equipe/operação",
      executivo: "Executivo / Alta gestão",
      empresario: "Empresário / Dono de negócio",
    };

    expect(personaLabels["gestor"]).toBe("Gestor de equipe/operação");
    expect(personaLabels["jovem"]).toBe("Jovem Profissional (18-26 anos)");
    expect(personaLabels["executivo"]).toBe("Executivo / Alta gestão");
    expect(personaLabels["empresario"]).toBe("Empresário / Dono de negócio");
  });

  it("should generate level labels correctly", () => {
    const levelLabels: Record<string, string> = {
      fundamentos: "Fundamentos",
      aplicacao: "Aplicação",
      escala: "Escala",
      estrategia: "Estratégia & Execução",
    };

    expect(levelLabels["aplicacao"]).toBe("Aplicação");
    expect(levelLabels["fundamentos"]).toBe("Fundamentos");
    expect(levelLabels["escala"]).toBe("Escala");
    expect(levelLabels["estrategia"]).toBe("Estratégia & Execução");
  });

  it("should handle all answer keys from the radar questionnaire", () => {
    const expectedKeys = [
      "cx1", "cx2", "cx3", "cx4", "cx5",
      "data1", "data2", "data3", "data4", "data5",
      "ia1", "ia2", "ia3", "ia4", "ia5",
      "gov1", "gov2", "gov3", "gov4", "gov5",
    ];

    const answerKeys = Object.keys(sampleInput.answers);
    expect(answerKeys.sort()).toEqual(expectedKeys.sort());
    expect(answerKeys.length).toBe(20);
  });

  it("should have valid score ranges", () => {
    expect(sampleInput.scoreCX).toBeGreaterThanOrEqual(0);
    expect(sampleInput.scoreCX).toBeLessThanOrEqual(5);
    expect(sampleInput.scoreData).toBeGreaterThanOrEqual(0);
    expect(sampleInput.scoreData).toBeLessThanOrEqual(5);
    expect(sampleInput.scoreIA).toBeGreaterThanOrEqual(0);
    expect(sampleInput.scoreIA).toBeLessThanOrEqual(5);
    expect(sampleInput.scoreGovernance).toBeGreaterThanOrEqual(0);
    expect(sampleInput.scoreGovernance).toBeLessThanOrEqual(5);
    expect(sampleInput.scoreTotal).toBeGreaterThanOrEqual(0);
    expect(sampleInput.scoreTotal).toBeLessThanOrEqual(5);
  });

  it("should call invokeOpenAI with correct structure", async () => {
    const { invokeOpenAI } = await import("./openaiChat");

    const messages = [
      { role: "system" as const, content: "You are a consultant..." },
      { role: "user" as const, content: "Analyze this profile..." },
    ];

    const response = await invokeOpenAI({
      messages,
      model: "gpt-4.1-mini",
      maxTokens: 2048,
      temperature: 0.7,
    });

    expect(response.choices).toBeDefined();
    expect(response.choices.length).toBeGreaterThan(0);
    expect(response.choices[0].message.content).toBeTruthy();
    expect(response.choices[0].message.content).toContain("Visão Geral");
    expect(invokeOpenAI).toHaveBeenCalledWith({
      messages,
      model: "gpt-4.1-mini",
      maxTokens: 2048,
      temperature: 0.7,
    });
  });

  it("should handle OpenAI failure gracefully", async () => {
    const { invokeOpenAI } = await import("./openaiChat");
    (invokeOpenAI as any).mockRejectedValueOnce(new Error("API Error"));

    try {
      await invokeOpenAI({
        messages: [{ role: "user", content: "test" }],
      });
    } catch (error: any) {
      expect(error.message).toBe("API Error");
    }
  });

  it("should build system prompt with correct context", () => {
    const systemPrompt = `Você é um consultor sênior especialista em CX (Customer Experience), Dados & Analytics e Inteligência Artificial aplicada a negócios. Você faz parte do programa "Protocolo Vértice" da Data CX, liderado por Samuel Rosa.`;

    expect(systemPrompt).toContain("Protocolo Vértice");
    expect(systemPrompt).toContain("Data CX");
    expect(systemPrompt).toContain("Samuel Rosa");
    expect(systemPrompt).toContain("CX");
    expect(systemPrompt).toContain("Dados & Analytics");
    expect(systemPrompt).toContain("Inteligência Artificial");
  });

  it("should build user prompt with profile data", () => {
    const personaLabels: Record<string, string> = {
      gestor: "Gestor de equipe/operação",
    };
    const levelLabels: Record<string, string> = {
      aplicacao: "Aplicação",
    };

    const userPrompt = `## Perfil do Profissional
- **Nome:** ${sampleInput.name}
- **Persona:** ${personaLabels[sampleInput.persona]}
- **Setor:** ${sampleInput.sector}
- **Tamanho da equipe:** ${sampleInput.teamSize}
- **Objetivo principal:** ${sampleInput.mainGoal}
- **Nível recomendado:** ${levelLabels[sampleInput.recommendedLevel]}`;

    expect(userPrompt).toContain("João Silva");
    expect(userPrompt).toContain("Gestor de equipe/operação");
    expect(userPrompt).toContain("Tecnologia");
    expect(userPrompt).toContain("11-50");
    expect(userPrompt).toContain("Aumentar eficiência");
    expect(userPrompt).toContain("Aplicação");
  });
});
