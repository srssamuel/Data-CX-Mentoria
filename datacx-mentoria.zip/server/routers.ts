import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import * as db from "./db";
import { notifyOwner } from "./_core/notification";
import { invokeOpenAI } from "./openaiChat";
import Stripe from "stripe";
import { products, getProductById, formatPrice } from "./products";
import { registerUser, loginUser, requestPasswordReset, resetPassword, createEmailAuthToken } from "./emailAuth";
import { sendPasswordResetEmail, sendWelcomeEmail, sendPurchaseConfirmationEmail } from "./emailService";

// Admin-only procedure
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Acesso restrito a administradores' });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    updateProfile: protectedProcedure
      .input(z.object({
        name: z.string().optional(),
        phone: z.string().optional(),
        company: z.string().optional(),
        position: z.string().optional(),
        bio: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.updateUserProfile(ctx.user.id, input);
        return { success: true };
      }),
    // Email/Password auth
    register: publicProcedure
      .input(z.object({
        name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
        email: z.string().email("E-mail inv\u00e1lido"),
        password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
        phone: z.string().optional(),
        company: z.string().optional(),
        position: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await registerUser(input);
        if (!result.success || !result.user) {
          throw new TRPCError({ code: "BAD_REQUEST", message: result.error || "Erro ao cadastrar" });
        }
        // Set session cookie
        const token = await createEmailAuthToken(result.user.id, result.user.openId, result.user.name || "");
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, token, { ...cookieOptions, maxAge: ONE_YEAR_MS });
        // Send welcome email
        const origin = ctx.req.headers.origin || "https://datacx-mentoria.manus.space";
        sendWelcomeEmail(input.email, input.name, origin).catch((err) => {
          console.error("[Auth] Failed to send welcome email:", err);
        });
        return { success: true, user: { id: result.user.id, name: result.user.name, email: result.user.email } };
      }),
    login: publicProcedure
      .input(z.object({
        email: z.string().email("E-mail inv\u00e1lido"),
        password: z.string().min(1, "Senha \u00e9 obrigat\u00f3ria"),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await loginUser(input.email, input.password);
        if (!result.success || !result.token) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: result.error || "Credenciais inv\u00e1lidas" });
        }
        // Set session cookie (same as OAuth)
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, result.token, { ...cookieOptions, maxAge: ONE_YEAR_MS });
        return { success: true, user: { id: result.user.id, name: result.user.name, email: result.user.email } };
      }),
    requestPasswordReset: publicProcedure
      .input(z.object({
        email: z.string().email("E-mail inv\u00e1lido"),
        origin: z.string(),
      }))
      .mutation(async ({ input }) => {
        const result = await requestPasswordReset(input.email);
        if (!result.success) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: result.error || "Erro interno" });
        }
        // Send password reset email via Resend
        if (result.resetToken) {
          const resetUrl = `${input.origin}/reset-password?token=${result.resetToken}`;
          console.log(`[Auth] Password reset link: ${resetUrl}`);
          // Send actual email
          await sendPasswordResetEmail(input.email, "", resetUrl).catch((err) => {
            console.error("[Auth] Failed to send reset email:", err);
          });
          // Also notify owner
          await notifyOwner({
            title: "Solicita\u00e7\u00e3o de Recupera\u00e7\u00e3o de Senha",
            content: `Usu\u00e1rio ${input.email} solicitou recupera\u00e7\u00e3o de senha.\nLink: ${resetUrl}`,
          }).catch(() => {});
        }
        return { success: true, message: "Se o e-mail estiver cadastrado, voc\u00ea receber\u00e1 instru\u00e7\u00f5es para redefinir sua senha." };
      }),
    resetPassword: publicProcedure
      .input(z.object({
        token: z.string(),
        password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
      }))
      .mutation(async ({ input }) => {
        const result = await resetPassword(input.token, input.password);
        if (!result.success) {
          throw new TRPCError({ code: "BAD_REQUEST", message: result.error || "Erro ao redefinir senha" });
        }
        return { success: true, message: "Senha redefinida com sucesso! Fa\u00e7a login com sua nova senha." };
      }),
  }),

  // Programs/Offers
  programs: router({
    list: publicProcedure.query(async () => {
      return db.getAllPrograms(true);
    }),
    listAll: adminProcedure.query(async () => {
      return db.getAllPrograms(false);
    }),
    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        return db.getProgramBySlug(input.slug);
      }),
    create: adminProcedure
      .input(z.object({
        slug: z.string(),
        name: z.string(),
        description: z.string().optional(),
        shortDescription: z.string().optional(),
        type: z.enum(["group", "individual", "diagnostic"]),
        duration: z.string().optional(),
        price: z.string(),
        features: z.array(z.string()).optional(),
        maxParticipants: z.number().optional(),
        stripePriceId: z.string().optional(),
        stripeProductId: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createProgram(input);
        return { success: true };
      }),
    update: adminProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          description: z.string().optional(),
          shortDescription: z.string().optional(),
          duration: z.string().optional(),
          price: z.string().optional(),
          features: z.array(z.string()).optional(),
          maxParticipants: z.number().optional(),
          isActive: z.boolean().optional(),
          stripePriceId: z.string().optional(),
          stripeProductId: z.string().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        await db.updateProgram(input.id, input.data);
        return { success: true };
      }),
  }),

  // Enrollments
  enrollments: router({
    myEnrollments: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserEnrollments(ctx.user.id);
    }),
    listAll: adminProcedure.query(async () => {
      return db.getAllEnrollments();
    }),
    create: protectedProcedure
      .input(z.object({
        programId: z.number(),
        stripePaymentIntentId: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.createEnrollment({
          userId: ctx.user.id,
          programId: input.programId,
          stripePaymentIntentId: input.stripePaymentIntentId,
          status: 'pending',
          paymentStatus: 'pending',
        });
        return { success: true };
      }),
    updateStatus: adminProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["pending", "active", "completed", "cancelled"]),
        paymentStatus: z.enum(["pending", "paid", "failed", "refunded"]).optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.updateEnrollment(input.id, {
          status: input.status,
          paymentStatus: input.paymentStatus,
          notes: input.notes,
        });
        return { success: true };
      }),
    updateEndDate: adminProcedure
      .input(z.object({
        id: z.number(),
        endDate: z.string().nullable(),
      }))
      .mutation(async ({ input }) => {
        await db.updateEnrollment(input.id, {
          endDate: input.endDate ? new Date(input.endDate) : null,
        });
        return { success: true };
      }),
  }),

  // Contents
  contents: router({
    list: protectedProcedure.query(async () => {
      return db.getAllContents();
    }),
    listByCategory: protectedProcedure
      .input(z.object({ category: z.enum(["introducao", "cx", "dados", "ia"]).optional() }))
      .query(async ({ input }) => {
        return db.getContentsByCategory(input.category);
      }),
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getContentById(input.id);
      }),
    listByProgram: protectedProcedure
      .input(z.object({ programId: z.number() }))
      .query(async ({ input }) => {
        return db.getContentsByProgram(input.programId);
      }),
    listPublic: publicProcedure.query(async () => {
      return db.getPublicContents();
    }),
    // V2 - Trails
    trails: protectedProcedure.query(async () => {
      return db.getTrails();
    }),
    byPilar: protectedProcedure
      .input(z.object({ pilar: z.string() }))
      .query(async ({ input }) => {
        return db.getModulesByPilar(input.pilar);
      }),
    byCode: protectedProcedure
      .input(z.object({ moduleCode: z.string() }))
      .query(async ({ input }) => {
        return db.getModuleByCode(input.moduleCode);
      }),
    search: protectedProcedure
      .input(z.object({ query: z.string() }))
      .query(async ({ input }) => {
        return db.searchModules(input.query);
      }),
    withProgress: protectedProcedure.query(async ({ ctx }) => {
      return db.getAllModulesWithProgress(ctx.user.id);
    }),
    recentlyViewed: protectedProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ ctx, input }) => {
        return db.getRecentlyViewedModules(ctx.user.id, input.limit || 5);
      }),
    checkAccess: protectedProcedure
      .input(z.object({ moduleCode: z.string() }))
      .query(async ({ ctx, input }) => {
        const hasAccess = await db.checkModuleAccess(ctx.user.id, input.moduleCode);
        return { hasAccess };
      }),
    accessibleModules: protectedProcedure.query(async ({ ctx }) => {
      const planSlugs = await db.getUserActivePlanSlugs(ctx.user.id);
      const moduleCodes = await db.getUserAccessibleModuleCodes(ctx.user.id);
      const isAdmin = ctx.user.role === 'admin';
      const hasActivePlan = planSlugs.length > 0 || isAdmin;
      return { planSlugs, planSlug: planSlugs[0] || null, moduleCodes, isAdmin, hasActivePlan };
    }),
    create: adminProcedure
      .input(z.object({
        programId: z.number().optional(),
        title: z.string(),
        description: z.string().optional(),
        type: z.enum(["playbook", "template", "video", "document", "link"]),
        fileUrl: z.string().optional(),
        fileKey: z.string().optional(),
        mimeType: z.string().optional(),
        fileSize: z.number().optional(),
        thumbnailUrl: z.string().optional(),
        sortOrder: z.number().optional(),
        isPublic: z.boolean().optional(),
        releaseDate: z.string().nullable().optional(),
      }))
      .mutation(async ({ input }) => {
        const createData: any = { ...input };
        if (input.releaseDate) {
          createData.releaseDate = new Date(input.releaseDate);
        } else {
          delete createData.releaseDate;
        }
        await db.createContent(createData);
        return { success: true };
      }),
    update: adminProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          title: z.string().optional(),
          description: z.string().optional(),
          type: z.enum(["playbook", "template", "video", "document", "link", "audio"]).optional(),
          category: z.enum(["introducao", "cx", "dados", "ia"]).optional(),
          fileUrl: z.string().nullable().optional(),
          fileKey: z.string().optional(),
          videoUrl: z.string().nullable().optional(),
          audioUrl: z.string().nullable().optional(),
          markdownContent: z.string().nullable().optional(),
          sortOrder: z.number().optional(),
          isPublic: z.boolean().optional(),
          releaseDate: z.string().nullable().optional(),
          contentVersion: z.string().optional(),
          versionNotes: z.string().nullable().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        const updateData: any = { ...input.data };
        if (input.data.releaseDate !== undefined) {
          updateData.releaseDate = input.data.releaseDate ? new Date(input.data.releaseDate) : null;
        }
        await db.updateContent(input.id, updateData);
        return { success: true };
      }),
     delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteContent(input.id);
        return { success: true };
      }),
    bulkSetReleaseDates: adminProcedure
      .input(z.object({
        schedules: z.array(z.object({
          contentId: z.number(),
          releaseDate: z.string().nullable(),
        })),
      }))
      .mutation(async ({ input }) => {
        for (const schedule of input.schedules) {
          await db.updateContent(schedule.contentId, {
            releaseDate: schedule.releaseDate ? new Date(schedule.releaseDate) : null,
          });
        }
        return { success: true, updated: input.schedules.length };
      }),
  }),
  // User Progress
  progress: router({
    myProgress: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserProgressByUser(ctx.user.id);
    }),
    markComplete: protectedProcedure
      .input(z.object({ contentId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.markContentComplete(ctx.user.id, input.contentId);
        
        // Award points for completing content
        await db.createOrUpdateUserPoints(ctx.user.id, 10, "Conteúdo concluído", "content", input.contentId);
        
        // Check and award any new badges
        const awardedBadges = await db.checkAndAwardBadges(ctx.user.id);
        
        // Check and award any new certificates for completed categories
        const newCertificates = await db.checkAndAwardCertificates(ctx.user.id);
        
        return { success: true, awardedBadges, newCertificates };
      }),
  }),

  // Testimonials
  testimonials: router({
    listActive: publicProcedure.query(async () => {
      return db.getActiveTestimonials();
    }),
    listAll: adminProcedure.query(async () => {
      return db.getAllTestimonials();
    }),
    create: adminProcedure
      .input(z.object({
        name: z.string(),
        company: z.string().optional(),
        position: z.string().optional(),
        content: z.string(),
        rating: z.number().min(1).max(5).optional(),
        avatarUrl: z.string().optional(),
        sortOrder: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createTestimonial(input);
        return { success: true };
      }),
    update: adminProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          company: z.string().optional(),
          position: z.string().optional(),
          content: z.string().optional(),
          rating: z.number().optional(),
          isActive: z.boolean().optional(),
          sortOrder: z.number().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        await db.updateTestimonial(input.id, input.data);
        return { success: true };
      }),
    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteTestimonial(input.id);
        return { success: true };
      }),
  }),

  // Contact
  contact: router({
    submit: publicProcedure
      .input(z.object({
        name: z.string(),
        email: z.string().email(),
        phone: z.string().optional(),
        company: z.string().optional(),
        message: z.string(),
        type: z.enum(["contact", "diagnostic"]).optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createContactSubmission({
          ...input,
          type: input.type || "contact",
        });
        
        // Notify owner
        await notifyOwner({
          title: input.type === "diagnostic" 
            ? `Nova solicitação de diagnóstico: ${input.name}`
            : `Novo contato: ${input.name}`,
          content: `Nome: ${input.name}\nEmail: ${input.email}\nEmpresa: ${input.company || 'Não informada'}\nMensagem: ${input.message}`,
        });
        
        // Enviar notificação WhatsApp via Make.com (se configurado)
        try {
          const webhookUrl = process.env.MAKE_WEBHOOK_URL;
          if (webhookUrl) {
            await fetch(webhookUrl, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                type: input.type === "diagnostic" ? "new_diagnostic" : "new_contact",
                phone: "+5584991278513",
                name: input.name,
                email: input.email,
                company: input.company,
                message: input.message,
                timestamp: new Date().toISOString(),
              }),
            });
          }
        } catch (e) {
          console.error("[Make Webhook] Erro ao enviar:", e);
        }
        
        return { success: true };
      }),
    listAll: adminProcedure.query(async () => {
      return db.getAllContactSubmissions();
    }),
    updateStatus: adminProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["new", "contacted", "scheduled", "completed"]),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.updateContactSubmission(input.id, {
          status: input.status,
          notes: input.notes,
        });
        return { success: true };
      }),
  }),

  // Admin Dashboard
  admin: router({
    metrics: adminProcedure.query(async () => {
      return db.getDashboardMetrics();
    }),
    users: adminProcedure.query(async () => {
      return db.getAllUsers();
    }),
    getUser: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getUserById(input.id);
      }),
    updateUser: adminProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          email: z.string().optional(),
          role: z.enum(["admin", "user"]).optional(),
          phone: z.string().optional(),
          company: z.string().optional(),
          position: z.string().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        await db.updateUserById(input.id, input.data);
        return { success: true };
      }),
    deleteUser: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        // Não permitir excluir o próprio usuário
        if (input.id === ctx.user.id) {
          throw new TRPCError({ code: 'BAD_REQUEST', message: 'Você não pode excluir sua própria conta' });
        }
        await db.deleteUserById(input.id);
        return { success: true };
      }),
    analytics: adminProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ input }) => {
        return db.getAnalyticsEvents(input.limit || 100);
      }),
    enhancedMetrics: adminProcedure.query(async () => {
      return db.getEnhancedDashboardMetrics();
    }),
    feedbackList: adminProcedure
      .input(z.object({ limit: z.number().optional() }).optional())
      .query(async ({ input }) => {
        return db.getAdminFeedbackList({ limit: input?.limit || 100 });
      }),
    feedbackStatsByModule: adminProcedure.query(async () => {
      return db.getFeedbackStatsByModule();
    }),
    studentProgress: adminProcedure.query(async () => {
      return db.getStudentProgressOverview();
    }),
    moduleEngagement: adminProcedure.query(async () => {
      return db.getModuleEngagementMetrics();
    }),
    quizPerformance: adminProcedure.query(async () => {
      return db.getQuizPerformanceMetrics();
    }),
    // User access management
    getUserAccess: adminProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => {
        return db.getUserAccessDetails(input.userId);
      }),
    setModuleOverride: adminProcedure
      .input(z.object({
        userId: z.number(),
        moduleCode: z.string(),
        action: z.enum(['grant', 'revoke']),
        reason: z.string().optional(),
        expiresAt: z.string().optional(), // ISO date string
      }))
      .mutation(async ({ input, ctx }) => {
        await db.setUserModuleOverride({
          userId: input.userId,
          moduleCode: input.moduleCode,
          action: input.action,
          reason: input.reason,
          grantedBy: ctx.user.id,
          expiresAt: input.expiresAt ? new Date(input.expiresAt) : undefined,
        });
        return { success: true };
      }),
    removeModuleOverride: adminProcedure
      .input(z.object({
        userId: z.number(),
        moduleCode: z.string(),
      }))
      .mutation(async ({ input }) => {
        await db.removeUserModuleOverride(input.userId, input.moduleCode);
        return { success: true };
      }),
    grantAllModules: adminProcedure
      .input(z.object({
        userId: z.number(),
        reason: z.string().optional(),
        expiresAt: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Get all module codes
        const allModules = await db.getAllContents();
        const moduleCodes = Array.from(new Set(allModules.map((m: any) => m.moduleCode).filter(Boolean)));
        for (const code of moduleCodes) {
          await db.setUserModuleOverride({
            userId: input.userId,
            moduleCode: code as string,
            action: 'grant',
            reason: input.reason || 'Acesso total concedido pelo admin',
            grantedBy: ctx.user.id,
            expiresAt: input.expiresAt ? new Date(input.expiresAt) : undefined,
          });
        }
        return { success: true, count: moduleCodes.length };
      }),
    revokeAllOverrides: adminProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input }) => {
        const overrides = await db.getUserOverrides(input.userId);
        for (const o of overrides) {
          await db.removeUserModuleOverride(input.userId, o.moduleCode);
        }
        return { success: true, count: overrides.length };
      }),
    getPlanModuleMapping: adminProcedure.query(async () => {
      const allPlans = await db.getAllPrograms();
      const result: Record<string, string[]> = {};
      for (const plan of allPlans) {
        const modules = await db.getAccessibleModuleCodes(plan.slug);
        result[plan.slug] = modules;
      }
      return result;
    }),
  }),

  // Radar Vértice
  radar: router({
    submit: publicProcedure
      .input(z.object({
        name: z.string(),
        email: z.string().email(),
        phone: z.string().optional(),
        persona: z.enum(["jovem", "gestor", "executivo", "empresario"]),
        sector: z.string().optional(),
        teamSize: z.enum(["1-10", "11-50", "51-200", "200+"]).optional(),
        mainGoal: z.string().optional(),
        answers: z.any(),
        scoreCX: z.string(),
        scoreData: z.string(),
        scoreIA: z.string(),
        scoreGovernance: z.string(),
        scoreTotal: z.string(),
        recommendedLevel: z.enum(["fundamentos", "aplicacao", "escala", "estrategia"]),
        recommendedProduct: z.string(),
        mainCost: z.string().optional(),
        urgency: z.enum(["0-30", "60", "90", "sem-urgencia"]).optional(),
        preferredFormat: z.enum(["grupo", "individual"]).optional(),
        budgetRange: z.string().optional(),
        challenges: z.string().optional(),
        consentMarketing: z.boolean(),
        consentPrivacy: z.boolean(),
        consentWhatsapp: z.boolean().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Auto-segment based on challenges
        let challengeSegment: string | undefined;
        let challengeSegments: string[] | undefined;
        if (input.challenges) {
          const { determinePrimarySegment, getMatchingSegments } = await import("../shared/challengeSegments");
          challengeSegment = determinePrimarySegment(input.challenges) || undefined;
          const matchingSegs = getMatchingSegments(input.challenges);
          challengeSegments = matchingSegs.length > 0 ? matchingSegs : undefined;
        }
        
        const result = await db.createRadarLead({
          userId: ctx.user?.id,
          ...input,
          consentWhatsapp: input.consentWhatsapp || false,
          challengeSegment: challengeSegment as any,
          challengeSegments,
        });
        
        // Notify owner about new lead
        await notifyOwner({
          title: `Novo lead Radar Vértice: ${input.name}`,
          content: `Persona: ${input.persona}\nEmail: ${input.email}\nNível recomendado: ${input.recommendedLevel}\nProduto: ${input.recommendedProduct}\nScore total: ${input.scoreTotal}${input.challenges ? `\nDesafios: ${input.challenges.substring(0, 200)}` : ''}`,
        });
        
        // Enviar notificação WhatsApp via Make.com (se configurado)
        try {
          const webhookUrl = process.env.MAKE_WEBHOOK_URL;
          if (webhookUrl) {
            await fetch(webhookUrl, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                type: "new_radar_lead",
                phone: "+5584991278513",
                leadPhone: input.phone || "",
                consentWhatsapp: input.consentWhatsapp || false,
                name: input.name,
                email: input.email,
                persona: input.persona,
                score: input.scoreTotal,
                level: input.recommendedLevel,
                product: input.recommendedProduct,
                segment: challengeSegment || "geral",
                challenges: input.challenges || "",
                timestamp: new Date().toISOString(),
              }),
            });
          }
        } catch (e) {
          console.error("[Make Webhook] Erro ao enviar:", e);
        }
        
        // Criar régua de nurture automática pós-diagnóstico
        if (result?.id && input.consentMarketing) {
          try {
            await db.createNurtureSequence(result.id, {
              name: input.name,
              email: input.email,
              recommendedProduct: input.recommendedProduct,
              scoreCX: input.scoreCX,
              scoreData: input.scoreData,
              scoreIA: input.scoreIA,
              scoreGovernance: input.scoreGovernance,
              challenges: input.challenges,
              challengeSegment: challengeSegment,
            });
          } catch (e) {
            console.error("[Nurture] Erro ao criar sequência:", e);
          }
        }
        
        return { success: true, id: result?.id || null };
      }),
    getResult: publicProcedure
      .input(z.object({ email: z.string().email() }))
      .query(async ({ input }) => {
        return db.getRadarLeadByEmail(input.email);
      }),
    listAll: adminProcedure.query(async () => {
      return db.getAllRadarLeads();
    }),
    metrics: adminProcedure.query(async () => {
      return db.getRadarMetrics();
    }),
    updateStatus: adminProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["new", "contacted", "nurturing", "converted", "lost"]),
      }))
      .mutation(async ({ input }) => {
        await db.updateRadarLeadStatus(input.id, input.status);
        return { success: true };
      }),
    generateAnalysis: publicProcedure
      .input(z.object({
        name: z.string(),
        persona: z.enum(["jovem", "gestor", "executivo", "empresario"]),
        sector: z.string().optional(),
        teamSize: z.string().optional(),
        mainGoal: z.string().optional(),
        mainCost: z.string().optional(),
        urgency: z.string().optional(),
        challenges: z.string().optional(),
        answers: z.record(z.string(), z.number()),
        scoreCX: z.number(),
        scoreData: z.number(),
        scoreIA: z.number(),
        scoreGovernance: z.number(),
        scoreTotal: z.number(),
        recommendedLevel: z.string(),
        recommendedProduct: z.string(),
      }))
      .mutation(async ({ input }) => {
        const personaLabels: Record<string, string> = {
          jovem: "Jovem Profissional (18-26 anos)",
          gestor: "Gestor de equipe/operação",
          executivo: "Executivo / Alta gestão",
          empresario: "Empresário / Dono de negócio",
        };
        const levelLabels: Record<string, string> = {
          fundamentos: "Fundamentos",
          aplicacao: "Aplicação",
          escala: "Escala",
          estrategia: "Estratégia & Execução",
        };
        const questionTexts: Record<string, string> = {
          cx1: "Consigo explicar a jornada do cliente e onde estão os principais atritos",
          cx2: "Tenho clareza do que é 'boa experiência' no meu contexto",
          cx3: "Uso métricas de CX como ferramenta de decisão",
          cx4: "Sei diferenciar 'sintoma' (nota/indicador) de 'causa' (driver)",
          cx5: "Consigo transformar VOC/feedback em backlog priorizado",
          data1: "Confio nos números que uso para decidir",
          data2: "Tenho indicadores bem definidos (conceito, fórmula, dono, meta)",
          data3: "Sei fazer recortes que explicam variação (segmentação, coortes)",
          data4: "Consigo ligar indicador a impacto (custo, receita, churn)",
          data5: "Tenho rotina de acompanhamento com ação e responsável",
          ia1: "Uso IA no dia a dia para produtividade",
          ia2: "Sei escrever prompts objetivos e revisar criticamente as respostas",
          ia3: "Entendo onde IA ajuda mais: análise, classificação, automação, QA",
          ia4: "Sei os riscos básicos (privacidade, alucinação, compliance)",
          ia5: "Tenho processo de validação humana (human-in-the-loop)",
          gov1: "Tenho prioridades claras e não vivo apagando incêndio",
          gov2: "Tenho rituais de gestão que sustentam evolução",
          gov3: "Consigo transformar diagnóstico em plano 30/60/90",
          gov4: "Tenho padrão de qualidade/execução (checklists, playbooks)",
          gov5: "Sei medir se a melhoria 'pegou' ou se voltou ao normal",
        };
        const scaleLabels: Record<number, string> = {
          1: "Não faço / não sei",
          2: "Faço raramente",
          3: "Faço às vezes",
          4: "Faço bem",
          5: "Faço de forma consistente",
        };

        const answersDetail = Object.entries(input.answers)
          .map(([key, val]) => {
            const q = questionTexts[key] || key;
            const numVal = val as number;
            const s = scaleLabels[numVal] || String(numVal);
            return `- ${q}: ${numVal}/5 (${s})`;
          })
          .join("\n");

        const systemPrompt = `Você é um consultor sênior especialista em CX (Customer Experience), Dados & Analytics e Inteligência Artificial aplicada a negócios. Você faz parte do programa "Protocolo Vértice" da Data CX, liderado por Samuel Rosa.

Sua tarefa é analisar o resultado do Radar Vértice de um profissional e gerar um diagnóstico personalizado, direto e acionável.

Regras:
- Escreva em português brasileiro, tom profissional mas acessível
- Seja específico e contextual (use o setor, persona e respostas para personalizar)
- Não seja genérico. Cada observação deve refletir as respostas reais
- Use markdown para formatação (## para títulos, **negrito** para destaques, - para listas)
- Máximo 800 palavras no total
- Não repita os scores numéricos (o usuário já os vê no gráfico)
- Foque em insights que o profissional não perceberia sozinho
- Se o profissional descreveu desafios específicos, enderece-os diretamente na análise e nas recomendações`;

        const userPrompt = `## Perfil do Profissional
- **Nome:** ${input.name}
- **Persona:** ${personaLabels[input.persona] || input.persona}
- **Setor:** ${input.sector || "Não informado"}
- **Tamanho da equipe:** ${input.teamSize || "Não informado"}
- **Objetivo principal:** ${input.mainGoal || "Não informado"}
- **Maior custo de não agir:** ${input.mainCost || "Não informado"}
- **Urgência:** ${input.urgency || "Não informada"}
- **Desafios e contexto:** ${input.challenges || "Não informado"}

## Scores
- CX: ${input.scoreCX.toFixed(1)}/5
- Dados: ${input.scoreData.toFixed(1)}/5
- IA: ${input.scoreIA.toFixed(1)}/5
- Governança: ${input.scoreGovernance.toFixed(1)}/5
- **Total: ${input.scoreTotal.toFixed(1)}/5**
- **Nível recomendado:** ${levelLabels[input.recommendedLevel] || input.recommendedLevel}
- **Produto recomendado:** ${input.recommendedProduct}

## Respostas Detalhadas
${answersDetail}

---

Gere um diagnóstico personalizado com a seguinte estrutura:

## 🔍 Visão Geral
Um parágrafo de 3-4 linhas com a leitura geral do perfil. Identifique o padrão dominante (ex: "sabe o que fazer mas não tem método", "tem dados mas não confia neles", "usa IA mas sem governança").

## 📊 Análise por Pilar

### CX - Cliente & Jornada
Análise de 2-3 frases sobre os pontos fortes e gaps em CX, baseado nas respostas específicas.

### Dados - Métricas & Diagnóstico
Análise de 2-3 frases sobre maturidade em dados.

### IA - Uso & Confiança
Análise de 2-3 frases sobre como está usando (ou não) IA.

### Governança & Execução
Análise de 2-3 frases sobre capacidade de execução e sustentação.

## 🎯 Onde Focar Primeiro
3 ações prioritárias e específicas para os próximos 30 dias, considerando o perfil e nível.

## 💡 Observação Final
Uma reflexão de 2 linhas conectando o perfil à oportunidade (tom motivacional mas realista).`;

        try {
          const response = await invokeOpenAI({
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: userPrompt },
            ],
            model: "gpt-4.1-mini",
            maxTokens: 2048,
            temperature: 0.7,
          });

          const analysis = response.choices?.[0]?.message?.content || "";
          return { success: true, analysis };
        } catch (error) {
          console.error("[Radar AI Analysis] Error:", error);
          return { success: false, analysis: "" };
        }
      }),
    saveAnalysis: protectedProcedure
      .input(z.object({
        leadId: z.number(),
        analysis: z.string(),
      }))
      .mutation(async ({ input }) => {
        await db.saveRadarAiAnalysis(input.leadId, input.analysis);
        return { success: true };
      }),
    sendDiagnosticEmail: publicProcedure
      .input(z.object({
        leadId: z.number(),
        email: z.string().email(),
        name: z.string(),
        persona: z.string(),
        sector: z.string().optional(),
        scoreCX: z.number(),
        scoreData: z.number(),
        scoreIA: z.number(),
        scoreGovernance: z.number(),
        scoreTotal: z.number(),
        recommendedLevel: z.string(),
        recommendedProduct: z.string(),
        aiAnalysis: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { sendRadarDiagnosticEmail } = await import("./emailService");
        const result = await sendRadarDiagnosticEmail({
          to: input.email,
          name: input.name,
          persona: input.persona,
          sector: input.sector,
          scoreCX: input.scoreCX,
          scoreData: input.scoreData,
          scoreIA: input.scoreIA,
          scoreGovernance: input.scoreGovernance,
          scoreTotal: input.scoreTotal,
          recommendedLevel: input.recommendedLevel,
          recommendedProduct: input.recommendedProduct,
          aiAnalysis: input.aiAnalysis,
        });
        if (result.success) {
          await db.markRadarEmailSent(input.leadId);
        }
        return result;
      }),
    getHistory: protectedProcedure
      .query(async ({ ctx }) => {
        return db.getRadarHistoryByUserId(ctx.user.id);
      }),
    segmentTrends: adminProcedure
      .input(z.object({ months: z.number().min(1).max(24).optional() }).optional())
      .query(async ({ input }) => {
        return db.getSegmentTrends(input?.months || 6);
      }),
    leadsBySegment: adminProcedure
      .input(z.object({ segment: z.string() }))
      .query(async ({ input }) => {
        return db.getLeadsBySegment(input.segment);
      }),
    sendWhatsappFollowup: adminProcedure
      .input(z.object({
        segment: z.string().optional(),
        leadIds: z.array(z.number()).optional(),
        message: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const webhookUrl = process.env.MAKE_WEBHOOK_URL;
        if (!webhookUrl) {
          throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Webhook do Make.com não configurado. Configure em Settings > Secrets." });
        }
        
        // Get leads to send to
        let leads: any[] = [];
        if (input.leadIds && input.leadIds.length > 0) {
          // Specific leads
          for (const id of input.leadIds) {
            const lead = await db.getRadarLeadById(id);
            if (lead) leads.push(lead);
          }
        } else if (input.segment) {
          leads = await db.getLeadsBySegment(input.segment);
        }
        
        // Filter only leads with phone and WhatsApp consent
        const eligibleLeads = leads.filter((l: any) => l.phone && l.consentWhatsapp);
        
        if (eligibleLeads.length === 0) {
          return { sent: 0, total: leads.length, message: "Nenhum lead elegível (sem telefone ou sem consentimento de WhatsApp)." };
        }
        
        // Send webhook for each eligible lead
        let sent = 0;
        for (const lead of eligibleLeads) {
          try {
            const { getSegmentById } = await import("../shared/challengeSegments");
            const segDef = lead.challengeSegment ? getSegmentById(lead.challengeSegment) : null;
            
            await fetch(webhookUrl, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                type: "whatsapp_nurture",
                phone: lead.phone,
                name: lead.name,
                email: lead.email,
                persona: lead.persona,
                segment: lead.challengeSegment || "geral",
                segmentLabel: segDef?.label || "Geral",
                score: lead.scoreTotal,
                level: lead.recommendedLevel,
                product: lead.recommendedProduct,
                challenges: lead.challenges || "",
                customMessage: input.message || "",
                timestamp: new Date().toISOString(),
              }),
            });
            sent++;
          } catch (e) {
            console.error(`[WhatsApp Nurture] Erro ao enviar para ${lead.name}:`, e);
          }
        }
        
        return { sent, total: leads.length, eligible: eligibleLeads.length };
      }),
    sendSegmentNurture: adminProcedure
      .input(z.object({
        segment: z.string(),
        subject: z.string().optional(),
        content: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { getSegmentById, SEGMENTS } = await import("../shared/challengeSegments");
        type SegmentCategory = "dados" | "cx" | "ia" | "governanca" | "cultura";
        const segmentDef = getSegmentById(input.segment as SegmentCategory);
        if (!segmentDef) throw new TRPCError({ code: "BAD_REQUEST", message: "Segmento inválido" });
        
        const leads = await db.getLeadsBySegment(input.segment);
        let sentCount = 0;
        
        for (const lead of leads) {
          if (!lead.consentMarketing || !lead.email) continue;
          const subject = (input.subject || segmentDef.nurtureSubject).replace(/\{\{name\}\}/g, lead.name);
          const content = (input.content || segmentDef.nurtureContent).replace(/\{\{name\}\}/g, lead.name);
          
          try {
            const { Resend } = await import("resend");
            const apiKey = process.env.RESEND_API_KEY;
            if (!apiKey) continue;
            const resend = new Resend(apiKey);
            const envFrom = process.env.EMAIL_FROM;
            const from = envFrom && envFrom.includes("@") ? (envFrom.includes("<") ? envFrom : `Data CX <${envFrom}>`) : "Data CX <noreply@datacx.com.br>";
            
            await resend.emails.send({
              from,
              to: lead.email,
              subject,
              html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#111827;color:#e5e7eb;border-radius:12px;">
                <div style="border-bottom:2px solid ${segmentDef.color};padding-bottom:16px;margin-bottom:20px;">
                  <h1 style="color:#fff;font-size:20px;margin:0;">Data CX <span style="color:${segmentDef.color};">Mentoria</span></h1>
                  <p style="color:${segmentDef.color};font-size:12px;margin:4px 0 0;">${segmentDef.icon} ${segmentDef.label}</p>
                </div>
                <div style="white-space:pre-wrap;line-height:1.7;font-size:15px;">${content}</div>
                <div style="text-align:center;margin:24px 0;">
                  <a href="https://datacx.manus.space/ofertas" style="display:inline-block;background:${segmentDef.color};color:#fff;font-weight:600;padding:12px 28px;border-radius:8px;text-decoration:none;">Agendar Sessão Gratuita →</a>
                </div>
                <p style="color:#6b7280;font-size:11px;border-top:1px solid #1f2937;padding-top:16px;margin-top:24px;">Você recebeu este email porque completou o Radar Vértice. Para cancelar, responda com "cancelar".</p>
              </div>`,
            });
            sentCount++;
          } catch (err) {
            console.error(`[SegmentNurture] Failed to send to ${lead.email}:`, err);
          }
        }
        
        return { success: true, sentCount, totalLeads: leads.length };
      }),
    sendWeeklyReport: adminProcedure
      .mutation(async () => {
        const { sendWeeklyReport } = await import("./weeklyReport");
        const success = await sendWeeklyReport();
        return { success };
      }),
  }),

  // Analytics tracking
  analytics: router({
    track: publicProcedure
      .input(z.object({
        eventType: z.string(),
        eventData: z.any().optional(),
        pageUrl: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.trackEvent({
          userId: ctx.user?.id,
          eventType: input.eventType,
          eventData: input.eventData,
          pageUrl: input.pageUrl,
        });
        return { success: true };
      }),
  }),

  // Stripe Checkout
  stripe: router({
    getProducts: publicProcedure.query(() => {
      return products.map(p => ({
        ...p,
        formattedPrice: formatPrice(p.price, p.currency),
      }));
    }),
    
    createCheckout: protectedProcedure
      .input(z.object({
        productId: z.string(),
        couponCode: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const product = getProductById(input.productId);
        if (!product) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Produto não encontrado" });
        }
        
        const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
          apiVersion: "2026-01-28.clover",
        });
        
        const origin = ctx.req.headers.origin || "https://datacx-mentoria.manus.space";
        
        // Validar cupom se fornecido
        let stripePromotionCodeId: string | undefined;
        let couponData: { code: string; discountType: string; discountValue: number } | undefined;
        
        if (input.couponCode) {
          const couponResult = await db.validateCoupon(input.couponCode, input.productId);
          if (!couponResult.valid || !couponResult.coupon) {
            throw new TRPCError({ code: "BAD_REQUEST", message: couponResult.error || "Cupom inválido" });
          }
          
          // Verificar limite de uso por usuário
          const userUsageCount = await db.getUserCouponUsageCount(ctx.user.id, couponResult.coupon.id);
          if (userUsageCount >= couponResult.coupon.usageLimitPerUser) {
            throw new TRPCError({ code: "BAD_REQUEST", message: "Você já usou este cupom o número máximo de vezes" });
          }
          
          stripePromotionCodeId = couponResult.coupon.stripePromotionCodeId || undefined;
          couponData = {
            code: couponResult.coupon.code,
            discountType: couponResult.coupon.discountType,
            discountValue: Number(couponResult.coupon.discountValue),
          };
        }
        
        // Configurar métodos de pagamento: cartão
        // Nota: PIX requer ativação manual no Stripe Dashboard (https://dashboard.stripe.com/account/payments/settings)
        // Para habilitar PIX, ative-o no dashboard e descomente a linha abaixo
        const paymentMethods: Stripe.Checkout.SessionCreateParams.PaymentMethodType[] = ["card"];
        
        // Adicionar PIX para pagamentos em BRL (apenas para pagamentos únicos)
        // Descomente as linhas abaixo após ativar PIX no Stripe Dashboard
        // if (product.currency === "brl" && product.type === "one_time") {
        //   paymentMethods.push("pix");
        // }
        
        // Calcular desconto para verificar se é 100% OFF
        let finalAmountCents = product.price;
        if (couponData) {
          if (couponData.discountType === "percentage") {
            const discountAmount = Math.round(product.price * couponData.discountValue / 100);
            finalAmountCents = Math.max(0, product.price - discountAmount);
          } else {
            // fixed discount em reais, converter para centavos
            const discountCents = Math.round(couponData.discountValue * 100);
            finalAmountCents = Math.max(0, product.price - discountCents);
          }
        }
        
        // Se o preço final é 0 (100% OFF), criar enrollment diretamente sem Stripe
        if (finalAmountCents === 0 && couponData) {
          console.log(`[Checkout] 100% OFF coupon applied for user ${ctx.user.id}, product ${product.id}`);
          
          // Map product_id to program slug
          const productToProgramSlug: Record<string, string> = {
            playbook_vertice: "playbook_377",
            mentoria_grupo: "grupo_8_semanas",
            mentoria_sprint: "individual_90_dias",
            mentoria_90dias: "individual_90_dias",
            mentoria_executive: "executive_6m",
            diagnostico_360: "empresas_diagnostico",
            assessoria_mensal: "empresas_diagnostico",
          };
          
          const programSlug = productToProgramSlug[product.id];
          let programId = 30001;
          
          if (programSlug) {
            const program = await db.getProgramBySlug(programSlug);
            if (program) {
              programId = program.id;
            }
          }
          
          // Criar enrollment diretamente
          await db.createEnrollment({
            userId: ctx.user.id,
            programId,
            status: "active",
          });
          
          // Registrar uso do cupom
          if (couponData.code) {
            const couponRecord = await db.getCouponByCode(couponData.code);
            if (couponRecord) {
              await db.incrementCouponUsage(couponRecord.id);
              await db.recordCouponUsage({
                couponId: couponRecord.id,
                userId: ctx.user.id,
                discountApplied: (product.price / 100).toFixed(2),
                originalAmount: (product.price / 100).toFixed(2),
                finalAmount: "0.00",
                stripeSessionId: `free_${Date.now()}`,
              });
            }
          }
          
          console.log(`[Checkout] Free enrollment created for user ${ctx.user.id} in program ${programId}`);
          
          // Retornar URL de sucesso diretamente (sem Stripe)
          return { url: `${origin}/pagamento-sucesso?product=${product.id}&free=true` };
        }
        
        const sessionParams: Stripe.Checkout.SessionCreateParams = {
          payment_method_types: paymentMethods,
          mode: product.type === "recurring" ? "subscription" : "payment",
          customer_email: ctx.user.email || undefined,
          client_reference_id: ctx.user.id.toString(),
          // Se tiver cupom com promo code do Stripe, usar ele; senão permitir códigos promocionais
          ...(stripePromotionCodeId ? {
            discounts: [{ promotion_code: stripePromotionCodeId }],
          } : {
            allow_promotion_codes: true,
          }),
          metadata: {
            user_id: ctx.user.id.toString(),
            customer_email: ctx.user.email || "",
            customer_name: ctx.user.name || "",
            product_id: product.id,
            product_name: product.name,
            origin: origin,
            ...(couponData ? { coupon_code: couponData.code } : {}),
          },
          line_items: [
            {
              price_data: {
                currency: product.currency,
                product_data: {
                  name: product.name,
                  description: product.description,
                },
                unit_amount: product.price,
                ...(product.type === "recurring" && product.interval ? {
                  recurring: {
                    interval: product.interval,
                  },
                } : {}),
              },
              quantity: 1,
            },
          ],
          success_url: `${origin}/pagamento-sucesso?product=${product.id}`,
          cancel_url: `${origin}/ofertas?cancelled=true`,
        };
        
        const session = await stripe.checkout.sessions.create(sessionParams);
        
        return { url: session.url };
      }),
    
    getPaymentHistory: protectedProcedure.query(async ({ ctx }) => {
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
        apiVersion: "2026-01-28.clover",
      });
      
      try {
        // Search for customer by email
        const customers = await stripe.customers.list({
          email: ctx.user.email || undefined,
          limit: 1,
        });
        
        if (customers.data.length === 0) {
          return [];
        }
        
        const customerId = customers.data[0].id;
        
        // Get payment intents for this customer
        const paymentIntents = await stripe.paymentIntents.list({
          customer: customerId,
          limit: 20,
        });
        
        return paymentIntents.data.map(pi => ({
          id: pi.id,
          amount: pi.amount,
          currency: pi.currency,
          status: pi.status,
          createdAt: new Date(pi.created * 1000).toISOString(),
          description: pi.description,
        }));
      } catch (error) {
        console.error("[Stripe] Error fetching payment history:", error);
        return [];
      }
    }),
  }),

  // Coupons
  coupons: router({
    // Public - validate coupon
    validate: publicProcedure
      .input(z.object({
        code: z.string(),
        productSlug: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const result = await db.validateCoupon(input.code, input.productSlug);
        if (!result.valid || !result.coupon) {
          return { valid: false, error: result.error };
        }
        return {
          valid: true,
          coupon: {
            code: result.coupon.code,
            name: result.coupon.name,
            discountType: result.coupon.discountType,
            discountValue: Number(result.coupon.discountValue),
            maxDiscountAmount: result.coupon.maxDiscountAmount ? Number(result.coupon.maxDiscountAmount) : null,
          },
        };
      }),
    
    // Admin - list all coupons
    listAll: adminProcedure.query(async () => {
      return db.getAllCoupons();
    }),
    
    // Admin - get coupon metrics
    metrics: adminProcedure.query(async () => {
      return db.getCouponMetrics();
    }),
    
    // Admin - get coupon by ID
    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getCouponById(input.id);
      }),
    
    // Admin - get coupon usages
    getUsages: adminProcedure
      .input(z.object({ couponId: z.number() }))
      .query(async ({ input }) => {
        return db.getCouponUsages(input.couponId);
      }),
    
    // Admin - create coupon
    create: adminProcedure
      .input(z.object({
        code: z.string().min(3).max(50),
        name: z.string().min(1).max(255),
        description: z.string().optional(),
        discountType: z.enum(["percentage", "fixed"]),
        discountValue: z.number().positive(),
        minPurchaseAmount: z.number().optional(),
        maxDiscountAmount: z.number().optional(),
        applicableProducts: z.array(z.string()).optional(),
        usageLimit: z.number().optional(),
        usageLimitPerUser: z.number().default(1),
        validFrom: z.date().optional(),
        validUntil: z.date().optional(),
        isActive: z.boolean().default(true),
      }))
      .mutation(async ({ input }) => {
        // Create coupon in Stripe
        const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
          apiVersion: "2026-01-28.clover",
        });
        
        let stripeCouponId: string | undefined;
        let stripePromotionCodeId: string | undefined;
        
        try {
          // Create Stripe coupon
          const stripeCoupon = await stripe.coupons.create({
            ...(input.discountType === "percentage" 
              ? { percent_off: input.discountValue }
              : { amount_off: Math.round(input.discountValue * 100), currency: "brl" }),
            duration: "once",
            max_redemptions: input.usageLimit || undefined,
            redeem_by: input.validUntil ? Math.floor(input.validUntil.getTime() / 1000) : undefined,
            name: input.name,
          });
          stripeCouponId = stripeCoupon.id;
          
          // Create promotion code for the coupon
          const promoCode = await stripe.promotionCodes.create({
            coupon: stripeCoupon.id,
            code: input.code.toUpperCase(),
          } as any);
          stripePromotionCodeId = promoCode.id;
        } catch (error) {
          console.error("[Stripe] Error creating coupon:", error);
          // Continue without Stripe integration
        }
        
        await db.createCoupon({
          ...input,
          discountValue: input.discountValue.toString(),
          minPurchaseAmount: input.minPurchaseAmount?.toString(),
          maxDiscountAmount: input.maxDiscountAmount?.toString(),
          stripeCouponId,
          stripePromotionCodeId,
        });
        
        return { success: true };
      }),
    
    // Admin - update coupon
    update: adminProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          code: z.string().min(3).max(50).optional(),
          name: z.string().min(1).max(255).optional(),
          description: z.string().optional(),
          discountType: z.enum(["percentage", "fixed"]).optional(),
          discountValue: z.number().positive().optional(),
          minPurchaseAmount: z.number().optional(),
          maxDiscountAmount: z.number().optional(),
          applicableProducts: z.array(z.string()).optional(),
          usageLimit: z.number().optional(),
          usageLimitPerUser: z.number().optional(),
          validFrom: z.date().optional(),
          validUntil: z.date().optional(),
          isActive: z.boolean().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        const updateData: Record<string, unknown> = { ...input.data };
        if (input.data.discountValue !== undefined) {
          updateData.discountValue = input.data.discountValue.toString();
        }
        if (input.data.minPurchaseAmount !== undefined) {
          updateData.minPurchaseAmount = input.data.minPurchaseAmount.toString();
        }
        if (input.data.maxDiscountAmount !== undefined) {
          updateData.maxDiscountAmount = input.data.maxDiscountAmount.toString();
        }
        await db.updateCoupon(input.id, updateData as any);
        return { success: true };
      }),
    
    // Admin - delete coupon
    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const coupon = await db.getCouponById(input.id);
        
        // Delete from Stripe if exists
        if (coupon?.stripeCouponId) {
          try {
            const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
              apiVersion: "2026-01-28.clover",
            });
            await stripe.coupons.del(coupon.stripeCouponId);
          } catch (error) {
            console.error("[Stripe] Error deleting coupon:", error);
          }
        }
        
        await db.deleteCoupon(input.id);
        return { success: true };
      }),
    
    // Admin - toggle coupon active status
    toggleActive: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const coupon = await db.getCouponById(input.id);
        if (!coupon) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Cupom não encontrado" });
        }
        await db.updateCoupon(input.id, { isActive: !coupon.isActive });
        return { success: true, isActive: !coupon.isActive };
      }),
  }),

  // Gamification
  gamification: router({
    myPoints: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserPoints(ctx.user.id);
    }),
    leaderboard: protectedProcedure.query(async () => {
      return db.getLeaderboard(10);
    }),
    myBadges: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserBadges(ctx.user.id);
    }),
    allBadges: protectedProcedure.query(async () => {
      return db.getAllBadges();
    }),
    myTransactions: protectedProcedure.query(async ({ ctx }) => {
      return db.getPointTransactions(ctx.user.id);
    }),
    // Get full profile stats for user
    myStats: protectedProcedure.query(async ({ ctx }) => {
      const [points, badges, userBadges, progress, contents, enrollments, transactions] = await Promise.all([
        db.getUserPoints(ctx.user.id),
        db.getAllBadges(),
        db.getUserBadges(ctx.user.id),
        db.getUserProgressByUser(ctx.user.id),
        db.getAllContents(),
        db.getUserEnrollments(ctx.user.id),
        db.getPointTransactions(ctx.user.id, 10),
      ]);
      
      const completedContentIds = new Set(progress.filter(p => p.completed).map(p => p.contentId));
      const totalContents = contents.length;
      const completedContents = completedContentIds.size;
      
      // Calculate progress by category
      const categoryProgress = {
        introducao: { total: 0, completed: 0 },
        cx: { total: 0, completed: 0 },
        dados: { total: 0, completed: 0 },
        ia: { total: 0, completed: 0 },
      };
      
      contents.forEach(content => {
        const cat = content.category as keyof typeof categoryProgress;
        if (categoryProgress[cat]) {
          categoryProgress[cat].total++;
          if (completedContentIds.has(content.id)) {
            categoryProgress[cat].completed++;
          }
        }
      });
      
      // Map badges with earned status
      const earnedBadgeIds = new Set(userBadges.map(ub => ub.badgeId));
      const badgesWithStatus = badges.map(badge => ({
        ...badge,
        earned: earnedBadgeIds.has(badge.id),
        earnedAt: userBadges.find(ub => ub.badgeId === badge.id)?.earnedAt,
      }));
      
      return {
        points: points || { points: 0, level: 1, levelName: 'Iniciante', totalPointsEarned: 0 },
        badges: badgesWithStatus,
        earnedBadgesCount: userBadges.length,
        totalBadges: badges.length,
        progress: {
          total: totalContents,
          completed: completedContents,
          percentage: totalContents > 0 ? Math.round((completedContents / totalContents) * 100) : 0,
          byCategory: categoryProgress,
        },
        enrollments: enrollments.filter(e => e.status === 'active').length,
        recentActivity: transactions,
      };
    }),
  }),

  // Community
  community: router({
    listPosts: protectedProcedure
      .input(z.object({ programId: z.number().optional(), space: z.string().optional() }).optional())
      .query(async ({ input }) => {
        return db.getCommunityPosts(input?.programId, input?.space);
      }),
    createPost: protectedProcedure
      .input(z.object({
        title: z.string().optional(),
        content: z.string(),
        type: z.enum(["discussion", "question", "announcement", "resource"]).optional(),
        programId: z.number().optional(),
        space: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.createPost({
          userId: ctx.user.id,
          title: input.title,
          content: input.content,
          type: input.type || "discussion",
          programId: input.programId,
          space: input.space || "geral",
        });
        return { success: true };
      }),
    toggleLike: protectedProcedure
      .input(z.object({ postId: z.number().optional(), commentId: z.number().optional() }))
      .mutation(async ({ ctx, input }) => {
        return db.toggleLike(ctx.user.id, input.postId, input.commentId);
      }),
    createComment: protectedProcedure
      .input(z.object({
        postId: z.number(),
        content: z.string(),
        parentId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.createComment({
          postId: input.postId,
          userId: ctx.user.id,
          content: input.content,
          parentId: input.parentId,
        });
        return { success: true };
      }),
    getComments: protectedProcedure
      .input(z.object({ postId: z.number() }))
      .query(async ({ input }) => {
        return db.getPostComments(input.postId);
      }),
    // Moderação Admin
    deletePost: adminProcedure
      .input(z.object({ postId: z.number() }))
      .mutation(async ({ input }) => {
        await db.deletePost(input.postId);
        return { success: true };
      }),
    togglePin: adminProcedure
      .input(z.object({ postId: z.number() }))
      .mutation(async ({ input }) => {
        const post = await db.getPostById(input.postId);
        if (!post) throw new TRPCError({ code: 'NOT_FOUND', message: 'Post não encontrado' });
        await db.updatePostPin(input.postId, !post.isPinned);
        return { success: true, isPinned: !post.isPinned };
      }),
    deleteComment: adminProcedure
      .input(z.object({ commentId: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteComment(input.commentId);
        return { success: true };
      }),
  }),

  // Certificates
  certificates: router({
    myCertificates: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserCertificates(ctx.user.id);
    }),
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getCertificateById(input.id);
      }),
    verify: publicProcedure
      .input(z.object({ code: z.string() }))
      .query(async ({ input }) => {
        return db.getCertificateByVerificationCode(input.code);
      }),
    getCategoryProgress: protectedProcedure.query(async ({ ctx }) => {
      return db.checkCategoryCompletion(ctx.user.id);
    }),
    generate: protectedProcedure
      .input(z.object({ programId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        // Verificar se o usuário completou todos os conteúdos do programa
        const contents = await db.getContentsByProgramId(input.programId);
        const progress = await db.getUserProgressByProgram(ctx.user.id, input.programId);
        
        const completedCount = progress.filter(p => p.completed).length;
        if (completedCount < contents.length) {
          throw new TRPCError({ 
            code: 'BAD_REQUEST', 
            message: `Você precisa completar todos os ${contents.length} conteúdos do programa. Completados: ${completedCount}` 
          });
        }
        
        // Verificar se já existe certificado
        const existingCert = await db.getCertificateByUserAndProgram(ctx.user.id, input.programId);
        if (existingCert) {
          return existingCert;
        }
        
        // Gerar certificado
        const certificateNumber = `DCX-${Date.now().toString(36).toUpperCase()}-${ctx.user.id}`;
        const verificationCode = `${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 8)}`.toUpperCase();
        
        const certificate = await db.createCertificate({
          userId: ctx.user.id,
          programId: input.programId,
          certificateNumber,
          completionDate: new Date(),
          verificationCode,
        });
        
        return certificate;
      }),
    generateCategory: protectedProcedure
      .input(z.object({ category: z.enum(["introducao", "cx", "dados", "ia"]) }))
      .mutation(async ({ ctx, input }) => {
        // Verificar se a categoria está completa
        const { completedCategories } = await db.checkCategoryCompletion(ctx.user.id);
        
        if (!completedCategories.includes(input.category)) {
          throw new TRPCError({ 
            code: 'BAD_REQUEST', 
            message: `Você precisa completar todos os conteúdos da categoria ${input.category} para gerar o certificado.` 
          });
        }
        
        // Verificar se já existe certificado
        const existingCert = await db.getCertificateByUserAndCategory(ctx.user.id, input.category);
        if (existingCert) {
          return existingCert;
        }
        
        // Gerar certificado
        const cert = await db.createCategoryCertificate(ctx.user.id, input.category);
        return cert;
      }),
  }),

  // Quizzes
  quizzes: router({
    // Admin routes
    listAll: adminProcedure.query(async () => {
      return db.getAllQuizzes();
    }),
    create: adminProcedure
      .input(z.object({
        contentId: z.number(),
        title: z.string(),
        description: z.string().optional(),
        passingScore: z.number().default(70),
        timeLimit: z.number().optional(),
        attemptsAllowed: z.number().default(3),
        pointsReward: z.number().default(50),
      }))
      .mutation(async ({ input }) => {
        await db.createQuiz(input);
        return { success: true };
      }),
    addQuestion: adminProcedure
      .input(z.object({
        quizId: z.number(),
        question: z.string(),
        type: z.enum(["multiple_choice", "true_false", "multiple_select"]),
        options: z.array(z.object({
          id: z.string(),
          text: z.string(),
          isCorrect: z.boolean(),
        })),
        explanation: z.string().optional(),
        points: z.number().default(10),
        sortOrder: z.number().default(0),
      }))
      .mutation(async ({ input }) => {
        await db.createQuizQuestion(input);
        return { success: true };
      }),
    getByContent: protectedProcedure
      .input(z.object({ contentId: z.number() }))
      .query(async ({ input }) => {
        const quiz = await db.getQuizByContentId(input.contentId);
        if (!quiz) return null;
        const questions = await db.getQuizQuestions(quiz.id);
        return { ...quiz, questions };
      }),
    submitAttempt: protectedProcedure
      .input(z.object({
        quizId: z.number(),
        answers: z.record(z.string(), z.array(z.string())),
        timeSpent: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const quiz = await db.getQuizById(input.quizId);
        if (!quiz) throw new TRPCError({ code: "NOT_FOUND" });
        
        const questions = await db.getQuizQuestions(input.quizId);
        let correctAnswers = 0;
        
        for (const question of questions) {
          const userAnswers = input.answers[question.id.toString()] || [];
          const correctOptions = (question.options as any[]).filter((o: any) => o.isCorrect).map((o: any) => o.id);
          
          const userAnswersArr = Array.isArray(userAnswers) ? userAnswers : [];
          if (JSON.stringify([...userAnswersArr].sort()) === JSON.stringify([...correctOptions].sort())) {
            correctAnswers++;
          }
        }
        
        const score = Math.round((correctAnswers / questions.length) * 100);
        const passed = score >= quiz.passingScore;
        const pointsEarned = passed ? quiz.pointsReward : 0;
        
        await db.createQuizAttempt({
          userId: ctx.user.id,
          quizId: input.quizId,
          score,
          correctAnswers,
          totalQuestions: questions.length,
          answers: input.answers as Record<string, string[]>,
          passed,
          timeSpent: input.timeSpent,
          pointsEarned,
        });
        
        return { score, passed, correctAnswers, totalQuestions: questions.length, pointsEarned };
      }),
    myAttempts: protectedProcedure
      .input(z.object({ quizId: z.number() }))
      .query(async ({ ctx, input }) => {
        return db.getUserQuizAttempts(ctx.user.id, input.quizId);
      }),
  }),

  // AI Assistant
  ai: router({
    chat: publicProcedure
      .input(z.object({
        message: z.string(),
        systemPrompt: z.string().optional(),
        history: z.array(z.object({
          role: z.enum(["user", "assistant"]),
          content: z.string(),
        })).optional(),
      }))
      .mutation(async ({ input }) => {
        const messages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [];
        
        // Add system prompt
        messages.push({
          role: "system",
          content: input.systemPrompt || `Você é o Assistente Virtual do Protocolo Vértice, a metodologia de Samuel Rosa para transformar CX, dados e IA em resultado real.
          
          Você pode ajudar com:
          - Dúvidas sobre o Protocolo Vértice e seus 5 passos (Clareza, Evidência, Prioridade, Execução, Escala)
          - Informações sobre os programas de mentoria disponíveis
          - Orientações sobre CX, análise de dados e IA aplicada
          - Como fazer o Radar Vértice para descobrir seu nível de maturidade
          
          Seja profissional, didático e sempre conecte as respostas com a metodologia Vértice.
          Quando apropriado, sugira que o usuário faça o Radar Vértice ou agende uma sessão diagnóstica.
          Responda sempre em português brasileiro.`,
        });
        
        // Add history
        if (input.history) {
          for (const msg of input.history) {
            messages.push({
              role: msg.role,
              content: msg.content,
            });
          }
        }
        
        // Add current message
        messages.push({
          role: "user",
          content: input.message,
        });
        
        try {
          const response = await invokeOpenAI({ messages });
          const reply = response.choices?.[0]?.message?.content || "Desculpe, não consegui processar sua mensagem.";
          
          return { reply };
        } catch (error) {
          console.error("[AI Chat] Erro:", error);
          return { reply: "Desculpe, ocorreu um erro ao processar sua mensagem. Por favor, tente novamente." };
        }
      }),
  }),

  // Module Chat - Chat within content modules
  moduleChat: router({
    getHistory: protectedProcedure
      .input(z.object({ contentId: z.number() }))
      .query(async ({ ctx, input }) => {
        return db.getModuleChatHistory(ctx.user.id, input.contentId);
      }),
    getFeedback: protectedProcedure
      .input(z.object({ contentId: z.number() }))
      .query(async ({ ctx, input }) => {
        return db.getChatFeedbackByContent(ctx.user.id, input.contentId);
      }),
    submitFeedback: protectedProcedure
      .input(z.object({
        chatMessageId: z.number(),
        contentId: z.number(),
        rating: z.number().min(1).max(5),
        comment: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const id = await db.submitChatFeedback({
          userId: ctx.user.id,
          chatMessageId: input.chatMessageId,
          contentId: input.contentId,
          rating: input.rating,
          comment: input.comment || null,
        });
        return { success: true, id };
      }),
    sendMessage: protectedProcedure
      .input(z.object({
        contentId: z.number(),
        message: z.string(),
        moduleTitle: z.string().optional(),
        moduleDescription: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Save user message
        await db.createModuleChatMessage({
          userId: ctx.user.id,
          contentId: input.contentId,
          message: input.message,
          role: "user",
        });
        
        // Get chat history for context
        const history = await db.getModuleChatHistory(ctx.user.id, input.contentId);
        
        // Build messages for LLM
        const messages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
          {
            role: "system",
            content: `Você é um tutor especializado no módulo "${input.moduleTitle || 'Conteúdo'}". 
            ${input.moduleDescription ? `Descrição do módulo: ${input.moduleDescription}` : ''}
            Ajude o aluno a entender o conteúdo, responda dúvidas e forneça exemplos práticos.
            Seja didático e encoraje o aprendizado. Responda em português brasileiro.`,
          },
        ];
        
        // Add history (last 10 messages)
        const recentHistory = history.slice(-10);
        for (const msg of recentHistory) {
          messages.push({
            role: msg.role as "user" | "assistant",
            content: msg.message,
          });
        }
        
        // Add current message
        messages.push({ role: "user", content: input.message });
        
        try {
          const response = await invokeOpenAI({ messages });
          const replyContent = response.choices?.[0]?.message?.content;
          const reply = typeof replyContent === 'string' ? replyContent : "Desculpe, não consegui processar sua pergunta.";
          
          // Save assistant response and get its ID for feedback
          const messageId = await db.createModuleChatMessage({
            userId: ctx.user.id,
            contentId: input.contentId,
            message: reply,
            role: "assistant",
          });
          
          return { reply, messageId };
        } catch (error) {
          console.error("[Module Chat] Error:", error);
          return { reply: "Desculpe, ocorreu um erro. Tente novamente." };
        }
      }),
  }),

  // Consulting Projects - Workspace for enterprise clients
  consulting: router({
    listProjects: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role === 'admin') {
        return db.getConsultingProjects();
      }
      return db.getConsultingProjects(ctx.user.id);
    }),
    getProject: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const project = await db.getConsultingProjectById(input.id);
        if (!project) throw new TRPCError({ code: 'NOT_FOUND' });
        if (ctx.user.role !== 'admin' && project.clientUserId !== ctx.user.id) {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        return project;
      }),
    createProject: adminProcedure
      .input(z.object({
        clientUserId: z.number(),
        name: z.string(),
        description: z.string().optional(),
        type: z.enum(["diagnostic", "consulting", "advisory_6m", "advisory_12m"]),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
        contractValue: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createConsultingProject({
          ...input,
          startDate: input.startDate ? new Date(input.startDate) : undefined,
          endDate: input.endDate ? new Date(input.endDate) : undefined,
        });
        return { success: true };
      }),
    updateProject: adminProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          description: z.string().optional(),
          status: z.enum(["planning", "discovery", "execution", "review", "completed", "on_hold"]).optional(),
          currentPhase: z.string().optional(),
          progress: z.number().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        await db.updateConsultingProject(input.id, input.data);
        return { success: true };
      }),
    
    // Tasks
    getTasks: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ input }) => {
        return db.getProjectTasks(input.projectId);
      }),
    createTask: protectedProcedure
      .input(z.object({
        projectId: z.number(),
        title: z.string(),
        description: z.string().optional(),
        assigneeId: z.number().optional(),
        priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
        dueDate: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createProjectTask({
          ...input,
          dueDate: input.dueDate ? new Date(input.dueDate) : undefined,
        });
        return { success: true };
      }),
    updateTask: protectedProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          title: z.string().optional(),
          description: z.string().optional(),
          status: z.enum(["backlog", "todo", "in_progress", "review", "done"]).optional(),
          priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
          assigneeId: z.number().optional(),
          dueDate: z.string().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        await db.updateProjectTask(input.id, {
          ...input.data,
          dueDate: input.data.dueDate ? new Date(input.data.dueDate) : undefined,
          completedAt: input.data.status === 'done' ? new Date() : undefined,
        });
        return { success: true };
      }),
    deleteTask: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteProjectTask(input.id);
        return { success: true };
      }),
    
    // Documents
    getDocuments: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ input }) => {
        return db.getProjectDocuments(input.projectId);
      }),
    uploadDocument: protectedProcedure
      .input(z.object({
        projectId: z.number(),
        name: z.string(),
        description: z.string().optional(),
        folder: z.string().optional(),
        fileUrl: z.string(),
        fileKey: z.string().optional(),
        mimeType: z.string().optional(),
        fileSize: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.createProjectDocument({
          ...input,
          uploadedById: ctx.user.id,
        });
        return { success: true };
      }),
    deleteDocument: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteProjectDocument(input.id);
        return { success: true };
      }),
    
    // Meetings
    getMeetings: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ input }) => {
        return db.getProjectMeetings(input.projectId);
      }),
    createMeeting: protectedProcedure
      .input(z.object({
        projectId: z.number(),
        title: z.string(),
        date: z.string(),
        attendees: z.array(z.string()).optional(),
        agenda: z.string().optional(),
        notes: z.string().optional(),
        decisions: z.array(z.object({
          decision: z.string(),
          owner: z.string(),
          deadline: z.string().optional(),
        })).optional(),
        actionItems: z.array(z.object({
          item: z.string(),
          owner: z.string(),
          deadline: z.string().optional(),
          status: z.string(),
        })).optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createProjectMeeting({
          ...input,
          date: new Date(input.date),
        });
        return { success: true };
      }),
    updateMeeting: protectedProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          notes: z.string().optional(),
          decisions: z.array(z.object({
            decision: z.string(),
            owner: z.string(),
            deadline: z.string().optional(),
          })).optional(),
          actionItems: z.array(z.object({
            item: z.string(),
            owner: z.string(),
            deadline: z.string().optional(),
            status: z.string(),
          })).optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        await db.updateProjectMeeting(input.id, input.data);
        return { success: true };
      }),
    
    // Chat
    getChatMessages: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ input }) => {
        return db.getProjectChatMessages(input.projectId);
      }),
    sendChatMessage: protectedProcedure
      .input(z.object({
        projectId: z.number(),
        message: z.string(),
        attachmentUrl: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.createProjectChatMessage({
          ...input,
          userId: ctx.user.id,
        });
        return { success: true };
      }),
    
    // Milestones
    getMilestones: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ input }) => {
        return db.getProjectMilestones(input.projectId);
      }),
    createMilestone: adminProcedure
      .input(z.object({
        projectId: z.number(),
        title: z.string(),
        description: z.string().optional(),
        dueDate: z.string().optional(),
        sortOrder: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createProjectMilestone({
          ...input,
          dueDate: input.dueDate ? new Date(input.dueDate) : undefined,
        });
        return { success: true };
      }),
    updateMilestone: adminProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          status: z.enum(["pending", "in_progress", "completed", "delayed"]).optional(),
          completedAt: z.string().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        await db.updateProjectMilestone(input.id, {
          ...input.data,
          completedAt: input.data.completedAt ? new Date(input.data.completedAt) : undefined,
        });
        return { success: true };
      }),

    // Stages (Jornada)
    getStages: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ input }) => {
        return db.getProjectStages(input.projectId);
      }),
    createStage: adminProcedure
      .input(z.object({
        projectId: z.number(),
        title: z.string(),
        description: z.string().optional(),
        content: z.string().optional(),
        videoUrl: z.string().optional(),
        status: z.enum(["locked", "available", "in_progress", "completed"]).optional(),
        sortOrder: z.number().optional(),
        dueDate: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createProjectStage({
          ...input,
          dueDate: input.dueDate ? new Date(input.dueDate) : undefined,
          unlockedAt: input.status === 'available' || input.status === 'in_progress' ? new Date() : undefined,
        });
        return { success: true };
      }),
    updateStage: adminProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          title: z.string().optional(),
          description: z.string().optional(),
          content: z.string().optional(),
          videoUrl: z.string().optional(),
          status: z.enum(["locked", "available", "in_progress", "completed"]).optional(),
          sortOrder: z.number().optional(),
          dueDate: z.string().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        const updateData: any = { ...input.data };
        if (input.data.dueDate) updateData.dueDate = new Date(input.data.dueDate);
        if (input.data.status === 'completed') updateData.completedAt = new Date();
        if (input.data.status === 'available' || input.data.status === 'in_progress') updateData.unlockedAt = new Date();
        await db.updateProjectStage(input.id, updateData);
        return { success: true };
      }),
    deleteStage: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteProjectStage(input.id);
        return { success: true };
      }),

    reorderStages: adminProcedure
      .input(z.object({
        stageOrders: z.array(z.object({
          id: z.number(),
          sortOrder: z.number(),
        })),
      }))
      .mutation(async ({ input }) => {
        await db.reorderProjectStages(input.stageOrders);
        return { success: true };
      }),

    // Deliverables
    getDeliverables: protectedProcedure
      .input(z.object({ stageId: z.number() }))
      .query(async ({ input }) => {
        return db.getStageDeliverables(input.stageId);
      }),
    getProjectDeliverables: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ input }) => {
        return db.getProjectDeliverables(input.projectId);
      }),
    createDeliverable: protectedProcedure
      .input(z.object({
        stageId: z.number(),
        projectId: z.number(),
        title: z.string(),
        description: z.string().optional(),
        fileUrl: z.string().optional(),
        fileKey: z.string().optional(),
        mimeType: z.string().optional(),
        fileSize: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.createStageDeliverable({
          ...input,
          uploadedById: ctx.user.id,
          status: input.fileUrl ? 'uploaded' : 'pending',
        });
        return { success: true };
      }),
    updateDeliverable: protectedProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          title: z.string().optional(),
          description: z.string().optional(),
          fileUrl: z.string().optional(),
          fileKey: z.string().optional(),
          mimeType: z.string().optional(),
          fileSize: z.number().optional(),
          status: z.enum(["pending", "uploaded", "in_review", "approved", "revision_needed"]).optional(),
          reviewNotes: z.string().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        await db.updateStageDeliverable(input.id, input.data);
        return { success: true };
      }),
    deleteDeliverable: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteStageDeliverable(input.id);
        return { success: true };
      }),

    journeyDashboard: protectedProcedure
      .query(async ({ ctx }) => {
        return db.getStudentJourneyDashboard(ctx.user.id);
      }),

    // ============ STAGE CONTENTS (Admin CRUD) ============
    getStageContents: protectedProcedure
      .input(z.object({ stageId: z.number() }))
      .query(async ({ input }) => {
        return db.getStageContents(input.stageId);
      }),
    createStageContent: adminProcedure
      .input(z.object({
        stageId: z.number(),
        projectId: z.number(),
        title: z.string(),
        description: z.string().optional(),
        type: z.enum(["document", "video", "link", "text", "audio"]),
        fileUrl: z.string().optional(),
        fileKey: z.string().optional(),
        mimeType: z.string().optional(),
        fileSize: z.number().optional(),
        videoUrl: z.string().optional(),
        linkUrl: z.string().optional(),
        textContent: z.string().optional(),
        audioUrl: z.string().optional(),
        sortOrder: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const id = await db.createStageContent(input);
        return { success: true, id };
      }),
    updateStageContent: adminProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          title: z.string().optional(),
          description: z.string().optional(),
          type: z.enum(["document", "video", "link", "text", "audio"]).optional(),
          fileUrl: z.string().optional(),
          fileKey: z.string().optional(),
          mimeType: z.string().optional(),
          fileSize: z.number().optional(),
          videoUrl: z.string().optional(),
          linkUrl: z.string().optional(),
          textContent: z.string().optional(),
          audioUrl: z.string().optional(),
          sortOrder: z.number().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        await db.updateStageContent(input.id, input.data);
        return { success: true };
      }),
    deleteStageContent: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteStageContent(input.id);
        return { success: true };
      }),

    // Stage Checklist Items (Admin CRUD)
    getChecklistItems: protectedProcedure
      .input(z.object({ stageId: z.number() }))
      .query(async ({ input }) => {
        return db.getStageChecklistItems(input.stageId);
      }),
    createChecklistItem: adminProcedure
      .input(z.object({
        stageId: z.number(),
        projectId: z.number(),
        title: z.string(),
        description: z.string().optional(),
        sortOrder: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const id = await db.createStageChecklistItem(input);
        return { success: true, id };
      }),
    updateChecklistItem: adminProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          title: z.string().optional(),
          description: z.string().optional(),
          sortOrder: z.number().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        await db.updateStageChecklistItem(input.id, input.data);
        return { success: true };
      }),
    deleteChecklistItem: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteStageChecklistItem(input.id);
        return { success: true };
      }),

    // Member: Toggle checklist item
    toggleChecklist: protectedProcedure
      .input(z.object({
        checklistItemId: z.number(),
        completed: z.boolean(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.toggleChecklistItem(input.checklistItemId, ctx.user.id, input.completed);
        return { success: true };
      }),

    // Stage Comments
    getComments: protectedProcedure
      .input(z.object({ stageId: z.number() }))
      .query(async ({ input }) => {
        return db.getStageComments(input.stageId);
      }),
    addComment: protectedProcedure
      .input(z.object({
        stageId: z.number(),
        projectId: z.number(),
        message: z.string().min(1),
        parentId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const id = await db.createStageComment({
          ...input,
          userId: ctx.user.id,
          isAdminReply: ctx.user.role === 'admin',
        });

        // Notify admin when a member posts a comment
        if (ctx.user.role !== 'admin') {
          try {
            const stage = await db.getProjectStageById(input.stageId);
            const project = await db.getConsultingProjectById(input.projectId);
            const stageName = stage?.title || `Etapa #${input.stageId}`;
            const projectName = project?.name || `Projeto #${input.projectId}`;
            const messagePreview = input.message.length > 200 ? input.message.substring(0, 200) + '...' : input.message;
            await notifyOwner({
              title: `Nova d\u00favida na Jornada: ${stageName}`,
              content: `Membro: ${ctx.user.name || ctx.user.email}\nProjeto: ${projectName}\nEtapa: ${stageName}\n\nComent\u00e1rio:\n${messagePreview}`,
            });
          } catch (e) {
            console.error('[Jornada] Failed to notify owner about comment:', e);
          }
        }

        return { success: true, id };
      }),
    deleteComment: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteStageComment(input.id);
        return { success: true };
      }),

    // Member: Stage progress
    updateMemberProgress: protectedProcedure
      .input(z.object({
        stageId: z.number(),
        status: z.enum(["not_started", "in_progress", "completed"]),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.updateStageMemberProgress(input.stageId, ctx.user.id, input.status);

        // Auto-unlock next stage when member completes current stage
        if (input.status === 'completed') {
          try {
            const currentStage = await db.getProjectStageById(input.stageId);
            if (currentStage) {
              const allStages = await db.getProjectStages(currentStage.projectId);
              const sortedStages = allStages.sort((a, b) => a.sortOrder - b.sortOrder);
              const currentIndex = sortedStages.findIndex(s => s.id === input.stageId);
              if (currentIndex >= 0 && currentIndex < sortedStages.length - 1) {
                const nextStage = sortedStages[currentIndex + 1];
                if (nextStage && nextStage.status === 'locked') {
                  await db.updateProjectStage(nextStage.id, {
                    status: 'available',
                    unlockedAt: new Date(),
                  });
                }
              }
            }
          } catch (e) {
            console.error('[Jornada] Failed to auto-unlock next stage:', e);
          }
        }

        return { success: true };
      }),

    // Full stage detail (member view)
    getFullStageDetail: protectedProcedure
      .input(z.object({ stageId: z.number() }))
      .query(async ({ ctx, input }) => {
        return db.getFullStageDetail(input.stageId, ctx.user.id);
      }),

    // Admin: All projects with stages
    allProjectsWithStages: adminProcedure
      .query(async () => {
        return db.getAllProjectsWithStages();
      }),

    // File upload for stage content
    uploadStageFile: protectedProcedure
      .input(z.object({
        fileName: z.string(),
        fileData: z.string(), // base64
        mimeType: z.string(),
      }))
      .mutation(async ({ input }) => {
        const { storagePut } = await import("./storage");
        const buffer = Buffer.from(input.fileData, "base64");
        const randomSuffix = Math.random().toString(36).substring(2, 10);
        const fileKey = `stage-files/${Date.now()}-${randomSuffix}-${input.fileName}`;
        const { url } = await storagePut(fileKey, buffer, input.mimeType);
        return { url, fileKey, fileSize: buffer.length };
      }),
  }),

  // Community Events
  events: router({
    list: protectedProcedure.query(async () => {
      return db.getCommunityEvents();
    }),
    upcoming: publicProcedure.query(async () => {
      return db.getUpcomingEvents();
    }),
    create: adminProcedure
      .input(z.object({
        title: z.string(),
        description: z.string().optional(),
        type: z.enum(["office_hours", "ama", "workshop", "webinar", "networking"]),
        programId: z.number().optional(),
        startTime: z.string(),
        endTime: z.string(),
        location: z.string().optional(),
        maxAttendees: z.number().optional(),
        isRecurring: z.boolean().optional(),
        recurringPattern: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.createCommunityEvent({
          ...input,
          hostId: ctx.user.id,
          startTime: new Date(input.startTime),
          endTime: new Date(input.endTime),
        });
        return { success: true };
      }),
    update: adminProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          title: z.string().optional(),
          description: z.string().optional(),
          status: z.enum(["scheduled", "live", "completed", "cancelled"]).optional(),
          recordingUrl: z.string().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        await db.updateCommunityEvent(input.id, input.data);
        return { success: true };
      }),
    register: protectedProcedure
      .input(z.object({ eventId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.registerForEvent({
          eventId: input.eventId,
          userId: ctx.user.id,
        });
        return { success: true };
      }),
    getRegistrations: adminProcedure
      .input(z.object({ eventId: z.number() }))
      .query(async ({ input }) => {
        return db.getEventRegistrations(input.eventId);
      }),
  }),

  // Direct Messages
  dm: router({
    getConversations: protectedProcedure.query(async ({ ctx }) => {
      const partnerIds = await db.getUserConversations(ctx.user.id);
      // Get user details for each partner
      const partners = [];
      for (const partnerId of partnerIds) {
        const user = await db.getUserById(partnerId);
        if (user) partners.push(user);
      }
      return partners;
    }),
    getMessages: protectedProcedure
      .input(z.object({ otherUserId: z.number() }))
      .query(async ({ ctx, input }) => {
        // Mark messages as read
        await db.markMessagesAsRead(ctx.user.id, input.otherUserId);
        return db.getDirectMessages(ctx.user.id, input.otherUserId);
      }),
    send: protectedProcedure
      .input(z.object({
        receiverId: z.number(),
        message: z.string(),
        attachmentUrl: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.createDirectMessage({
          senderId: ctx.user.id,
          ...input,
        });
        // Create notification for receiver
        await db.createNotification({
          userId: input.receiverId,
          type: "message",
          title: "Nova mensagem",
          content: `${ctx.user.name || 'Alguém'} enviou uma mensagem para você`,
          link: `/mensagens/${ctx.user.id}`,
        });
        return { success: true };
      }),
    unreadCount: protectedProcedure.query(async ({ ctx }) => {
      return db.getUnreadMessageCount(ctx.user.id);
    }),
  }),

  // Notifications
  notifications: router({
    list: protectedProcedure
      .input(z.object({ unreadOnly: z.boolean().optional() }).optional())
      .query(async ({ ctx, input }) => {
        return db.getUserNotifications(ctx.user.id, input?.unreadOnly);
      }),
    markAsRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.markNotificationAsRead(input.id);
        return { success: true };
      }),
    markAllAsRead: protectedProcedure.mutation(async ({ ctx }) => {
      await db.markAllNotificationsAsRead(ctx.user.id);
      return { success: true };
    }),
  }),

  // Audit Logs (Admin only)
  audit: router({
    list: adminProcedure
      .input(z.object({
        limit: z.number().optional(),
        entityType: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return db.getAuditLogs(input?.limit || 100, input?.entityType);
      }),
  }),

  // System Health (Admin only)
  health: router({
    logs: adminProcedure
      .input(z.object({ limit: z.number().optional() }).optional())
      .query(async ({ input }) => {
        return db.getSystemHealthLogs(input?.limit || 100);
      }),
    stats: adminProcedure.query(async () => {
      return db.getSystemHealthStats();
    }),
  }),

  // User persona from radar
  userPersona: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      const persona = await db.getUserPersonaFromRadar(ctx.user.id);
      return { persona };
    }),
  }),

  // Persona Versions - Mini apostilas + áudio por persona
  personaVersions: router({
    // Get version for a specific content + persona (sem audioScriptAdmin - admin only)
    get: protectedProcedure
      .input(z.object({ contentId: z.number(), persona: z.string() }))
      .query(async ({ input }) => {
        const version = await db.getPersonaVersion(input.contentId, input.persona);
        if (!version) return null;
        // Remove admin-only fields from student response
        const { audioScriptAdmin, ...safeVersion } = version;
        return safeVersion;
      }),
    
    // Get all versions for a content
    byContent: protectedProcedure
      .input(z.object({ contentId: z.number() }))
      .query(async ({ input }) => {
        return db.getPersonaVersionsByContent(input.contentId);
      }),
    
    // Get content with persona version merged (sem audioScriptAdmin)
    getContentWithPersona: protectedProcedure
      .input(z.object({ contentId: z.number(), persona: z.string() }))
      .query(async ({ input }) => {
        const result = await db.getContentWithPersona(input.contentId, input.persona);
        if (result?.personaVersion) {
          const { audioScriptAdmin, ...safeVersion } = result.personaVersion;
          return { ...result, personaVersion: safeVersion };
        }
        return result;
      }),
    
    // Admin: Status overview
    statusOverview: adminProcedure.query(async () => {
      return db.getAllPersonaVersionsStatus();
    }),
    
    // Admin: Generate apostila for a single module+persona
    generateApostila: adminProcedure
      .input(z.object({
        contentId: z.number(),
        persona: z.enum(["jovem", "gestor", "executivo", "empresario"]),
      }))
      .mutation(async ({ input }) => {
        const { generateApostila } = await import("./apostilaGenerator");
        const { generateSpeech } = await import("./_core/tts");
        const { storagePut } = await import("./storage");
        
        // Get original content
        const content = await db.getContentById(input.contentId);
        if (!content) throw new TRPCError({ code: 'NOT_FOUND', message: 'Conteúdo não encontrado' });
        
        // Mark as generating
        await db.upsertPersonaVersion({
          contentId: input.contentId,
          persona: input.persona,
          apostilaStatus: "generating",
          audioStatus: "pending",
        });
        
        try {
          // Generate apostila + audio script
          const { markdown, audioScript } = await generateApostila(
            content.title,
            content.description || "",
            content.markdownContent || "",
            input.persona,
            content.pilar || "CX",
          );
          
          // Save apostila
          await db.upsertPersonaVersion({
            contentId: input.contentId,
            persona: input.persona,
            apostilaMarkdown: markdown,
            audioScriptAdmin: audioScript,
            apostilaStatus: "ready",
            generatedAt: new Date(),
          });
          
          // Generate audio from script
          await db.upsertPersonaVersion({
            contentId: input.contentId,
            persona: input.persona,
            audioStatus: "generating",
          });
          
          const ttsResult = await generateSpeech({
            text: audioScript,
            voice: "nova",
            speed: 1.0,
          });
          
          if ("error" in ttsResult) {
            console.error(`[TTS] Error for ${content.moduleCode}-${input.persona}:`, ttsResult);
            await db.upsertPersonaVersion({
              contentId: input.contentId,
              persona: input.persona,
              audioStatus: "error",
            });
            return { success: true, apostilaReady: true, audioReady: false, error: ttsResult.error };
          }
          
          // Upload audio to S3
          const audioKey = `audio/modules/${content.moduleCode}-${input.persona}-${Date.now()}.mp3`;
          const { url: audioUrl } = await storagePut(audioKey, ttsResult.audioBuffer, "audio/mpeg");
          
          // Estimate duration (MP3 ~128kbps = 16KB/s)
          const estimatedDuration = Math.round(ttsResult.audioBuffer.length / 16000);
          
          await db.upsertPersonaVersion({
            contentId: input.contentId,
            persona: input.persona,
            audioUrl,
            audioDurationSeconds: estimatedDuration,
            audioStatus: "ready",
          });
          
          return { success: true, apostilaReady: true, audioReady: true };
        } catch (error) {
          console.error(`[Generate] Error for ${content.moduleCode}-${input.persona}:`, error);
          await db.upsertPersonaVersion({
            contentId: input.contentId,
            persona: input.persona,
            apostilaStatus: "error",
            audioStatus: "error",
          });
          throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'Erro na geração' });
        }
      }),
    
    // Admin: Batch generate for all modules + all personas
    batchGenerate: adminProcedure
      .input(z.object({
        personas: z.array(z.enum(["jovem", "gestor", "executivo", "empresario"])).optional(),
        contentIds: z.array(z.number()).optional(),
        skipExisting: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { generateApostila } = await import("./apostilaGenerator");
        const { generateSpeech } = await import("./_core/tts");
        const { storagePut } = await import("./storage");
        
        const allContents = await db.getAllContents();
        const targetContents = input.contentIds
          ? allContents.filter(c => input.contentIds!.includes(c.id))
          : allContents;
        const personas = input.personas || ["jovem", "gestor", "executivo", "empresario"];
        
        const results: Array<{ contentId: number; moduleCode: string; persona: string; status: string; error?: string }> = [];
        
        for (const content of targetContents) {
          for (const persona of personas) {
            // Check if already exists
            if (input.skipExisting) {
              const existing = await db.getPersonaVersion(content.id, persona);
              if (existing && existing.apostilaStatus === "ready") {
                results.push({ contentId: content.id, moduleCode: content.moduleCode || "", persona, status: "skipped" });
                continue;
              }
            }
            
            try {
              // Mark generating
              await db.upsertPersonaVersion({
                contentId: content.id,
                persona,
                apostilaStatus: "generating",
                audioStatus: "pending",
              });
              
              // Generate apostila
              const { markdown, audioScript } = await generateApostila(
                content.title,
                content.description || "",
                content.markdownContent || "",
                persona as any,
                content.pilar || "CX",
              );
              
              await db.upsertPersonaVersion({
                contentId: content.id,
                persona,
                apostilaMarkdown: markdown,
                audioScriptAdmin: audioScript,
                apostilaStatus: "ready",
                audioStatus: "generating",
                generatedAt: new Date(),
              });
              
              // Generate audio
              const ttsResult = await generateSpeech({
                text: audioScript,
                voice: "nova",
                speed: 1.0,
              });
              
              if ("error" in ttsResult) {
                await db.upsertPersonaVersion({
                  contentId: content.id,
                  persona,
                  audioStatus: "error",
                });
                results.push({ contentId: content.id, moduleCode: content.moduleCode || "", persona, status: "apostila_only", error: ttsResult.error });
              } else {
                const audioKey = `audio/modules/${content.moduleCode}-${persona}-${Date.now()}.mp3`;
                const { url: audioUrl } = await storagePut(audioKey, ttsResult.audioBuffer, "audio/mpeg");
                const estimatedDuration = Math.round(ttsResult.audioBuffer.length / 16000);
                
                await db.upsertPersonaVersion({
                  contentId: content.id,
                  persona,
                  audioUrl,
                  audioDurationSeconds: estimatedDuration,
                  audioStatus: "ready",
                });
                results.push({ contentId: content.id, moduleCode: content.moduleCode || "", persona, status: "complete" });
              }
            } catch (error) {
              console.error(`[Batch] Error ${content.moduleCode}-${persona}:`, error);
              await db.upsertPersonaVersion({
                contentId: content.id,
                persona,
                apostilaStatus: "error",
                audioStatus: "error",
              });
              results.push({
                contentId: content.id,
                moduleCode: content.moduleCode || "",
                persona,
                status: "error",
                error: error instanceof Error ? error.message : "Unknown",
              });
            }
          }
        }
        
        return { total: results.length, results };
      }),
  }),
});

export type AppRouter = typeof appRouter;
