import { describe, expect, it, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: { origin: "http://localhost:3000" },
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

function createMemberContext(id = 2): TrpcContext {
  const user: AuthenticatedUser = {
    id,
    openId: "member-user",
    email: "member@example.com",
    name: "Member User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: { origin: "http://localhost:3000" },
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("Jornada Management", () => {
  const adminCaller = appRouter.createCaller(createAdminContext());
  const memberCaller = appRouter.createCaller(createMemberContext());

  // ============ STAGE CONTENTS ============

  describe("Stage Contents (Admin CRUD)", () => {
    it("admin can create a text content for a stage", async () => {
      const result = await adminCaller.consulting.createStageContent({
        stageId: 1,
        projectId: 1,
        title: "Introducao ao CX",
        description: "Material de introducao",
        type: "text",
        textContent: "# Bem-vindo\n\nEste e o conteudo introdutorio.",
        sortOrder: 0,
      });
      expect(result.success).toBe(true);
      expect(result.id).toBeDefined();
    });

    it("admin can create a video content", async () => {
      const result = await adminCaller.consulting.createStageContent({
        stageId: 1,
        projectId: 1,
        title: "Video Explicativo",
        type: "video",
        videoUrl: "https://youtube.com/watch?v=test123",
        sortOrder: 1,
      });
      expect(result.success).toBe(true);
    });

    it("admin can create a link content", async () => {
      const result = await adminCaller.consulting.createStageContent({
        stageId: 1,
        projectId: 1,
        title: "Artigo Recomendado",
        type: "link",
        linkUrl: "https://example.com/artigo",
        sortOrder: 2,
      });
      expect(result.success).toBe(true);
    });

    it("can list stage contents", async () => {
      const contents = await memberCaller.consulting.getStageContents({ stageId: 1 });
      expect(Array.isArray(contents)).toBe(true);
    });

    it("admin can delete a stage content", async () => {
      const created = await adminCaller.consulting.createStageContent({
        stageId: 1,
        projectId: 1,
        title: "Temp Content",
        type: "text",
        sortOrder: 99,
      });
      const result = await adminCaller.consulting.deleteStageContent({ id: Number(created.id) });
      expect(result.success).toBe(true);
    });

    it("member cannot create stage content", async () => {
      await expect(
        memberCaller.consulting.createStageContent({
          stageId: 1,
          projectId: 1,
          title: "Unauthorized",
          type: "text",
          sortOrder: 0,
        })
      ).rejects.toThrow();
    });
  });

  // ============ CHECKLIST ITEMS ============

  describe("Checklist Items", () => {
    let checklistItemId: number;

    it("admin can create a checklist item", async () => {
      const result = await adminCaller.consulting.createChecklistItem({
        stageId: 1,
        projectId: 1,
        title: "Ler material introdutorio",
        description: "Leia todo o material antes de prosseguir",
        sortOrder: 0,
      });
      expect(result.success).toBe(true);
      expect(result.id).toBeDefined();
      checklistItemId = Number(result.id);
    });

    it("can list checklist items", async () => {
      const items = await memberCaller.consulting.getChecklistItems({ stageId: 1 });
      expect(Array.isArray(items)).toBe(true);
    });

    it("member can toggle a checklist item", async () => {
      if (!checklistItemId) return;
      const result = await memberCaller.consulting.toggleChecklist({
        checklistItemId,
        completed: true,
      });
      expect(result.success).toBe(true);
    });

    it("member can untoggle a checklist item", async () => {
      if (!checklistItemId) return;
      const result = await memberCaller.consulting.toggleChecklist({
        checklistItemId,
        completed: false,
      });
      expect(result.success).toBe(true);
    });

    it("admin can delete a checklist item", async () => {
      const created = await adminCaller.consulting.createChecklistItem({
        stageId: 1,
        projectId: 1,
        title: "Temp Item",
        sortOrder: 99,
      });
      const result = await adminCaller.consulting.deleteChecklistItem({ id: Number(created.id) });
      expect(result.success).toBe(true);
    });

    it("member cannot create checklist items", async () => {
      await expect(
        memberCaller.consulting.createChecklistItem({
          stageId: 1,
          projectId: 1,
          title: "Unauthorized",
          sortOrder: 0,
        })
      ).rejects.toThrow();
    });
  });

  // ============ COMMENTS ============

  describe("Stage Comments", () => {
    it("member can add a comment", async () => {
      const result = await memberCaller.consulting.addComment({
        stageId: 1,
        projectId: 1,
        message: "Tenho uma duvida sobre este conteudo.",
      });
      expect(result.success).toBe(true);
      expect(result.id).toBeDefined();
    });

    it("admin can add a comment (marked as admin reply)", async () => {
      const result = await adminCaller.consulting.addComment({
        stageId: 1,
        projectId: 1,
        message: "Boa pergunta! Vou explicar melhor.",
      });
      expect(result.success).toBe(true);
    });

    it("can list comments for a stage", async () => {
      const comments = await memberCaller.consulting.getComments({ stageId: 1 });
      expect(Array.isArray(comments)).toBe(true);
    });

    it("can delete a comment", async () => {
      const created = await memberCaller.consulting.addComment({
        stageId: 1,
        projectId: 1,
        message: "Temp comment",
      });
      const result = await memberCaller.consulting.deleteComment({ id: Number(created.id) });
      expect(result.success).toBe(true);
    });
  });

  // ============ MEMBER PROGRESS ============

  describe("Member Progress", () => {
    it("member can start a stage", async () => {
      const result = await memberCaller.consulting.updateMemberProgress({
        stageId: 1,
        status: "in_progress",
      });
      expect(result.success).toBe(true);
    });

    it("member can complete a stage", async () => {
      const result = await memberCaller.consulting.updateMemberProgress({
        stageId: 1,
        status: "completed",
      });
      expect(result.success).toBe(true);
    });

    it("member can reopen a stage", async () => {
      const result = await memberCaller.consulting.updateMemberProgress({
        stageId: 1,
        status: "in_progress",
      });
      expect(result.success).toBe(true);
    });
  });

  // ============ FULL STAGE DETAIL ============

  describe("Full Stage Detail", () => {
    it("returns full stage detail with contents, checklist, comments", async () => {
      const detail = await memberCaller.consulting.getFullStageDetail({ stageId: 1 });
      // May be null if stage doesn't exist in test DB, but should not throw
      if (detail) {
        expect(detail).toHaveProperty("contents");
        expect(detail).toHaveProperty("checklist");
        expect(detail).toHaveProperty("comments");
        expect(detail).toHaveProperty("checklistProgress");
        expect(detail).toHaveProperty("memberProgress");
        expect(detail).toHaveProperty("deliverables");
      }
    });
  });

  // ============ REORDER STAGES ============

  describe("Reorder Stages", () => {
    it("admin can reorder stages", async () => {
      const result = await adminCaller.consulting.reorderStages({
        stageOrders: [
          { id: 1, sortOrder: 2 },
          { id: 2, sortOrder: 0 },
          { id: 3, sortOrder: 1 },
        ],
      });
      expect(result.success).toBe(true);
    });

    it("member cannot reorder stages", async () => {
      await expect(
        memberCaller.consulting.reorderStages({
          stageOrders: [{ id: 1, sortOrder: 0 }],
        })
      ).rejects.toThrow();
    });
  });

  // ============ NOTIFICATION ON COMMENT ============

  describe("Notification on Member Comment", () => {
    it("member comment triggers notification (does not throw)", async () => {
      // This test verifies the comment creation succeeds even with notification logic
      const result = await memberCaller.consulting.addComment({
        stageId: 1,
        projectId: 1,
        message: "Duvida que deve gerar notificacao ao admin.",
      });
      expect(result.success).toBe(true);
    });

    it("admin comment does NOT trigger notification", async () => {
      const result = await adminCaller.consulting.addComment({
        stageId: 1,
        projectId: 1,
        message: "Resposta do admin sem notificacao.",
      });
      expect(result.success).toBe(true);
    });
  });

  // ============ AUTO-UNLOCK NEXT STAGE ============

  describe("Auto-unlock Next Stage", () => {
    it("completing a stage does not throw (auto-unlock logic runs)", async () => {
      const result = await memberCaller.consulting.updateMemberProgress({
        stageId: 1,
        status: "completed",
      });
      expect(result.success).toBe(true);
    });
  });

  // ============ ADMIN: ALL PROJECTS WITH STAGES ============

  describe("Admin: All Projects with Stages", () => {
    it("admin can list all projects with stages", async () => {
      const result = await adminCaller.consulting.allProjectsWithStages();
      expect(Array.isArray(result)).toBe(true);
    });

    it("member cannot list all projects with stages", async () => {
      await expect(memberCaller.consulting.allProjectsWithStages()).rejects.toThrow();
    });
  });
});
