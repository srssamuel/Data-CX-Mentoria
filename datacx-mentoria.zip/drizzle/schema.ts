import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, decimal, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  avatarUrl: text("avatarUrl"),
  phone: varchar("phone", { length: 20 }),
  company: varchar("company", { length: 255 }),
  position: varchar("position", { length: 255 }),
  bio: text("bio"),
  // Email/Password auth fields
  passwordHash: varchar("passwordHash", { length: 255 }),
  emailVerified: boolean("emailVerified").default(false),
  resetToken: varchar("resetToken", { length: 255 }),
  resetTokenExpiry: timestamp("resetTokenExpiry"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Mentorship programs/offers
 */
export const mentorshipPrograms = mysqlTable("mentorship_programs", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  shortDescription: text("shortDescription"),
  type: mysqlEnum("type", ["group", "individual", "diagnostic"]).notNull(),
  duration: varchar("duration", { length: 100 }),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 3 }).default("BRL").notNull(),
  features: json("features").$type<string[]>(),
  maxParticipants: int("maxParticipants"),
  isActive: boolean("isActive").default(true).notNull(),
  stripePriceId: varchar("stripePriceId", { length: 255 }),
  stripeProductId: varchar("stripeProductId", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MentorshipProgram = typeof mentorshipPrograms.$inferSelect;
export type InsertMentorshipProgram = typeof mentorshipPrograms.$inferInsert;

/**
 * User enrollments in mentorship programs
 */
export const enrollments = mysqlTable("enrollments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  programId: int("programId").notNull(),
  status: mysqlEnum("status", ["pending", "active", "completed", "cancelled"]).default("pending").notNull(),
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }),
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "paid", "failed", "refunded"]).default("pending").notNull(),
  paidAmount: decimal("paidAmount", { precision: 10, scale: 2 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Enrollment = typeof enrollments.$inferSelect;
export type InsertEnrollment = typeof enrollments.$inferInsert;

/**
 * Content/Materials for mentorship
 */
export const contents = mysqlTable("contents", {
  id: int("id").autoincrement().primaryKey(),
  programId: int("programId"),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", ["playbook", "template", "video", "document", "link", "audio", "module"]).notNull(),
  category: mysqlEnum("category", ["introducao", "cx", "dados", "ia"]).default("introducao").notNull(),
  fileUrl: text("fileUrl"),
  fileKey: varchar("fileKey", { length: 500 }),
  videoUrl: text("videoUrl"),
  audioUrl: text("audioUrl"),
  markdownContent: text("markdownContent"),
  mimeType: varchar("mimeType", { length: 100 }),
  fileSize: int("fileSize"),
  thumbnailUrl: text("thumbnailUrl"),
  sortOrder: int("sortOrder").default(0).notNull(),
  isPublic: boolean("isPublic").default(false).notNull(),
  // V2 fields
  moduleCode: varchar("moduleCode", { length: 20 }),
  nivel: mysqlEnum("nivel", ["fundamentos", "aplicacao", "escala"]),
  pilar: varchar("pilar", { length: 20 }),
  duracao: varchar("duracao", { length: 50 }),
  tags: json("tags").$type<string[]>(),
  prerequisites: json("prerequisites").$type<string[]>(),
  personas: json("personas").$type<string[]>(),
  isPublished: boolean("isPublished").default(true),
  releaseDate: timestamp("releaseDate"),
  contentVersion: varchar("contentVersion", { length: 20 }).default("1.0"),
  versionNotes: text("versionNotes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Content = typeof contents.$inferSelect;
export type InsertContent = typeof contents.$inferInsert;

/**
 * Plan Module Access - Maps which modules are accessible per plan
 */
export const planModuleAccess = mysqlTable("plan_module_access", {
  id: int("id").autoincrement().primaryKey(),
  planSlug: varchar("planSlug", { length: 100 }).notNull(),
  moduleCode: varchar("moduleCode", { length: 20 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PlanModuleAccess = typeof planModuleAccess.$inferSelect;
export type InsertPlanModuleAccess = typeof planModuleAccess.$inferInsert;

/**
 * User Module Overrides - Admin can manually grant/revoke access per user
 */
export const userModuleOverrides = mysqlTable("user_module_overrides", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  moduleCode: varchar("moduleCode", { length: 20 }).notNull(),
  action: mysqlEnum("action", ["grant", "revoke"]).notNull(),
  reason: text("reason"),
  grantedBy: int("grantedBy"), // admin user id
  expiresAt: timestamp("expiresAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserModuleOverride = typeof userModuleOverrides.$inferSelect;
export type InsertUserModuleOverride = typeof userModuleOverrides.$inferInsert;

/**
 * User progress tracking
 */
export const userProgress = mysqlTable("user_progress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  contentId: int("contentId").notNull(),
  completed: boolean("completed").default(false).notNull(),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = typeof userProgress.$inferInsert;

/**
 * Testimonials
 */
export const testimonials = mysqlTable("testimonials", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  company: varchar("company", { length: 255 }),
  position: varchar("position", { length: 255 }),
  content: text("content").notNull(),
  rating: int("rating").default(5).notNull(),
  avatarUrl: text("avatarUrl"),
  isActive: boolean("isActive").default(true).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Testimonial = typeof testimonials.$inferSelect;
export type InsertTestimonial = typeof testimonials.$inferInsert;

/**
 * Contact form submissions
 */
export const contactSubmissions = mysqlTable("contact_submissions", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  company: varchar("company", { length: 255 }),
  message: text("message").notNull(),
  type: mysqlEnum("type", ["contact", "diagnostic"]).default("contact").notNull(),
  status: mysqlEnum("status", ["new", "contacted", "scheduled", "completed"]).default("new").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ContactSubmission = typeof contactSubmissions.$inferSelect;
export type InsertContactSubmission = typeof contactSubmissions.$inferInsert;

/**
 * Analytics/Metrics tracking
 */
export const analyticsEvents = mysqlTable("analytics_events", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  eventType: varchar("eventType", { length: 100 }).notNull(),
  eventData: json("eventData"),
  pageUrl: text("pageUrl"),
  referrer: text("referrer"),
  userAgent: text("userAgent"),
  ipAddress: varchar("ipAddress", { length: 45 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AnalyticsEvent = typeof analyticsEvents.$inferSelect;
export type InsertAnalyticsEvent = typeof analyticsEvents.$inferInsert;


/**
 * Radar Vértice - Leads and Assessment Results
 */
export const radarLeads = mysqlTable("radar_leads", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  persona: mysqlEnum("persona", ["jovem", "gestor", "executivo", "empresario"]).notNull(),
  sector: varchar("sector", { length: 100 }),
  teamSize: mysqlEnum("teamSize", ["1-10", "11-50", "51-200", "200+"]),
  mainGoal: varchar("mainGoal", { length: 255 }),
  
  // Scores by dimension (average 1-5)
  scoreCX: decimal("scoreCX", { precision: 3, scale: 2 }),
  scoreData: decimal("scoreData", { precision: 3, scale: 2 }),
  scoreIA: decimal("scoreIA", { precision: 3, scale: 2 }),
  scoreGovernance: decimal("scoreGovernance", { precision: 3, scale: 2 }),
  scoreTotal: decimal("scoreTotal", { precision: 3, scale: 2 }),
  
  // Full answers stored as JSON
  answers: json("answers").$type<Record<string, number | string>>(),
  
  // Recommendation
  recommendedLevel: mysqlEnum("recommendedLevel", ["fundamentos", "aplicacao", "escala", "estrategia"]),
  recommendedProduct: varchar("recommendedProduct", { length: 255 }),
  
  // Intent and urgency
  mainCost: varchar("mainCost", { length: 100 }),
  urgency: mysqlEnum("urgency", ["0-30", "60", "90", "sem-urgencia"]),
  preferredFormat: mysqlEnum("preferredFormat", ["grupo", "individual"]),
  budgetRange: varchar("budgetRange", { length: 100 }),
  
  // Open-ended challenges / context
  challenges: text("challenges"),
  
  // Auto-segmentation based on challenges
  challengeSegment: mysqlEnum("challengeSegment", ["dados", "cx", "ia", "governanca", "cultura"]),
  challengeSegments: json("challengeSegments").$type<string[]>(),
  
  // LGPD consent
  consentMarketing: boolean("consentMarketing").default(false).notNull(),
  consentPrivacy: boolean("consentPrivacy").default(true).notNull(),
  consentWhatsapp: boolean("consentWhatsapp").default(false).notNull(),
  
  // AI Analysis
  aiAnalysis: text("aiAnalysis"),
  
  // Status tracking
  status: mysqlEnum("status", ["new", "contacted", "nurturing", "converted", "lost"]).default("new").notNull(),
  reportSentAt: timestamp("reportSentAt"),
  emailSentAt: timestamp("emailSentAt"),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type RadarLead = typeof radarLeads.$inferSelect;
export type InsertRadarLead = typeof radarLeads.$inferInsert;


/**
 * Discount Coupons
 */
export const coupons = mysqlTable("coupons", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 50 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  
  // Discount type and value
  discountType: mysqlEnum("discountType", ["percentage", "fixed"]).notNull(),
  discountValue: decimal("discountValue", { precision: 10, scale: 2 }).notNull(),
  
  // Restrictions
  minPurchaseAmount: decimal("minPurchaseAmount", { precision: 10, scale: 2 }),
  maxDiscountAmount: decimal("maxDiscountAmount", { precision: 10, scale: 2 }),
  applicableProducts: json("applicableProducts").$type<string[]>(), // product slugs, null = all
  
  // Usage limits
  usageLimit: int("usageLimit"), // null = unlimited
  usageCount: int("usageCount").default(0).notNull(),
  usageLimitPerUser: int("usageLimitPerUser").default(1).notNull(),
  
  // Validity
  validFrom: timestamp("validFrom"),
  validUntil: timestamp("validUntil"),
  
  // Status
  isActive: boolean("isActive").default(true).notNull(),
  
  // Stripe integration
  stripeCouponId: varchar("stripeCouponId", { length: 255 }),
  stripePromotionCodeId: varchar("stripePromotionCodeId", { length: 255 }),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Coupon = typeof coupons.$inferSelect;
export type InsertCoupon = typeof coupons.$inferInsert;

/**
 * Coupon usage tracking
 */
export const couponUsages = mysqlTable("coupon_usages", {
  id: int("id").autoincrement().primaryKey(),
  couponId: int("couponId").notNull(),
  userId: int("userId"),
  enrollmentId: int("enrollmentId"),
  discountApplied: decimal("discountApplied", { precision: 10, scale: 2 }).notNull(),
  originalAmount: decimal("originalAmount", { precision: 10, scale: 2 }).notNull(),
  finalAmount: decimal("finalAmount", { precision: 10, scale: 2 }).notNull(),
  stripeSessionId: varchar("stripeSessionId", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CouponUsage = typeof couponUsages.$inferSelect;
export type InsertCouponUsage = typeof couponUsages.$inferInsert;


/**
 * Gamification - User Points
 */
export const userPoints = mysqlTable("user_points", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  points: int("points").default(0).notNull(),
  level: int("level").default(1).notNull(),
  levelName: varchar("levelName", { length: 100 }).default("Iniciante").notNull(),
  totalPointsEarned: int("totalPointsEarned").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserPoints = typeof userPoints.$inferSelect;
export type InsertUserPoints = typeof userPoints.$inferInsert;

/**
 * Gamification - Point Transactions
 */
export const pointTransactions = mysqlTable("point_transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  points: int("points").notNull(),
  type: mysqlEnum("type", ["earned", "spent", "bonus", "penalty"]).notNull(),
  reason: varchar("reason", { length: 255 }).notNull(),
  referenceType: varchar("referenceType", { length: 50 }), // content, quiz, badge, etc
  referenceId: int("referenceId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PointTransaction = typeof pointTransactions.$inferSelect;
export type InsertPointTransaction = typeof pointTransactions.$inferInsert;

/**
 * Gamification - Badges
 */
export const badges = mysqlTable("badges", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  iconUrl: text("iconUrl"),
  category: mysqlEnum("category", ["progress", "engagement", "achievement", "special"]).notNull(),
  requirement: json("requirement").$type<{ type: string; value: number; target?: string }>(),
  pointsReward: int("pointsReward").default(0).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Badge = typeof badges.$inferSelect;
export type InsertBadge = typeof badges.$inferInsert;

/**
 * Gamification - User Badges
 */
export const userBadges = mysqlTable("user_badges", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  badgeId: int("badgeId").notNull(),
  earnedAt: timestamp("earnedAt").defaultNow().notNull(),
});

export type UserBadge = typeof userBadges.$inferSelect;
export type InsertUserBadge = typeof userBadges.$inferInsert;

/**
 * Community - Posts
 */
export const communityPosts = mysqlTable("community_posts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  programId: int("programId"), // null = general community
  space: varchar("space", { length: 50 }).default("geral"), // geral, jovens, gestores, executivos, empresas
  title: varchar("title", { length: 255 }),
  content: text("content").notNull(),
  type: mysqlEnum("type", ["discussion", "question", "announcement", "resource"]).default("discussion").notNull(),
  isPinned: boolean("isPinned").default(false).notNull(),
  likesCount: int("likesCount").default(0).notNull(),
  commentsCount: int("commentsCount").default(0).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CommunityPost = typeof communityPosts.$inferSelect;
export type InsertCommunityPost = typeof communityPosts.$inferInsert;

/**
 * Community - Comments
 */
export const communityComments = mysqlTable("community_comments", {
  id: int("id").autoincrement().primaryKey(),
  postId: int("postId").notNull(),
  userId: int("userId").notNull(),
  parentId: int("parentId"), // for nested replies
  content: text("content").notNull(),
  likesCount: int("likesCount").default(0).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CommunityComment = typeof communityComments.$inferSelect;
export type InsertCommunityComment = typeof communityComments.$inferInsert;

/**
 * Community - Likes
 */
export const communityLikes = mysqlTable("community_likes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  postId: int("postId"),
  commentId: int("commentId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CommunityLike = typeof communityLikes.$inferSelect;
export type InsertCommunityLike = typeof communityLikes.$inferInsert;

/**
 * Certificates - Issued when user completes a category or program
 */
export const certificates = mysqlTable("certificates", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  programId: int("programId"), // null if category certificate
  category: mysqlEnum("category", ["introducao", "cx", "dados", "ia"]), // null if program certificate
  type: mysqlEnum("type", ["category", "program", "general"]).default("category").notNull(),
  certificateNumber: varchar("certificateNumber", { length: 50 }).notNull().unique(),
  completionDate: timestamp("completionDate").notNull(),
  expirationDate: timestamp("expirationDate"),
  pdfUrl: text("pdfUrl"),
  verificationCode: varchar("verificationCode", { length: 100 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Certificate = typeof certificates.$inferSelect;
export type InsertCertificate = typeof certificates.$inferInsert;

/**
 * Quizzes
 */
export const quizzes = mysqlTable("quizzes", {
  id: int("id").autoincrement().primaryKey(),
  contentId: int("contentId").notNull(), // linked to a content/module
  moduleCode: varchar("moduleCode", { length: 20 }),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  passingScore: int("passingScore").default(70).notNull(), // percentage
  timeLimit: int("timeLimit"), // minutes, null = no limit
  attemptsAllowed: int("attemptsAllowed").default(3).notNull(),
  questionsPerAttempt: int("questionsPerAttempt").default(10),
  pointsReward: int("pointsReward").default(50).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Quiz = typeof quizzes.$inferSelect;
export type InsertQuiz = typeof quizzes.$inferInsert;

/**
 * Quiz Questions
 */
export const quizQuestions = mysqlTable("quiz_questions", {
  id: int("id").autoincrement().primaryKey(),
  quizId: int("quizId").notNull(),
  question: text("question").notNull(),
  type: mysqlEnum("type", ["multiple_choice", "true_false", "multiple_select"]).notNull(),
  options: json("options").$type<{ id: string; text: string; isCorrect: boolean }[]>().notNull(),
  explanation: text("explanation"),
  points: int("points").default(10).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type QuizQuestion = typeof quizQuestions.$inferSelect;
export type InsertQuizQuestion = typeof quizQuestions.$inferInsert;

/**
 * Quiz Attempts
 */
export const quizAttempts = mysqlTable("quiz_attempts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  quizId: int("quizId").notNull(),
  score: int("score").notNull(), // percentage
  correctAnswers: int("correctAnswers").notNull(),
  totalQuestions: int("totalQuestions").notNull(),
  answers: json("answers").$type<Record<string, string[]>>(),
  passed: boolean("passed").notNull(),
  timeSpent: int("timeSpent"), // seconds
  pointsEarned: int("pointsEarned").default(0).notNull(),
  completedAt: timestamp("completedAt").defaultNow().notNull(),
});

export type QuizAttempt = typeof quizAttempts.$inferSelect;
export type InsertQuizAttempt = typeof quizAttempts.$inferInsert;


/**
 * Module Chat - Chat messages within content modules
 */
export const moduleChats = mysqlTable("module_chats", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  contentId: int("contentId").notNull(),
  message: text("message").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  metadata: json("metadata").$type<{ sources?: string[]; context?: string }>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ModuleChat = typeof moduleChats.$inferSelect;
export type InsertModuleChat = typeof moduleChats.$inferInsert;

/**
 * Module Materials - Versioned materials for modules
 */
export const moduleMaterials = mysqlTable("module_materials", {
  id: int("id").autoincrement().primaryKey(),
  contentId: int("contentId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  fileUrl: text("fileUrl"),
  fileKey: varchar("fileKey", { length: 500 }),
  mimeType: varchar("mimeType", { length: 100 }),
  version: int("version").default(1).notNull(),
  isLatest: boolean("isLatest").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ModuleMaterial = typeof moduleMaterials.$inferSelect;
export type InsertModuleMaterial = typeof moduleMaterials.$inferInsert;

/**
 * Consulting Projects - Workspace for enterprise clients
 */
export const consultingProjects = mysqlTable("consulting_projects", {
  id: int("id").autoincrement().primaryKey(),
  clientUserId: int("clientUserId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", ["diagnostic", "consulting", "advisory_6m", "advisory_12m"]).notNull(),
  status: mysqlEnum("status", ["planning", "discovery", "execution", "review", "completed", "on_hold"]).default("planning").notNull(),
  currentPhase: varchar("currentPhase", { length: 100 }),
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  contractValue: decimal("contractValue", { precision: 10, scale: 2 }),
  progress: int("progress").default(0).notNull(), // percentage
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ConsultingProject = typeof consultingProjects.$inferSelect;
export type InsertConsultingProject = typeof consultingProjects.$inferInsert;

/**
 * Project Tasks - Backlog items for consulting projects
 */
export const projectTasks = mysqlTable("project_tasks", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  assigneeId: int("assigneeId"),
  status: mysqlEnum("status", ["backlog", "todo", "in_progress", "review", "done"]).default("backlog").notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium").notNull(),
  dueDate: timestamp("dueDate"),
  completedAt: timestamp("completedAt"),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProjectTask = typeof projectTasks.$inferSelect;
export type InsertProjectTask = typeof projectTasks.$inferInsert;

/**
 * Project Documents - Repository for consulting projects
 */
export const projectDocuments = mysqlTable("project_documents", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  uploadedById: int("uploadedById").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  folder: varchar("folder", { length: 255 }).default("general"),
  fileUrl: text("fileUrl").notNull(),
  fileKey: varchar("fileKey", { length: 500 }),
  mimeType: varchar("mimeType", { length: 100 }),
  fileSize: int("fileSize"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ProjectDocument = typeof projectDocuments.$inferSelect;
export type InsertProjectDocument = typeof projectDocuments.$inferInsert;

/**
 * Project Meetings - Meeting notes/decisions for consulting projects
 */
export const projectMeetings = mysqlTable("project_meetings", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  date: timestamp("date").notNull(),
  attendees: json("attendees").$type<string[]>(),
  agenda: text("agenda"),
  notes: text("notes"),
  decisions: json("decisions").$type<{ decision: string; owner: string; deadline?: string }[]>(),
  actionItems: json("actionItems").$type<{ item: string; owner: string; deadline?: string; status: string }[]>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProjectMeeting = typeof projectMeetings.$inferSelect;
export type InsertProjectMeeting = typeof projectMeetings.$inferInsert;

/**
 * Project Milestones - Timeline markers for consulting projects
 */
export const projectMilestones = mysqlTable("project_milestones", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  dueDate: timestamp("dueDate"),
  completedAt: timestamp("completedAt"),
  status: mysqlEnum("status", ["pending", "in_progress", "completed", "delayed"]).default("pending").notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ProjectMilestone = typeof projectMilestones.$inferSelect;
export type InsertProjectMilestone = typeof projectMilestones.$inferInsert;

/**
 * Project Stages - Etapas da jornada de consultoria/mentoria com conteúdo
 */
export const projectStages = mysqlTable("project_stages", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  content: text("content"), // Rich content (markdown) with instructions, links, videos
  videoUrl: text("videoUrl"),
  status: mysqlEnum("status", ["locked", "available", "in_progress", "completed"]).default("locked").notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  dueDate: timestamp("dueDate"),
  completedAt: timestamp("completedAt"),
  unlockedAt: timestamp("unlockedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProjectStage = typeof projectStages.$inferSelect;
export type InsertProjectStage = typeof projectStages.$inferInsert;

/**
 * Stage Deliverables - Entregas associadas a cada etapa
 */
export const stageDeliverables = mysqlTable("stage_deliverables", {
  id: int("id").autoincrement().primaryKey(),
  stageId: int("stageId").notNull(),
  projectId: int("projectId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  fileUrl: text("fileUrl"),
  fileKey: varchar("fileKey", { length: 500 }),
  mimeType: varchar("mimeType", { length: 100 }),
  fileSize: int("fileSize"),
  status: mysqlEnum("status", ["pending", "uploaded", "in_review", "approved", "revision_needed"]).default("pending").notNull(),
  uploadedById: int("uploadedById"),
  reviewNotes: text("reviewNotes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type StageDeliverable = typeof stageDeliverables.$inferSelect;
export type InsertStageDeliverable = typeof stageDeliverables.$inferInsert;

/**
 * Project Chat - Messages for consulting projects
 */
export const projectChats = mysqlTable("project_chats", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  userId: int("userId").notNull(),
  message: text("message").notNull(),
  attachmentUrl: text("attachmentUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ProjectChat = typeof projectChats.$inferSelect;
export type InsertProjectChat = typeof projectChats.$inferInsert;

/**
 * Community Events - Office hours, AMA, workshops
 */
export const communityEvents = mysqlTable("community_events", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", ["office_hours", "ama", "workshop", "webinar", "networking"]).notNull(),
  hostId: int("hostId").notNull(),
  programId: int("programId"), // null = open to all
  startTime: timestamp("startTime").notNull(),
  endTime: timestamp("endTime").notNull(),
  timezone: varchar("timezone", { length: 50 }).default("America/Sao_Paulo"),
  location: varchar("location", { length: 255 }), // URL for online events
  maxAttendees: int("maxAttendees"),
  isRecurring: boolean("isRecurring").default(false).notNull(),
  recurringPattern: varchar("recurringPattern", { length: 100 }), // weekly, monthly, etc
  status: mysqlEnum("status", ["scheduled", "live", "completed", "cancelled"]).default("scheduled").notNull(),
  recordingUrl: text("recordingUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CommunityEvent = typeof communityEvents.$inferSelect;
export type InsertCommunityEvent = typeof communityEvents.$inferInsert;

/**
 * Event Registrations
 */
export const eventRegistrations = mysqlTable("event_registrations", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  userId: int("userId").notNull(),
  status: mysqlEnum("status", ["registered", "attended", "no_show", "cancelled"]).default("registered").notNull(),
  registeredAt: timestamp("registeredAt").defaultNow().notNull(),
  attendedAt: timestamp("attendedAt"),
});

export type EventRegistration = typeof eventRegistrations.$inferSelect;
export type InsertEventRegistration = typeof eventRegistrations.$inferInsert;

/**
 * Direct Messages
 */
export const directMessages = mysqlTable("direct_messages", {
  id: int("id").autoincrement().primaryKey(),
  senderId: int("senderId").notNull(),
  receiverId: int("receiverId").notNull(),
  message: text("message").notNull(),
  attachmentUrl: text("attachmentUrl"),
  isRead: boolean("isRead").default(false).notNull(),
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DirectMessage = typeof directMessages.$inferSelect;
export type InsertDirectMessage = typeof directMessages.$inferInsert;

/**
 * Notifications
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["message", "event", "content", "badge", "system", "reminder"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content"),
  link: varchar("link", { length: 500 }),
  isRead: boolean("isRead").default(false).notNull(),
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Audit Logs
 */
export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  action: varchar("action", { length: 100 }).notNull(),
  entityType: varchar("entityType", { length: 100 }).notNull(),
  entityId: int("entityId"),
  oldValue: json("oldValue"),
  newValue: json("newValue"),
  ipAddress: varchar("ipAddress", { length: 45 }),
  userAgent: text("userAgent"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

/**
 * System Health Logs
 */
export const systemHealthLogs = mysqlTable("system_health_logs", {
  id: int("id").autoincrement().primaryKey(),
  route: varchar("route", { length: 255 }).notNull(),
  statusCode: int("statusCode").notNull(),
  responseTime: int("responseTime"), // milliseconds
  errorMessage: text("errorMessage"),
  errorStack: text("errorStack"),
  userAgent: text("userAgent"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SystemHealthLog = typeof systemHealthLogs.$inferSelect;
export type InsertSystemHealthLog = typeof systemHealthLogs.$inferInsert;

/**
 * Radar Nurture Sequence - Automated follow-up messages
 */
export const radarNurtureMessages = mysqlTable("radar_nurture_messages", {
  id: int("id").autoincrement().primaryKey(),
  leadId: int("leadId").notNull(),
  sequenceStep: int("sequenceStep").notNull(), // 1-5
  messageType: mysqlEnum("messageType", ["diagnosis", "content", "invite", "social_proof", "offer"]).notNull(),
  subject: varchar("subject", { length: 255 }),
  content: text("content"),
  scheduledAt: timestamp("scheduledAt").notNull(),
  sentAt: timestamp("sentAt"),
  openedAt: timestamp("openedAt"),
  clickedAt: timestamp("clickedAt"),
  status: mysqlEnum("status", ["scheduled", "sent", "opened", "clicked", "failed"]).default("scheduled").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type RadarNurtureMessage = typeof radarNurtureMessages.$inferSelect;
export type InsertRadarNurtureMessage = typeof radarNurtureMessages.$inferInsert;


/**
 * Content Persona Versions - Mini apostila + áudio por persona para cada módulo
 */
export const contentPersonaVersions = mysqlTable("content_persona_versions", {
  id: int("id").autoincrement().primaryKey(),
  contentId: int("contentId").notNull(),
  persona: mysqlEnum("persona", ["jovem", "gestor", "executivo", "empresario"]).notNull(),
  
  // Mini apostila completa (markdown)
  apostilaMarkdown: text("apostilaMarkdown"),
  
  // Áudio narrado
  audioUrl: text("audioUrl"),
  audioDurationSeconds: int("audioDurationSeconds"),
  
  // Roteiro do áudio (visível apenas no admin)
  audioScriptAdmin: text("audioScriptAdmin"),
  
  // Status de geração
  apostilaStatus: mysqlEnum("apostilaStatus", ["pending", "generating", "ready", "error"]).default("pending").notNull(),
  audioStatus: mysqlEnum("audioStatus", ["pending", "generating", "ready", "error"]).default("pending").notNull(),
  
  // Metadata
  generatedAt: timestamp("generatedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ContentPersonaVersion = typeof contentPersonaVersions.$inferSelect;
export type InsertContentPersonaVersion = typeof contentPersonaVersions.$inferInsert;

/**
 * Chat Feedback - Star ratings and comments for Tutor IA responses
 */
export const chatFeedback = mysqlTable("chat_feedback", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  chatMessageId: int("chatMessageId").notNull(), // references moduleChats.id
  contentId: int("contentId").notNull(),
  rating: int("rating").notNull(), // 1-5 stars
  comment: text("comment"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ChatFeedback = typeof chatFeedback.$inferSelect;
export type InsertChatFeedback = typeof chatFeedback.$inferInsert;


/**
 * Scheduled Emails - Onboarding drip campaign
 */
export const scheduledEmails = mysqlTable("scheduled_emails", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  enrollmentId: int("enrollmentId"),
  emailType: mysqlEnum("emailType", ["onboarding_day1", "onboarding_day3", "onboarding_day7", "reengagement", "custom"]).notNull(),
  scheduledFor: timestamp("scheduledFor").notNull(),
  sentAt: timestamp("sentAt"),
  status: mysqlEnum("status", ["pending", "sent", "failed", "cancelled"]).default("pending").notNull(),
  subject: varchar("subject", { length: 500 }),
  metadata: json("metadata").$type<Record<string, string>>(),
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ScheduledEmail = typeof scheduledEmails.$inferSelect;
export type InsertScheduledEmail = typeof scheduledEmails.$inferInsert;


// ============ STAGE CONTENTS (documents, videos, links, text, audio per stage) ============

export const stageContents = mysqlTable("stage_contents", {
  id: int("id").autoincrement().primaryKey(),
  stageId: int("stageId").notNull(),
  projectId: int("projectId").notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", ["document", "video", "link", "text", "audio"]).notNull(),
  // Document fields
  fileUrl: text("fileUrl"),
  fileKey: varchar("fileKey", { length: 500 }),
  mimeType: varchar("mimeType", { length: 100 }),
  fileSize: int("fileSize"),
  // Video fields
  videoUrl: text("videoUrl"),
  // Link fields
  linkUrl: text("linkUrl"),
  // Text content
  textContent: text("textContent"),
  // Audio fields
  audioUrl: text("audioUrl"),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type StageContent = typeof stageContents.$inferSelect;
export type InsertStageContent = typeof stageContents.$inferInsert;

// ============ STAGE CHECKLIST ITEMS ============

export const stageChecklistItems = mysqlTable("stage_checklist_items", {
  id: int("id").autoincrement().primaryKey(),
  stageId: int("stageId").notNull(),
  projectId: int("projectId").notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description"),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StageChecklistItem = typeof stageChecklistItems.$inferSelect;
export type InsertStageChecklistItem = typeof stageChecklistItems.$inferInsert;

// ============ STAGE CHECKLIST PROGRESS (per user) ============

export const stageChecklistProgress = mysqlTable("stage_checklist_progress", {
  id: int("id").autoincrement().primaryKey(),
  checklistItemId: int("checklistItemId").notNull(),
  userId: int("userId").notNull(),
  completed: boolean("completed").default(false).notNull(),
  completedAt: timestamp("completedAt"),
});

export type StageChecklistProgressRow = typeof stageChecklistProgress.$inferSelect;
export type InsertStageChecklistProgress = typeof stageChecklistProgress.$inferInsert;

// ============ STAGE COMMENTS ============

export const stageComments = mysqlTable("stage_comments", {
  id: int("id").autoincrement().primaryKey(),
  stageId: int("stageId").notNull(),
  projectId: int("projectId").notNull(),
  userId: int("userId").notNull(),
  message: text("message").notNull(),
  parentId: int("parentId"),
  isAdminReply: boolean("isAdminReply").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type StageComment = typeof stageComments.$inferSelect;
export type InsertStageComment = typeof stageComments.$inferInsert;

// ============ STAGE MEMBER PROGRESS ============

export const stageMemberProgress = mysqlTable("stage_member_progress", {
  id: int("id").autoincrement().primaryKey(),
  stageId: int("stageId").notNull(),
  userId: int("userId").notNull(),
  status: mysqlEnum("status", ["not_started", "in_progress", "completed"]).default("not_started").notNull(),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type StageMemberProgress = typeof stageMemberProgress.$inferSelect;
export type InsertStageMemberProgress = typeof stageMemberProgress.$inferInsert;
