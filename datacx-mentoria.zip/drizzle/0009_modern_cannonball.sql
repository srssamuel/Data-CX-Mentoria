ALTER TABLE `contents` ADD `contentVersion` varchar(20) DEFAULT '1.0';--> statement-breakpoint
ALTER TABLE `contents` ADD `versionNotes` text;