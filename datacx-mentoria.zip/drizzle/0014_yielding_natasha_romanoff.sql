CREATE TABLE `project_stages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`content` text,
	`videoUrl` text,
	`status` enum('locked','available','in_progress','completed') NOT NULL DEFAULT 'locked',
	`sortOrder` int NOT NULL DEFAULT 0,
	`dueDate` timestamp,
	`completedAt` timestamp,
	`unlockedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `project_stages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stage_deliverables` (
	`id` int AUTO_INCREMENT NOT NULL,
	`stageId` int NOT NULL,
	`projectId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`fileUrl` text,
	`fileKey` varchar(500),
	`mimeType` varchar(100),
	`fileSize` int,
	`status` enum('pending','uploaded','in_review','approved','revision_needed') NOT NULL DEFAULT 'pending',
	`uploadedById` int,
	`reviewNotes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `stage_deliverables_id` PRIMARY KEY(`id`)
);
