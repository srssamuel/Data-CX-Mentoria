CREATE TABLE `content_persona_versions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`contentId` int NOT NULL,
	`persona` enum('jovem','gestor','executivo','empresario') NOT NULL,
	`apostilaMarkdown` text,
	`audioUrl` text,
	`audioDurationSeconds` int,
	`audioScriptAdmin` text,
	`apostilaStatus` enum('pending','generating','ready','error') NOT NULL DEFAULT 'pending',
	`audioStatus` enum('pending','generating','ready','error') NOT NULL DEFAULT 'pending',
	`generatedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `content_persona_versions_id` PRIMARY KEY(`id`)
);
