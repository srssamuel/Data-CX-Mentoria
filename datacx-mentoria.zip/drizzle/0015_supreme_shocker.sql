CREATE TABLE `stage_checklist_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`stageId` int NOT NULL,
	`projectId` int NOT NULL,
	`title` varchar(500) NOT NULL,
	`description` text,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stage_checklist_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stage_checklist_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`checklistItemId` int NOT NULL,
	`userId` int NOT NULL,
	`completed` boolean NOT NULL DEFAULT false,
	`completedAt` timestamp,
	CONSTRAINT `stage_checklist_progress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stage_comments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`stageId` int NOT NULL,
	`projectId` int NOT NULL,
	`userId` int NOT NULL,
	`message` text NOT NULL,
	`parentId` int,
	`isAdminReply` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `stage_comments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stage_contents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`stageId` int NOT NULL,
	`projectId` int NOT NULL,
	`title` varchar(500) NOT NULL,
	`description` text,
	`type` enum('document','video','link','text','audio') NOT NULL,
	`fileUrl` text,
	`fileKey` varchar(500),
	`mimeType` varchar(100),
	`fileSize` int,
	`videoUrl` text,
	`linkUrl` text,
	`textContent` text,
	`audioUrl` text,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `stage_contents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stage_member_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`stageId` int NOT NULL,
	`userId` int NOT NULL,
	`status` enum('not_started','in_progress','completed') NOT NULL DEFAULT 'not_started',
	`startedAt` timestamp,
	`completedAt` timestamp,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `stage_member_progress_id` PRIMARY KEY(`id`)
);
