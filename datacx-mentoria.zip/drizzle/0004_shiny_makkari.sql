CREATE TABLE `user_module_overrides` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`moduleCode` varchar(20) NOT NULL,
	`action` enum('grant','revoke') NOT NULL,
	`reason` text,
	`grantedBy` int,
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_module_overrides_id` PRIMARY KEY(`id`)
);
