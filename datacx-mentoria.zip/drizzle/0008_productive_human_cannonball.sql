ALTER TABLE `radar_leads` ADD `aiAnalysis` text;--> statement-breakpoint
ALTER TABLE `radar_leads` ADD `emailSentAt` timestamp;