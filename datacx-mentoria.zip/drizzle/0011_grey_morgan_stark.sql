ALTER TABLE `radar_leads` ADD `challengeSegment` enum('dados','cx','ia','governanca','cultura');--> statement-breakpoint
ALTER TABLE `radar_leads` ADD `challengeSegments` json;