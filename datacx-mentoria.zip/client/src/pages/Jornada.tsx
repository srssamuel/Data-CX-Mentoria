import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import SEO, { PAGE_SEO } from "@/components/SEO";
import { ArrowRight, Send, CheckCircle2, Sparkles, Target, TrendingUp, Brain, Users, Share2, MessageCircle, Linkedin, Mail, Copy, Check } from "lucide-react";
import { toast } from "sonner";

// Foto do Samuel Rosa
const MENTOR_AVATAR = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/ZHhNGsdLrRALYMZL.png";

interface Message {
  id: number;
  type: "assistant" | "user" | "options" | "final";
  content: string;
  options?: { label: string; value: string; icon?: React.ReactNode }[];
  inputType?: "text" | "phone" | "email" | "select";
  placeholder?: string;
}

const JOURNEY_STEPS: Message[] = [
  {
    id: 1,
    type: "assistant",
    content: "Olá! Sou o Samuel Rosa, especialista em CX, Dados e IA. Vou criar um **Diagnóstico Personalizado** para você descobrir como transformar sua operação com inteligência de dados.",
  },
  {
    id: 2,
    type: "assistant",
    content: "Para começar, qual é o seu nome?",
    inputType: "text",
    placeholder: "Digite seu nome completo...",
  },
  {
    id: 3,
    type: "assistant",
    content: "Prazer em conhecê-lo, {name}! Qual é o seu WhatsApp? Assim posso enviar seu diagnóstico personalizado.",
    inputType: "phone",
    placeholder: "(11) 99999-9999",
  },
  {
    id: 4,
    type: "assistant",
    content: "E qual é o seu melhor e-mail?",
    inputType: "email",
    placeholder: "seu@email.com",
  },
  {
    id: 5,
    type: "assistant",
    content: "Qual é o seu cargo ou função atual?",
    inputType: "text",
    placeholder: "Ex: Gerente de CX, Diretor de Dados...",
  },
  {
    id: 6,
    type: "options",
    content: "Em qual momento da sua carreira você está?",
    options: [
      { label: "Início de carreira (18-26 anos)", value: "jovem", icon: <Sparkles className="w-4 h-4" /> },
      { label: "Gestor/Coordenador", value: "gestor", icon: <Target className="w-4 h-4" /> },
      { label: "Executivo/Diretor", value: "executivo", icon: <TrendingUp className="w-4 h-4" /> },
      { label: "Empresário/Dono de negócio", value: "empresario", icon: <Users className="w-4 h-4" /> },
    ],
  },
  {
    id: 7,
    type: "options",
    content: "Qual é o seu principal desafio hoje?",
    options: [
      { label: "Tomar decisões baseadas em dados", value: "decisoes" },
      { label: "Melhorar a experiência do cliente", value: "cx" },
      { label: "Implementar IA na operação", value: "ia" },
      { label: "Crescer na carreira com CX/Dados", value: "carreira" },
      { label: "Transformar digitalmente minha empresa", value: "transformacao" },
    ],
  },
  {
    id: 8,
    type: "options",
    content: "Qual é o nível de urgência para resolver esse desafio?",
    options: [
      { label: "Urgente - Preciso resolver em 30 dias", value: "0-30" },
      { label: "Importante - Nos próximos 60 dias", value: "60" },
      { label: "Planejando - Em até 90 dias", value: "90" },
      { label: "Explorando opções - Sem urgência definida", value: "sem-urgencia" },
    ],
  },
  {
    id: 9,
    type: "final",
    content: "Excelente, {name}! Com base nas suas respostas, preparei um diagnóstico inicial. Mas para uma análise completa da sua maturidade em CX, Dados e IA, recomendo fazer o **Radar Vértice** - nossa ferramenta de autoavaliação com 28 perguntas que vai mapear exatamente onde você está e qual o melhor caminho para evoluir.",
  },
];

export default function Jornada() {
  const [, setLocation] = useLocation();
  const [currentStep, setCurrentStep] = useState(0);
  const [messages, setMessages] = useState<{ type: "assistant" | "user"; content: string }[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [userData, setUserData] = useState<Record<string, string>>({});
  const [showFinal, setShowFinal] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const submitContact = trpc.contact.submit.useMutation();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  useEffect(() => {
    // Iniciar a jornada
    setTimeout(() => {
      addAssistantMessage(JOURNEY_STEPS[0].content);
      setTimeout(() => {
        addAssistantMessage(JOURNEY_STEPS[1].content);
        setCurrentStep(2);
      }, 1500);
    }, 500);
  }, []);

  const addAssistantMessage = (content: string) => {
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      const processedContent = content
        .replace("{name}", userData.name || "")
        .replace(/\*\*(.*?)\*\*/g, "$1");
      setMessages((prev) => [...prev, { type: "assistant", content: processedContent }]);
    }, 800 + Math.random() * 500);
  };

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    if (numbers.length <= 2) return `(${numbers}`;
    if (numbers.length <= 7) return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const step = JOURNEY_STEPS[currentStep - 1];
    if (step?.inputType === "phone") {
      setInputValue(formatPhone(e.target.value));
    } else {
      setInputValue(e.target.value);
    }
  };

  const handleSubmit = async (value?: string) => {
    const submittedValue = value || inputValue;
    if (!submittedValue.trim()) return;

    // Adicionar resposta do usuário
    setMessages((prev) => [...prev, { type: "user", content: submittedValue }]);
    setInputValue("");

    // Salvar dados
    const step = JOURNEY_STEPS[currentStep - 1];
    const fieldMap: Record<number, string> = {
      2: "name",
      3: "phone",
      4: "email",
      5: "position",
      6: "persona",
      7: "mainGoal",
      8: "urgency",
    };
    
    const field = fieldMap[currentStep];
    if (field) {
      setUserData((prev) => ({ ...prev, [field]: submittedValue }));
    }

    // Próximo passo
    const nextStep = currentStep + 1;
    if (nextStep <= JOURNEY_STEPS.length) {
      const nextMessage = JOURNEY_STEPS[nextStep - 1];
      
      if (nextMessage.type === "final") {
        // Enviar dados para o backend via contact form
        try {
          const contactData = {
            name: userData.name || submittedValue,
            email: userData.email || "",
            phone: userData.phone || "",
            company: userData.position || "",
            message: `[Jornada Inicial] Persona: ${userData.persona || "gestor"}, Desafio: ${userData.mainGoal || ""}, Urgência: ${userData.urgency || submittedValue}`,
            type: "diagnostic" as const,
          };
          
          await submitContact.mutateAsync(contactData);
        } catch (error) {
          console.error("Error submitting lead:", error);
        }
        
        setShowFinal(true);
        setTimeout(() => {
          const finalContent = nextMessage.content
            .replace("{name}", userData.name || submittedValue);
          addAssistantMessage(finalContent);
        }, 500);
      } else {
        setTimeout(() => {
          const content = nextMessage.content
            .replace("{name}", field === "name" ? submittedValue : userData.name || "");
          addAssistantMessage(content);
          setCurrentStep(nextStep);
        }, 500);
      }
    }
  };

  const handleOptionSelect = (value: string, label: string) => {
    handleSubmit(label);
    const fieldMap: Record<number, string> = {
      6: "persona",
      7: "mainGoal",
      8: "urgency",
    };
    const field = fieldMap[currentStep];
    if (field) {
      setUserData((prev) => ({ ...prev, [field]: value }));
    }
  };

  const currentStepData = JOURNEY_STEPS[currentStep - 1];
  const showInput = currentStepData?.inputType && !showFinal;
  const showOptions = currentStepData?.type === "options" && !showFinal;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a1628] via-[#0d1e36] to-[#0a1628] flex flex-col">
      <SEO title={PAGE_SEO.jornada.title} description={PAGE_SEO.jornada.description} path="/jornada" />
      {/* Header */}
      <header className="border-b border-white/10 bg-[#0a1628]/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img 
                src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/yiFXtpCIREJMAdgt.png" 
                alt="DCX" 
                className="h-8 w-auto"
              />
              <div>
                <span className="text-white font-semibold">Data CX</span>
                <span className="text-primary text-xs block">PROTOCOLO VÉRTICE</span>
              </div>
            </div>
            <div className="hidden md:flex items-center gap-2 text-sm text-gray-400">
              <Brain className="w-4 h-4 text-teal-400" />
              <span>Diagnóstico com <span className="text-teal-400">Inteligência Artificial</span></span>
            </div>
          </div>
        </div>
      </header>

      {/* Chat Area */}
      <main className="flex-1 container mx-auto px-4 py-8 max-w-2xl">
        <div className="space-y-4">
          <AnimatePresence>
            {messages.map((message, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}
              >
                {message.type === "assistant" && (
                  <div className="flex items-start gap-3 max-w-[85%]">
                    <img
                      src={MENTOR_AVATAR}
                      alt="Samuel Rosa"
                      className="w-10 h-10 rounded-full object-cover border-2 border-teal-400/30"
                    />
                    <div className="bg-white/5 border border-white/10 rounded-2xl rounded-tl-none px-4 py-3 text-gray-200">
                      {message.content}
                    </div>
                  </div>
                )}
                {message.type === "user" && (
                  <div className="bg-teal-500/20 border border-teal-400/30 rounded-2xl rounded-tr-none px-4 py-3 text-white max-w-[85%]">
                    {message.content}
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Typing indicator */}
          {isTyping && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-start gap-3"
            >
              <img
                src={MENTOR_AVATAR}
                alt="Samuel Rosa"
                className="w-10 h-10 rounded-full object-cover border-2 border-teal-400/30"
              />
              <div className="bg-white/5 border border-white/10 rounded-2xl rounded-tl-none px-4 py-3">
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-teal-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                  <span className="w-2 h-2 bg-teal-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                  <span className="w-2 h-2 bg-teal-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              </div>
            </motion.div>
          )}

          {/* Options */}
          {showOptions && !isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-wrap gap-2 justify-end"
            >
              {currentStepData.options?.map((option) => (
                <Button
                  key={option.value}
                  variant="outline"
                  className="bg-white/5 border-teal-400/30 text-white hover:bg-teal-500/20 hover:border-teal-400 transition-all"
                  onClick={() => handleOptionSelect(option.value, option.label)}
                >
                  {option.icon && <span className="mr-2">{option.icon}</span>}
                  {option.label}
                </Button>
              ))}
            </motion.div>
          )}

          {/* Final CTA */}
          {showFinal && !isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1 }}
              className="mt-8 space-y-4"
            >
              <div className="bg-gradient-to-r from-teal-500/20 to-cyan-500/20 border border-teal-400/30 rounded-2xl p-6 text-center">
                <CheckCircle2 className="w-12 h-12 text-teal-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">
                  Diagnóstico Inicial Registrado!
                </h3>
                <p className="text-gray-300 mb-6">
                  Agora, faça o Radar Vértice para uma análise completa da sua maturidade em CX, Dados e IA.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button
                    size="lg"
                    className="bg-gradient-to-r from-[#ff6b6b] to-[#ff8e53] hover:from-[#ff5252] hover:to-[#ff7b3d] text-white font-semibold"
                    onClick={() => setLocation("/radar")}
                  >
                    <Target className="w-5 h-5 mr-2" />
                    Fazer Radar Vértice
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    className="border-white/20 text-white hover:bg-white/10"
                    onClick={() => setLocation("/ofertas")}
                  >
                    Ver Programas de Mentoria
                  </Button>
                </div>

                {/* Botões de Compartilhamento */}
                <div className="mt-6 pt-6 border-t border-white/10">
                  <p className="text-gray-400 text-sm mb-4">Compartilhe esta jornada com colegas:</p>
                  <div className="flex flex-wrap gap-2 justify-center">
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-green-500/30 text-green-400 hover:bg-green-500/20 hover:border-green-400"
                      onClick={() => {
                        const url = encodeURIComponent(window.location.href);
                        const text = encodeURIComponent("Descubra seu nível de maturidade em CX, Dados e IA com o Diagnóstico Gratuito da Data CX!");
                        window.open(`https://wa.me/?text=${text}%20${url}`, "_blank");
                      }}
                    >
                      <MessageCircle className="w-4 h-4 mr-2" />
                      WhatsApp
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-blue-500/30 text-blue-400 hover:bg-blue-500/20 hover:border-blue-400"
                      onClick={() => {
                        const url = encodeURIComponent(window.location.href);
                        const title = encodeURIComponent("Diagnóstico de Maturidade em CX, Dados e IA");
                        window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${url}`, "_blank");
                      }}
                    >
                      <Linkedin className="w-4 h-4 mr-2" />
                      LinkedIn
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-purple-500/30 text-purple-400 hover:bg-purple-500/20 hover:border-purple-400"
                      onClick={() => {
                        const subject = encodeURIComponent("Diagnóstico Gratuito de CX, Dados e IA");
                        const body = encodeURIComponent(`Olá!\n\nDescobri essa ferramenta incrível para avaliar maturidade em CX, Dados e IA. Achei que você poderia gostar:\n\n${window.location.href}\n\nAbraco!`);
                        window.open(`mailto:?subject=${subject}&body=${body}`);
                      }}
                    >
                      <Mail className="w-4 h-4 mr-2" />
                      E-mail
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-gray-500/30 text-gray-400 hover:bg-gray-500/20 hover:border-gray-400"
                      onClick={() => {
                        navigator.clipboard.writeText(window.location.href);
                        toast.success("Link copiado para a área de transferência!");
                      }}
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copiar Link
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input Area */}
      {showInput && !isTyping && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="border-t border-white/10 bg-[#0a1628]/80 backdrop-blur-sm p-4"
        >
          <div className="container mx-auto max-w-2xl">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSubmit();
              }}
              className="flex gap-2"
            >
              <Input
                type={currentStepData.inputType === "email" ? "email" : "text"}
                value={inputValue}
                onChange={handleInputChange}
                placeholder={currentStepData.placeholder}
                className="flex-1 bg-white/5 border-white/20 text-white placeholder:text-gray-500 focus:border-teal-400"
                autoFocus
              />
              <Button
                type="submit"
                size="icon"
                className="bg-teal-500 hover:bg-teal-600 text-white"
                disabled={!inputValue.trim()}
              >
                <Send className="w-5 h-5" />
              </Button>
            </form>
          </div>
        </motion.div>
      )}
    </div>
  );
}
