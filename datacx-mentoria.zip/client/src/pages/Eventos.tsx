import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, MapPin, Users, Video, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export default function Eventos() {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const { data: events, isLoading } = trpc.events.list.useQuery(undefined, {
    enabled: !!user,
  });
  const { data: upcomingEvents } = trpc.events.upcoming.useQuery();

  const registerMutation = trpc.events.register.useMutation({
    onSuccess: () => {
      toast.success("Inscrição realizada com sucesso!");
      utils.events.list.invalidate();
    },
    onError: () => {
      toast.error("Erro ao realizar inscrição. Tente novamente.");
    },
  });

  const getEventTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      office_hours: "Office Hours",
      ama: "AMA (Pergunte-me Qualquer Coisa)",
      workshop: "Workshop",
      webinar: "Webinar",
      networking: "Networking",
    };
    return labels[type] || type;
  };

  const getEventTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      office_hours: "bg-blue-500/20 text-blue-400",
      ama: "bg-purple-500/20 text-purple-400",
      workshop: "bg-green-500/20 text-green-400",
      webinar: "bg-yellow-500/20 text-yellow-400",
      networking: "bg-pink-500/20 text-pink-400",
    };
    return colors[type] || "bg-gray-500/20 text-gray-400";
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      scheduled: "bg-blue-500/20 text-blue-400",
      live: "bg-red-500/20 text-red-400",
      completed: "bg-gray-500/20 text-gray-400",
      cancelled: "bg-red-500/20 text-red-400",
    };
    return colors[status] || "bg-gray-500/20 text-gray-400";
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString("pt-BR", {
      weekday: "long",
      day: "numeric",
      month: "long",
    });
  };

  const formatTime = (date: Date | string) => {
    return new Date(date).toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background p-8">
        <div className="container max-w-4xl">
          <h1 className="text-3xl font-bold mb-6">Eventos da Comunidade</h1>
          
          {/* Public upcoming events */}
          <div className="grid gap-6">
            {upcomingEvents?.map((event) => (
              <Card key={event.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <Badge className={getEventTypeColor(event.type)}>
                        {getEventTypeLabel(event.type)}
                      </Badge>
                      <CardTitle className="mt-2">{event.title}</CardTitle>
                      <CardDescription className="mt-1">
                        {event.description}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      {formatDate(event.startTime)}
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      {formatTime(event.startTime)} - {formatTime(event.endTime)}
                    </div>
                    {event.location && (
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        {event.location}
                      </div>
                    )}
                  </div>
                  <div className="mt-4">
                    <Button disabled>
                      Faça login para se inscrever
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {(!upcomingEvents || upcomingEvents.length === 0) && (
              <Card className="text-center py-12">
                <CardContent>
                  <Calendar className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Nenhum evento agendado</h3>
                  <p className="text-muted-foreground">
                    Fique atento! Novos eventos serão anunciados em breve.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-8">
        <div className="container max-w-4xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-muted rounded w-1/3" />
            <div className="h-48 bg-muted rounded-lg" />
            <div className="h-48 bg-muted rounded-lg" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="container max-w-4xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Eventos da Comunidade</h1>
          <p className="text-muted-foreground">
            Participe de office hours, workshops e encontros com a comunidade
          </p>
        </div>

        <div className="grid gap-6">
          {events?.map((event) => (
            <Card key={event.id} className="overflow-hidden">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex gap-2 mb-2">
                      <Badge className={getEventTypeColor(event.type)}>
                        {getEventTypeLabel(event.type)}
                      </Badge>
                      <Badge className={getStatusColor(event.status)}>
                        {event.status === "scheduled" && "Agendado"}
                        {event.status === "live" && "🔴 Ao Vivo"}
                        {event.status === "completed" && "Concluído"}
                        {event.status === "cancelled" && "Cancelado"}
                      </Badge>
                    </div>
                    <CardTitle>{event.title}</CardTitle>
                    <CardDescription className="mt-1">
                      {event.description}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    {formatDate(event.startTime)}
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    {formatTime(event.startTime)} - {formatTime(event.endTime)}
                  </div>
                  {event.location && (
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      {event.location}
                    </div>
                  )}
                  {event.maxAttendees && (
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      Máximo {event.maxAttendees} participantes
                    </div>
                  )}
                </div>

                <div className="flex gap-3">
                  {event.status === "scheduled" && (
                    <Button 
                      onClick={() => registerMutation.mutate({ eventId: event.id })}
                      disabled={registerMutation.isPending}
                    >
                      <CheckCircle2 className="h-4 w-4 mr-2" />
                      Inscrever-se
                    </Button>
                  )}
                  {event.status === "live" && (
                    <Button className="bg-red-600 hover:bg-red-700">
                      <Video className="h-4 w-4 mr-2" />
                      Entrar Agora
                    </Button>
                  )}
                  {event.status === "completed" && event.recordingUrl && (
                    <Button variant="outline" asChild>
                      <a href={event.recordingUrl} target="_blank" rel="noopener noreferrer">
                        <Video className="h-4 w-4 mr-2" />
                        Ver Gravação
                      </a>
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}

          {(!events || events.length === 0) && (
            <Card className="text-center py-12">
              <CardContent>
                <Calendar className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhum evento disponível</h3>
                <p className="text-muted-foreground">
                  Novos eventos serão anunciados em breve. Fique atento!
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
