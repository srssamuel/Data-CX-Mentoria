import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO, { PAGE_SEO } from "@/components/SEO";
import { Link, useLocation } from "wouter";
import {
  ArrowRight,
  CheckCircle2,
  Lock,
  Unlock,
  Crown,
  Zap,
  Star,
  Shield,
  Loader2,
  BookOpen,
  Sparkles,
  ChevronRight,
} from "lucide-react";
import { useState, useMemo } from "react";
import { Quote, MessageSquareQuote } from "lucide-react";

// Plan hierarchy - maps plan slugs to their details
const PLAN_HIERARCHY = [
  {
    slug: "playbook_vertice",
    name: "Playbook Vértice",
    shortName: "Playbook",
    price: "R$ 377",
    priceNote: "Pagamento único",
    modules: 6,
    pilares: ["Introdução"],
    icon: BookOpen,
    color: "from-blue-500 to-blue-700",
    features: [
      "6 módulos de Introdução",
      "Playbooks em PDF",
      "Templates prontos",
      "Acesso vitalício",
    ],
  },
  {
    slug: "mentoria_grupo",
    name: "Mentoria em Grupo",
    shortName: "Grupo",
    price: "R$ 2.997",
    priceNote: "Pagamento único",
    modules: 24,
    pilares: ["Introdução", "CX"],
    icon: Star,
    color: "from-emerald-500 to-emerald-700",
    popular: true,
    features: [
      "24 módulos (Intro + CX)",
      "8 encontros ao vivo",
      "Comunidade WhatsApp",
      "Certificado de conclusão",
      "Quizzes e avaliações",
      "Tutor IA por módulo",
    ],
  },
  {
    slug: "mentoria_sprint",
    name: "Mentoria Sprint 1:1",
    shortName: "Sprint",
    price: "R$ 4.997",
    priceNote: "Pagamento único",
    modules: 42,
    pilares: ["Introdução", "CX", "Dados"],
    icon: Zap,
    color: "from-purple-500 to-purple-700",
    features: [
      "42 módulos (Intro + CX + Dados)",
      "4 sessões individuais",
      "Diagnóstico personalizado",
      "Suporte via WhatsApp",
      "Plano de ação customizado",
      "Follow-up de 30 dias",
    ],
  },
  {
    slug: "mentoria_90dias",
    name: "Mentoria 90 Dias",
    shortName: "90 Dias",
    price: "R$ 8.997",
    priceNote: "Pagamento único",
    modules: 60,
    pilares: ["Introdução", "CX", "Dados", "IA"],
    icon: Shield,
    color: "from-amber-500 to-amber-700",
    features: [
      "Todos os 60 módulos",
      "12 sessões individuais",
      "Diagnóstico completo 360°",
      "Suporte prioritário",
      "Certificado de conclusão",
      "Revisão mensal de resultados",
    ],
  },
  {
    slug: "mentoria_executive",
    name: "Mentoria Executive",
    shortName: "Executive",
    price: "R$ 19.997",
    priceNote: "Pagamento único",
    modules: 60,
    pilares: ["Introdução", "CX", "Dados", "IA", "+ Exclusivos"],
    icon: Crown,
    color: "from-yellow-500 to-yellow-700",
    features: [
      "Todos os 60 módulos + exclusivos",
      "24 sessões individuais",
      "Consultoria para equipe",
      "Suporte VIP 24/7",
      "Relatórios executivos",
      "Networking exclusivo",
    ],
  },
];

// Static testimonials for social proof (fallback when DB is empty)
const STATIC_TESTIMONIALS = [
  {
    id: 1,
    name: "Mariana Costa",
    position: "Head de CX",
    company: "TechBR Solutions",
    content: "A mentoria mudou completamente a forma como estruturamos nossa área de CX. Em 90 dias, conseguimos implementar um programa de Voz do Cliente que reduziu nosso churn em 23%. O conteúdo é extremamente prático e aplicável.",
    rating: 5,
    avatarUrl: null,
  },
  {
    id: 2,
    name: "Rafael Oliveira",
    position: "Diretor de Operações",
    company: "DataFlow Analytics",
    content: "O investimento na Mentoria Sprint se pagou em menos de 2 meses. As sessões individuais foram fundamentais para adaptar os frameworks ao nosso contexto. Recomendo para quem quer resultados rápidos e concretos.",
    rating: 5,
    avatarUrl: null,
  },
  {
    id: 3,
    name: "Camila Santos",
    position: "Gerente de Dados",
    company: "Inova Consultoria",
    content: "Os playbooks e templates são de altíssima qualidade. Mesmo com o plano básico, já consegui estruturar dashboards de CX que impressionaram a diretoria. O tutor IA é um diferencial incrível.",
    rating: 5,
    avatarUrl: null,
  },
  {
    id: 4,
    name: "Pedro Henrique Lima",
    position: "CEO",
    company: "CX Partners",
    content: "A Mentoria Executive transformou não só minha visão, mas a de toda a equipe. O networking exclusivo e as sessões de consultoria nos ajudaram a fechar 3 novos contratos corporativos em 60 dias.",
    rating: 5,
    avatarUrl: null,
  },
  {
    id: 5,
    name: "Ana Beatriz Ferreira",
    position: "Coordenadora de Inovação",
    company: "Grupo Vanguarda",
    content: "Fiz o upgrade do Playbook para a Mentoria em Grupo e foi a melhor decisão. Os encontros ao vivo trazem insights que você não encontra em nenhum curso online. Vale cada centavo.",
    rating: 5,
    avatarUrl: null,
  },
];

function TestimonialsSection() {
  const { data: dbTestimonials } = trpc.testimonials.listActive.useQuery();
  const testimonials = dbTestimonials && dbTestimonials.length > 0 ? dbTestimonials : STATIC_TESTIMONIALS;

  return (
    <div className="mt-16">
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-4">
          <MessageSquareQuote className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium text-primary">Prova Social</span>
        </div>
        <h2 className="text-2xl md:text-3xl font-bold">
          O que nossos <span className="gradient-text">mentorados</span> dizem
        </h2>
        <p className="text-muted-foreground mt-2 max-w-xl mx-auto">
          Resultados reais de profissionais que transformaram suas carreiras e empresas
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {testimonials.slice(0, 6).map((t) => (
          <Card key={t.id} className="bg-card/50 border-border/30 hover:border-primary/30 transition-all duration-300 group">
            <CardContent className="p-6">
              {/* Quote icon */}
              <Quote className="w-8 h-8 text-primary/20 mb-3 group-hover:text-primary/40 transition-colors" />

              {/* Content */}
              <p className="text-sm text-muted-foreground leading-relaxed mb-5 line-clamp-4">
                "{t.content}"
              </p>

              {/* Rating stars */}
              <div className="flex gap-0.5 mb-4">
                {Array.from({ length: t.rating || 5 }).map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                ))}
              </div>

              {/* Author */}
              <div className="flex items-center gap-3">
                {t.avatarUrl ? (
                  <img src={t.avatarUrl} alt={t.name} className="w-10 h-10 rounded-full object-cover border-2 border-primary/20" />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center border-2 border-primary/20">
                    <span className="text-sm font-bold text-primary">
                      {t.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                    </span>
                  </div>
                )}
                <div>
                  <p className="text-sm font-semibold">{t.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {t.position}{t.company ? ` • ${t.company}` : ""}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Stats bar */}
      <div className="mt-10 grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Mentorados", value: "200+" },
          { label: "Satisfação", value: "98%" },
          { label: "Empresas impactadas", value: "50+" },
          { label: "NPS médio", value: "87" },
        ].map((stat) => (
          <div key={stat.label} className="text-center bg-card/30 border border-border/30 rounded-xl py-4 px-3">
            <p className="text-2xl font-extrabold gradient-text">{stat.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Upgrade() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [loadingPlan, setLoadingPlan] = useState<string | null>(null);

  const { data: accessData } = trpc.contents.accessibleModules.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const checkout = trpc.stripe.createCheckout.useMutation({
    onSuccess: (data) => {
      if (data.url) window.location.href = data.url;
    },
    onError: (err) => {
      toast.error(err.message || "Erro ao iniciar checkout");
      setLoadingPlan(null);
    },
  });

  const currentPlanSlug = accessData?.planSlug || null;
  const currentModuleCount = accessData?.moduleCodes?.length || 0;

  // Find current plan index
  const currentPlanIndex = useMemo(() => {
    if (!currentPlanSlug) return -1;
    return PLAN_HIERARCHY.findIndex((p) => p.slug === currentPlanSlug);
  }, [currentPlanSlug]);

  const handleUpgrade = (planSlug: string) => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }
    setLoadingPlan(planSlug);
    checkout.mutate({
      productId: planSlug,
    });
  };

  return (
    <div className="min-h-screen bg-background bg-navy-gradient">
      <SEO title={PAGE_SEO.upgrade.title} description={PAGE_SEO.upgrade.description} path="/upgrade" noindex />
      <Navbar />

      {/* Header */}
      <section className="pt-28 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="absolute inset-0 bg-radial" />
        <div className="container relative z-10 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-coral mb-6">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm font-medium">Evolua sua jornada</span>
          </div>
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-extrabold mb-4">
            Desbloqueie Mais{" "}
            <span className="gradient-text">Módulos</span>
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Escolha o plano ideal para acelerar sua transformação em CX, Dados e
            IA. Cada upgrade libera novos módulos e funcionalidades exclusivas.
          </p>

          {/* Current plan info */}
          {currentPlanSlug && (
            <div className="mt-6 inline-flex items-center gap-3 bg-card/50 border border-border/50 rounded-xl px-5 py-3">
              <CheckCircle2 className="w-5 h-5 text-primary" />
              <span className="text-sm">
                Seu plano atual:{" "}
                <strong className="text-foreground">
                  {PLAN_HIERARCHY.find((p) => p.slug === currentPlanSlug)
                    ?.name || currentPlanSlug}
                </strong>
              </span>
              <Badge variant="outline" className="text-xs">
                {currentModuleCount} módulos
              </Badge>
            </div>
          )}
        </div>
      </section>

      {/* Plans Comparison */}
      <section className="pb-20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
            {PLAN_HIERARCHY.map((plan, index) => {
              const PlanIcon = plan.icon;
              const isCurrent = plan.slug === currentPlanSlug;
              const isDowngrade = index <= currentPlanIndex;
              const isUpgrade = index > currentPlanIndex;
              const additionalModules =
                plan.modules - (currentModuleCount || 0);

              return (
                <Card
                  key={plan.slug}
                  className={`relative overflow-hidden transition-all duration-300 ${
                    plan.popular
                      ? "border-primary/50 shadow-lg shadow-primary/10 scale-[1.02]"
                      : "border-border/50"
                  } ${isCurrent ? "border-primary ring-2 ring-primary/20" : ""}`}
                >
                  {/* Popular badge */}
                  {plan.popular && (
                    <div className="absolute top-0 right-0 bg-primary text-primary-foreground text-[10px] font-bold px-3 py-1 rounded-bl-lg">
                      MAIS POPULAR
                    </div>
                  )}

                  {/* Current badge */}
                  {isCurrent && (
                    <div className="absolute top-0 left-0 bg-primary text-primary-foreground text-[10px] font-bold px-3 py-1 rounded-br-lg">
                      SEU PLANO
                    </div>
                  )}

                  <CardContent className="p-5">
                    {/* Icon */}
                    <div
                      className={`w-12 h-12 rounded-xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-4`}
                    >
                      <PlanIcon className="w-6 h-6 text-white" />
                    </div>

                    {/* Plan name */}
                    <h3 className="font-bold text-lg mb-1">{plan.name}</h3>

                    {/* Price */}
                    <div className="mb-4">
                      <span className="text-2xl font-extrabold gradient-text">
                        {plan.price}
                      </span>
                      <span className="text-xs text-muted-foreground block mt-0.5">
                        {plan.priceNote}
                      </span>
                    </div>

                    {/* Modules count */}
                    <div className="flex items-center gap-2 mb-4 bg-muted/20 rounded-lg px-3 py-2">
                      <BookOpen className="w-4 h-4 text-primary" />
                      <span className="text-sm font-medium">
                        {plan.modules} módulos
                      </span>
                      {isUpgrade && additionalModules > 0 && (
                        <Badge className="bg-primary/20 text-primary text-[10px] ml-auto">
                          +{additionalModules} novos
                        </Badge>
                      )}
                    </div>

                    {/* Pilares */}
                    <div className="flex flex-wrap gap-1 mb-4">
                      {plan.pilares.map((pilar) => (
                        <Badge
                          key={pilar}
                          variant="outline"
                          className="text-[10px]"
                        >
                          {pilar}
                        </Badge>
                      ))}
                    </div>

                    {/* Features */}
                    <ul className="space-y-2 mb-6">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2 text-xs">
                          <CheckCircle2 className="w-3.5 h-3.5 text-primary flex-shrink-0 mt-0.5" />
                          <span className="text-muted-foreground">
                            {feature}
                          </span>
                        </li>
                      ))}
                    </ul>

                    {/* CTA */}
                    {isCurrent ? (
                      <Button
                        disabled
                        className="w-full"
                        variant="outline"
                        size="sm"
                      >
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        Plano Atual
                      </Button>
                    ) : isDowngrade && currentPlanSlug ? (
                      <Button
                        disabled
                        className="w-full opacity-50"
                        variant="outline"
                        size="sm"
                      >
                        <Lock className="w-4 h-4 mr-2" />
                        Incluído no seu plano
                      </Button>
                    ) : (
                      <Button
                        className={`w-full ${
                          plan.popular ? "btn-coral" : ""
                        }`}
                        size="sm"
                        onClick={() => handleUpgrade(plan.slug)}
                        disabled={loadingPlan === plan.slug}
                      >
                        {loadingPlan === plan.slug ? (
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                          <Unlock className="w-4 h-4 mr-2" />
                        )}
                        {currentPlanSlug ? "Fazer Upgrade" : "Começar Agora"}
                      </Button>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Module unlock visualization */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-center mb-8">
              O que cada plano <span className="gradient-text">desbloqueia</span>
            </h2>

            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr>
                    <th className="text-left p-3 text-sm font-semibold text-muted-foreground border-b border-border/50">
                      Pilar
                    </th>
                    {PLAN_HIERARCHY.map((plan) => (
                      <th
                        key={plan.slug}
                        className={`p-3 text-center text-xs font-semibold border-b border-border/50 ${
                          plan.slug === currentPlanSlug
                            ? "text-primary"
                            : "text-muted-foreground"
                        }`}
                      >
                        {plan.shortName}
                        {plan.slug === currentPlanSlug && (
                          <span className="block text-[10px] text-primary/70 mt-0.5">
                            (atual)
                          </span>
                        )}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[
                    {
                      pilar: "Introdução",
                      modules: 6,
                      color: "text-blue-400",
                    },
                    {
                      pilar: "CX",
                      modules: 18,
                      color: "text-emerald-400",
                    },
                    {
                      pilar: "Dados",
                      modules: 18,
                      color: "text-purple-400",
                    },
                    {
                      pilar: "IA",
                      modules: 18,
                      color: "text-amber-400",
                    },
                  ].map((row) => (
                    <tr key={row.pilar} className="border-b border-border/30">
                      <td className="p-3">
                        <span className={`font-medium text-sm ${row.color}`}>
                          {row.pilar}
                        </span>
                        <span className="text-xs text-muted-foreground ml-2">
                          ({row.modules} módulos)
                        </span>
                      </td>
                      {PLAN_HIERARCHY.map((plan) => {
                        const hasAccess =
                          plan.pilares.includes(row.pilar) ||
                          plan.pilares.includes("+ Exclusivos");
                        return (
                          <td key={plan.slug} className="p-3 text-center">
                            {hasAccess ? (
                              <CheckCircle2 className="w-5 h-5 text-primary mx-auto" />
                            ) : (
                              <Lock className="w-4 h-4 text-muted-foreground/30 mx-auto" />
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                  <tr className="border-b border-border/30">
                    <td className="p-3">
                      <span className="font-medium text-sm text-foreground">
                        Sessões 1:1
                      </span>
                    </td>
                    {PLAN_HIERARCHY.map((plan) => {
                      const sessions =
                        plan.slug === "playbook_vertice"
                          ? "—"
                          : plan.slug === "mentoria_grupo"
                          ? "1×30min"
                          : plan.slug === "mentoria_sprint"
                          ? "4×1h"
                          : plan.slug === "mentoria_90dias"
                          ? "12×1h"
                          : "24×1h";
                      return (
                        <td
                          key={plan.slug}
                          className="p-3 text-center text-xs text-muted-foreground"
                        >
                          {sessions}
                        </td>
                      );
                    })}
                  </tr>
                  <tr>
                    <td className="p-3">
                      <span className="font-medium text-sm text-foreground">
                        Tutor IA
                      </span>
                    </td>
                    {PLAN_HIERARCHY.map((plan) => (
                      <td key={plan.slug} className="p-3 text-center">
                        <CheckCircle2 className="w-5 h-5 text-primary mx-auto" />
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Testimonials / Social Proof */}
          <TestimonialsSection />

          {/* FAQ / Guarantee */}
          <div className="mt-16 max-w-2xl mx-auto text-center">
            <div className="bg-card/50 border border-border/50 rounded-2xl p-8">
              <Shield className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-3">
                Garantia de 7 Dias
              </h3>
              <p className="text-muted-foreground text-sm">
                Se em até 7 dias você sentir que o programa não é para você,
                devolvemos 100% do seu investimento. Sem perguntas, sem
                burocracia.
              </p>
            </div>
          </div>

          {/* Back to members */}
          <div className="mt-8 text-center">
            <Link href="/membros">
              <Button variant="ghost" className="text-muted-foreground">
                <ChevronRight className="w-4 h-4 mr-2 rotate-180" />
                Voltar para Área de Membros
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
