import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import Navbar from "@/components/Navbar";
import SEO, { PAGE_SEO } from "@/components/SEO";
import Footer from "@/components/Footer";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  Mail,
  Phone,
  MapPin,
  Linkedin,
  Instagram,
  Send,
  CheckCircle2,
  Calendar,
  MessageSquare,
  Building2,
  User,
  Briefcase,
  Clock,
  Shield,
} from "lucide-react";

// Opções de segmento
const segmentos = [
  "Financeiro / Bancos",
  "Telecom",
  "Varejo / E-commerce",
  "Saúde",
  "Seguros",
  "Mobilidade / Transporte",
  "Delivery / Logística",
  "Tecnologia / SaaS",
  "Educação",
  "Indústria",
  "Serviços",
  "Governo / Setor Público",
  "Outro",
];

// Opções de tamanho da empresa
const tamanhos = [
  "Autônomo / MEI",
  "Micro (até 10 funcionários)",
  "Pequena (11-50 funcionários)",
  "Média (51-200 funcionários)",
  "Grande (201-1000 funcionários)",
  "Enterprise (1000+ funcionários)",
];

// Opções de interesse
const interesses = [
  { value: "playbook", label: "Playbook Vértice (R$ 377)" },
  { value: "mentoria_grupo", label: "Mentoria em Grupo (8 semanas)" },
  { value: "mentoria_individual", label: "Mentoria Individual (1:1)" },
  { value: "diagnostico", label: "Diagnóstico 360º" },
  { value: "assessoria", label: "Assessoria Contínua" },
  { value: "palestra", label: "Palestra / Workshop" },
  { value: "outro", label: "Outro / Não sei ainda" },
];

// Opções de como conheceu
const fontes = [
  "LinkedIn",
  "Google",
  "Indicação de colega",
  "Evento / Palestra",
  "Instagram",
  "YouTube",
  "Podcast",
  "Outro",
];

// Opções de horário
const horarios = [
  "Manhã (8h - 12h)",
  "Tarde (12h - 18h)",
  "Noite (18h - 21h)",
  "Qualquer horário",
];

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    cargo: "",
    segmento: "",
    tamanho: "",
    interesse: "",
    desafio: "",
    fonte: "",
    horario: "",
    type: "contact" as "contact" | "diagnostic",
    lgpdConsent: false,
  });
  const [submitted, setSubmitted] = useState(false);

  const submitMutation = trpc.contact.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      toast.success("Mensagem enviada com sucesso!");
    },
    onError: () => {
      toast.error("Erro ao enviar mensagem. Tente novamente.");
    },
  });

  // Máscara de telefone brasileiro
  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    if (numbers.length <= 2) return `(${numbers}`;
    if (numbers.length <= 7) return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    if (numbers.length <= 11) return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7)}`;
    return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhone(e.target.value);
    setFormData({ ...formData, phone: formatted });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.lgpdConsent) {
      toast.error("Por favor, aceite os termos de privacidade para continuar.");
      return;
    }

    // Monta a mensagem completa com todos os dados
    const mensagemCompleta = `
**Dados do Contato:**
- Cargo: ${formData.cargo || "Não informado"}
- Segmento: ${formData.segmento || "Não informado"}
- Tamanho da empresa: ${formData.tamanho || "Não informado"}
- Interesse principal: ${interesses.find(i => i.value === formData.interesse)?.label || "Não informado"}
- Como conheceu: ${formData.fonte || "Não informado"}
- Melhor horário: ${formData.horario || "Não informado"}

**Desafio/Mensagem:**
${formData.desafio}
    `.trim();

    submitMutation.mutate({
      name: formData.name,
      email: formData.email,
      phone: formData.phone,
      company: formData.company,
      message: mensagemCompleta,
      type: formData.type,
    });
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-background bg-navy-gradient">
        <SEO title="Mensagem Enviada" description={PAGE_SEO.contato.description} path="/contato" />
        <Navbar />
        <section className="pt-32 pb-20 min-h-[80vh] flex items-center">
          <div className="container">
            <div className="max-w-2xl mx-auto">
              {/* Animação de sucesso */}
              <div className="text-center mb-8">
                <div className="relative w-24 h-24 mx-auto mb-6">
                  <div className="absolute inset-0 rounded-full bg-primary/20 animate-ping" />
                  <div className="relative w-24 h-24 rounded-full bg-gradient-to-br from-primary to-teal-400 flex items-center justify-center">
                    <CheckCircle2 className="w-12 h-12 text-white" />
                  </div>
                </div>
                <h1 className="text-4xl font-bold mb-4 gradient-text">Mensagem Enviada com Sucesso!</h1>
                <p className="text-xl text-muted-foreground">
                  Obrigado pelo seu interesse no <strong className="text-primary">Protocolo Vértice</strong>!
                </p>
              </div>

              {/* Card de confirmação */}
              <Card className="program-card border-primary/30 mb-8">
                <CardContent className="p-6 md:p-8">
                  <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-primary" />
                    O que acontece agora?
                  </h2>
                  
                  <div className="space-y-4">
                    <div className="flex items-start gap-4 p-4 rounded-xl bg-primary/5 border border-primary/20">
                      <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-primary font-bold">1</span>
                      </div>
                      <div>
                        <h3 className="font-semibold mb-1">Análise do seu perfil</h3>
                        <p className="text-muted-foreground text-sm">
                          Vou analisar suas informações para entender melhor seu cenário e necessidades.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4 p-4 rounded-xl bg-primary/5 border border-primary/20">
                      <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-primary font-bold">2</span>
                      </div>
                      <div>
                        <h3 className="font-semibold mb-1">Contato em até 24h úteis</h3>
                        <p className="text-muted-foreground text-sm">
                          Entrarei em contato pelo <strong>WhatsApp</strong> ou <strong>e-mail</strong> informado para dar continuidade.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4 p-4 rounded-xl bg-coral/5 border border-coral/20">
                      <div className="w-10 h-10 rounded-full bg-coral/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-coral font-bold">3</span>
                      </div>
                      <div>
                        <h3 className="font-semibold mb-1">Próximos passos personalizados</h3>
                        <p className="text-muted-foreground text-sm">
                          {formData.type === "diagnostic" 
                            ? "Vamos agendar sua sessão diagnóstica gratuita de 30 minutos para mapear seu cenário."
                            : "Vou preparar uma proposta ou recomendação personalizada com base no seu interesse."
                          }
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Resumo do que foi enviado */}
                  <div className="mt-6 pt-6 border-t border-border/50">
                    <h3 className="text-sm font-medium text-muted-foreground mb-3">Resumo do seu contato:</h3>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Nome:</span>
                        <p className="font-medium">{formData.name}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">E-mail:</span>
                        <p className="font-medium">{formData.email}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">WhatsApp:</span>
                        <p className="font-medium">{formData.phone}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Tipo:</span>
                        <p className="font-medium">{formData.type === "diagnostic" ? "Sessão Diagnóstica" : "Contato Geral"}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* CTAs */}
              <div className="text-center">
                <p className="text-muted-foreground mb-6">
                  Enquanto isso, que tal descobrir seu nível de maturidade em CX, Dados e IA?
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button onClick={() => setSubmitted(false)} variant="outline" size="lg">
                    <Send className="w-4 h-4 mr-2" />
                    Enviar Nova Mensagem
                  </Button>
                  <Button asChild className="btn-coral" size="lg">
                    <a href="/radar">
                      Fazer Radar Vértice
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background bg-navy-gradient">
      <SEO title={PAGE_SEO.contato.title} description={PAGE_SEO.contato.description} path="/contato" />
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="absolute inset-0 bg-radial" />

        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
              <MessageSquare className="w-4 h-4" />
              Vamos Conversar
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Entre em <span className="gradient-text">Contato</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              Preencha o formulário abaixo para que eu possa entender melhor seu cenário e oferecer a melhor solução para você.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-12">
        <div className="container">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Form */}
            <div className="lg:col-span-2">
              <Card className="program-card border-border/50">
                <CardContent className="p-6 md:p-8">
                  <form onSubmit={handleSubmit} className="space-y-8">
                    {/* Type Selection */}
                    <div className="space-y-3">
                      <Label className="text-base font-semibold">Como posso ajudar?</Label>
                      <RadioGroup
                        value={formData.type}
                        onValueChange={(value) =>
                          setFormData({ ...formData, type: value as "contact" | "diagnostic" })
                        }
                        className="grid grid-cols-1 sm:grid-cols-2 gap-4"
                      >
                        <Label
                          htmlFor="contact"
                          className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                            formData.type === "contact"
                              ? "border-primary bg-primary/10"
                              : "border-border/50 hover:border-primary/50 bg-card/30"
                          }`}
                        >
                          <RadioGroupItem value="contact" id="contact" className="mt-1" />
                          <div>
                            <MessageSquare className="w-5 h-5 text-primary mb-2" />
                            <span className="font-medium block">Contato Geral</span>
                            <span className="text-muted-foreground text-sm">Dúvidas, informações ou proposta comercial</span>
                          </div>
                        </Label>
                        <Label
                          htmlFor="diagnostic"
                          className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                            formData.type === "diagnostic"
                              ? "border-coral bg-coral/10"
                              : "border-border/50 hover:border-coral/50 bg-card/30"
                          }`}
                        >
                          <RadioGroupItem value="diagnostic" id="diagnostic" className="mt-1" />
                          <div>
                            <Calendar className="w-5 h-5 text-coral mb-2" />
                            <span className="font-medium block">Sessão Diagnóstica</span>
                            <span className="text-muted-foreground text-sm">30 minutos gratuitos para entender seu cenário</span>
                          </div>
                        </Label>
                      </RadioGroup>
                    </div>

                    {/* Seção 1: Dados Pessoais */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-primary">
                        <User className="w-5 h-5" />
                        <h3 className="font-semibold">Seus Dados</h3>
                      </div>
                      
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="name">Nome completo *</Label>
                          <Input
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            placeholder="Seu nome completo"
                            required
                            className="bg-background/50"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email">E-mail profissional *</Label>
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleChange}
                            placeholder="seu@empresa.com"
                            required
                            className="bg-background/50"
                          />
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="phone">WhatsApp *</Label>
                          <Input
                            id="phone"
                            name="phone"
                            value={formData.phone}
                            onChange={handlePhoneChange}
                            placeholder="(84) 99127-8513"
                            required
                            className="bg-background/50"
                            maxLength={15}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="cargo">Cargo / Função</Label>
                          <Input
                            id="cargo"
                            name="cargo"
                            value={formData.cargo}
                            onChange={handleChange}
                            placeholder="Ex: Gerente de CX, Analista de Dados..."
                            className="bg-background/50"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Seção 2: Dados da Empresa */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-primary">
                        <Building2 className="w-5 h-5" />
                        <h3 className="font-semibold">Sobre sua Empresa</h3>
                      </div>
                      
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="company">Empresa / Organização</Label>
                          <Input
                            id="company"
                            name="company"
                            value={formData.company}
                            onChange={handleChange}
                            placeholder="Nome da empresa"
                            className="bg-background/50"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Segmento de Atuação</Label>
                          <Select
                            value={formData.segmento}
                            onValueChange={(value) => setFormData({ ...formData, segmento: value })}
                          >
                            <SelectTrigger className="bg-background/50">
                              <SelectValue placeholder="Selecione o segmento" />
                            </SelectTrigger>
                            <SelectContent>
                              {segmentos.map((seg) => (
                                <SelectItem key={seg} value={seg}>
                                  {seg}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label>Tamanho da Empresa</Label>
                        <Select
                          value={formData.tamanho}
                          onValueChange={(value) => setFormData({ ...formData, tamanho: value })}
                        >
                          <SelectTrigger className="bg-background/50">
                            <SelectValue placeholder="Selecione o tamanho" />
                          </SelectTrigger>
                          <SelectContent>
                            {tamanhos.map((tam) => (
                              <SelectItem key={tam} value={tam}>
                                {tam}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Seção 3: Interesse */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-primary">
                        <Briefcase className="w-5 h-5" />
                        <h3 className="font-semibold">Seu Interesse</h3>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Interesse Principal *</Label>
                        <Select
                          value={formData.interesse}
                          onValueChange={(value) => setFormData({ ...formData, interesse: value })}
                          required
                        >
                          <SelectTrigger className="bg-background/50">
                            <SelectValue placeholder="O que você busca?" />
                          </SelectTrigger>
                          <SelectContent>
                            {interesses.map((int) => (
                              <SelectItem key={int.value} value={int.value}>
                                {int.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="desafio">Qual seu principal desafio ou objetivo? *</Label>
                        <Textarea
                          id="desafio"
                          name="desafio"
                          value={formData.desafio}
                          onChange={handleChange}
                          placeholder={
                            formData.type === "diagnostic"
                              ? "Descreva seu cenário atual: quais são os principais desafios em CX, dados ou IA? O que você espera alcançar com a mentoria ou diagnóstico?"
                              : "Conte um pouco sobre o que você busca: dúvidas, informações sobre programas, proposta comercial..."
                          }
                          required
                          rows={5}
                          className="bg-background/50 resize-none"
                        />
                      </div>
                    </div>

                    {/* Seção 4: Preferências (simplificado) */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-primary">
                        <Clock className="w-5 h-5" />
                        <h3 className="font-semibold">Preferências de Contato</h3>
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Melhor horário para contato</Label>
                          <Select
                            value={formData.horario}
                            onValueChange={(value) => setFormData({ ...formData, horario: value })}
                          >
                            <SelectTrigger className="bg-background/50">
                              <SelectValue placeholder="Selecione o horário" />
                            </SelectTrigger>
                            <SelectContent>
                              {horarios.map((hor) => (
                                <SelectItem key={hor} value={hor}>
                                  {hor}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Como conheceu a Data CX?</Label>
                          <Select
                            value={formData.fonte}
                            onValueChange={(value) => setFormData({ ...formData, fonte: value })}
                          >
                            <SelectTrigger className="bg-background/50">
                              <SelectValue placeholder="Selecione a fonte" />
                            </SelectTrigger>
                            <SelectContent>
                              {fontes.map((fonte) => (
                                <SelectItem key={fonte} value={fonte}>
                                  {fonte}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    {/* LGPD Consent */}
                    <div className="space-y-4 pt-4 border-t border-border/50">
                      <div className="flex items-start gap-3">
                        <Checkbox
                          id="lgpd"
                          checked={formData.lgpdConsent}
                          onCheckedChange={(checked) =>
                            setFormData({ ...formData, lgpdConsent: checked as boolean })
                          }
                          className="mt-1"
                        />
                        <Label htmlFor="lgpd" className="text-sm text-muted-foreground cursor-pointer">
                          <Shield className="w-4 h-4 inline mr-1 text-primary" />
                          Concordo com o tratamento dos meus dados pessoais para fins de contato comercial, conforme a <a href="#" className="text-primary hover:underline">Política de Privacidade</a>. Seus dados estão seguros e não serão compartilhados com terceiros.
                        </Label>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full btn-coral h-14 rounded-xl text-lg"
                      disabled={submitMutation.isPending || !formData.lgpdConsent}
                    >
                      {submitMutation.isPending ? (
                        "Enviando..."
                      ) : (
                        <>
                          Enviar Mensagem
                          <Send className="w-5 h-5 ml-2" />
                        </>
                      )}
                    </Button>

                    <p className="text-center text-muted-foreground text-sm">
                      Respondo em até 24 horas úteis via WhatsApp ou e-mail
                    </p>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Contact Info */}
            <div className="space-y-6">
              <Card className="program-card border-border/50">
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Informações de Contato</h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Mail className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">E-mail</p>
                        <a
                          href="mailto:contato@datacx.com.br"
                          className="text-foreground hover:text-primary transition-colors"
                        >
                          contato@datacx.com.br
                        </a>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Phone className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">WhatsApp</p>
                        <a
                          href="https://wa.me/5584991278513"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-foreground hover:text-primary transition-colors"
                        >
                          +55 (84) 99127-8513
                        </a>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <MapPin className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Localização</p>
                        <p className="text-foreground">Brasil (Atendimento 100% Online)</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="program-card border-border/50">
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Redes Sociais</h3>
                  <div className="flex gap-3">
                    <a
                      href="https://linkedin.com/in/samuel-rosa-5a1447b7"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center hover:bg-primary/20 transition-colors"
                    >
                      <Linkedin className="w-5 h-5 text-primary" />
                    </a>
                    <a
                      href="https://instagram.com/srssamuelrosa"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center hover:bg-primary/20 transition-colors"
                    >
                      <Instagram className="w-5 h-5 text-primary" />
                    </a>
                  </div>
                </CardContent>
              </Card>

              <Card className="program-card border-coral/30 bg-coral/5">
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-2 text-coral">Sessão Diagnóstica Gratuita</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    30 minutos para entender seu cenário, identificar oportunidades e recomendar o melhor caminho para sua evolução em CX, Dados e IA.
                  </p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-coral" />
                      <span>Análise do seu momento atual</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-coral" />
                      <span>Identificação de quick wins</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-coral" />
                      <span>Recomendação personalizada</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="program-card border-primary/30">
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-2">Não sabe por onde começar?</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Faça o Radar Vértice e descubra seu nível de maturidade em CX, Dados e IA em menos de 5 minutos.
                  </p>
                  <Button asChild variant="outline" className="w-full">
                    <a href="/radar">Fazer Radar Vértice</a>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
