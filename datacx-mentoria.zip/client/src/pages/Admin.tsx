import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Link, useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { trpc } from "@/lib/trpc";
import {
  Users,
  DollarSign,
  TrendingUp,
  TrendingDown,
  MessageSquare,
  BookOpen,
  Star,
  ArrowRight,
  Lock,
  Loader2,
  RefreshCw,
  Eye,
  Mail,
  Calendar,
  CheckCircle2,
  Clock,
  XCircle,
  Compass,
  Phone,
  Target,
  Ticket,
  Plus,
  Trash2,
  Edit,
  Percent,
  FileText,
  Shield,
  Briefcase,
  FolderKanban,
  History,
  AlertTriangle,
  BarChart3,
  Brain,
  GraduationCap,
  Search,
  ChevronUp,
  ChevronDown,
  Minus,
  Activity,
  Headphones,
  FileCheck,
  ThumbsUp,
  Award,
  Send,
  PieChart,
} from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { useState, useMemo, useEffect } from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, Legend } from "recharts";
import { toast } from "sonner";

const statusColors: Record<string, string> = {
  new: "bg-blue-500/10 text-blue-500",
  contacted: "bg-yellow-500/10 text-yellow-500",
  scheduled: "bg-primary/10 text-primary",
  completed: "bg-green-500/10 text-green-500",
  pending: "bg-yellow-500/10 text-yellow-500",
  active: "bg-green-500/10 text-green-500",
  cancelled: "bg-red-500/10 text-red-500",
  paid: "bg-green-500/10 text-green-500",
  failed: "bg-red-500/10 text-red-500",
};

const statusLabels: Record<string, string> = {
  new: "Novo",
  contacted: "Contatado",
  scheduled: "Agendado",
  completed: "Concluído",
  pending: "Pendente",
  active: "Ativo",
  cancelled: "Cancelado",
  paid: "Pago",
  failed: "Falhou",
};

const categoryLabels: Record<string, string> = {
  introducao: "Introdução",
  cx: "CX",
  dados: "Dados",
  ia: "IA",
};

const categoryColors: Record<string, string> = {
  introducao: "bg-purple-500/10 text-purple-500",
  cx: "bg-teal-500/10 text-teal-500",
  dados: "bg-blue-500/10 text-blue-500",
  ia: "bg-orange-500/10 text-orange-500",
};

// ============ TREND INDICATOR ============
function TrendBadge({ current, previous }: { current: number; previous: number }) {
  if (previous === 0 && current === 0) return <Minus className="w-3 h-3 text-muted-foreground" />;
  if (previous === 0 && current > 0) return <ChevronUp className="w-4 h-4 text-green-500" />;
  const pct = Math.round(((current - previous) / Math.max(previous, 1)) * 100);
  if (pct > 0) return <span className="flex items-center gap-0.5 text-xs text-green-500"><ChevronUp className="w-3 h-3" />+{pct}%</span>;
  if (pct < 0) return <span className="flex items-center gap-0.5 text-xs text-red-400"><ChevronDown className="w-3 h-3" />{pct}%</span>;
  return <Minus className="w-3 h-3 text-muted-foreground" />;
}

// ============ STAR DISPLAY ============
function StarDisplay({ rating, size = "sm" }: { rating: number; size?: "sm" | "md" }) {
  const cls = size === "sm" ? "w-3 h-3" : "w-4 h-4";
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map(i => (
        <Star key={i} className={`${cls} ${i <= Math.round(rating) ? "fill-primary text-primary" : "text-muted-foreground/30"}`} />
      ))}
    </div>
  );
}

// ============ USER EDIT DIALOG ============
function UserEditDialog({ user: u, onSuccess }: { user: any; onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState(u.name || "");
  const [email, setEmail] = useState(u.email || "");
  const [role, setRole] = useState<"admin" | "user">(u.role || "user");
  const [phone, setPhone] = useState(u.phone || "");
  const [company, setCompany] = useState(u.company || "");
  const [position, setPosition] = useState(u.position || "");
  
  const updateUser = trpc.admin.updateUser.useMutation({
    onSuccess: () => {
      toast.success("Usuário atualizado com sucesso!");
      setOpen(false);
      onSuccess();
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao atualizar usuário");
    },
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8"><Edit className="h-4 w-4" /></Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader><DialogTitle>Editar Usuário</DialogTitle></DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2"><Label>Nome</Label><Input value={name} onChange={e => setName(e.target.value)} /></div>
          <div className="grid gap-2"><Label>Email</Label><Input type="email" value={email} onChange={e => setEmail(e.target.value)} /></div>
          <div className="grid gap-2">
            <Label>Perfil</Label>
            <Select value={role} onValueChange={v => setRole(v as "admin" | "user")}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="user">Usuário</SelectItem>
                <SelectItem value="admin">Administrador</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2"><Label>Telefone</Label><Input value={phone} onChange={e => setPhone(e.target.value)} /></div>
          <div className="grid gap-2"><Label>Empresa</Label><Input value={company} onChange={e => setCompany(e.target.value)} /></div>
          <div className="grid gap-2"><Label>Cargo</Label><Input value={position} onChange={e => setPosition(e.target.value)} /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button onClick={() => updateUser.mutate({ id: u.id, data: { name, email, role, phone, company, position } })} disabled={updateUser.isPending}>
            {updateUser.isPending && <Loader2 className="h-4 w-4 animate-spin mr-2" />}Salvar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============ USER DELETE DIALOG ============
function UserDeleteDialog({ user: u, currentUserId, onSuccess }: { user: any; currentUserId?: number; onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const deleteUser = trpc.admin.deleteUser.useMutation({
    onSuccess: () => { toast.success("Usuário excluído!"); setOpen(false); onSuccess(); },
    onError: (error) => { toast.error(error.message || "Erro ao excluir"); },
  });
  if (u.id === currentUserId) return null;
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive"><Trash2 className="h-4 w-4" /></Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Excluir Usuário</DialogTitle></DialogHeader>
        <p className="text-sm text-muted-foreground py-4">Tem certeza que deseja excluir <strong>{u.name || u.email}</strong>? Esta ação não pode ser desfeita.</p>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button variant="destructive" onClick={() => deleteUser.mutate({ id: u.id })} disabled={deleteUser.isPending}>
            {deleteUser.isPending && <Loader2 className="h-4 w-4 animate-spin mr-2" />}Excluir
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============ SCHEDULE TAB ============
function ScheduleTab({ contents, onRefresh }: { contents: any[]; onRefresh: () => void }) {
  const [schedules, setSchedules] = useState<Record<number, string>>({});
  const [startDate, setStartDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [intervalDays, setIntervalDays] = useState(7);
  const [selectedPilar, setSelectedPilar] = useState("all");

  const bulkSet = trpc.contents.bulkSetReleaseDates.useMutation({
    onSuccess: () => {
      toast.success("Cronograma salvo com sucesso!");
      onRefresh();
    },
    onError: (err: any) => toast.error(err.message || "Erro ao salvar cronograma"),
  });

  // Group contents by pilar
  const pilares = useMemo(() => {
    const grouped: Record<string, any[]> = {};
    (contents || []).forEach((c: any) => {
      const pilar = c.pilar || c.category || "INTRO";
      if (!grouped[pilar]) grouped[pilar] = [];
      grouped[pilar].push(c);
    });
    return grouped;
  }, [contents]);

  const filteredContents = useMemo(() => {
    if (selectedPilar === "all") return contents || [];
    return (contents || []).filter((c: any) => (c.pilar || c.category || "INTRO") === selectedPilar);
  }, [contents, selectedPilar]);

  // Auto-generate weekly schedule
  const generateWeeklySchedule = () => {
    const sorted = [...filteredContents].sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
    const newSchedules: Record<number, string> = {};
    const start = new Date(startDate + "T00:00:00");
    sorted.forEach((c, i) => {
      const releaseDate = new Date(start);
      releaseDate.setDate(releaseDate.getDate() + i * intervalDays);
      newSchedules[c.id] = releaseDate.toISOString().split("T")[0];
    });
    setSchedules(prev => ({ ...prev, ...newSchedules }));
  };

  // Save all schedules
  const saveSchedules = () => {
    const schedulesArray = Object.entries(schedules).map(([id, date]) => ({
      contentId: parseInt(id),
      releaseDate: date || null,
    }));
    if (schedulesArray.length === 0) {
      toast.error("Nenhuma data definida para salvar.");
      return;
    }
    bulkSet.mutate({ schedules: schedulesArray });
  };

  // Initialize from existing dates
  useEffect(() => {
    const existing: Record<number, string> = {};
    (contents || []).forEach((c: any) => {
      if (c.releaseDate) {
        existing[c.id] = new Date(c.releaseDate).toISOString().split("T")[0];
      }
    });
    setSchedules(existing);
  }, [contents]);

  return (
    <Card className="bg-card/50 border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          Cronograma de Liberação
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Auto-generate controls */}
        <div className="bg-muted/20 rounded-xl p-5 border border-border/30">
          <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
            <Clock className="w-4 h-4 text-primary" />
            Gerar Cronograma Automático
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 items-end">
            <div>
              <Label className="text-xs">Trilha</Label>
              <Select value={selectedPilar} onValueChange={setSelectedPilar}>
                <SelectTrigger className="h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as Trilhas</SelectItem>
                  {Object.keys(pilares).map(p => (
                    <SelectItem key={p} value={p}>{p} ({pilares[p].length})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Data Inicial</Label>
              <Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="h-9" />
            </div>
            <div>
              <Label className="text-xs">Intervalo (dias)</Label>
              <Input type="number" min={1} max={30} value={intervalDays} onChange={e => setIntervalDays(parseInt(e.target.value) || 7)} className="h-9" />
            </div>
            <Button onClick={generateWeeklySchedule} variant="outline" size="sm" className="h-9">
              <Calendar className="w-4 h-4 mr-2" />
              Gerar Datas
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-3">
            Gera datas de liberação progressiva para {filteredContents.length} módulos, começando em {startDate} com intervalo de {intervalDays} dia(s).
          </p>
        </div>

        {/* Schedule table */}
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[80px]">Código</TableHead>
                <TableHead>Título</TableHead>
                <TableHead className="w-[100px]">Trilha</TableHead>
                <TableHead className="w-[160px]">Data de Liberação</TableHead>
                <TableHead className="w-[100px]">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredContents.sort((a: any, b: any) => (a.sortOrder || 0) - (b.sortOrder || 0)).map((c: any) => {
                const dateValue = schedules[c.id] || "";
                const isScheduled = dateValue && new Date(dateValue) > new Date();
                const isReleased = dateValue && new Date(dateValue) <= new Date();
                return (
                  <TableRow key={c.id}>
                    <TableCell>
                      <Badge variant="outline" className="font-mono text-xs">{c.moduleCode || "-"}</Badge>
                    </TableCell>
                    <TableCell className="font-medium text-sm">{c.title}</TableCell>
                    <TableCell>
                      <Badge className="text-xs">{c.pilar || c.category || "INTRO"}</Badge>
                    </TableCell>
                    <TableCell>
                      <Input
                        type="date"
                        value={dateValue}
                        onChange={e => setSchedules(prev => ({ ...prev, [c.id]: e.target.value }))}
                        className="h-8 text-xs"
                      />
                    </TableCell>
                    <TableCell>
                      {!dateValue ? (
                        <span className="text-xs text-muted-foreground">Imediato</span>
                      ) : isScheduled ? (
                        <Badge className="bg-amber-500/20 text-amber-400 text-[10px]">Agendado</Badge>
                      ) : isReleased ? (
                        <Badge className="bg-green-500/20 text-green-400 text-[10px]">Liberado</Badge>
                      ) : null}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>

        {/* Save button */}
        <div className="flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            {Object.keys(schedules).length} módulos com data definida
          </p>
          <Button onClick={saveSchedules} disabled={bulkSet.isPending}>
            {bulkSet.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}
            Salvar Cronograma
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// ============ CONTENT EDIT DIALOG ============
function ContentEditDialog({ content, onSuccess }: { content: any; onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState(content.title || "");
  const [description, setDescription] = useState(content.description || "");
  const [videoUrl, setVideoUrl] = useState(content.videoUrl || "");
  const [fileUrl, setFileUrl] = useState(content.fileUrl || "");
  const [releaseDate, setReleaseDate] = useState(content.releaseDate ? new Date(content.releaseDate).toISOString().split('T')[0] : "");
  const [contentVersion, setContentVersion] = useState(content.contentVersion || "1.0");
  const [versionNotes, setVersionNotes] = useState(content.versionNotes || "");
  
  const updateContent = trpc.contents.update.useMutation({
    onSuccess: () => { toast.success("Conteúdo atualizado!"); setOpen(false); onSuccess(); },
    onError: (error) => { toast.error(error.message || "Erro ao atualizar"); },
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8"><Edit className="h-4 w-4" /></Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>Editar Conteúdo</DialogTitle></DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2"><Label>Título</Label><Input value={title} onChange={e => setTitle(e.target.value)} /></div>
          <div className="space-y-2"><Label>Descrição</Label><Input value={description} onChange={e => setDescription(e.target.value)} /></div>
          <div className="space-y-2"><Label>URL do Vídeo</Label><Input value={videoUrl} onChange={e => setVideoUrl(e.target.value)} placeholder="https://youtube.com/..." /></div>
          <div className="space-y-2"><Label>URL do Arquivo</Label><Input value={fileUrl} onChange={e => setFileUrl(e.target.value)} placeholder="https://..." /></div>
          <div className="space-y-2">
            <Label>Data de Liberação (Agendamento)</Label>
            <Input type="date" value={releaseDate} onChange={e => setReleaseDate(e.target.value)} />
            <p className="text-xs text-muted-foreground">Deixe em branco para liberar imediatamente</p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Versão</Label>
              <Input value={contentVersion} onChange={e => setContentVersion(e.target.value)} placeholder="1.0" />
            </div>
            <div className="space-y-2">
              <Label>Notas da Versão</Label>
              <Input value={versionNotes} onChange={e => setVersionNotes(e.target.value)} placeholder="O que mudou..." />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button onClick={() => updateContent.mutate({ id: content.id, data: { title, description, videoUrl: videoUrl || null, fileUrl: fileUrl || null, releaseDate: releaseDate ? new Date(releaseDate).toISOString() : null, contentVersion: contentVersion || undefined, versionNotes: versionNotes || null } })} disabled={updateContent.isPending}>
            {updateContent.isPending && <Loader2 className="h-4 w-4 animate-spin mr-2" />}Salvar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============ ENROLLMENT DATE DIALOG ============
function EditEnrollmentDateDialog({ enrollment, onSuccess }: { enrollment: any; onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [endDate, setEndDate] = useState(enrollment.endDate ? new Date(enrollment.endDate).toISOString().split('T')[0] : '');
  const updateMutation = trpc.enrollments.updateEndDate.useMutation({
    onSuccess: () => { toast.success("Data atualizada!"); onSuccess(); setOpen(false); },
    onError: (error: any) => { toast.error(error.message || "Erro"); },
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button variant="outline" size="sm"><Calendar className="w-4 h-4 mr-1" />Editar</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Editar Data de Término</DialogTitle></DialogHeader>
        <div className="space-y-4 py-4">
          <p className="text-sm text-muted-foreground">Matrícula #{enrollment.id}</p>
          <div className="space-y-2">
            <Label>Nova Data de Término</Label>
            <Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
            <p className="text-xs text-muted-foreground">Deixe em branco para acesso ilimitado</p>
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="outline">Cancelar</Button></DialogClose>
          <Button onClick={() => updateMutation.mutate({ id: enrollment.id, endDate: endDate ? new Date(endDate).toISOString() : null })} disabled={updateMutation.isPending}>
            {updateMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}Salvar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============ QUIZ CREATE DIALOG ============
function QuizCreateDialog({ onSuccess }: { onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [contentId, setContentId] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [passingScore, setPassingScore] = useState(70);
  const [pointsReward, setPointsReward] = useState(50);
  const { data: contents } = trpc.contents.list.useQuery();
  const createQuiz = trpc.quizzes.create.useMutation({
    onSuccess: () => { toast.success("Quiz criado!"); setOpen(false); setContentId(""); setTitle(""); setDescription(""); onSuccess(); },
    onError: (error) => { toast.error(error.message || "Erro"); },
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button size="sm"><Plus className="w-4 h-4 mr-2" />Novo Quiz</Button></DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>Criar Novo Quiz</DialogTitle></DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Conteúdo/Módulo</Label>
            <Select value={contentId} onValueChange={setContentId}>
              <SelectTrigger><SelectValue placeholder="Selecione o conteúdo" /></SelectTrigger>
              <SelectContent>{contents?.map(c => <SelectItem key={c.id} value={c.id.toString()}>{c.title}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-2"><Label>Título</Label><Input value={title} onChange={e => setTitle(e.target.value)} /></div>
          <div className="space-y-2"><Label>Descrição</Label><Input value={description} onChange={e => setDescription(e.target.value)} /></div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2"><Label>Nota mínima (%)</Label><Input type="number" value={passingScore} onChange={e => setPassingScore(Number(e.target.value))} /></div>
            <div className="space-y-2"><Label>Pontos</Label><Input type="number" value={pointsReward} onChange={e => setPointsReward(Number(e.target.value))} /></div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button onClick={() => { if (!contentId || !title) { toast.error("Preencha conteúdo e título"); return; } createQuiz.mutate({ contentId: parseInt(contentId), title, description, passingScore, pointsReward }); }} disabled={createQuiz.isPending}>
            {createQuiz.isPending && <Loader2 className="h-4 w-4 animate-spin mr-2" />}Criar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============ QUIZZES LIST (reused from original) ============
function QuizzesList() {
  const { data: quizzes, isLoading } = trpc.quizzes.listAll.useQuery();
  if (isLoading) return <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>;
  if (!quizzes || quizzes.length === 0) return <p className="text-center text-muted-foreground py-8">Nenhum quiz cadastrado.</p>;
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Título</TableHead>
          <TableHead>Conteúdo</TableHead>
          <TableHead>Nota Mínima</TableHead>
          <TableHead>Questões</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {quizzes.map((q: any) => (
          <TableRow key={q.id}>
            <TableCell className="font-medium">{q.title}</TableCell>
            <TableCell>{q.contentId}</TableCell>
            <TableCell>{q.passingScore}%</TableCell>
            <TableCell><Badge variant="outline">{q.questionCount || 0}</Badge></TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}

// ============ ACCESS MANAGEMENT TAB ============
function AccessManagementTab({ allUsers }: { allUsers: any[] }) {
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [searchAccess, setSearchAccess] = useState("");
  const [grantModule, setGrantModule] = useState("");
  const [grantReason, setGrantReason] = useState("");

  const { data: userAccess, isLoading: accessLoading, refetch: refetchAccess } = trpc.admin.getUserAccess.useQuery(
    { userId: selectedUserId! },
    { enabled: !!selectedUserId }
  );
  const { data: planMapping } = trpc.admin.getPlanModuleMapping.useQuery();

  const setOverride = trpc.admin.setModuleOverride.useMutation({
    onSuccess: () => { toast.success("Acesso atualizado!"); refetchAccess(); setGrantModule(""); setGrantReason(""); },
    onError: (err) => toast.error(err.message || "Erro"),
  });
  const grantAll = trpc.admin.grantAllModules.useMutation({
    onSuccess: (data) => { toast.success(`${data.count} módulos liberados!`); refetchAccess(); },
    onError: (err) => toast.error(err.message || "Erro"),
  });
  const revokeAll = trpc.admin.revokeAllOverrides.useMutation({
    onSuccess: (data) => { toast.success(`${data.count} overrides removidos!`); refetchAccess(); },
    onError: (err) => toast.error(err.message || "Erro"),
  });
  const removeOverride = trpc.admin.removeModuleOverride.useMutation({
    onSuccess: () => { toast.success("Override removido!"); refetchAccess(); },
    onError: (err) => toast.error(err.message || "Erro"),
  });

  const filteredUsers = useMemo(() => {
    if (!searchAccess) return allUsers.slice(0, 20);
    const q = searchAccess.toLowerCase();
    return allUsers.filter((u: any) =>
      (u.name || "").toLowerCase().includes(q) ||
      (u.email || "").toLowerCase().includes(q)
    ).slice(0, 20);
  }, [allUsers, searchAccess]);

  const selectedUser = allUsers.find((u: any) => u.id === selectedUserId);

  // All module codes for the grant dropdown
  const allModuleCodes = useMemo(() => {
    if (!planMapping) return [];
    const codes = new Set<string>();
    Object.values(planMapping).forEach(modules => modules.forEach(m => codes.add(m)));
    return Array.from(codes).sort();
  }, [planMapping]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* User selector */}
        <Card className="bg-card/50 border-border/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2"><Users className="w-4 h-4" />Selecionar Usuário</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Buscar usuário..." value={searchAccess} onChange={e => setSearchAccess(e.target.value)} className="pl-8 h-9" />
            </div>
            <div className="max-h-[400px] overflow-y-auto space-y-1">
              {filteredUsers.map((u: any) => (
                <button
                  key={u.id}
                  onClick={() => setSelectedUserId(u.id)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                    selectedUserId === u.id ? "bg-primary/10 text-primary border border-primary/30" : "hover:bg-muted/50"
                  }`}
                >
                  <div className="font-medium truncate">{u.name || "Sem nome"}</div>
                  <div className="text-xs text-muted-foreground truncate">{u.email}</div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* User access details */}
        <Card className="bg-card/50 border-border/50 lg:col-span-2">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm flex items-center gap-2">
                <Shield className="w-4 h-4" />
                {selectedUser ? `Acessos de ${selectedUser.name || selectedUser.email}` : "Selecione um usuário"}
              </CardTitle>
              {selectedUser && (
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => grantAll.mutate({ userId: selectedUserId!, reason: "Acesso total via admin" })}
                    disabled={grantAll.isPending}
                    className="text-xs h-7"
                  >
                    {grantAll.isPending ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <CheckCircle2 className="w-3 h-3 mr-1" />}
                    Liberar Tudo
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => revokeAll.mutate({ userId: selectedUserId! })}
                    disabled={revokeAll.isPending}
                    className="text-xs h-7 text-destructive hover:text-destructive"
                  >
                    {revokeAll.isPending ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <XCircle className="w-3 h-3 mr-1" />}
                    Revogar Overrides
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {!selectedUserId ? (
              <div className="text-center py-12">
                <Shield className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                <p className="text-muted-foreground text-sm">Selecione um usuário para gerenciar seus acessos</p>
              </div>
            ) : accessLoading ? (
              <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
            ) : userAccess ? (
              <div className="space-y-4">
                {/* Plan info */}
                <div className="bg-muted/20 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <BookOpen className="w-4 h-4 text-primary" />
                    <span className="text-sm font-medium">Planos Ativos</span>
                  </div>
                  {userAccess.planSlugs.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {userAccess.planSlugs.map((slug: string) => (
                        <Badge key={slug} className="bg-primary/10 text-primary">{slug}</Badge>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-muted-foreground">Nenhum plano ativo. Todos os módulos estão bloqueados (exceto INT-01).</p>
                  )}
                </div>

                {/* Effective modules count */}
                <div className="bg-muted/20 rounded-lg p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Lock className="w-4 h-4 text-amber-400" />
                      <span className="text-sm font-medium">Módulos Acessíveis</span>
                    </div>
                    <Badge variant="outline">{userAccess.effectiveModules?.length || 0} / 60</Badge>
                  </div>
                  {userAccess.effectiveModules && userAccess.effectiveModules.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {userAccess.effectiveModules.map((code: string) => (
                        <span key={code} className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded">{code}</span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Overrides */}
                <div className="bg-muted/20 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Edit className="w-4 h-4 text-amber-400" />
                    <span className="text-sm font-medium">Overrides Manuais</span>
                  </div>
                  {userAccess.overrides && userAccess.overrides.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="text-xs">Módulo</TableHead>
                          <TableHead className="text-xs">Ação</TableHead>
                          <TableHead className="text-xs">Motivo</TableHead>
                          <TableHead className="text-xs">Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {userAccess.overrides.map((o: any) => (
                          <TableRow key={o.id}>
                            <TableCell className="text-xs font-mono">{o.moduleCode}</TableCell>
                            <TableCell>
                              <Badge className={o.action === "grant" ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"} variant="outline">
                                {o.action === "grant" ? "Liberado" : "Bloqueado"}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-xs text-muted-foreground">{o.reason || "-"}</TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 text-destructive"
                                onClick={() => removeOverride.mutate({ userId: selectedUserId!, moduleCode: o.moduleCode })}
                                disabled={removeOverride.isPending}
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <p className="text-xs text-muted-foreground">Nenhum override manual. O acesso segue apenas o plano.</p>
                  )}
                </div>

                {/* Grant/Revoke individual module */}
                <div className="bg-muted/20 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-3">
                    <Plus className="w-4 h-4 text-primary" />
                    <span className="text-sm font-medium">Adicionar Override</span>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <Select value={grantModule} onValueChange={setGrantModule}>
                      <SelectTrigger className="h-8 text-xs flex-1"><SelectValue placeholder="Selecione o módulo" /></SelectTrigger>
                      <SelectContent>
                        {allModuleCodes.map(code => (
                          <SelectItem key={code} value={code}>{code}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input
                      placeholder="Motivo (opcional)"
                      value={grantReason}
                      onChange={e => setGrantReason(e.target.value)}
                      className="h-8 text-xs flex-1"
                    />
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        className="h-8 text-xs"
                        onClick={() => {
                          if (!grantModule) { toast.error("Selecione um módulo"); return; }
                          setOverride.mutate({ userId: selectedUserId!, moduleCode: grantModule, action: "grant", reason: grantReason || "Liberado pelo admin" });
                        }}
                        disabled={setOverride.isPending || !grantModule}
                      >
                        <CheckCircle2 className="w-3 h-3 mr-1" />Liberar
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        className="h-8 text-xs"
                        onClick={() => {
                          if (!grantModule) { toast.error("Selecione um módulo"); return; }
                          setOverride.mutate({ userId: selectedUserId!, moduleCode: grantModule, action: "revoke", reason: grantReason || "Bloqueado pelo admin" });
                        }}
                        disabled={setOverride.isPending || !grantModule}
                      >
                        <XCircle className="w-3 h-3 mr-1" />Bloquear
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </CardContent>
        </Card>
      </div>

      {/* Plan mapping reference */}
      {planMapping && (
        <Card className="bg-card/50 border-border/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2"><BookOpen className="w-4 h-4" />Mapeamento de Planos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {Object.entries(planMapping).map(([slug, modules]) => (
                <div key={slug} className="bg-muted/20 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">{slug}</span>
                    <Badge variant="outline" className="text-xs">{(modules as string[]).length} módulos</Badge>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {(modules as string[]).slice(0, 12).map(code => (
                      <span key={code} className="text-[9px] bg-muted/50 px-1 py-0.5 rounded">{code}</span>
                    ))}
                    {(modules as string[]).length > 12 && (
                      <span className="text-[9px] text-muted-foreground">+{(modules as string[]).length - 12} mais</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ============ MAIN ADMIN PAGE ============
export default function Admin() {
  const { user, isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();
  const [searchUsers, setSearchUsers] = useState("");
  const [searchContents, setSearchContents] = useState("");
  const [searchFeedback, setSearchFeedback] = useState("");
  const [feedbackFilter, setFeedbackFilter] = useState("all");

  // Existing queries
  const { data: metrics, isLoading: metricsLoading, refetch: refetchMetrics } = trpc.admin.metrics.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: enhancedMetrics, isLoading: enhancedLoading } = trpc.admin.enhancedMetrics.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: allUsers, isLoading: usersLoading } = trpc.admin.users.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: enrollments, isLoading: enrollmentsLoading, refetch: refetchEnrollments } = trpc.enrollments.listAll.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: contents, isLoading: contentsLoading, refetch: refetchContents } = trpc.contents.list.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: testimonials, isLoading: testimonialsLoading } = trpc.testimonials.listAll.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: contacts, isLoading: contactsLoading, refetch: refetchContacts } = trpc.contact.listAll.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: radarLeads, isLoading: radarLoading, refetch: refetchRadar } = trpc.radar.listAll.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: radarMetrics, isLoading: radarMetricsLoading } = trpc.radar.metrics.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: segmentTrendsRaw } = trpc.radar.segmentTrends.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const segmentTrendData = useMemo(() => {
    if (!segmentTrendsRaw || segmentTrendsRaw.length === 0) return [];
    const monthMap: Record<string, Record<string, number>> = {};
    for (const row of segmentTrendsRaw) {
      const m = row.month;
      if (!monthMap[m]) monthMap[m] = { dados: 0, cx: 0, ia: 0, governanca: 0, cultura: 0, none: 0 };
      const seg = row.segment || "none";
      monthMap[m][seg] = row.count;
    }
    return Object.entries(monthMap)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, segs]) => ({
        month: new Date(month + "-01").toLocaleDateString("pt-BR", { month: "short", year: "2-digit" }),
        ...segs,
        total: Object.values(segs).reduce((s, v) => s + v, 0),
      }));
  }, [segmentTrendsRaw]);
  const { data: allCoupons, isLoading: couponsLoading, refetch: refetchCoupons } = trpc.coupons.listAll.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: couponMetrics, isLoading: couponMetricsLoading } = trpc.coupons.metrics.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: auditLogs, isLoading: auditLoading, refetch: refetchAudit } = trpc.audit.list.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: projects, isLoading: projectsLoading, refetch: refetchProjects } = trpc.consulting.listProjects.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );

  // New queries
  const { data: feedbackList, isLoading: feedbackLoading, refetch: refetchFeedback } = trpc.admin.feedbackList.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: feedbackByModule, isLoading: feedbackByModuleLoading } = trpc.admin.feedbackStatsByModule.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: studentProgress, isLoading: progressLoading } = trpc.admin.studentProgress.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: moduleEngagement, isLoading: engagementLoading } = trpc.admin.moduleEngagement.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: quizPerformance, isLoading: quizPerfLoading } = trpc.admin.quizPerformance.useQuery(
    undefined, { enabled: isAuthenticated && user?.role === "admin" }
  );

  // Coupon mutations
  const createCouponMutation = trpc.coupons.create.useMutation({
    onSuccess: () => { toast.success("Cupom criado!"); refetchCoupons(); setShowCreateCoupon(false); resetCouponForm(); },
    onError: (error) => { toast.error(error.message || "Erro"); },
  });
  const toggleCouponMutation = trpc.coupons.toggleActive.useMutation({
    onSuccess: (data) => { toast.success(data.isActive ? "Cupom ativado!" : "Cupom desativado!"); refetchCoupons(); },
  });
  const deleteCouponMutation = trpc.coupons.delete.useMutation({
    onSuccess: () => { toast.success("Cupom excluído!"); refetchCoupons(); },
  });

  const [leadSearchQuery, setLeadSearchQuery] = useState("");
  const [selectedLead, setSelectedLead] = useState<any>(null);
  const [selectedSegmentFilter, setSelectedSegmentFilter] = useState<string>("all");
  const [nurtureSendingSegment, setNurtureSendingSegment] = useState<string | null>(null);
  
  const [whatsappSendingSegment, setWhatsappSendingSegment] = useState<string | null>(null);
  const sendWhatsappFollowupMutation = trpc.radar.sendWhatsappFollowup.useMutation({
    onSuccess: (data) => {
      toast.success(`WhatsApp enviado! ${data.sent} de ${data.eligible || 0} leads elegíveis receberam a mensagem.`);
      setWhatsappSendingSegment(null);
    },
    onError: (err) => {
      toast.error(`Erro ao enviar WhatsApp: ${err.message}`);
      setWhatsappSendingSegment(null);
    },
  });
  const sendSegmentNurtureMutation = trpc.radar.sendSegmentNurture.useMutation({
    onSuccess: (data) => {
      toast.success(`Nurture enviado! ${data.sentCount} de ${data.totalLeads} leads receberam o email.`);
      setNurtureSendingSegment(null);
    },
    onError: (err) => {
      toast.error(`Erro ao enviar nurture: ${err.message}`);
      setNurtureSendingSegment(null);
    },
  });
  const [showCreateCoupon, setShowCreateCoupon] = useState(false);
  const [couponForm, setCouponForm] = useState({
    code: "", name: "", description: "",
    discountType: "percentage" as "percentage" | "fixed",
    discountValue: 10, usageLimit: undefined as number | undefined, validUntil: "",
  });
  const resetCouponForm = () => setCouponForm({ code: "", name: "", description: "", discountType: "percentage", discountValue: 10, usageLimit: undefined, validUntil: "" });

  // Filtered data
  const filteredUsers = useMemo(() => {
    if (!allUsers) return [];
    if (!searchUsers) return allUsers;
    const q = searchUsers.toLowerCase();
    return allUsers.filter((u: any) =>
      (u.name || "").toLowerCase().includes(q) ||
      (u.email || "").toLowerCase().includes(q) ||
      (u.company || "").toLowerCase().includes(q)
    );
  }, [allUsers, searchUsers]);

  const filteredContents = useMemo(() => {
    if (!contents) return [];
    if (!searchContents) return contents;
    const q = searchContents.toLowerCase();
    return contents.filter((c: any) =>
      (c.title || "").toLowerCase().includes(q) ||
      (c.moduleCode || "").toLowerCase().includes(q)
    );
  }, [contents, searchContents]);

  const filteredFeedback = useMemo(() => {
    if (!feedbackList) return [];
    let list = feedbackList;
    if (feedbackFilter !== "all") {
      const rating = parseInt(feedbackFilter);
      list = list.filter((f: any) => f.rating === rating);
    }
    if (searchFeedback) {
      const q = searchFeedback.toLowerCase();
      list = list.filter((f: any) =>
        (f.comment || "").toLowerCase().includes(q) ||
        (f.contentTitle || "").toLowerCase().includes(q) ||
        (f.userName || "").toLowerCase().includes(q)
      );
    }
    return list;
  }, [feedbackList, feedbackFilter, searchFeedback]);

  // Loading
  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-32 pb-20 flex items-center justify-center min-h-[80vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
        <Footer />
      </div>
    );
  }

  // Not admin
  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <section className="pt-32 pb-20 min-h-[80vh] flex items-center">
          <div className="container">
            <div className="max-w-lg mx-auto text-center">
              <div className="w-20 h-20 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-6">
                <Lock className="w-10 h-10 text-destructive" />
              </div>
              <h1 className="text-3xl font-bold mb-4">Acesso Restrito</h1>
              <p className="text-muted-foreground mb-8">Esta área é exclusiva para administradores.</p>
              <Link href="/"><Button variant="outline">Voltar ao Início</Button></Link>
            </div>
          </div>
        </section>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Header */}
      <section className="pt-32 pb-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="absolute inset-0 bg-radial" />
        <div className="container relative z-10">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2">
                Painel <span className="gradient-text">Administrativo</span>
              </h1>
              <p className="text-muted-foreground">Gerencie sua plataforma de mentoria</p>
            </div>
            <Button onClick={() => { refetchMetrics(); refetchFeedback(); }} variant="outline" size="sm">
              <RefreshCw className="w-4 h-4 mr-2" />Atualizar
            </Button>
          </div>
        </div>
      </section>

      {/* Enhanced Metrics Row */}
      <section className="py-4">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <Card className="bg-card/50 border-border/50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Users className="w-4 h-4 text-primary" />
                  </div>
                  {enhancedMetrics && <TrendBadge current={enhancedMetrics.newUsersThisWeek} previous={enhancedMetrics.newUsersPrevWeek} />}
                </div>
                <p className="text-2xl font-bold">{metricsLoading ? "-" : metrics?.totalUsers || 0}</p>
                <TooltipProvider><Tooltip><TooltipTrigger asChild><p className="text-muted-foreground text-xs cursor-help">Usuários totais</p></TooltipTrigger><TooltipContent><p>Total de usuários cadastrados na plataforma (incluindo admin e membros)</p></TooltipContent></Tooltip></TooltipProvider>
                {enhancedMetrics && <p className="text-xs text-muted-foreground mt-1">+{enhancedMetrics.newUsersThisWeek} esta semana</p>}
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-border/50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="w-9 h-9 rounded-lg bg-green-500/10 flex items-center justify-center">
                    <BookOpen className="w-4 h-4 text-green-500" />
                  </div>
                  {enhancedMetrics && <TrendBadge current={enhancedMetrics.newEnrollmentsThisWeek} previous={enhancedMetrics.newEnrollmentsPrevWeek} />}
                </div>
                <p className="text-2xl font-bold">{metricsLoading ? "-" : metrics?.activeEnrollments || 0}</p>
                <TooltipProvider><Tooltip><TooltipTrigger asChild><p className="text-muted-foreground text-xs cursor-help">Matrículas ativas</p></TooltipTrigger><TooltipContent><p>Número de matrículas com status ativo em programas pagos</p></TooltipContent></Tooltip></TooltipProvider>
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-border/50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="w-9 h-9 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                    <DollarSign className="w-4 h-4 text-yellow-500" />
                  </div>
                </div>
                <p className="text-2xl font-bold">{metricsLoading ? "-" : `R$ ${(metrics?.totalRevenue || 0).toLocaleString("pt-BR")}`}</p>
                <TooltipProvider><Tooltip><TooltipTrigger asChild><p className="text-muted-foreground text-xs cursor-help">Receita total</p></TooltipTrigger><TooltipContent><p>Soma de todos os pagamentos confirmados via Stripe (checkout sessions completadas)</p></TooltipContent></Tooltip></TooltipProvider>
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-border/50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="w-9 h-9 rounded-lg bg-blue-500/10 flex items-center justify-center">
                    <MessageSquare className="w-4 h-4 text-blue-500" />
                  </div>
                  {enhancedMetrics && <TrendBadge current={enhancedMetrics.chatMessagesThisWeek} previous={enhancedMetrics.chatMessagesPrevWeek} />}
                </div>
                <p className="text-2xl font-bold">{enhancedLoading ? "-" : enhancedMetrics?.chatMessagesThisWeek || 0}</p>
                  <TooltipProvider><Tooltip><TooltipTrigger asChild><p className="text-muted-foreground text-xs cursor-help">Msgs chat (semana)</p></TooltipTrigger><TooltipContent><p>Mensagens enviadas ao assistente IA nos últimos 7 dias</p></TooltipContent></Tooltip></TooltipProvider>
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-border/50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="w-9 h-9 rounded-lg bg-orange-500/10 flex items-center justify-center">
                    <Star className="w-4 h-4 text-orange-500" />
                  </div>
                </div>
                <p className="text-2xl font-bold">{enhancedLoading ? "-" : enhancedMetrics?.avgFeedbackRating || "-"}<span className="text-sm text-muted-foreground">/5</span></p>
                <TooltipProvider><Tooltip><TooltipTrigger asChild><p className="text-muted-foreground text-xs cursor-help">{enhancedMetrics?.totalFeedback || 0} avaliações IA</p></TooltipTrigger><TooltipContent><p>Média das avaliações de qualidade do feedback IA (1-5 estrelas) dado pelos alunos</p></TooltipContent></Tooltip></TooltipProvider>
              </CardContent>
            </Card>
          </div>

          {/* Second row: engagement metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
            <Card className="bg-card/30 border-border/30">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-teal-500/10 flex items-center justify-center">
                  <CheckCircle2 className="w-4 h-4 text-teal-500" />
                </div>
                <div>
                  <p className="text-lg font-bold">{enhancedLoading ? "-" : enhancedMetrics?.completionsThisWeek || 0}</p>
                  <TooltipProvider><Tooltip><TooltipTrigger asChild><p className="text-muted-foreground text-xs cursor-help">Conclusões (semana)</p></TooltipTrigger><TooltipContent><p>Módulos marcados como concluídos nos últimos 7 dias</p></TooltipContent></Tooltip></TooltipProvider>
                </div>
                {enhancedMetrics && <div className="ml-auto"><TrendBadge current={enhancedMetrics.completionsThisWeek} previous={enhancedMetrics.completionsPrevWeek} /></div>}
              </CardContent>
            </Card>
            <Card className="bg-card/30 border-border/30">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center">
                  <GraduationCap className="w-4 h-4 text-purple-500" />
                </div>
                <div>
                  <p className="text-lg font-bold">{enhancedLoading ? "-" : enhancedMetrics?.quizAttemptsThisWeek || 0}</p>
                  <TooltipProvider><Tooltip><TooltipTrigger asChild><p className="text-muted-foreground text-xs cursor-help">Quizzes (semana)</p></TooltipTrigger><TooltipContent><p>Tentativas de quiz realizadas nos últimos 7 dias</p></TooltipContent></Tooltip></TooltipProvider>
                </div>
                {enhancedMetrics && <div className="ml-auto"><TrendBadge current={enhancedMetrics.quizAttemptsThisWeek} previous={enhancedMetrics.quizAttemptsPrevWeek} /></div>}
              </CardContent>
            </Card>
            <Card className="bg-card/30 border-border/30">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Compass className="w-4 h-4 text-blue-500" />
                </div>
                <div>
                  <p className="text-lg font-bold">{radarMetricsLoading ? "-" : radarMetrics?.total || 0}</p>
                  <TooltipProvider><Tooltip><TooltipTrigger asChild><p className="text-muted-foreground text-xs cursor-help">Leads Radar</p></TooltipTrigger><TooltipContent><p>Total de diagnósticos Radar Vértice preenchidos (leads capturados)</p></TooltipContent></Tooltip></TooltipProvider>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-card/30 border-border/30">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-red-500/10 flex items-center justify-center">
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                </div>
                <div>
                  <p className="text-lg font-bold">{metricsLoading ? "-" : metrics?.pendingContacts || 0}</p>
                  <TooltipProvider><Tooltip><TooltipTrigger asChild><p className="text-muted-foreground text-xs cursor-help">Contatos pendentes</p></TooltipTrigger><TooltipContent><p>Formulários de contato aguardando resposta (status: novo)</p></TooltipContent></Tooltip></TooltipProvider>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Main Tabs */}
      <section className="py-4 pb-20">
        <div className="container">
          <Tabs defaultValue="feedbacks" className="space-y-4">
            <TabsList className="bg-card/50 flex-wrap h-auto gap-1 p-1.5">
              {/* Aprendizado */}
              <span className="text-[10px] text-muted-foreground/60 uppercase tracking-wider px-1.5 py-0.5 self-center hidden sm:inline">Aprendizado</span>
              <TabsTrigger value="feedbacks" className="text-xs">Feedbacks IA</TabsTrigger>
              <TabsTrigger value="progress" className="text-xs">Progresso</TabsTrigger>
              <TabsTrigger value="engagement" className="text-xs">Engajamento</TabsTrigger>
              <TabsTrigger value="quizzes" className="text-xs">Quizzes</TabsTrigger>
              <span className="hidden sm:inline text-border/50 self-center px-0.5">|</span>
              {/* Comercial */}
              <span className="text-[10px] text-muted-foreground/60 uppercase tracking-wider px-1.5 py-0.5 self-center hidden sm:inline">Comercial</span>
              <TabsTrigger value="radar" className="text-xs">Radar</TabsTrigger>
              <TabsTrigger value="contacts" className="text-xs">Contatos</TabsTrigger>
              <TabsTrigger value="enrollments" className="text-xs">Matrículas</TabsTrigger>
              <TabsTrigger value="coupons" className="text-xs">Cupons</TabsTrigger>
              <span className="hidden sm:inline text-border/50 self-center px-0.5">|</span>
              {/* Gestão */}
              <span className="text-[10px] text-muted-foreground/60 uppercase tracking-wider px-1.5 py-0.5 self-center hidden sm:inline">Gestão</span>
              <TabsTrigger value="users" className="text-xs">Usuários</TabsTrigger>
              <TabsTrigger value="contents" className="text-xs">Conteúdos</TabsTrigger>
              <TabsTrigger value="schedule" className="text-xs">Cronograma</TabsTrigger>
              <TabsTrigger value="access" className="text-xs">Acessos</TabsTrigger>
              <TabsTrigger value="audit" className="text-xs">Auditoria</TabsTrigger>
              <TabsTrigger value="workspace" className="text-xs">Workspace</TabsTrigger>
              <TabsTrigger value="health" className="text-xs">Saúde</TabsTrigger>
            </TabsList>

            {/* ============ FEEDBACKS IA TAB ============ */}
            <TabsContent value="feedbacks">
              {/* Feedback stats by module */}
              <Card className="bg-card/50 border-border/50 mb-4">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <BarChart3 className="w-5 h-5" />
                    Avaliações por Módulo
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {feedbackByModuleLoading ? (
                    <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                  ) : feedbackByModule && feedbackByModule.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Módulo</TableHead>
                          <TableHead>Trilha</TableHead>
                          <TableHead>Avaliações</TableHead>
                          <TableHead>Média</TableHead>
                          <TableHead>Comentários</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {feedbackByModule.map((m: any, i: number) => (
                          <TableRow key={i}>
                            <TableCell className="font-medium">
                              <div className="flex items-center gap-2">
                                <Badge variant="outline" className="font-mono text-xs">{m.moduleCode}</Badge>
                                <span className="truncate max-w-[200px]">{m.contentTitle}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge className={categoryColors[m.category] || "bg-muted"}>{categoryLabels[m.category] || m.category}</Badge>
                            </TableCell>
                            <TableCell>{m.totalFeedback}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <StarDisplay rating={m.avgRating} />
                                <span className="text-sm font-medium">{m.avgRating}</span>
                              </div>
                            </TableCell>
                            <TableCell>{m.totalComments}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <p className="text-center text-muted-foreground py-8">Nenhuma avaliação registrada ainda.</p>
                  )}
                </CardContent>
              </Card>

              {/* Recent feedback list */}
              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <ThumbsUp className="w-5 h-5" />
                      Feedbacks Recentes
                    </CardTitle>
                    <div className="flex gap-2">
                      <div className="relative">
                        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input placeholder="Buscar..." value={searchFeedback} onChange={e => setSearchFeedback(e.target.value)} className="pl-8 h-9 w-48" />
                      </div>
                      <Select value={feedbackFilter} onValueChange={setFeedbackFilter}>
                        <SelectTrigger className="h-9 w-32"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todas</SelectItem>
                          <SelectItem value="5">5 estrelas</SelectItem>
                          <SelectItem value="4">4 estrelas</SelectItem>
                          <SelectItem value="3">3 estrelas</SelectItem>
                          <SelectItem value="2">2 estrelas</SelectItem>
                          <SelectItem value="1">1 estrela</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {feedbackLoading ? (
                    <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                  ) : filteredFeedback.length > 0 ? (
                    <div className="space-y-3">
                      {filteredFeedback.map((f: any) => (
                        <div key={f.id} className="flex items-start gap-3 p-3 rounded-lg bg-muted/30 border border-border/30">
                          <div className="flex-shrink-0 mt-0.5">
                            <StarDisplay rating={f.rating} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium text-sm">{f.userName || "Anônimo"}</span>
                              <Badge variant="outline" className="text-xs font-mono">{f.moduleCode}</Badge>
                              <span className="text-xs text-muted-foreground">{new Date(f.createdAt).toLocaleDateString("pt-BR")}</span>
                            </div>
                            {f.comment && <p className="text-sm text-muted-foreground">{f.comment}</p>}
                            {!f.comment && <p className="text-xs text-muted-foreground italic">Sem comentário</p>}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-center text-muted-foreground py-8">Nenhum feedback encontrado.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* ============ PROGRESS TAB ============ */}
            <TabsContent value="progress">
              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <GraduationCap className="w-5 h-5" />
                    Progresso dos Alunos
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {progressLoading ? (
                    <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                  ) : studentProgress && studentProgress.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Aluno</TableHead>
                          <TableHead>Empresa</TableHead>
                          <TableHead>Módulos</TableHead>
                          <TableHead>Chat</TableHead>
                          <TableHead>Quizzes</TableHead>
                          <TableHead>Nota Média</TableHead>
                          <TableHead>Última Atividade</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {studentProgress.map((s: any) => (
                          <TableRow key={s.userId}>
                            <TableCell>
                              <div>
                                <p className="font-medium">{s.userName || "Sem nome"}</p>
                                <p className="text-xs text-muted-foreground">{s.userEmail}</p>
                              </div>
                            </TableCell>
                            <TableCell className="text-muted-foreground text-sm">{s.company || "-"}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className="font-mono">
                                <CheckCircle2 className="w-3 h-3 mr-1" />{s.totalCompleted}/{enhancedMetrics?.totalModules || 60}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="font-mono">
                                <MessageSquare className="w-3 h-3 mr-1" />{s.totalChatMessages}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="font-mono">
                                <GraduationCap className="w-3 h-3 mr-1" />{s.totalQuizAttempts}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {s.avgQuizScore ? (
                                <span className={`font-medium ${s.avgQuizScore >= 70 ? "text-green-500" : "text-yellow-500"}`}>
                                  {s.avgQuizScore}%
                                </span>
                              ) : "-"}
                            </TableCell>
                            <TableCell className="text-xs text-muted-foreground">
                              {s.lastActivity && new Date(s.lastActivity).getFullYear() > 2000
                                ? new Date(s.lastActivity).toLocaleDateString("pt-BR")
                                : "Sem atividade"}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <p className="text-center text-muted-foreground py-8">Nenhum aluno encontrado.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* ============ ENGAGEMENT TAB ============ */}
            <TabsContent value="engagement">
              {/* Quiz Performance */}
              <Card className="bg-card/50 border-border/50 mb-4">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Award className="w-5 h-5" />
                    Performance dos Quizzes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {quizPerfLoading ? (
                    <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                  ) : quizPerformance && quizPerformance.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Módulo</TableHead>
                          <TableHead>Trilha</TableHead>
                          <TableHead>Tentativas</TableHead>
                          <TableHead>Aprovações</TableHead>
                          <TableHead>Taxa</TableHead>
                          <TableHead>Nota Média</TableHead>
                          <TableHead>Alunos</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {quizPerformance.map((q: any, i: number) => {
                          const passRate = q.totalAttempts > 0 ? Math.round((q.passCount / q.totalAttempts) * 100) : 0;
                          return (
                            <TableRow key={i}>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <Badge variant="outline" className="font-mono text-xs">{q.moduleCode}</Badge>
                                  <span className="truncate max-w-[180px] text-sm">{q.quizTitle}</span>
                                </div>
                              </TableCell>
                              <TableCell><Badge className={categoryColors[q.category] || "bg-muted"}>{categoryLabels[q.category] || q.category}</Badge></TableCell>
                              <TableCell>{q.totalAttempts}</TableCell>
                              <TableCell>{q.passCount}</TableCell>
                              <TableCell>
                                <span className={`font-medium ${passRate >= 70 ? "text-green-500" : passRate >= 50 ? "text-yellow-500" : "text-red-400"}`}>
                                  {passRate}%
                                </span>
                              </TableCell>
                              <TableCell>{q.avgScore || "-"}%</TableCell>
                              <TableCell>{q.uniqueUsers}</TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  ) : (
                    <p className="text-center text-muted-foreground py-8">Nenhuma tentativa de quiz registrada.</p>
                  )}
                </CardContent>
              </Card>

              {/* Module Engagement */}
              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Activity className="w-5 h-5" />
                    Engajamento por Módulo
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {engagementLoading ? (
                    <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                  ) : moduleEngagement && moduleEngagement.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Módulo</TableHead>
                          <TableHead>Trilha</TableHead>
                          <TableHead>Conclusões</TableHead>
                          <TableHead>Chat Msgs</TableHead>
                          <TableHead>Usuários Chat</TableHead>
                          <TableHead>Feedbacks</TableHead>
                          <TableHead>Nota IA</TableHead>
                          <TableHead>Apostilas</TableHead>
                          <TableHead>Áudios</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {moduleEngagement.map((m: any) => (
                          <TableRow key={m.contentId}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Badge variant="outline" className="font-mono text-xs">{m.moduleCode}</Badge>
                                <span className="truncate max-w-[150px] text-sm">{m.title}</span>
                              </div>
                            </TableCell>
                            <TableCell><Badge className={categoryColors[m.category] || "bg-muted"}>{categoryLabels[m.category] || m.category}</Badge></TableCell>
                            <TableCell>{m.totalCompletions}</TableCell>
                            <TableCell>{m.totalChatMessages}</TableCell>
                            <TableCell>{m.uniqueChatUsers}</TableCell>
                            <TableCell>{m.totalFeedback}</TableCell>
                            <TableCell>
                              {m.avgFeedbackRating ? (
                                <div className="flex items-center gap-1">
                                  <Star className="w-3 h-3 fill-primary text-primary" />
                                  <span className="text-sm">{m.avgFeedbackRating}</span>
                                </div>
                              ) : "-"}
                            </TableCell>
                            <TableCell>
                              {m.hasApostila > 0 ? <Badge className="bg-green-500/10 text-green-500">{m.hasApostila}/4</Badge> : <XCircle className="w-4 h-4 text-muted-foreground" />}
                            </TableCell>
                            <TableCell>
                              {m.hasAudio > 0 ? <Badge className="bg-green-500/10 text-green-500">{m.hasAudio}/4</Badge> : <XCircle className="w-4 h-4 text-muted-foreground" />}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <p className="text-center text-muted-foreground py-8">Nenhum módulo encontrado.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* ============ RADAR TAB ============ */}
            <TabsContent value="radar">
              <div className="grid md:grid-cols-4 gap-4 mb-6">
                <Card className="bg-card/50 border-border/50">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center"><Compass className="w-5 h-5 text-primary" /></div>
                      <div><p className="text-2xl font-bold">{radarMetricsLoading ? "-" : radarMetrics?.total || 0}</p><p className="text-muted-foreground text-sm">Total Leads</p></div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-card/50 border-border/50">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center"><Target className="w-5 h-5 text-blue-500" /></div>
                      <div><p className="text-2xl font-bold">{radarMetricsLoading ? "-" : radarMetrics?.newLeads || 0}</p><p className="text-muted-foreground text-sm">Novos</p></div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-card/50 border-border/50">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-yellow-500/10 flex items-center justify-center"><Phone className="w-5 h-5 text-yellow-500" /></div>
                      <div><p className="text-2xl font-bold">{radarMetricsLoading ? "-" : radarMetrics?.contacted || 0}</p><p className="text-muted-foreground text-sm">Contatados</p></div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-card/50 border-border/50">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center"><CheckCircle2 className="w-5 h-5 text-green-500" /></div>
                      <div><p className="text-2xl font-bold">{radarMetricsLoading ? "-" : radarMetrics?.converted || 0}</p><p className="text-muted-foreground text-sm">Convertidos</p></div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Segment Distribution */}
              <Card className="bg-card/50 border-border/50 mb-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><PieChart className="w-5 h-5" />Segmentação por Desafios</CardTitle>
                </CardHeader>
                <CardContent>
                  {radarMetricsLoading ? (
                    <div className="flex justify-center py-4"><Loader2 className="w-5 h-5 animate-spin" /></div>
                  ) : (
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                        {[
                          { id: "dados", label: "Dados & Integração", icon: "📊", color: "#3B82F6" },
                          { id: "cx", label: "CX & Jornada", icon: "🎯", color: "#8B5CF6" },
                          { id: "ia", label: "IA & Automação", icon: "🤖", color: "#10B981" },
                          { id: "governanca", label: "Governança", icon: "🛡️", color: "#F59E0B" },
                          { id: "cultura", label: "Cultura & Liderança", icon: "🧠", color: "#EF4444" },
                        ].map((seg) => {
                          const segCount = (radarMetrics as any)?.segments?.[seg.id] || 0;
                          const total = radarMetrics?.total || 1;
                          const pct = total > 0 ? Math.round((segCount / total) * 100) : 0;
                          return (
                            <div
                              key={seg.id}
                              className={`rounded-xl p-4 border cursor-pointer transition-all hover:scale-[1.02] ${
                                selectedSegmentFilter === seg.id ? "ring-2 ring-offset-2 ring-offset-background" : "border-border/50"
                              }`}
                              style={{ borderColor: selectedSegmentFilter === seg.id ? seg.color : undefined, background: `${seg.color}10` }}
                              onClick={() => setSelectedSegmentFilter(selectedSegmentFilter === seg.id ? "all" : seg.id)}
                            >
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-lg">{seg.icon}</span>
                                <span className="text-2xl font-bold" style={{ color: seg.color }}>{segCount}</span>
                              </div>
                              <p className="text-xs font-medium text-muted-foreground">{seg.label}</p>
                              <div className="mt-2 h-1.5 bg-muted rounded-full overflow-hidden">
                                <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: seg.color }} />
                              </div>
                              <p className="text-[10px] text-muted-foreground mt-1">{pct}% dos leads</p>
                              <Button
                                variant="outline"
                                size="sm"
                                className="w-full mt-2 text-xs h-7"
                                style={{ borderColor: `${seg.color}40`, color: seg.color }}
                                disabled={segCount === 0 || nurtureSendingSegment === seg.id || sendSegmentNurtureMutation.isPending}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (confirm(`Enviar email de nurture personalizado para ${segCount} leads do segmento "${seg.label}"?`)) {
                                    setNurtureSendingSegment(seg.id);
                                    sendSegmentNurtureMutation.mutate({ segment: seg.id });
                                  }
                                }}
                              >
                                {nurtureSendingSegment === seg.id ? (
                                  <><Loader2 className="w-3 h-3 animate-spin mr-1" />Enviando...</>
                                ) : (
                                  <><Send className="w-3 h-3 mr-1" />Nurture</>
                                )}
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="w-full mt-1 text-xs h-7"
                                style={{ borderColor: '#25D36640', color: '#25D366' }}
                                disabled={segCount === 0 || whatsappSendingSegment === seg.id || sendWhatsappFollowupMutation.isPending}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (confirm(`Enviar follow-up via WhatsApp para leads do segmento "${seg.label}" que autorizaram?`)) {
                                    setWhatsappSendingSegment(seg.id);
                                    sendWhatsappFollowupMutation.mutate({ segment: seg.id });
                                  }
                                }}
                              >
                                {whatsappSendingSegment === seg.id ? (
                                  <><Loader2 className="w-3 h-3 animate-spin mr-1" />Enviando...</>
                                ) : (
                                  <><MessageSquare className="w-3 h-3 mr-1" />WhatsApp</>
                                )}
                              </Button>
                            </div>
                          );
                        })}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {(radarMetrics as any)?.segments?.none || 0} leads sem segmento definido. Clique em um segmento para filtrar a tabela abaixo.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Segment Trends Chart */}
              {segmentTrendData.length > 0 && (
                <Card className="bg-card/50 border-border/50 mb-6">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2"><TrendingUp className="w-5 h-5" />Evolução Temporal dos Segmentos</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={segmentTrendData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                          <defs>
                            <linearGradient id="gradDados" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                            </linearGradient>
                            <linearGradient id="gradCx" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0} />
                            </linearGradient>
                            <linearGradient id="gradIa" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#10B981" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                            </linearGradient>
                            <linearGradient id="gradGov" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="#F59E0B" stopOpacity={0} />
                            </linearGradient>
                            <linearGradient id="gradCultura" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#EF4444" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="#EF4444" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                          <XAxis dataKey="month" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }} />
                          <YAxis tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }} allowDecimals={false} />
                          <RechartsTooltip
                            contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, color: "hsl(var(--foreground))" }}
                            labelStyle={{ color: "hsl(var(--foreground))", fontWeight: 600 }}
                          />
                          <Legend wrapperStyle={{ fontSize: 12 }} />
                          <Area type="monotone" dataKey="dados" name="📊 Dados" stroke="#3B82F6" fill="url(#gradDados)" strokeWidth={2} />
                          <Area type="monotone" dataKey="cx" name="🎯 CX" stroke="#8B5CF6" fill="url(#gradCx)" strokeWidth={2} />
                          <Area type="monotone" dataKey="ia" name="🤖 IA" stroke="#10B981" fill="url(#gradIa)" strokeWidth={2} />
                          <Area type="monotone" dataKey="governanca" name="🛡️ Gov" stroke="#F59E0B" fill="url(#gradGov)" strokeWidth={2} />
                          <Area type="monotone" dataKey="cultura" name="🧠 Cultura" stroke="#EF4444" fill="url(#gradCultura)" strokeWidth={2} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="flex flex-wrap gap-4 mt-4 pt-3 border-t border-border">
                      {segmentTrendData.length >= 2 && (() => {
                        const latest = segmentTrendData[segmentTrendData.length - 1];
                        const prev = segmentTrendData[segmentTrendData.length - 2];
                        const segments = [
                          { key: "dados", label: "Dados", color: "#3B82F6" },
                          { key: "cx", label: "CX", color: "#8B5CF6" },
                          { key: "ia", label: "IA", color: "#10B981" },
                          { key: "governanca", label: "Gov", color: "#F59E0B" },
                          { key: "cultura", label: "Cultura", color: "#EF4444" },
                        ];
                        return segments.map((seg) => {
                          const curr = (latest as any)[seg.key] || 0;
                          const prevVal = (prev as any)[seg.key] || 0;
                          const diff = curr - prevVal;
                          const pctChange = prevVal > 0 ? Math.round((diff / prevVal) * 100) : curr > 0 ? 100 : 0;
                          return (
                            <div key={seg.key} className="flex items-center gap-1.5 text-xs">
                              <span className="w-2 h-2 rounded-full" style={{ background: seg.color }} />
                              <span className="text-muted-foreground">{seg.label}:</span>
                              {diff > 0 ? (
                                <span className="flex items-center text-green-500 font-medium"><TrendingUp className="w-3 h-3 mr-0.5" />+{pctChange}%</span>
                              ) : diff < 0 ? (
                                <span className="flex items-center text-red-500 font-medium"><TrendingDown className="w-3 h-3 mr-0.5" />{pctChange}%</span>
                              ) : (
                                <span className="text-muted-foreground font-medium">0%</span>
                              )}
                            </div>
                          );
                        });
                      })()}
                    </div>
                  </CardContent>
                </Card>
              )}

              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2"><Compass className="w-5 h-5" />Leads do Radar Vértice</CardTitle>
                    <Button onClick={() => refetchRadar()} variant="outline" size="sm"><RefreshCw className="w-4 h-4 mr-2" />Atualizar</Button>
                  </div>
                  <div className="relative mt-3">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      placeholder="Buscar por nome, email ou desafios..."
                      className="pl-9 bg-background"
                      value={leadSearchQuery}
                      onChange={(e) => setLeadSearchQuery(e.target.value)}
                    />
                  </div>
                </CardHeader>
                <CardContent>
                  {radarLoading ? (
                    <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                  ) : radarLeads && radarLeads.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Nome</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Persona</TableHead>
                          <TableHead>Score</TableHead>
                          <TableHead>Segmento</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Desafios</TableHead>
                          <TableHead>Data</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {(() => {
                          const segmentLabels: Record<string, { label: string; color: string; icon: string }> = {
                            dados: { label: "Dados", color: "#3B82F6", icon: "📊" },
                            cx: { label: "CX", color: "#8B5CF6", icon: "🎯" },
                            ia: { label: "IA", color: "#10B981", icon: "🤖" },
                            governanca: { label: "Gov", color: "#F59E0B", icon: "🛡️" },
                            cultura: { label: "Cultura", color: "#EF4444", icon: "🧠" },
                          };
                          let filtered = radarLeads || [];
                          // Filter by segment
                          if (selectedSegmentFilter !== "all") {
                            filtered = filtered.filter((lead: any) => lead.challengeSegment === selectedSegmentFilter);
                          }
                          // Filter by search
                          if (leadSearchQuery.trim()) {
                            const q = leadSearchQuery.toLowerCase();
                            filtered = filtered.filter((lead: any) =>
                              (lead.name || "").toLowerCase().includes(q) ||
                              (lead.email || "").toLowerCase().includes(q) ||
                              (lead.challenges || "").toLowerCase().includes(q)
                            );
                          }
                          return filtered.map((lead: any) => {
                            const seg = segmentLabels[lead.challengeSegment as string];
                            return (
                              <TableRow key={lead.id} className="cursor-pointer hover:bg-muted/30" onClick={() => setSelectedLead(lead)}>
                                <TableCell className="font-medium">{lead.name}</TableCell>
                                <TableCell className="text-muted-foreground text-sm">{lead.email}</TableCell>
                                <TableCell><Badge variant="outline">{lead.persona}</Badge></TableCell>
                                <TableCell className="font-mono">{lead.scoreTotal || "-"}</TableCell>
                                <TableCell>
                                  {seg ? (
                                    <Badge style={{ background: `${seg.color}20`, color: seg.color, border: `1px solid ${seg.color}40` }}>
                                      {seg.icon} {seg.label}
                                    </Badge>
                                  ) : (
                                    <span className="text-muted-foreground text-xs">-</span>
                                  )}
                                </TableCell>
                                <TableCell><Badge className={statusColors[lead.status]}>{statusLabels[lead.status] || lead.status}</Badge></TableCell>
                                <TableCell className="text-muted-foreground text-xs max-w-[200px] truncate" title={lead.challenges || ""}>{lead.challenges ? lead.challenges.substring(0, 60) + (lead.challenges.length > 60 ? "..." : "") : "-"}</TableCell>
                                <TableCell className="text-muted-foreground text-sm">{new Date(lead.createdAt).toLocaleDateString("pt-BR")}</TableCell>
                              </TableRow>
                            );
                          });
                        })()}
                      </TableBody>
                    </Table>
                  ) : (
                    <p className="text-center text-muted-foreground py-8">Nenhum lead registrado.</p>
                  )}
                </CardContent>
              </Card>

              {/* Lead Detail Dialog */}
              <Dialog open={!!selectedLead} onOpenChange={(open) => !open && setSelectedLead(null)}>
                <DialogContent className="max-w-lg">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <Compass className="w-5 h-5 text-primary" />
                      Detalhes do Lead
                    </DialogTitle>
                  </DialogHeader>
                  {selectedLead && (
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <p className="text-xs text-muted-foreground">Nome</p>
                          <p className="font-medium">{selectedLead.name}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Email</p>
                          <p className="text-sm">{selectedLead.email}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Persona</p>
                          <Badge variant="outline">{selectedLead.persona}</Badge>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Score Total</p>
                          <p className="font-mono font-bold">{selectedLead.scoreTotal || "-"}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Produto Recomendado</p>
                          <Badge className="bg-primary/10 text-primary">{selectedLead.recommendedProduct || "-"}</Badge>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Nível</p>
                          <p className="text-sm">{selectedLead.recommendedLevel || "-"}</p>
                        </div>
                        {selectedLead.phone && (
                          <div>
                            <p className="text-xs text-muted-foreground">Telefone</p>
                            <p className="text-sm">{selectedLead.phone}</p>
                          </div>
                        )}
                        {selectedLead.sector && (
                          <div>
                            <p className="text-xs text-muted-foreground">Setor</p>
                            <p className="text-sm">{selectedLead.sector}</p>
                          </div>
                        )}
                        <div>
                          <p className="text-xs text-muted-foreground">Data</p>
                          <p className="text-sm">{new Date(selectedLead.createdAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" })}</p>
                        </div>
                        {selectedLead.challengeSegment && (
                          <div>
                            <p className="text-xs text-muted-foreground">Segmento</p>
                            <Badge style={{
                              background: { dados: "#3B82F620", cx: "#8B5CF620", ia: "#10B98120", governanca: "#F59E0B20", cultura: "#EF444420" }[selectedLead.challengeSegment as string] || "#6b728020",
                              color: { dados: "#3B82F6", cx: "#8B5CF6", ia: "#10B981", governanca: "#F59E0B", cultura: "#EF4444" }[selectedLead.challengeSegment as string] || "#6b7280",
                            }}>
                              {{ dados: "📊 Dados", cx: "🎯 CX", ia: "🤖 IA", governanca: "🛡️ Gov", cultura: "🧠 Cultura" }[selectedLead.challengeSegment as string] || selectedLead.challengeSegment}
                            </Badge>
                          </div>
                        )}
                      </div>

                      {/* Scores por dimensão */}
                      <div className="border-t border-border pt-3">
                        <p className="text-xs text-muted-foreground mb-2 font-medium">Scores por Dimensão</p>
                        <div className="grid grid-cols-4 gap-2">
                          {[
                            { label: "CX", value: selectedLead.scoreCX, color: "text-blue-400" },
                            { label: "Dados", value: selectedLead.scoreData, color: "text-emerald-400" },
                            { label: "IA", value: selectedLead.scoreIA, color: "text-purple-400" },
                            { label: "Gov", value: selectedLead.scoreGovernance, color: "text-amber-400" },
                          ].map((dim) => (
                            <div key={dim.label} className="text-center bg-muted/30 rounded-lg p-2">
                              <p className={`text-lg font-bold ${dim.color}`}>{dim.value || "-"}</p>
                              <p className="text-[10px] text-muted-foreground">{dim.label}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Desafios */}
                      {selectedLead.challenges && (
                        <div className="border-t border-border pt-3">
                          <p className="text-xs text-muted-foreground mb-2 font-medium flex items-center gap-1">
                            <Target className="w-3 h-3" /> Desafios e Contexto
                          </p>
                          <div className="bg-muted/20 rounded-lg p-3 text-sm whitespace-pre-wrap">
                            {selectedLead.challenges}
                          </div>
                        </div>
                      )}

                      {/* WhatsApp Consent & Follow-up */}
                      <div className="border-t border-border pt-3">
                        <p className="text-xs text-muted-foreground mb-2 font-medium flex items-center gap-1">
                          <MessageSquare className="w-3 h-3" /> WhatsApp
                        </p>
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${selectedLead.consentWhatsapp ? 'bg-green-500' : 'bg-red-400'}`} />
                            <span className="text-sm">{selectedLead.consentWhatsapp ? 'Autorizado' : 'Não autorizado'}</span>
                          </div>
                          {selectedLead.phone && (
                            <span className="text-sm text-muted-foreground">{selectedLead.phone}</span>
                          )}
                          {selectedLead.consentWhatsapp && selectedLead.phone && (
                            <Button
                              variant="outline"
                              size="sm"
                              className="ml-auto text-xs h-7"
                              style={{ borderColor: '#25D36640', color: '#25D366' }}
                              disabled={sendWhatsappFollowupMutation.isPending}
                              onClick={() => {
                                if (confirm(`Enviar follow-up via WhatsApp para ${selectedLead.name}?`)) {
                                  sendWhatsappFollowupMutation.mutate({ leadIds: [selectedLead.id] });
                                }
                              }}
                            >
                              <MessageSquare className="w-3 h-3 mr-1" />Enviar WhatsApp
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                  <DialogFooter>
                    <DialogClose asChild>
                      <Button variant="outline">Fechar</Button>
                    </DialogClose>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </TabsContent>

            {/* ============ CONTACTS TAB ============ */}
            <TabsContent value="contacts">
              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2"><Mail className="w-5 h-5" />Contatos</CardTitle>
                    <Button onClick={() => refetchContacts()} variant="outline" size="sm"><RefreshCw className="w-4 h-4 mr-2" />Atualizar</Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {contactsLoading ? (
                    <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                  ) : contacts && contacts.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Nome</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Telefone</TableHead>
                          <TableHead>Empresa</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Data</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {contacts.map((c: any) => (
                          <TableRow key={c.id}>
                            <TableCell className="font-medium">{c.name}</TableCell>
                            <TableCell className="text-muted-foreground text-sm">{c.email}</TableCell>
                            <TableCell className="text-muted-foreground text-sm">{c.phone || "-"}</TableCell>
                            <TableCell className="text-muted-foreground text-sm">{c.company || "-"}</TableCell>
                            <TableCell><Badge className={statusColors[c.status]}>{statusLabels[c.status]}</Badge></TableCell>
                            <TableCell className="text-muted-foreground text-sm">{new Date(c.createdAt).toLocaleDateString("pt-BR")}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <p className="text-center text-muted-foreground py-8">Nenhum contato registrado.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* ============ USERS TAB ============ */}
            <TabsContent value="users">
              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                    <CardTitle className="flex items-center gap-2"><Users className="w-5 h-5" />Usuários</CardTitle>
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input placeholder="Buscar por nome, email ou empresa..." value={searchUsers} onChange={e => setSearchUsers(e.target.value)} className="pl-8 h-9 w-72" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {usersLoading ? (
                    <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                  ) : filteredUsers.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Nome</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Perfil</TableHead>
                          <TableHead>Empresa</TableHead>
                          <TableHead>Cadastro</TableHead>
                          <TableHead>Último Acesso</TableHead>
                          <TableHead>Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredUsers.map((u: any) => (
                          <TableRow key={u.id}>
                            <TableCell className="font-medium">{u.name || "-"}</TableCell>
                            <TableCell className="text-muted-foreground text-sm">{u.email || "-"}</TableCell>
                            <TableCell><Badge className={u.role === "admin" ? "bg-primary/10 text-primary" : "bg-muted"}>{u.role === "admin" ? "Admin" : "Usuário"}</Badge></TableCell>
                            <TableCell className="text-muted-foreground text-sm">{u.company || "-"}</TableCell>
                            <TableCell className="text-muted-foreground text-sm">{new Date(u.createdAt).toLocaleDateString("pt-BR")}</TableCell>
                            <TableCell className="text-muted-foreground text-sm">{new Date(u.lastSignedIn).toLocaleDateString("pt-BR")}</TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                <UserEditDialog user={u} onSuccess={() => window.location.reload()} />
                                <UserDeleteDialog user={u} currentUserId={user?.id} onSuccess={() => window.location.reload()} />
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <p className="text-center text-muted-foreground py-8">{searchUsers ? "Nenhum usuário encontrado." : "Nenhum usuário cadastrado."}</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* ============ ENROLLMENTS TAB ============ */}
            <TabsContent value="enrollments">
              <Card className="bg-card/50 border-border/50">
                <CardHeader><CardTitle className="flex items-center gap-2"><BookOpen className="w-5 h-5" />Matrículas</CardTitle></CardHeader>
                <CardContent>
                  {enrollmentsLoading ? (
                    <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                  ) : enrollments && enrollments.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Usuário</TableHead>
                          <TableHead>Programa</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Pagamento</TableHead>
                          <TableHead>Início</TableHead>
                          <TableHead>Término</TableHead>
                          <TableHead>Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {enrollments.map((e: any) => (
                          <TableRow key={e.id}>
                            <TableCell>#{e.id}</TableCell>
                            <TableCell>{e.userId}</TableCell>
                            <TableCell>{e.programId}</TableCell>
                            <TableCell><Badge className={statusColors[e.status]}>{statusLabels[e.status]}</Badge></TableCell>
                            <TableCell><Badge className={statusColors[e.paymentStatus]}>{statusLabels[e.paymentStatus]}</Badge></TableCell>
                            <TableCell className="text-muted-foreground text-sm">{new Date(e.createdAt).toLocaleDateString("pt-BR")}</TableCell>
                            <TableCell className="text-muted-foreground text-sm">{e.endDate ? new Date(e.endDate).toLocaleDateString("pt-BR") : "-"}</TableCell>
                            <TableCell><EditEnrollmentDateDialog enrollment={e} onSuccess={() => refetchEnrollments()} /></TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <p className="text-center text-muted-foreground py-8">Nenhuma matrícula registrada.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* ============ CONTENTS TAB ============ */}
            <TabsContent value="contents">
              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                    <CardTitle className="flex items-center gap-2"><BookOpen className="w-5 h-5" />Conteúdos</CardTitle>
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input placeholder="Buscar por título ou código..." value={searchContents} onChange={e => setSearchContents(e.target.value)} className="pl-8 h-9 w-64" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {contentsLoading ? (
                    <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                  ) : filteredContents.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Código</TableHead>
                          <TableHead>Título</TableHead>
                          <TableHead>Trilha</TableHead>
                          <TableHead>Tipo</TableHead>
                          <TableHead>Vídeo</TableHead>
                          <TableHead>Público</TableHead>
                          <TableHead>Liberação</TableHead>
                          <TableHead>Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredContents.map((c: any) => (
                          <TableRow key={c.id}>
                            <TableCell><Badge variant="outline" className="font-mono text-xs">{c.moduleCode || "-"}</Badge></TableCell>
                            <TableCell className="font-medium max-w-[200px] truncate">{c.title}</TableCell>
                            <TableCell><Badge className={categoryColors[c.category] || "bg-muted"}>{categoryLabels[c.category] || c.category}</Badge></TableCell>
                            <TableCell><Badge variant="outline">{c.type}</Badge></TableCell>
                            <TableCell>{c.videoUrl ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <XCircle className="w-4 h-4 text-muted-foreground" />}</TableCell>
                            <TableCell>{c.isPublic ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <XCircle className="w-4 h-4 text-muted-foreground" />}</TableCell>
                            <TableCell>
                              {c.releaseDate ? (
                                <span className={`text-xs font-medium ${new Date(c.releaseDate) > new Date() ? 'text-amber-400' : 'text-green-400'}`}>
                                  {new Date(c.releaseDate).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}
                                </span>
                              ) : (
                                <span className="text-xs text-muted-foreground">Imediato</span>
                              )}
                            </TableCell>
                            <TableCell><ContentEditDialog content={c} onSuccess={() => refetchContents()} /></TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <p className="text-center text-muted-foreground py-8">{searchContents ? "Nenhum conteúdo encontrado." : "Nenhum conteúdo cadastrado."}</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* ============ SCHEDULE TAB ============ */}
            <TabsContent value="schedule">
              <ScheduleTab contents={contents || []} onRefresh={() => refetchContents()} />
            </TabsContent>

            {/* ============ COUPONS TAB ============ */}
            <TabsContent value="coupons">
              <div className="grid md:grid-cols-4 gap-4 mb-6">
                <Card className="bg-card/50 border-border/50">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center"><Ticket className="w-5 h-5 text-primary" /></div>
                      <div><p className="text-2xl font-bold">{couponMetricsLoading ? "-" : couponMetrics?.totalCoupons || 0}</p><p className="text-muted-foreground text-sm">Total Cupons</p></div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-card/50 border-border/50">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center"><CheckCircle2 className="w-5 h-5 text-green-500" /></div>
                      <div><p className="text-2xl font-bold">{couponMetricsLoading ? "-" : couponMetrics?.activeCoupons || 0}</p><p className="text-muted-foreground text-sm">Ativos</p></div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-card/50 border-border/50">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center"><BarChart3 className="w-5 h-5 text-blue-500" /></div>
                      <div><p className="text-2xl font-bold">{couponMetricsLoading ? "-" : couponMetrics?.totalUsages || 0}</p><p className="text-muted-foreground text-sm">Usos</p></div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-card/50 border-border/50">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-yellow-500/10 flex items-center justify-center"><DollarSign className="w-5 h-5 text-yellow-500" /></div>
                      <div><p className="text-2xl font-bold">{couponMetricsLoading ? "-" : `R$ ${(couponMetrics?.totalDiscount || 0).toLocaleString("pt-BR")}`}</p><p className="text-muted-foreground text-sm">Desconto Total</p></div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2"><Ticket className="w-5 h-5" />Cupons de Desconto</CardTitle>
                    <Button size="sm" onClick={() => setShowCreateCoupon(!showCreateCoupon)}><Plus className="w-4 h-4 mr-2" />Novo Cupom</Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {showCreateCoupon && (
                    <div className="mb-6 p-4 rounded-lg border border-border/50 bg-muted/20 space-y-4">
                      <h3 className="font-semibold">Criar Cupom</h3>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2"><Label>Código</Label><Input value={couponForm.code} onChange={e => setCouponForm({ ...couponForm, code: e.target.value.toUpperCase() })} placeholder="EX: DESCONTO10" /></div>
                        <div className="space-y-2"><Label>Nome</Label><Input value={couponForm.name} onChange={e => setCouponForm({ ...couponForm, name: e.target.value })} placeholder="Desconto de lançamento" /></div>
                        <div className="space-y-2">
                          <Label>Tipo</Label>
                          <Select value={couponForm.discountType} onValueChange={v => setCouponForm({ ...couponForm, discountType: v as any })}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="percentage">Percentual (%)</SelectItem>
                              <SelectItem value="fixed">Valor Fixo (R$)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2"><Label>Valor</Label><Input type="number" value={couponForm.discountValue} onChange={e => setCouponForm({ ...couponForm, discountValue: Number(e.target.value) })} /></div>
                        <div className="space-y-2"><Label>Limite de Uso</Label><Input type="number" value={couponForm.usageLimit || ""} onChange={e => setCouponForm({ ...couponForm, usageLimit: e.target.value ? Number(e.target.value) : undefined })} placeholder="Ilimitado" /></div>
                        <div className="space-y-2"><Label>Válido até</Label><Input type="date" value={couponForm.validUntil} onChange={e => setCouponForm({ ...couponForm, validUntil: e.target.value })} /></div>
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={() => {
                          if (!couponForm.code || !couponForm.name) { toast.error("Preencha código e nome"); return; }
                          createCouponMutation.mutate({ code: couponForm.code, name: couponForm.name, description: couponForm.description || undefined, discountType: couponForm.discountType, discountValue: couponForm.discountValue, usageLimit: couponForm.usageLimit, validUntil: couponForm.validUntil ? new Date(couponForm.validUntil) : undefined });
                        }} disabled={createCouponMutation.isPending}>
                          {createCouponMutation.isPending && <Loader2 className="h-4 w-4 animate-spin mr-2" />}Criar
                        </Button>
                        <Button variant="outline" onClick={() => { setShowCreateCoupon(false); resetCouponForm(); }}>Cancelar</Button>
                      </div>
                    </div>
                  )}
                  {couponsLoading ? (
                    <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                  ) : allCoupons && allCoupons.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Código</TableHead>
                          <TableHead>Nome</TableHead>
                          <TableHead>Desconto</TableHead>
                          <TableHead>Usos</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {allCoupons.map((c: any) => (
                          <TableRow key={c.id}>
                            <TableCell className="font-mono font-bold">{c.code}</TableCell>
                            <TableCell>{c.name}</TableCell>
                            <TableCell>{c.discountType === "percentage" ? `${c.discountValue}%` : `R$ ${c.discountValue}`}</TableCell>
                            <TableCell>{c.usageCount || 0}{c.usageLimit ? `/${c.usageLimit}` : ""}</TableCell>
                            <TableCell><Badge className={c.isActive ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"}>{c.isActive ? "Ativo" : "Inativo"}</Badge></TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                <Button variant="ghost" size="sm" onClick={() => toggleCouponMutation.mutate({ id: c.id })}>{c.isActive ? "Desativar" : "Ativar"}</Button>
                                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => deleteCouponMutation.mutate({ id: c.id })}><Trash2 className="h-4 w-4" /></Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <p className="text-center text-muted-foreground py-8">Nenhum cupom cadastrado.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* ============ QUIZZES TAB ============ */}
            <TabsContent value="quizzes">
              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2"><FileText className="w-5 h-5" />Gerenciar Quizzes</CardTitle>
                    <QuizCreateDialog onSuccess={() => {}} />
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">Crie quizzes para avaliar o aprendizado dos alunos ao final de cada módulo.</p>
                  <QuizzesList />
                </CardContent>
              </Card>
            </TabsContent>

            {/* ============ AUDIT TAB ============ */}
            <TabsContent value="audit">
              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2"><History className="w-5 h-5" />Logs de Auditoria</CardTitle>
                    <Button onClick={() => refetchAudit()} variant="outline" size="sm"><RefreshCw className="w-4 h-4 mr-2" />Atualizar</Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {auditLoading ? (
                    <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                  ) : auditLogs && auditLogs.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Data/Hora</TableHead>
                          <TableHead>Usuário</TableHead>
                          <TableHead>Ação</TableHead>
                          <TableHead>Entidade</TableHead>
                          <TableHead>Detalhes</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {auditLogs.map((log: any) => (
                          <TableRow key={log.id}>
                            <TableCell className="text-sm">{new Date(log.createdAt).toLocaleString("pt-BR")}</TableCell>
                            <TableCell><Badge variant="outline">{log.userName || `User #${log.userId}`}</Badge></TableCell>
                            <TableCell>
                              <Badge className={({ create: "bg-green-500/10 text-green-500", update: "bg-blue-500/10 text-blue-500", delete: "bg-red-500/10 text-red-500", login: "bg-primary/10 text-primary" } as Record<string, string>)[log.action as string] || "bg-muted"}>
                                {log.action}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-mono text-sm">{log.entityType} #{log.entityId}</TableCell>
                            <TableCell className="max-w-xs truncate text-sm text-muted-foreground">{log.details || "-"}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="text-center py-8">
                      <Shield className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">Nenhum log de auditoria registrado.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* ============ ACCESS MANAGEMENT TAB ============ */}
            <TabsContent value="access">
              <AccessManagementTab allUsers={allUsers || []} />
            </TabsContent>

            {/* ============ WORKSPACE TAB ============ */}
            <TabsContent value="workspace">
              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2"><FolderKanban className="w-5 h-5" />Projetos de Consultoria</CardTitle>
                    <Button onClick={() => refetchProjects()} variant="outline" size="sm"><RefreshCw className="w-4 h-4 mr-2" />Atualizar</Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {projectsLoading ? (
                    <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin" /></div>
                  ) : projects && projects.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Projeto</TableHead>
                          <TableHead>Cliente</TableHead>
                          <TableHead>Etapa</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Tarefas</TableHead>
                          <TableHead className="text-right">Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {projects.map((p: any) => (
                          <TableRow key={p.id}>
                            <TableCell className="font-medium">{p.name}</TableCell>
                            <TableCell>{p.clientName || `Cliente #${p.clientUserId}`}</TableCell>
                            <TableCell><Badge variant="outline">Etapa {p.currentPhase}/5</Badge></TableCell>
                            <TableCell><Badge className={statusColors[p.status] || "bg-muted"}>{statusLabels[p.status] || p.status}</Badge></TableCell>
                            <TableCell>{p.completedTasks || 0}/{p.totalTasks || 0}</TableCell>
                            <TableCell className="text-right">
                              <Link href={`/workspace/${p.id}`}><Button variant="ghost" size="sm"><Eye className="w-4 h-4 mr-1" />Ver</Button></Link>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="text-center py-8">
                      <Briefcase className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground mb-2">Nenhum projeto de consultoria cadastrado.</p>
                      <p className="text-sm text-muted-foreground">Projetos são criados automaticamente quando clientes enterprise contratam consultoria.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
             {/* ============ SAÚDE DO PORTAL TAB ============ */}
            <TabsContent value="health">
              <Card className="bg-card/50 border-border/50 mb-4">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Activity className="w-5 h-5 text-emerald-400" />
                    Saúde do Portal
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    {/* Status Cards */}
                    <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-sm font-medium text-emerald-400">Servidor</span>
                      </div>
                      <p className="text-2xl font-bold text-emerald-300">Online</p>
                      <p className="text-xs text-muted-foreground mt-1">Tempo de atividade: 99.9%</p>
                    </div>
                    <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-sm font-medium text-emerald-400">Banco de Dados</span>
                      </div>
                      <p className="text-2xl font-bold text-emerald-300">Conectado</p>
                      <p className="text-xs text-muted-foreground mt-1">TiDB Cloud (MySQL)</p>
                    </div>
                    <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-sm font-medium text-emerald-400">E-mail (Resend)</span>
                      </div>
                      <p className="text-2xl font-bold text-emerald-300">Ativo</p>
                      <p className="text-xs text-muted-foreground mt-1">Régua de nurture + transacional</p>
                    </div>
                    <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-sm font-medium text-emerald-400">Stripe</span>
                      </div>
                      <p className="text-2xl font-bold text-emerald-300">Sandbox</p>
                      <p className="text-xs text-muted-foreground mt-1">Modo teste ativo</p>
                    </div>
                  </div>

                  {/* Páginas Monitoradas */}
                  <h3 className="text-sm font-semibold text-foreground/80 mb-3">Páginas Principais</h3>
                  <div className="space-y-2 mb-6">
                    {[
                      { path: "/", name: "Home", status: "ok" },
                      { path: "/ofertas", name: "Ofertas", status: "ok" },
                      { path: "/contato", name: "Contato", status: "ok" },
                      { path: "/radar", name: "Radar Vértice", status: "ok" },
                      { path: "/membros", name: "Área de Membros", status: "ok" },
                      { path: "/comunidade", name: "Comunidade", status: "ok" },
                      { path: "/sobre", name: "Sobre", status: "ok" },
                      { path: "/ajuda", name: "Central de Ajuda", status: "ok" },
                      { path: "/upgrade", name: "Upgrade", status: "ok" },
                      { path: "/login", name: "Login", status: "ok" },
                    ].map((page) => (
                      <div key={page.path} className="flex items-center justify-between p-2 rounded bg-background/50 border border-border/30">
                        <div className="flex items-center gap-3">
                          <div className={`w-2.5 h-2.5 rounded-full ${page.status === "ok" ? "bg-emerald-500" : page.status === "slow" ? "bg-amber-500" : "bg-red-500"}`} />
                          <span className="text-sm font-medium">{page.name}</span>
                          <span className="text-xs text-muted-foreground">{page.path}</span>
                        </div>
                        <Badge variant="outline" className={page.status === "ok" ? "text-emerald-400 border-emerald-500/30" : page.status === "slow" ? "text-amber-400 border-amber-500/30" : "text-red-400 border-red-500/30"}>
                          {page.status === "ok" ? "OK" : page.status === "slow" ? "Lento" : "Erro"}
                        </Badge>
                      </div>
                    ))}
                  </div>

                  {/* Integrações */}
                  <h3 className="text-sm font-semibold text-foreground/80 mb-3">Integrações Externas</h3>
                  <div className="space-y-2 mb-6">
                    {[
                      { name: "Stripe Payments", status: "Sandbox", desc: "Pagamentos em modo teste" },
                      { name: "Resend E-mail", status: "Ativo", desc: "E-mails transacionais e nurture" },
                      { name: "Make.com Webhook", status: "Configurado", desc: "Alertas WhatsApp" },
                      { name: "OpenAI GPT", status: "Ativo", desc: "Chat IA + Análise Radar" },
                      { name: "Manus OAuth", status: "Ativo", desc: "Login admin" },
                      { name: "S3 Storage", status: "Ativo", desc: "Armazenamento de arquivos" },
                    ].map((integration) => (
                      <div key={integration.name} className="flex items-center justify-between p-2 rounded bg-background/50 border border-border/30">
                        <div>
                          <span className="text-sm font-medium">{integration.name}</span>
                          <p className="text-xs text-muted-foreground">{integration.desc}</p>
                        </div>
                        <Badge variant="outline" className="text-emerald-400 border-emerald-500/30">{integration.status}</Badge>
                      </div>
                    ))}
                  </div>

                  {/* Checklist de Produção */}
                  <h3 className="text-sm font-semibold text-foreground/80 mb-3">Checklist para Produção</h3>
                  <div className="space-y-2">
                    {[
                      { item: "Configurar Stripe em produção (Settings → Payment)", done: false },
                      { item: "Vincular conta bancária no Stripe", done: false },
                      { item: "Adicionar URLs do YouTube nos módulos", done: false },
                      { item: "Revisar valores dos planos", done: false },
                      { item: "Publicar o projeto (botão Publish)", done: false },
                      { item: "Configurar domínio personalizado", done: false },
                      { item: "Lazy loading em todas as páginas", done: true },
                      { item: "SEO e meta tags configurados", done: true },
                      { item: "Certificados automáticos", done: true },
                      { item: "Régua de e-mails configurada", done: true },
                      { item: "PWA (manifest + service worker)", done: true },
                      { item: "LGPD/Privacidade", done: true },
                    ].map((check) => (
                      <div key={check.item} className="flex items-center gap-3 p-2 rounded bg-background/50 border border-border/30">
                        <div className={`w-5 h-5 rounded flex items-center justify-center ${check.done ? "bg-emerald-500/20 text-emerald-400" : "bg-muted/50 text-muted-foreground"}`}>
                          {check.done ? <CheckCircle2 className="w-3.5 h-3.5" /> : <div className="w-3 h-3 rounded-sm border border-muted-foreground/40" />}
                        </div>
                        <span className={`text-sm ${check.done ? "text-foreground/80 line-through" : "text-foreground"}`}>{check.item}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

          </Tabs>
        </div>
      </section>
      <Footer />
    </div>
  );
}
