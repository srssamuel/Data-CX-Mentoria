import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  ArrowLeft, Download, Share2, CheckCircle, Play, Pause,
  Volume2, VolumeX, FileText, Video, Headphones, BookOpen,
  MessageSquare, GraduationCap, Send, Loader2, List,
  ChevronRight, Trophy, AlertCircle, RotateCcw, Clock,
  User, Users, Briefcase, Building2, Star, MessageCircle
} from "lucide-react";
import { useState, useRef, useEffect, useMemo, useCallback } from "react";
import { Streamdown } from "streamdown";
import { toast } from "sonner";
import { trackModuleCompleted, trackModuleStarted } from "@/lib/analytics";

/* ── Persona Toggle ── */
const PERSONA_CONFIG = {
  jovem: { label: "Jovem", icon: User, color: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
  gestor: { label: "Gestor", icon: Users, color: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" },
  executivo: { label: "Executivo", icon: Briefcase, color: "bg-purple-500/20 text-purple-400 border-purple-500/30" },
  empresario: { label: "Empresário", icon: Building2, color: "bg-orange-500/20 text-orange-400 border-orange-500/30" },
} as const;

type PersonaKey = keyof typeof PERSONA_CONFIG;

function PersonaToggle({ selected, onChange }: { selected: PersonaKey; onChange: (p: PersonaKey) => void }) {
  return (
    <div className="flex items-center gap-1.5 p-1 bg-card/80 border border-border/30 rounded-lg">
      {(Object.entries(PERSONA_CONFIG) as [PersonaKey, typeof PERSONA_CONFIG[PersonaKey]][]).map(([key, cfg]) => {
        const Icon = cfg.icon;
        const isActive = selected === key;
        return (
          <button
            key={key}
            onClick={() => onChange(key)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
              isActive
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
            }`}
          >
            <Icon className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">{cfg.label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ── Next Action Card ── */
function NextActionCard({ currentModuleCode, pilar, sortOrder }: { currentModuleCode: string; pilar: string; sortOrder: number }) {
  const { data: modules } = trpc.contents.byPilar.useQuery({ pilar }, { enabled: !!pilar });
  const [, setLocation] = useLocation();

  const nextModule = useMemo(() => {
    if (!modules || !currentModuleCode) return null;
    const sorted = [...modules].sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
    const currentIndex = sorted.findIndex(m => m.moduleCode === currentModuleCode);
    if (currentIndex === -1 || currentIndex >= sorted.length - 1) return null;
    return sorted[currentIndex + 1];
  }, [modules, currentModuleCode]);

  if (!nextModule) return null;

  const pilarColors: Record<string, string> = {
    introducao: "from-blue-500/20 to-blue-600/10 border-blue-500/30",
    cx: "from-emerald-500/20 to-emerald-600/10 border-emerald-500/30",
    dados: "from-purple-500/20 to-purple-600/10 border-purple-500/30",
    ia: "from-orange-500/20 to-orange-600/10 border-orange-500/30",
  };

  return (
    <Card className={`bg-gradient-to-r ${pilarColors[pilar] || "from-primary/10 to-primary/5 border-primary/20"} cursor-pointer hover:scale-[1.01] transition-transform`}
      onClick={() => setLocation(`/membros/conteudo/${nextModule.id}`)}>
      <CardContent className="p-5 flex items-center justify-between gap-4">
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
            <ChevronRight className="h-3 w-3" /> Próximo módulo
          </p>
          <h4 className="font-semibold text-sm truncate">{nextModule.title}</h4>
          <p className="text-xs text-muted-foreground">{nextModule.moduleCode} · {nextModule.duracao || ""}</p>
        </div>
        <Button size="sm" variant="ghost" className="shrink-0">
          <ArrowLeft className="h-4 w-4 rotate-180" />
        </Button>
      </CardContent>
    </Card>
  );
}

/* ── YouTube Player ── */
function YouTubePlayer({ videoUrl }: { videoUrl: string }) {
  const getYouTubeId = (url: string) => {
    const match = url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/);
    return match ? match[1] : null;
  };
  const videoId = getYouTubeId(videoUrl);
  if (!videoId) return (
    <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
      <p className="text-muted-foreground">URL de vídeo inválida</p>
    </div>
  );
  return (
    <div className="aspect-video rounded-lg overflow-hidden border border-border/30">
      <iframe width="100%" height="100%"
        src={`https://www.youtube.com/embed/${videoId}?rel=0&modestbranding=1`}
        title="YouTube video player" frameBorder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowFullScreen className="w-full h-full" />
    </div>
  );
}

/* ── Audio Player ── */
function AudioPlayer({ audioUrl, title }: { audioUrl: string; title: string }) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const onTime = () => setCurrentTime(audio.currentTime);
    const onMeta = () => setDuration(audio.duration);
    const onEnd = () => setIsPlaying(false);
    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("loadedmetadata", onMeta);
    audio.addEventListener("ended", onEnd);
    return () => { audio.removeEventListener("timeupdate", onTime); audio.removeEventListener("loadedmetadata", onMeta); audio.removeEventListener("ended", onEnd); };
  }, []);

  const fmt = (t: number) => `${Math.floor(t / 60)}:${Math.floor(t % 60).toString().padStart(2, "0")}`;

  return (
    <Card className="bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
      <CardContent className="p-4">
        <audio ref={audioRef} src={audioUrl} preload="metadata" />
        <div className="flex items-center gap-3">
          <Button variant="default" size="icon" className="h-12 w-12 rounded-full shrink-0"
            onClick={() => { if (audioRef.current) { isPlaying ? audioRef.current.pause() : audioRef.current.play(); setIsPlaying(!isPlaying); } }}>
            {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 ml-0.5" />}
          </Button>
          <div className="flex-1 min-w-0 space-y-1">
            <div className="flex items-center gap-2 truncate"><Headphones className="h-3.5 w-3.5 text-primary shrink-0" /><span className="text-sm font-medium truncate">{title}</span></div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground w-9">{fmt(currentTime)}</span>
              <input type="range" min="0" max={duration || 100} value={currentTime}
                onChange={(e) => { const t = parseFloat(e.target.value); if (audioRef.current) { audioRef.current.currentTime = t; setCurrentTime(t); } }}
                className="flex-1 h-1.5 bg-muted rounded-lg appearance-none cursor-pointer accent-primary" />
              <span className="text-xs text-muted-foreground w-9">{fmt(duration)}</span>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="shrink-0"
            onClick={() => { if (audioRef.current) { audioRef.current.muted = !isMuted; setIsMuted(!isMuted); } }}>
            {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

/* ── Placeholder de Vídeo (limpo) ── */
function VideoPlaceholder() {
  return (
    <div className="aspect-video rounded-lg bg-gradient-to-br from-zinc-800 to-zinc-900 border border-border/30 flex flex-col items-center justify-center gap-3">
      <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center">
        <Video className="h-8 w-8 text-primary/60" />
      </div>
      <p className="text-muted-foreground text-sm">Vídeo-aula em breve</p>
    </div>
  );
}

/* ── Pilar Badge ── */
function PilarBadge({ pilar }: { pilar: string }) {
  const cfg: Record<string, { label: string; cls: string }> = {
    INTRO: { label: "Introdução", cls: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
    CX: { label: "CX", cls: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" },
    DADOS: { label: "Dados", cls: "bg-purple-500/20 text-purple-400 border-purple-500/30" },
    IA: { label: "IA", cls: "bg-orange-500/20 text-orange-400 border-orange-500/30" },
  };
  const c = cfg[pilar] || cfg.INTRO;
  return <Badge variant="outline" className={c.cls}>{c.label}</Badge>;
}

/* ── Table of Contents ── */
function TableOfContents({ markdown, onNavigate, contentRef }: { markdown: string; onNavigate: (id: string) => void; contentRef: React.RefObject<HTMLDivElement | null> }) {
  const [activeId, setActiveId] = useState<string>("");
  const tocNavRef = useRef<HTMLDivElement>(null);

  const headings = useMemo(() => {
    const lines = markdown.split("\n");
    const result: { level: number; text: string; id: string }[] = [];
    for (const line of lines) {
      const match = line.match(/^(#{1,3})\s+(.+)/);
      if (match) {
        const text = match[2].replace(/\*\*/g, "").trim();
        const id = text.toLowerCase().replace(/[^a-z0-9\u00C0-\u024F]+/g, "-").replace(/(^-|-$)/g, "");
        result.push({ level: match[1].length, text, id });
      }
    }
    return result;
  }, [markdown]);

  // IntersectionObserver to track which heading is currently visible
  useEffect(() => {
    if (!contentRef?.current || headings.length === 0) return;

    const headingElements: { el: Element; id: string }[] = [];
    const allEls = Array.from(contentRef.current.querySelectorAll("h1, h2, h3"));
    for (const el of allEls) {
      const elId = (el.textContent || "").toLowerCase().replace(/[^a-z0-9\u00C0-\u024F]+/g, "-").replace(/(^-|-$)/g, "");
      if (headings.some(h => h.id === elId)) {
        headingElements.push({ el, id: elId });
      }
    }

    if (headingElements.length === 0) return;

    const visibleSet = new Set<string>();

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          const id = (entry.target.textContent || "").toLowerCase().replace(/[^a-z0-9\u00C0-\u024F]+/g, "-").replace(/(^-|-$)/g, "");
          if (entry.isIntersecting) {
            visibleSet.add(id);
          } else {
            visibleSet.delete(id);
          }
        });
        // Pick the first visible heading in document order
        for (const { id } of headingElements) {
          if (visibleSet.has(id)) {
            setActiveId(id);
            return;
          }
        }
      },
      { rootMargin: "-80px 0px -60% 0px", threshold: 0 }
    );

    headingElements.forEach(({ el }) => observer.observe(el));
    return () => observer.disconnect();
  }, [contentRef, headings]);

  // Auto-scroll the TOC nav to keep the active item visible
  useEffect(() => {
    if (!activeId || !tocNavRef.current) return;
    const activeBtn = tocNavRef.current.querySelector(`[data-toc-id="${activeId}"]`);
    if (activeBtn) {
      activeBtn.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  }, [activeId]);

  if (headings.length === 0) return null;

  return (
    <Card className="border-border/30 bg-card/50">
      <CardHeader className="py-3 px-4 border-b border-border/30">
        <div className="flex items-center gap-2">
          <List className="h-4 w-4 text-primary" />
          <CardTitle className="text-sm font-semibold">Índice do Módulo</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="p-2">
        <div ref={tocNavRef} className="max-h-[calc(100vh-180px)] overflow-y-auto scrollbar-thin scrollbar-thumb-border scrollbar-track-transparent">
          <nav className="space-y-0.5">
            {headings.map((h, i) => {
              const isActive = activeId === h.id;
              return (
                <button key={i} data-toc-id={h.id} onClick={() => onNavigate(h.id)}
                  className={`w-full text-left text-sm px-3 py-1.5 rounded-md transition-all duration-200 truncate ${
                    isActive
                      ? "bg-primary/15 text-primary font-semibold border-l-2 border-primary"
                      : h.level === 1 ? "font-semibold text-foreground hover:bg-accent/50" : h.level === 2 ? "pl-6 text-foreground/80 hover:bg-accent/50" : "pl-9 text-muted-foreground text-xs hover:bg-accent/50"
                  }`}>
                  <span className="flex items-center gap-1.5">
                    <ChevronRight className={`h-3 w-3 shrink-0 transition-transform duration-200 ${
                      isActive ? "text-primary rotate-90" : h.level === 1 ? "text-primary" : "text-muted-foreground/50"
                    }`} />
                    {h.text}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>
      </CardContent>
    </Card>
  );
}

/* ── Module Chat ── */
/* ── Star Rating Component ── */
function StarRating({ rating, onRate, size = 16, interactive = true }: {
  rating: number;
  onRate?: (r: number) => void;
  size?: number;
  interactive?: boolean;
}) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          disabled={!interactive}
          className={`transition-all duration-150 ${interactive ? 'cursor-pointer hover:scale-110' : 'cursor-default'}`}
          onMouseEnter={() => interactive && setHover(star)}
          onMouseLeave={() => interactive && setHover(0)}
          onClick={() => interactive && onRate?.(star)}
        >
          <Star
            size={size}
            className={`transition-colors ${
              (hover || rating) >= star
                ? 'fill-amber-400 text-amber-400'
                : 'text-muted-foreground/30'
            }`}
          />
        </button>
      ))}
    </div>
  );
}

/* ── Feedback Widget for Assistant Messages ── */
function ChatFeedbackWidget({ messageId, contentId, existingFeedback }: {
  messageId: number;
  contentId: number;
  existingFeedback?: { rating: number; comment: string | null } | null;
}) {
  const [rating, setRating] = useState(existingFeedback?.rating || 0);
  const [comment, setComment] = useState(existingFeedback?.comment || "");
  const [showComment, setShowComment] = useState(false);
  const [submitted, setSubmitted] = useState(!!existingFeedback);
  const utils = trpc.useUtils();

  const submitFeedback = trpc.moduleChat.submitFeedback.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      setShowComment(false);
      utils.moduleChat.getFeedback.invalidate({ contentId });
      toast.success("Obrigado pelo feedback!");
    },
    onError: () => toast.error("Erro ao enviar feedback."),
  });

  const handleRate = (r: number) => {
    setRating(r);
    submitFeedback.mutate({ chatMessageId: messageId, contentId, rating: r, comment: comment || undefined });
  };

  const handleCommentSubmit = () => {
    if (!rating) return;
    submitFeedback.mutate({ chatMessageId: messageId, contentId, rating, comment: comment || undefined });
  };

  return (
    <div className="mt-2 space-y-2">
      <div className="flex items-center gap-2">
        <StarRating rating={rating} onRate={handleRate} size={14} />
        {rating > 0 && (
          <button
            type="button"
            onClick={() => setShowComment(!showComment)}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
          >
            <MessageCircle size={12} />
            {submitted && comment ? 'Editar' : 'Comentar'}
          </button>
        )}
        {submitted && <span className="text-xs text-emerald-400/70">✓</span>}
      </div>
      {showComment && (
        <div className="flex gap-2 items-end">
          <Textarea
            placeholder="Seu comentário sobre esta resposta..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            rows={2}
            className="text-xs min-h-[48px] max-h-[80px] resize-none bg-background/50"
          />
          <Button
            size="sm"
            variant="outline"
            className="shrink-0 text-xs h-8"
            onClick={handleCommentSubmit}
            disabled={submitFeedback.isPending}
          >
            {submitFeedback.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : 'Enviar'}
          </Button>
        </div>
      )}
    </div>
  );
}

function ModuleChat({ contentId, moduleTitle, moduleDescription }: { contentId: number; moduleTitle: string; moduleDescription?: string }) {
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  // Session-only messages: each time the chat tab opens, start fresh
  const [sessionMessages, setSessionMessages] = useState<Array<{ id?: number; role: string; message: string }>>([]);

  const sendMsg = trpc.moduleChat.sendMessage.useMutation({
    onSuccess: (data: any) => {
      // Append the assistant response to session messages
      if (data && data.reply) {
        setSessionMessages(prev => [
          ...prev,
          { id: data.messageId, role: "assistant", message: data.reply }
        ]);
      }
      setInput("");
    },
    onError: () => toast.error("Erro ao enviar mensagem. Tente novamente."),
  });

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [sessionMessages, sendMsg.isPending]);

  const handleSend = () => {
    const msg = input.trim();
    if (!msg) return;
    // Add user message to session immediately
    setSessionMessages(prev => [...prev, { role: "user", message: msg }]);
    sendMsg.mutate({ contentId, message: msg, moduleTitle, moduleDescription });
  };

  return (
    <div className="flex flex-col h-[600px] overflow-hidden">
      <div className="bg-primary/5 border-b border-border/30 px-4 py-3 rounded-t-lg shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
              <MessageSquare className="h-4 w-4 text-primary" />
            </div>
            <div>
              <p className="text-sm font-semibold">Tutor IA - {moduleTitle}</p>
              <p className="text-xs text-muted-foreground">Tire dúvidas sobre este módulo</p>
            </div>
          </div>
          {sessionMessages.length > 0 && (
            <Button variant="ghost" size="sm" className="text-xs text-muted-foreground" onClick={() => setSessionMessages([])}>
              Nova conversa
            </Button>
          )}
        </div>
      </div>

      <ScrollArea className="flex-1 overflow-hidden" ref={scrollRef}>
        <div className="p-4">
        <div className="space-y-4">
          {sessionMessages.length === 0 && !sendMsg.isPending && (
            <div className="text-center py-12 space-y-3">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                <MessageSquare className="h-8 w-8 text-primary/50" />
              </div>
              <p className="text-muted-foreground text-sm">Faça uma pergunta sobre o conteúdo deste módulo</p>
              <div className="flex flex-wrap gap-2 justify-center">
                {["Resuma este módulo", "Dê um exemplo prático", "Quais os conceitos-chave?"].map((s) => (
                  <Button key={s} variant="outline" size="sm" className="text-xs"
                    onClick={() => { setInput(s); }}>
                    {s}
                  </Button>
                ))}
              </div>
            </div>
          )}

          {sessionMessages.map((msg, i) => (
            <div key={msg.id || i} className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}>
              <div className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                msg.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
              }`}>
                {msg.role === "assistant" ? (
                  <div className="prose prose-sm prose-invert max-w-none">
                    <Streamdown>{msg.message}</Streamdown>
                  </div>
                ) : (
                  <p className="text-sm">{msg.message}</p>
                )}
              </div>
            </div>
          ))}

          {sendMsg.isPending && (
            <div className="flex justify-start">
              <div className="bg-muted rounded-2xl px-4 py-3">
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span className="text-sm text-muted-foreground">Pensando...</span>
                </div>
              </div>
            </div>
          )}
        </div>
        </div>
      </ScrollArea>

      <div className="border-t border-border/30 p-3">
        <div className="flex gap-2">
          <Textarea placeholder="Pergunte algo sobre este módulo..." value={input}
            onChange={(e) => setInput(e.target.value)} rows={1}
            className="min-h-[40px] max-h-[120px] resize-none"
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }} />
          <Button size="icon" className="shrink-0 h-10 w-10" onClick={handleSend}
            disabled={!input.trim() || sendMsg.isPending}>
            {sendMsg.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </div>
      </div>
    </div>
  );
}

/* ── Quiz Component ── */
function ModuleQuiz({ contentId }: { contentId: number }) {
  const { data: quizData, isLoading } = trpc.quizzes.getByContent.useQuery({ contentId });
  const { data: attempts } = trpc.quizzes.myAttempts.useQuery(
    { quizId: quizData?.id || 0 },
    { enabled: !!quizData?.id }
  );
  const submitAttempt = trpc.quizzes.submitAttempt.useMutation();

  const [answers, setAnswers] = useState<Record<string, string[]>>({});
  const [showResults, setShowResults] = useState(false);
  const [result, setResult] = useState<{ score: number; passed: boolean; correctAnswers: number; totalQuestions: number; pointsEarned: number } | null>(null);
  const [currentQ, setCurrentQ] = useState(0);
  const [startTime] = useState(() => Date.now());

  if (isLoading) return <div className="flex items-center justify-center py-12"><Loader2 className="h-6 w-6 animate-spin" /></div>;

  if (!quizData || !quizData.questions || quizData.questions.length === 0) {
    return (
      <div className="text-center py-12 space-y-3">
        <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto">
          <GraduationCap className="h-8 w-8 text-muted-foreground/50" />
        </div>
        <p className="text-muted-foreground">Prova não disponível para este módulo</p>
      </div>
    );
  }

  const questions = quizData.questions;
  const attemptsUsed = attempts?.length || 0;
  const maxAttempts = quizData.attemptsAllowed || 3;
  const bestScore = attempts && attempts.length > 0 ? Math.max(...attempts.map((a: any) => a.score)) : 0;
  const hasPassed = attempts?.some((a: any) => a.passed);
  const canAttempt = attemptsUsed < maxAttempts && !hasPassed;

  const handleSelectAnswer = (questionId: string, optionId: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: [optionId] }));
  };

  const handleSubmit = async () => {
    if (!quizData) return;
    const timeSpent = Math.round((Date.now() - startTime) / 1000);
    try {
      const res = await submitAttempt.mutateAsync({ quizId: quizData.id, answers, timeSpent });
      setResult(res);
      setShowResults(true);
      if (res.passed) {
        toast.success(`Parabéns! Você passou com ${res.score}%! +${res.pointsEarned} pontos`);
      } else {
        toast.error(`Você obteve ${res.score}%. Necessário: ${quizData.passingScore}%`);
      }
    } catch { toast.error("Erro ao enviar prova"); }
  };

  const handleRetry = () => {
    setAnswers({});
    setShowResults(false);
    setResult(null);
    setCurrentQ(0);
  };

  // Results view
  if (showResults && result) {
    return (
      <div className="space-y-6 py-4">
        <div className={`text-center p-8 rounded-xl border ${result.passed ? "bg-emerald-500/10 border-emerald-500/30" : "bg-red-500/10 border-red-500/30"}`}>
          <div className={`w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center ${result.passed ? "bg-emerald-500/20" : "bg-red-500/20"}`}>
            {result.passed ? <Trophy className="h-10 w-10 text-emerald-400" /> : <AlertCircle className="h-10 w-10 text-red-400" />}
          </div>
          <h3 className="text-2xl font-bold mb-1">{result.passed ? "Aprovado!" : "Tente Novamente"}</h3>
          <p className="text-4xl font-bold my-3">{result.score}%</p>
          <p className="text-muted-foreground">{result.correctAnswers}/{result.totalQuestions} questões corretas</p>
          {result.pointsEarned > 0 && <p className="text-emerald-400 font-semibold mt-2">+{result.pointsEarned} pontos</p>}
        </div>

        <div className="space-y-4">
          <h4 className="font-semibold">Revisão das Questões</h4>
          {questions.map((q: any, i: number) => {
            const userAns = answers[q.id.toString()] || [];
            const correctOpts = (q.options as any[]).filter((o: any) => o.isCorrect).map((o: any) => o.id);
            const isCorrect = JSON.stringify([...userAns].sort()) === JSON.stringify([...correctOpts].sort());
            return (
              <Card key={q.id} className={`border ${isCorrect ? "border-emerald-500/30" : "border-red-500/30"}`}>
                <CardContent className="p-4 space-y-2">
                  <div className="flex items-start gap-2">
                    <span className={`text-xs font-bold px-2 py-0.5 rounded ${isCorrect ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}>
                      {isCorrect ? "✓" : "✗"} Q{i + 1}
                    </span>
                    <p className="text-sm font-medium">{q.question}</p>
                  </div>
                  <div className="pl-8 space-y-1">
                    {(q.options as any[]).map((opt: any) => {
                      const isSelected = userAns.includes(opt.id);
                      const isCorrectOpt = opt.isCorrect;
                      return (
                        <div key={opt.id} className={`text-xs px-2 py-1 rounded ${
                          isCorrectOpt ? "bg-emerald-500/10 text-emerald-300" : isSelected ? "bg-red-500/10 text-red-300" : "text-muted-foreground"
                        }`}>
                          {isCorrectOpt ? "✓" : isSelected ? "✗" : "○"} {opt.text}
                        </div>
                      );
                    })}
                  </div>
                  {q.explanation && <p className="text-xs text-muted-foreground pl-8 italic">{q.explanation}</p>}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {canAttempt && !result.passed && (
          <Button onClick={handleRetry} className="w-full">
            <RotateCcw className="h-4 w-4 mr-2" /> Tentar Novamente ({attemptsUsed + 1}/{maxAttempts})
          </Button>
        )}
      </div>
    );
  }

  // Already passed
  if (hasPassed) {
    return (
      <div className="text-center py-12 space-y-3">
        <div className="w-20 h-20 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto">
          <Trophy className="h-10 w-10 text-emerald-400" />
        </div>
        <h3 className="text-xl font-bold">Prova Concluída!</h3>
        <p className="text-muted-foreground">Melhor nota: <span className="text-emerald-400 font-bold">{bestScore}%</span></p>
        <p className="text-xs text-muted-foreground">{attemptsUsed} tentativa(s) utilizada(s)</p>
      </div>
    );
  }

  // No more attempts
  if (!canAttempt) {
    return (
      <div className="text-center py-12 space-y-3">
        <div className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center mx-auto">
          <AlertCircle className="h-8 w-8 text-red-400" />
        </div>
        <h3 className="text-xl font-bold">Tentativas Esgotadas</h3>
        <p className="text-muted-foreground">Melhor nota: {bestScore}%</p>
        <p className="text-xs text-muted-foreground">{attemptsUsed}/{maxAttempts} tentativas</p>
      </div>
    );
  }

  // Quiz form
  const q = questions[currentQ] as any;
  const totalQ = questions.length;

  return (
    <div className="space-y-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold">{quizData.title || "Prova do Módulo"}</h3>
          <p className="text-xs text-muted-foreground">Tentativa {attemptsUsed + 1} de {maxAttempts} · Mínimo: {quizData.passingScore}%</p>
        </div>
        <Badge variant="outline" className="gap-1"><Clock className="h-3 w-3" /> {currentQ + 1}/{totalQ}</Badge>
      </div>

      <Progress value={((currentQ + 1) / totalQ) * 100} className="h-1.5" />

      <Card className="border-border/30">
        <CardContent className="p-6 space-y-4">
          <p className="font-medium">{q.question}</p>
          <RadioGroup value={answers[q.id.toString()]?.[0] || ""}
            onValueChange={(val) => handleSelectAnswer(q.id.toString(), val)}>
            {(q.options as any[]).map((opt: any) => (
              <div key={opt.id} className="flex items-center space-x-3 p-3 rounded-lg border border-border/30 hover:bg-accent/30 transition-colors cursor-pointer"
                onClick={() => handleSelectAnswer(q.id.toString(), opt.id)}>
                <RadioGroupItem value={opt.id} id={`opt-${opt.id}`} />
                <Label htmlFor={`opt-${opt.id}`} className="cursor-pointer flex-1 text-sm">{opt.text}</Label>
              </div>
            ))}
          </RadioGroup>
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button variant="outline" disabled={currentQ === 0} onClick={() => setCurrentQ((p) => p - 1)}>Anterior</Button>
        {currentQ < totalQ - 1 ? (
          <Button onClick={() => setCurrentQ((p) => p + 1)} disabled={!answers[q.id.toString()]}>Próxima</Button>
        ) : (
          <Button onClick={handleSubmit} disabled={Object.keys(answers).length < totalQ || submitAttempt.isPending}
            className="bg-emerald-600 hover:bg-emerald-700">
            {submitAttempt.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <GraduationCap className="h-4 w-4 mr-2" />}
            Enviar Prova
          </Button>
        )}
      </div>

      <div className="flex flex-wrap gap-1.5 justify-center">
        {questions.map((_: any, i: number) => (
          <button key={i} onClick={() => setCurrentQ(i)}
            className={`w-7 h-7 rounded-full text-xs font-medium transition-colors ${
              i === currentQ ? "bg-primary text-primary-foreground" : answers[questions[i].id.toString()] ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30" : "bg-muted text-muted-foreground"
            }`}>
            {i + 1}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ── Main ContentView ── */
export default function ContentView() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("conteudo");
  const contentRef = useRef<HTMLDivElement>(null);

  // Get user's persona from radar (auto-detect)
  const { data: userPersonaData } = trpc.userPersona.get.useQuery(undefined, { retry: false });
  const [selectedPersona, setSelectedPersona] = useState<PersonaKey>("gestor");

  // Set persona from radar result when available
  useEffect(() => {
    if (userPersonaData?.persona) {
      setSelectedPersona(userPersonaData.persona as PersonaKey);
    }
  }, [userPersonaData]);

  const { data: content, isLoading } = trpc.contents.getById.useQuery(
    { id: parseInt(id || "0") },
    { enabled: !!id }
  );

  // Get persona-specific version
  const { data: personaVersion, isLoading: isLoadingPersona } = trpc.personaVersions.get.useQuery(
    { contentId: parseInt(id || "0"), persona: selectedPersona },
    { enabled: !!id && !!selectedPersona }
  );

  const { data: accessData } = trpc.contents.accessibleModules.useQuery(undefined, {
    retry: false,
  });

  // Check if module is locked
  const FREE_PREVIEW_MODULES = useMemo(() => ["INT-01"], []);
  const isLocked = useMemo(() => {
    if (!content || !accessData) return false;
    const isAdmin = (accessData as any)?.isAdmin === true;
    if (isAdmin) return false;
    const hasActivePlan = (accessData as any)?.hasActivePlan === true;
    if (hasActivePlan) {
      return content.moduleCode ? !accessData.moduleCodes.includes(content.moduleCode) : false;
    }
    // No plan: lock everything except free preview modules
    return content.moduleCode ? !FREE_PREVIEW_MODULES.includes(content.moduleCode) : false;
  }, [content, accessData, FREE_PREVIEW_MODULES]);

  // Determine which content to show: persona version > original
  const displayMarkdown = personaVersion?.apostilaMarkdown || content?.markdownContent || null;
  const displayAudioUrl = personaVersion?.audioUrl || content?.audioUrl || null;

  const markCompleteMutation = trpc.progress.markComplete.useMutation({
    onSuccess: (data) => {
      toast.success("Conteúdo marcado como concluído! +10 pontos");
      // Track module completion
      if (content) {
        trackModuleCompleted(content.moduleCode || "", content.pilar || "");
      }
      if (data.awardedBadges && data.awardedBadges.length > 0) {
        data.awardedBadges.forEach((badge, index) => {
          setTimeout(() => {
            toast.success(
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center">
                  <span className="text-xl">🏆</span>
                </div>
                <div>
                  <p className="font-bold">Nova Medalha!</p>
                  <p className="text-sm">{badge.name} · +{badge.pointsReward} pts</p>
                </div>
              </div>,
              { duration: 5000 }
            );
          }, (index + 1) * 1500);
        });
      }
      if (data.newCertificates && data.newCertificates.length > 0) {
        const delay = (data.awardedBadges?.length || 0) * 1500;
        data.newCertificates.forEach((cert, index) => {
          const names: Record<string, string> = { introducao: "Introdução", cx: "Customer Experience", dados: "Gestão de Dados", ia: "Inteligência Artificial" };
          setTimeout(() => {
            toast.success(
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center">
                  <span className="text-xl">🎓</span>
                </div>
                <div>
                  <p className="font-bold">Certificado!</p>
                  <p className="text-sm">{names[cert.category] || cert.category}</p>
                </div>
              </div>,
              { duration: 8000 }
            );
          }, delay + (index + 1) * 2000);
        });
      }
    },
  });

  const handleNavigateToHeading = useCallback((headingId: string) => {
    if (!contentRef.current) return;
    const allHeadings = Array.from(contentRef.current.querySelectorAll("h1, h2, h3"));
    for (const el of allHeadings) {
      const elId = (el.textContent || "").toLowerCase().replace(/[^a-z0-9\u00C0-\u024F]+/g, "-").replace(/(^-|-$)/g, "");
      if (elId === headingId) {
        el.scrollIntoView({ behavior: "smooth", block: "start" });
        break;
      }
    }
  }, []);

  const handleShare = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try { await navigator.share({ title: content?.title, text: content?.description || "", url }); } catch {}
    } else {
      await navigator.clipboard.writeText(url);
      toast.success("Link copiado!");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container max-w-5xl py-8 space-y-4">
          <Skeleton className="h-8 w-48" /><Skeleton className="h-64 w-full" /><Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (!content) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-8 text-center">
          <h2 className="text-xl font-semibold mb-2">Conteúdo não encontrado</h2>
          <p className="text-muted-foreground mb-4">O conteúdo que você está procurando não existe ou foi removido.</p>
          <Button onClick={() => setLocation("/membros")}><ArrowLeft className="h-4 w-4 mr-2" />Voltar</Button>
        </Card>
      </div>
    );
  }

  if (isLocked) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container max-w-3xl py-16">
          <Button variant="ghost" size="sm" onClick={() => setLocation("/membros")} className="mb-8">
            <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
          </Button>
          <Card className="border-border/30 overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-amber-500 to-orange-500" />
            <CardContent className="p-8 sm:p-12 text-center space-y-6">
              <div className="w-20 h-20 rounded-full bg-amber-500/10 flex items-center justify-center mx-auto">
                <span className="text-4xl">🔒</span>
              </div>
              <div>
                <h2 className="text-2xl font-bold mb-2">Módulo Bloqueado</h2>
                <p className="text-muted-foreground max-w-md mx-auto">
                  {(accessData as any)?.hasActivePlan
                    ? <>O módulo <strong>{content.title}</strong> ({content.moduleCode}) não está incluído no seu plano atual. Faça upgrade para desbloquear este e outros conteúdos exclusivos.</>
                    : <>O módulo <strong>{content.title}</strong> ({content.moduleCode}) requer um plano ativo. Adquira um dos nossos programas para acessar este e outros conteúdos exclusivos.</>
                  }
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button onClick={() => setLocation("/ofertas")} className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white">
                  Ver Planos e Fazer Upgrade
                </Button>
                <Button variant="outline" onClick={() => setLocation("/membros")}>
                  Explorar Módulos Disponíveis
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Sticky Header */}
      <div className="border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container max-w-5xl py-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-3 min-w-0">
              <Button variant="ghost" size="sm" onClick={() => setLocation("/membros")} className="shrink-0">
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div className="flex items-center gap-2 min-w-0">
                <PilarBadge pilar={content.pilar || content.category || "INTRO"} />
                {content.moduleCode && <Badge variant="secondary" className="text-xs shrink-0">{content.moduleCode}</Badge>}
                <span className="text-sm font-medium truncate hidden sm:inline">{content.title}</span>
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              {/* Persona Toggle */}
              <PersonaToggle selected={selectedPersona} onChange={setSelectedPersona} />
            </div>
          </div>
        </div>
      </div>

      {/* Content Area */}
      <div className="container max-w-5xl py-6">
        {/* Title + Actions */}
        <div className="mb-6 space-y-3">
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-2 min-w-0">
              <h1 className="text-2xl sm:text-3xl font-bold">{content.title}</h1>
              {content.description && <p className="text-muted-foreground" dangerouslySetInnerHTML={{ __html: content.description.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>') }} />}
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                {content.nivel && <span className="capitalize">{content.nivel}</span>}
                {content.duracao && <span><Clock className="h-3 w-3 inline mr-1" />{content.duracao}</span>}
                <Badge variant="outline" className={PERSONA_CONFIG[selectedPersona].color}>
                  {PERSONA_CONFIG[selectedPersona].label}
                </Badge>
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <Button variant="ghost" size="sm" onClick={handleShare} className="hidden sm:flex"><Share2 className="h-4 w-4" /></Button>
              {displayMarkdown && (
                <Button variant="ghost" size="sm" onClick={() => window.open(`/api/contents/${id}/pdf`, "_blank")} className="hidden sm:flex">
                  <Download className="h-4 w-4" />
                </Button>
              )}
              <Button size="sm" onClick={() => id && markCompleteMutation.mutate({ contentId: parseInt(id) })}
                disabled={markCompleteMutation.isPending} className="gap-1.5">
                <CheckCircle className="h-4 w-4" />
                <span className="hidden sm:inline">Concluir</span>
              </Button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full justify-start bg-card/50 border border-border/30 mb-6">
            <TabsTrigger value="conteudo" className="gap-1.5 data-[state=active]:bg-primary/10">
              <BookOpen className="h-4 w-4" /> Conteúdo
            </TabsTrigger>
            <TabsTrigger value="chat" className="gap-1.5 data-[state=active]:bg-primary/10">
              <MessageSquare className="h-4 w-4" /> Chat IA
            </TabsTrigger>
            <TabsTrigger value="prova" className="gap-1.5 data-[state=active]:bg-primary/10">
              <GraduationCap className="h-4 w-4" /> Prova
            </TabsTrigger>
          </TabsList>

          {/* ── Tab: Conteúdo ── */}
          <TabsContent value="conteudo" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6">
              <div className="space-y-6 min-w-0">
                {/* Video */}
                {content.videoUrl ? <YouTubePlayer videoUrl={content.videoUrl} /> : <VideoPlaceholder />}

                {/* Audio */}
                {displayAudioUrl ? (
                  <AudioPlayer audioUrl={displayAudioUrl} title={`Áudio: ${content.title}`} />
                ) : (
                  <Card className="bg-gradient-to-r from-zinc-800/50 to-zinc-900/50 border-border/30">
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                        <Headphones className="h-5 w-5 text-primary/60" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Áudio narrado em preparação</p>
                        <p className="text-xs text-muted-foreground/60">O áudio deste módulo está sendo gerado</p>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Markdown Content (persona version or original) */}
                {isLoadingPersona ? (
                  <Card className="border-border/30">
                    <CardContent className="p-6 space-y-4">
                      <Skeleton className="h-6 w-3/4" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-5/6" />
                      <Skeleton className="h-4 w-full" />
                    </CardContent>
                  </Card>
                ) : displayMarkdown ? (
                  <Card className="border-border/30">
                    <CardContent className="p-6 prose prose-invert max-w-none" ref={contentRef}>
                      <Streamdown>{displayMarkdown}</Streamdown>
                    </CardContent>
                  </Card>
                ) : null}

                {/* PDF Download */}
                {!displayMarkdown && content.fileUrl && (
                  <Card className="border-border/30">
                    <CardContent className="p-6 flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                          <FileText className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-semibold">{content.title}</h3>
                          <p className="text-sm text-muted-foreground">Clique para baixar</p>
                        </div>
                      </div>
                      <Button asChild><a href={content.fileUrl} target="_blank" rel="noopener noreferrer"><Download className="h-4 w-4 mr-2" />Baixar</a></Button>
                    </CardContent>
                  </Card>
                )}

                {/* Próxima Ação Recomendada */}
                {content.pilar && (
                  <NextActionCard currentModuleCode={content.moduleCode || ""} pilar={content.pilar} sortOrder={content.sortOrder} />
                )}

                {/* Share CTA */}
                <Card className="bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
                  <CardContent className="p-6 text-center">
                    <h3 className="font-semibold mb-1">Gostou do conteúdo?</h3>
                    <p className="text-sm text-muted-foreground mb-3">Compartilhe com outros profissionais!</p>
                    <Button variant="outline" size="sm" onClick={handleShare}><Share2 className="h-4 w-4 mr-2" />Compartilhar</Button>
                  </CardContent>
                </Card>
              </div>

              {/* Sidebar: Table of Contents */}
              {displayMarkdown && (
                <div className="hidden lg:block">
                  <div className="sticky top-20 max-h-[calc(100vh-100px)] overflow-hidden">
                    <TableOfContents markdown={displayMarkdown} onNavigate={handleNavigateToHeading} contentRef={contentRef} />
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          {/* ── Tab: Chat ── */}
          <TabsContent value="chat">
            <Card className="border-border/30 overflow-hidden">
              <ModuleChat contentId={parseInt(id || "0")} moduleTitle={content.title} moduleDescription={content.description || undefined} />
            </Card>
          </TabsContent>

          {/* ── Tab: Prova ── */}
          <TabsContent value="prova">
            <Card className="border-border/30">
              <CardContent className="p-6">
                <ModuleQuiz contentId={parseInt(id || "0")} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
