import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { Link, useParams, useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useState, useEffect } from "react";
import { 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Trophy, 
  ArrowLeft, 
  ArrowRight,
  Loader2,
  AlertCircle,
  Award,
} from "lucide-react";
import { toast } from "sonner";

export default function Quiz() {
  const { contentId } = useParams<{ contentId: string }>();
  const { user, isAuthenticated, loading } = useAuth();
  const [, setLocation] = useLocation();
  
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string[]>>({});
  const [showResults, setShowResults] = useState(false);
  const [timeSpent, setTimeSpent] = useState(0);
  
  const { data: quiz, isLoading: quizLoading } = trpc.quizzes.getByContent.useQuery(
    { contentId: parseInt(contentId || "0") },
    { enabled: !!contentId && isAuthenticated }
  );
  
  const { data: attempts } = trpc.quizzes.myAttempts.useQuery(
    { quizId: quiz?.id || 0 },
    { enabled: !!quiz?.id && isAuthenticated }
  );
  
  const submitAttempt = trpc.quizzes.submitAttempt.useMutation({
    onSuccess: (result) => {
      setShowResults(true);
      if (result.passed) {
        toast.success(`Parabéns! Você passou com ${result.score}%!`);
      } else {
        toast.error(`Você obteve ${result.score}%. Tente novamente!`);
      }
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao enviar quiz");
    },
  });
  
  // Timer
  useEffect(() => {
    if (!showResults && quiz) {
      const interval = setInterval(() => {
        setTimeSpent((prev) => prev + 1);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [showResults, quiz]);
  
  if (loading || quizLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <AlertCircle className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h1 className="text-2xl font-bold mb-4">Acesso Restrito</h1>
          <p className="text-muted-foreground mb-6">Faça login para acessar os quizzes.</p>
          <Button asChild>
            <a href={getLoginUrl("/membros")}>Fazer Login</a>
          </Button>
        </div>
        <Footer />
      </div>
    );
  }
  
  if (!quiz) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <AlertCircle className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h1 className="text-2xl font-bold mb-4">Quiz não encontrado</h1>
          <p className="text-muted-foreground mb-6">Este conteúdo não possui quiz de avaliação.</p>
          <Button asChild variant="outline">
            <Link href="/membros">Voltar para Área de Membros</Link>
          </Button>
        </div>
        <Footer />
      </div>
    );
  }
  
  const questions = quiz.questions || [];
  const question = questions[currentQuestion];
  const totalQuestions = questions.length;
  const progress = ((currentQuestion + 1) / totalQuestions) * 100;
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };
  
  const handleAnswerChange = (questionId: string, optionId: string, isMultiple: boolean) => {
    setAnswers((prev) => {
      if (isMultiple) {
        const current = prev[questionId] || [];
        if (current.includes(optionId)) {
          return { ...prev, [questionId]: current.filter((id) => id !== optionId) };
        }
        return { ...prev, [questionId]: [...current, optionId] };
      }
      return { ...prev, [questionId]: [optionId] };
    });
  };
  
  const handleSubmit = () => {
    submitAttempt.mutate({
      quizId: quiz.id,
      answers,
      timeSpent,
    });
  };
  
  const canSubmit = Object.keys(answers).length === totalQuestions;
  const lastAttempt = attempts?.[0];
  const attemptsRemaining = quiz.attemptsAllowed - (attempts?.length || 0);
  
  // Show previous results if already passed
  if (lastAttempt?.passed && !showResults) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-12 max-w-2xl">
          <Card className="bg-card/50 border-border/50">
            <CardHeader className="text-center">
              <div className="w-20 h-20 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-4">
                <Trophy className="w-10 h-10 text-green-500" />
              </div>
              <CardTitle className="text-2xl">Quiz Concluído!</CardTitle>
              <CardDescription>Você já completou este quiz com sucesso.</CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-3xl font-bold text-green-500">{lastAttempt.score}%</p>
                  <p className="text-sm text-muted-foreground">Sua Nota</p>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-3xl font-bold">{lastAttempt.correctAnswers}/{lastAttempt.totalQuestions}</p>
                  <p className="text-sm text-muted-foreground">Acertos</p>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-3xl font-bold text-primary">+{lastAttempt.pointsEarned}</p>
                  <p className="text-sm text-muted-foreground">Pontos</p>
                </div>
              </div>
              <Button asChild variant="outline" className="mt-6">
                <Link href="/membros">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Voltar para Área de Membros
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }
  
  // Show results after submission
  if (showResults && submitAttempt.data) {
    const result = submitAttempt.data;
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-12 max-w-2xl">
          <Card className="bg-card/50 border-border/50">
            <CardHeader className="text-center">
              <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 ${
                result.passed ? "bg-green-500/10" : "bg-red-500/10"
              }`}>
                {result.passed ? (
                  <CheckCircle2 className="w-10 h-10 text-green-500" />
                ) : (
                  <XCircle className="w-10 h-10 text-red-500" />
                )}
              </div>
              <CardTitle className="text-2xl">
                {result.passed ? "Parabéns! Você passou!" : "Não foi dessa vez..."}
              </CardTitle>
              <CardDescription>
                {result.passed 
                  ? "Você completou o quiz com sucesso!" 
                  : `Você precisa de ${quiz.passingScore}% para passar. Tente novamente!`}
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className={`text-3xl font-bold ${result.passed ? "text-green-500" : "text-red-500"}`}>
                    {result.score}%
                  </p>
                  <p className="text-sm text-muted-foreground">Sua Nota</p>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-3xl font-bold">{result.correctAnswers}/{result.totalQuestions}</p>
                  <p className="text-sm text-muted-foreground">Acertos</p>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-3xl font-bold text-primary">+{result.pointsEarned}</p>
                  <p className="text-sm text-muted-foreground">Pontos</p>
                </div>
              </div>
              
              <div className="flex gap-4 justify-center mt-6">
                <Button asChild variant="outline">
                  <Link href="/membros">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Voltar
                  </Link>
                </Button>
                {!result.passed && attemptsRemaining > 0 && (
                  <Button onClick={() => {
                    setShowResults(false);
                    setAnswers({});
                    setCurrentQuestion(0);
                    setTimeSpent(0);
                  }}>
                    Tentar Novamente
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }
  
  // Check attempts remaining
  if (attemptsRemaining <= 0 && !lastAttempt?.passed) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-12 max-w-2xl">
          <Card className="bg-card/50 border-border/50">
            <CardHeader className="text-center">
              <div className="w-20 h-20 rounded-full bg-red-500/10 flex items-center justify-center mx-auto mb-4">
                <AlertCircle className="w-10 h-10 text-red-500" />
              </div>
              <CardTitle className="text-2xl">Tentativas Esgotadas</CardTitle>
              <CardDescription>
                Você já utilizou todas as {quiz.attemptsAllowed} tentativas permitidas para este quiz.
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button asChild variant="outline">
                <Link href="/membros">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Voltar para Área de Membros
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container py-8 max-w-3xl">
        {/* Header */}
        <div className="mb-8">
          <Link href="/membros" className="text-sm text-muted-foreground hover:text-primary flex items-center gap-1 mb-4">
            <ArrowLeft className="w-4 h-4" />
            Voltar para Área de Membros
          </Link>
          <h1 className="text-2xl font-bold mb-2">{quiz.title}</h1>
          {quiz.description && (
            <p className="text-muted-foreground">{quiz.description}</p>
          )}
        </div>
        
        {/* Progress and Stats */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {formatTime(timeSpent)}
            </Badge>
            <Badge variant="outline">
              Questão {currentQuestion + 1} de {totalQuestions}
            </Badge>
          </div>
          <Badge variant="secondary">
            {attemptsRemaining} tentativas restantes
          </Badge>
        </div>
        
        <Progress value={progress} className="mb-8" />
        
        {/* Question Card */}
        {question && (
          <Card className="bg-card/50 border-border/50 mb-6">
            <CardHeader>
              <CardTitle className="text-lg">
                {currentQuestion + 1}. {question.question}
              </CardTitle>
              {question.type === "multiple_select" && (
                <CardDescription>Selecione todas as opções corretas</CardDescription>
              )}
            </CardHeader>
            <CardContent>
              {question.type === "multiple_choice" || question.type === "true_false" ? (
                <RadioGroup
                  value={answers[question.id.toString()]?.[0] || ""}
                  onValueChange={(value) => handleAnswerChange(question.id.toString(), value, false)}
                >
                  {(question.options as any[]).map((option: any) => (
                    <div key={option.id} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                      <RadioGroupItem value={option.id} id={option.id} />
                      <Label htmlFor={option.id} className="flex-1 cursor-pointer">
                        {option.text}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              ) : (
                <div className="space-y-2">
                  {(question.options as any[]).map((option: any) => (
                    <div key={option.id} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                      <Checkbox
                        id={option.id}
                        checked={answers[question.id.toString()]?.includes(option.id) || false}
                        onCheckedChange={() => handleAnswerChange(question.id.toString(), option.id, true)}
                      />
                      <Label htmlFor={option.id} className="flex-1 cursor-pointer">
                        {option.text}
                      </Label>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}
        
        {/* Navigation */}
        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={() => setCurrentQuestion((prev) => Math.max(0, prev - 1))}
            disabled={currentQuestion === 0}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Anterior
          </Button>
          
          {currentQuestion < totalQuestions - 1 ? (
            <Button
              onClick={() => setCurrentQuestion((prev) => Math.min(totalQuestions - 1, prev + 1))}
              disabled={!answers[question?.id.toString()]}
            >
              Próxima
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              disabled={!canSubmit || submitAttempt.isPending}
            >
              {submitAttempt.isPending ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Award className="w-4 h-4 mr-2" />
              )}
              Finalizar Quiz
            </Button>
          )}
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
