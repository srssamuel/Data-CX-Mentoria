import { useState, useEffect } from "react";
import { useSearch } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import {
  Award,
  CheckCircle2,
  XCircle,
  Search,
  Shield,
  Calendar,
  User,
  BookOpen,
  Loader2,
  Download,
} from "lucide-react";

interface VerificationResult {
  valid: boolean;
  certificate?: {
    certificateNumber: string;
    category: string;
    categoryName?: string;
    type?: string;
    completionDate: string;
    userName: string;
    verificationCode: string;
    pdfUrl?: string;
  };
}

const categoryNames: Record<string, string> = {
  introducao: "Introdução ao Protocolo Vértice",
  cx: "Customer Experience (CX)",
  dados: "Gestão de Dados",
  ia: "Inteligência Artificial",
  general: "Protocolo Vértice — Formação Completa",
};

export default function VerifyCertificate() {
  const searchString = useSearch();
  const params = new URLSearchParams(searchString);
  const codeFromUrl = params.get("code") || "";

  const [code, setCode] = useState(codeFromUrl);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<VerificationResult | null>(null);
  const [searched, setSearched] = useState(false);

  useEffect(() => {
    if (codeFromUrl) {
      handleVerify(codeFromUrl);
    }
  }, []);

  const handleVerify = async (verifyCode?: string) => {
    const codeToVerify = verifyCode || code;
    if (!codeToVerify.trim()) return;

    setLoading(true);
    setSearched(true);
    try {
      const res = await fetch(`/api/certificates/verify/${encodeURIComponent(codeToVerify.trim())}`);
      const data = await res.json();
      setResult(data);
    } catch {
      setResult({ valid: false });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container py-12 max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
            <Shield className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-3xl font-bold mb-2">Verificar Certificado</h1>
          <p className="text-muted-foreground">
            Insira o código de verificação para validar a autenticidade de um certificado.
          </p>
        </div>

        {/* Search */}
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="flex gap-2">
              <Input
                placeholder="Código de verificação (ex: abc123def456...)"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleVerify()}
                className="flex-1"
              />
              <Button onClick={() => handleVerify()} disabled={loading || !code.trim()}>
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Search className="w-4 h-4" />
                )}
                <span className="ml-2 hidden sm:inline">Verificar</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Result */}
        {searched && !loading && result && (
          <>
            {result.valid && result.certificate ? (
              <Card className={`${result.certificate.type === "general" ? "border-yellow-500/40 bg-gradient-to-br from-yellow-500/10 to-amber-900/10" : "border-green-500/30 bg-green-500/5"}`}>
                <CardHeader className="text-center pb-4">
                  <div className={`w-20 h-20 mx-auto mb-4 rounded-full flex items-center justify-center ${result.certificate.type === "general" ? "bg-yellow-500/10" : "bg-green-500/10"}`}>
                    {result.certificate.type === "general" ? (
                      <Award className="w-10 h-10 text-yellow-500" />
                    ) : (
                      <CheckCircle2 className="w-10 h-10 text-green-500" />
                    )}
                  </div>
                  <Badge className={`mx-auto mb-2 ${result.certificate.type === "general" ? "bg-yellow-500/10 text-yellow-500" : "bg-green-500/10 text-green-500"}`}>
                    {result.certificate.type === "general" ? (
                      <><Award className="w-3 h-3 mr-1" /> Certificado de Excelência</>
                    ) : (
                      <><CheckCircle2 className="w-3 h-3 mr-1" /> Certificado Válido</>
                    )}
                  </Badge>
                  <CardTitle className="text-2xl">
                    {result.certificate.type === "general" ? "Certificado Premium" : "Certificado Autêntico"}
                  </CardTitle>
                  {result.certificate.type === "general" && (
                    <p className="text-sm text-yellow-500/80 mt-1">Conclusão integral de todas as 4 trilhas do Protocolo Vértice</p>
                  )}
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-background/50 rounded-lg p-6 space-y-4">
                    <div className="flex items-center gap-3">
                      <User className="w-5 h-5 text-muted-foreground shrink-0" />
                      <div>
                        <p className="text-sm text-muted-foreground">Emitido para</p>
                        <p className="font-semibold text-lg">{result.certificate.userName}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <BookOpen className={`w-5 h-5 shrink-0 ${result.certificate.type === "general" ? "text-yellow-500" : "text-muted-foreground"}`} />
                      <div>
                        <p className="text-sm text-muted-foreground">
                          {result.certificate.type === "general" ? "Formação" : "Módulo Concluído"}
                        </p>
                        <p className={`font-semibold ${result.certificate.type === "general" ? "text-yellow-500" : ""}`}>
                          {result.certificate.categoryName || categoryNames[result.certificate.category] || result.certificate.category}
                        </p>
                        {result.certificate.type === "general" && (
                          <p className="text-xs text-muted-foreground mt-1">120 horas · Introdução + CX + Dados + IA</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <Calendar className="w-5 h-5 text-muted-foreground shrink-0" />
                      <div>
                        <p className="text-sm text-muted-foreground">Data de Conclusão</p>
                        <p className="font-semibold">
                          {new Date(result.certificate.completionDate).toLocaleDateString("pt-BR", {
                            day: "2-digit",
                            month: "long",
                            year: "numeric",
                          })}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <Award className="w-5 h-5 text-muted-foreground shrink-0" />
                      <div>
                        <p className="text-sm text-muted-foreground">Número do Certificado</p>
                        <p className="font-mono font-semibold">{result.certificate.certificateNumber}</p>
                      </div>
                    </div>
                  </div>

                  {result.certificate.pdfUrl && (
                    <div className="text-center pt-2">
                      <Button asChild variant="outline" className="gap-2">
                        <a href={result.certificate.pdfUrl} target="_blank" rel="noopener noreferrer">
                          <Download className="w-4 h-4" />
                          Baixar Certificado PDF
                        </a>
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card className="border-red-500/30 bg-red-500/5">
                <CardContent className="pt-8 pb-8 text-center">
                  <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-red-500/10 flex items-center justify-center">
                    <XCircle className="w-10 h-10 text-red-500" />
                  </div>
                  <Badge className="mx-auto bg-red-500/10 text-red-500 mb-4">
                    <XCircle className="w-3 h-3 mr-1" />
                    Não Encontrado
                  </Badge>
                  <h2 className="text-xl font-bold mb-2">Certificado Não Encontrado</h2>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    Nenhum certificado foi encontrado com este código de verificação.
                    Verifique se o código foi digitado corretamente.
                  </p>
                </CardContent>
              </Card>
            )}
          </>
        )}

        {/* Info */}
        <Card className="mt-8 bg-muted/30">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-lg bg-primary/10 shrink-0">
                <Shield className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Como funciona a verificação?</h3>
                <p className="text-sm text-muted-foreground">
                  Cada certificado emitido pela Data CX possui um código de verificação único.
                  Este código pode ser usado por empregadores, recrutadores ou qualquer pessoa
                  para confirmar a autenticidade do certificado. A verificação é pública e não
                  requer login.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
