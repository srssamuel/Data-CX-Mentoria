import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO from "@/components/SEO";
import { useState, useMemo, useEffect, useRef } from "react";
import { trackHelpSearch, trackHelpFaqOpened } from "@/lib/analytics";
import {
  HelpCircle,
  Search,
  BookOpen,
  MessageCircle,
  Mail,
  CreditCard,
  GraduationCap,
  Shield,
  Users,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  Headphones,
  Clock,
  Sparkles,
  ArrowRight,
} from "lucide-react";

interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

const faqItems: FAQItem[] = [
  // Acesso e Conta
  {
    category: "acesso",
    question: "Como acesso a Área de Membros?",
    answer: "Após fazer login, clique em \"Área de Membros\" no menu principal ou acesse diretamente /membros. Todos os seus materiais estarão organizados por trilha (CX, Dados, IA).",
  },
  {
    category: "acesso",
    question: "Esqueci minha senha. Como recupero?",
    answer: "Na tela de login, clique em \"Esqueci minha senha\". Você receberá um e-mail com um link para criar uma nova senha. O link é válido por 1 hora.",
  },
  {
    category: "acesso",
    question: "Posso acessar de qualquer dispositivo?",
    answer: "Sim! A plataforma é responsiva e funciona em computadores, tablets e celulares. Basta fazer login com suas credenciais em qualquer navegador.",
  },
  // Pagamento
  {
    category: "pagamento",
    question: "Quais formas de pagamento são aceitas?",
    answer: "Aceitamos cartão de crédito (Visa, Mastercard, Amex) através do Stripe, nossa plataforma de pagamento segura. Parcelamento disponível conforme o programa.",
  },
  {
    category: "pagamento",
    question: "Como aplico um cupom de desconto?",
    answer: "Na página de Programas (/ofertas), há um campo \"Tem um cupom de desconto?\" no topo. Digite o código e clique em \"Aplicar\". O desconto será refletido em todos os preços automaticamente.",
  },
  {
    category: "pagamento",
    question: "Recebi um cupom 100% OFF. Preciso colocar cartão?",
    answer: "Não! Cupons com 100% de desconto ativam a inscrição gratuita diretamente, sem necessidade de informar dados de pagamento. Basta clicar em \"Confirmar inscrição gratuita\".",
  },
  {
    category: "pagamento",
    question: "Posso solicitar reembolso?",
    answer: "Sim. Oferecemos garantia de 7 dias para produtos digitais, conforme o Código de Defesa do Consumidor. Entre em contato pelo WhatsApp ou e-mail para solicitar.",
  },
  // Conteúdo
  {
    category: "conteudo",
    question: "Como funciona o progresso dos módulos?",
    answer: "Ao concluir cada módulo (marcar como concluído), seu progresso é atualizado automaticamente. Você pode acompanhar pela barra de progresso na Área de Membros e na página de Certificados.",
  },
  {
    category: "conteudo",
    question: "Posso baixar os materiais em PDF?",
    answer: "Sim! Os playbooks e materiais de apoio estão disponíveis para download em PDF na Área de Membros. Clique no ícone de download ao lado de cada material.",
  },
  {
    category: "conteudo",
    question: "Por quanto tempo tenho acesso ao conteúdo?",
    answer: "O Playbook Vértice tem acesso vitalício. Mentorias em grupo incluem acesso às gravações por 1 ano. Mentorias individuais incluem acesso vitalício aos materiais de apoio.",
  },
  // Certificados
  {
    category: "certificados",
    question: "Como ganho um certificado?",
    answer: "Complete todos os módulos de uma trilha (CX, Dados ou IA) para ganhar o certificado daquela categoria. Complete as 4 trilhas para ganhar o Certificado de Excelência (Formação Completa).",
  },
  {
    category: "certificados",
    question: "O certificado é verificável?",
    answer: "Sim! Cada certificado possui um código único de verificação. Qualquer pessoa pode verificar a autenticidade em /verificar-certificado usando o código.",
  },
  {
    category: "certificados",
    question: "Posso compartilhar meu certificado no LinkedIn?",
    answer: "Sim! Na página de Certificados, use o botão \"Compartilhar no LinkedIn\" para publicar diretamente no seu perfil profissional.",
  },
  // Mentoria
  {
    category: "mentoria",
    question: "Como funciona a mentoria em grupo?",
    answer: "São 8 encontros semanais ao vivo de 2h cada, com turmas de até 15 pessoas. Você recebe acesso ao grupo exclusivo no WhatsApp, materiais complementares e certificado de conclusão.",
  },
  {
    category: "mentoria",
    question: "Como agendar sessões de mentoria individual?",
    answer: "Após a compra, Samuel Rosa entrará em contato em até 48h para agendar sua primeira sessão. As sessões subsequentes são agendadas de comum acordo.",
  },
  {
    category: "mentoria",
    question: "Posso remarcar uma sessão?",
    answer: "Sim, com aviso de pelo menos 24 horas de antecedência. Remarcações podem ser feitas diretamente pelo WhatsApp com Samuel Rosa.",
  },
];

const categories = [
  { id: "todos", name: "Todos", icon: HelpCircle },
  { id: "acesso", name: "Acesso e Conta", icon: Shield },
  { id: "pagamento", name: "Pagamento", icon: CreditCard },
  { id: "conteudo", name: "Conteúdo", icon: BookOpen },
  { id: "certificados", name: "Certificados", icon: GraduationCap },
  { id: "mentoria", name: "Mentoria", icon: Users },
];

function FAQAccordion({ item }: { item: FAQItem }) {
  const [isOpen, setIsOpen] = useState(false);
  const handleToggle = () => {
    if (!isOpen) trackHelpFaqOpened(item.question);
    setIsOpen(!isOpen);
  };
  
  return (
    <div className="border border-border/50 rounded-lg overflow-hidden">
      <button
        onClick={handleToggle}
        className="w-full flex items-center justify-between p-4 text-left hover:bg-muted/30 transition-colors"
      >
        <span className="font-medium text-sm pr-4">{item.question}</span>
        <ChevronDown className={`w-4 h-4 text-muted-foreground flex-shrink-0 transition-transform ${isOpen ? "rotate-180" : ""}`} />
      </button>
      {isOpen && (
        <div className="px-4 pb-4 text-sm text-muted-foreground border-t border-border/30 pt-3">
          {item.answer}
        </div>
      )}
    </div>
  );
}

export default function Help() {
  const { isAuthenticated } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("todos");

  // Track search with debounce
  const searchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (searchQuery.trim().length >= 3) {
      if (searchTimerRef.current) clearTimeout(searchTimerRef.current);
      searchTimerRef.current = setTimeout(() => {
        const query = searchQuery.toLowerCase();
        const results = faqItems.filter(
          item => item.question.toLowerCase().includes(query) || item.answer.toLowerCase().includes(query)
        );
        trackHelpSearch(searchQuery, results.length);
      }, 800);
    }
    return () => { if (searchTimerRef.current) clearTimeout(searchTimerRef.current); };
  }, [searchQuery]);

  const filteredFAQ = useMemo(() => {
    let items = faqItems;
    
    if (selectedCategory !== "todos") {
      items = items.filter(item => item.category === selectedCategory);
    }
    
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      items = items.filter(
        item => item.question.toLowerCase().includes(query) || item.answer.toLowerCase().includes(query)
      );
    }
    
    return items;
  }, [searchQuery, selectedCategory]);

  return (
    <div className="min-h-screen bg-background">
      <SEO 
        title="Central de Ajuda - Protocolo Vértice" 
        description="Encontre respostas para suas dúvidas sobre acesso, pagamento, conteúdo, certificados e mentorias." 
        path="/ajuda" 
      />
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="absolute inset-0 bg-radial" />
        <div className="container relative z-10">
          <div className="max-w-2xl mx-auto text-center">
            <Badge className="mb-4 bg-primary/20 text-primary">
              <Headphones className="w-3 h-3 mr-1" />
              Central de Ajuda
            </Badge>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              Como podemos <span className="gradient-text">ajudar</span>?
            </h1>
            <p className="text-muted-foreground mb-8">
              Encontre respostas rápidas ou entre em contato com nosso suporte.
            </p>
            
            {/* Search */}
            <div className="relative max-w-lg mx-auto">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Buscar por dúvida..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="pl-12 h-12 text-base bg-card/80 border-border/50"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Quick Links */}
      <section className="pb-8">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 max-w-3xl mx-auto">
            <Link href="/membros">
              <Card className="hover:border-primary/30 transition-colors cursor-pointer h-full">
                <CardContent className="p-4 text-center">
                  <BookOpen className="w-6 h-6 text-primary mx-auto mb-2" />
                  <p className="text-sm font-medium">Área de Membros</p>
                </CardContent>
              </Card>
            </Link>
            <Link href="/certificados">
              <Card className="hover:border-primary/30 transition-colors cursor-pointer h-full">
                <CardContent className="p-4 text-center">
                  <GraduationCap className="w-6 h-6 text-primary mx-auto mb-2" />
                  <p className="text-sm font-medium">Certificados</p>
                </CardContent>
              </Card>
            </Link>
            <Link href="/ofertas">
              <Card className="hover:border-primary/30 transition-colors cursor-pointer h-full">
                <CardContent className="p-4 text-center">
                  <Sparkles className="w-6 h-6 text-primary mx-auto mb-2" />
                  <p className="text-sm font-medium">Programas</p>
                </CardContent>
              </Card>
            </Link>
            <Link href="/contato">
              <Card className="hover:border-primary/30 transition-colors cursor-pointer h-full">
                <CardContent className="p-4 text-center">
                  <MessageCircle className="w-6 h-6 text-primary mx-auto mb-2" />
                  <p className="text-sm font-medium">Contato</p>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-12">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            {/* Category Tabs */}
            <div className="flex flex-wrap gap-2 mb-6">
              {categories.map(cat => {
                const Icon = cat.icon;
                return (
                  <Button
                    key={cat.id}
                    variant={selectedCategory === cat.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(cat.id)}
                    className="text-xs"
                  >
                    <Icon className="w-3 h-3 mr-1" />
                    {cat.name}
                  </Button>
                );
              })}
            </div>

            {/* FAQ Items */}
            <div className="space-y-2">
              {filteredFAQ.length > 0 ? (
                filteredFAQ.map((item, index) => (
                  <FAQAccordion key={index} item={item} />
                ))
              ) : (
                <div className="text-center py-12">
                  <Search className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                  <p className="text-muted-foreground mb-2">Nenhum resultado encontrado</p>
                  <p className="text-sm text-muted-foreground/70">
                    Tente buscar com outros termos ou entre em contato conosco.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-12 bg-card/20">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Não encontrou sua resposta?</h2>
              <p className="text-muted-foreground">Fale diretamente com nosso time de suporte.</p>
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <Card className="hover:border-primary/30 transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-3">
                    <MessageCircle className="w-6 h-6 text-green-500" />
                  </div>
                  <h3 className="font-semibold mb-1">WhatsApp</h3>
                  <p className="text-xs text-muted-foreground mb-3">Resposta em até 2 horas</p>
                  <a href="https://wa.me/5584991278513" target="_blank" rel="noopener noreferrer">
                    <Button size="sm" variant="outline" className="w-full">
                      Enviar mensagem
                      <ExternalLink className="w-3 h-3 ml-1" />
                    </Button>
                  </a>
                </CardContent>
              </Card>

              <Card className="hover:border-primary/30 transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                    <Mail className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-1">E-mail</h3>
                  <p className="text-xs text-muted-foreground mb-3">Resposta em até 24 horas</p>
                  <a href="mailto:contato@datacx.com.br">
                    <Button size="sm" variant="outline" className="w-full">
                      Enviar e-mail
                      <ExternalLink className="w-3 h-3 ml-1" />
                    </Button>
                  </a>
                </CardContent>
              </Card>

              <Card className="hover:border-primary/30 transition-colors">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-3">
                    <Clock className="w-6 h-6 text-accent" />
                  </div>
                  <h3 className="font-semibold mb-1">Horário</h3>
                  <p className="text-xs text-muted-foreground mb-3">Seg a Sex, 9h às 18h</p>
                  <Link href="/contato">
                    <Button size="sm" variant="outline" className="w-full">
                      Formulário de contato
                      <ArrowRight className="w-3 h-3 ml-1" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
