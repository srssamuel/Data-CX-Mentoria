import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO, { PAGE_SEO } from "@/components/SEO";
import JsonLd, { ORGANIZATION_LD, COURSE_LD, FAQ_LD } from "@/components/JsonLd";
import { trpc } from "@/lib/trpc";
import {
  ArrowRight,
  TrendingUp,
  Target,
  Zap,
  Shield,
  Users,
  BarChart3,
  Brain,
  CheckCircle2,
  Star,
  ChevronRight,
  Play,
  Clock,
  Award,
  Sparkles,
} from "lucide-react";
import { motion } from "framer-motion";

const fadeInUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
};

export default function Home() {
  const { isAuthenticated } = useAuth();
  const { data: testimonials } = trpc.testimonials.listActive.useQuery();

  return (
    <div className="min-h-screen bg-background bg-navy-gradient">
      <SEO title={PAGE_SEO.home.title} description={PAGE_SEO.home.description} path="/" />
      <JsonLd data={ORGANIZATION_LD} />
      <JsonLd data={COURSE_LD} />
      <JsonLd data={FAQ_LD} />
      <Navbar />

      {/* Hero Banner - Full-Width Cinematográfico */}
      <section className="relative min-h-[85vh] flex items-center overflow-hidden w-full">
        {/* Background Image - Full Width */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat scale-105"
          style={{ backgroundImage: 'url(https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/UhtZnSJroZcyyuqb.png)' }}
        />
        {/* Cinematic Overlays */}
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/85 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-background/40" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-transparent to-background" />
        {/* Vignette effect */}
        <div className="absolute inset-0" style={{ boxShadow: 'inset 0 0 200px rgba(0,0,0,0.5)' }} />
        
        <div className="w-full relative z-10 py-24 px-6 sm:px-10 md:px-16 lg:px-24 xl:px-32 2xl:px-40">
          <div className="max-w-3xl">
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-coral mb-6"
            >
              <Sparkles className="w-4 h-4" />
              <span className="text-sm font-medium">Agora é a hora da transformação</span>
            </motion.div>

            {/* Main Headline - Impactante */}
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-extrabold leading-[1.1] mb-6 drop-shadow-lg"
            >
              Vai ficar parado?
              <br />
              <span className="gradient-text">Qual seu próximo nível?</span>
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg md:text-xl text-muted-foreground max-w-xl mb-10 drop-shadow-sm"
            >
              O <strong className="text-foreground">Protocolo Vértice</strong> é a metodologia para tirar sua operação do achismo, aumentar previsibilidade e acelerar decisões — com governança, cadência e execução.
            </motion.p>

            {/* CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Link href="/radar">
                <Button size="lg" className="btn-coral px-8 h-14 text-base rounded-xl shadow-lg shadow-coral/20">
                  Descobrir Meu Nível (Gratuito)
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link href="/ofertas">
                <Button size="lg" variant="outline" className="px-8 h-14 text-base rounded-xl border-2 bg-background/30 backdrop-blur-sm hover:bg-background/50">
                  Ver Programas
                </Button>
              </Link>
            </motion.div>

            {/* Social Proof Mini */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="flex items-center gap-4 mt-10"
            >
              <div className="flex -space-x-2">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="w-8 h-8 rounded-full bg-gradient-to-br from-primary/40 to-accent/40 border-2 border-background flex items-center justify-center">
                    <Users className="w-3 h-3 text-primary" />
                  </div>
                ))}
              </div>
              <div className="text-sm text-muted-foreground">
                <span className="text-foreground font-semibold">+70 profissionais</span> já transformaram suas carreiras
              </div>
            </motion.div>
          </div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
        >
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="w-6 h-10 rounded-full border-2 border-white/20 flex items-start justify-center p-1.5"
          >
            <div className="w-1.5 h-1.5 rounded-full bg-white/40" />
          </motion.div>
        </motion.div>
      </section>

      {/* Hero Section - G4 Style */}
      <section id="main-content" className="relative py-20 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="absolute inset-0 bg-radial" />
        <div className="absolute inset-0 bg-radial-coral" />
        
        {/* Geometric shapes */}
        <div className="absolute top-20 right-10 w-72 h-72 border border-primary/20 rounded-full opacity-30" />
        <div className="absolute bottom-20 left-10 w-48 h-48 border border-coral/20 rounded-full opacity-30" />

        <div className="container relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div>
              {/* Badge - G4 Style */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-coral mb-6"
              >
                <Sparkles className="w-4 h-4" />
                <span className="text-sm font-medium">Vagas Limitadas — Próxima Turma em Breve</span>
              </motion.div>

              {/* Main Headline */}
              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-[1.1] mb-6"
              >
                Transforme{" "}
                <span className="gradient-text">CX, Dados e IA</span>
                <br />
                em Resultado Real
              </motion.h1>

              {/* Subheadline */}
              <motion.p
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="text-lg text-muted-foreground max-w-xl mb-8"
              >
                O <strong className="text-foreground">Protocolo Vértice</strong> é a metodologia para tirar sua operação do achismo, aumentar previsibilidade e acelerar decisões — com governança, cadência e execução.
              </motion.p>

              {/* CTAs - G4 Style */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="flex flex-col sm:flex-row gap-4 mb-8"
              >
                <Link href="/radar">
                  <Button size="lg" className="btn-coral px-8 h-14 text-base rounded-xl">
                    Descobrir Meu Nível (Gratuito)
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                <Link href="/ofertas">
                  <Button size="lg" variant="outline" className="px-8 h-14 text-base rounded-xl border-2">
                    Ver Programas
                  </Button>
                </Link>
              </motion.div>

              {/* Social Proof - G4 Style */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="flex items-center gap-6"
              >
                <div className="flex -space-x-3">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div
                      key={i}
                      className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/30 to-accent/30 border-2 border-background flex items-center justify-center"
                    >
                      <Users className="w-4 h-4 text-primary" />
                    </div>
                  ))}
                </div>
                <div>
                  <div className="flex items-center gap-1 mb-1">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-500 text-yellow-500" />
                    ))}
                    <span className="text-sm font-semibold ml-1">4.9</span>
                  </div>
                  <p className="text-sm text-muted-foreground">+70 profissionais transformados</p>
                </div>
              </motion.div>
            </div>

            {/* Right Content - Mentor Card */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="relative hidden lg:block"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-coral/10 rounded-3xl blur-3xl" />
              <Card className="relative program-card rounded-3xl overflow-hidden">
                <CardContent className="p-0">
                  {/* Image Section */}
                  <div className="relative h-80 bg-gradient-to-br from-primary/20 to-accent/10 flex items-center justify-center">
                    <img 
                      src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/MtNKHhWTMcGIDMFy.jpeg" 
                      alt="Samuel Rosa"
                      className="w-48 h-48 rounded-full object-cover object-[center_25%] border-4 border-background shadow-2xl"
                    />
                    <div className="absolute bottom-4 left-4 right-4">
                      <div className="glass rounded-xl p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-semibold">Samuel Rosa</p>
                            <p className="text-sm text-muted-foreground">Especialista em CX, Dados & IA</p>
                          </div>
                          <div className="badge-teal px-3 py-1 rounded-full text-xs font-medium">
                            Mentor
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Stats Section */}
                  <div className="p-6 grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary stat-number">+70</div>
                      <div className="text-xs text-muted-foreground">Clientes</div>
                    </div>
                    <div className="text-center border-x border-border">
                      <div className="text-2xl font-bold text-primary stat-number">+10</div>
                      <div className="text-xs text-muted-foreground">Segmentos</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary stat-number">15+</div>
                      <div className="text-xs text-muted-foreground">Anos Exp.</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Bar - G4 Style */}
      <section className="py-8 border-y border-border/50 bg-card/30">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: "$4.4T", label: "Impacto IA/ano (McKinsey)" },
              { value: "70%", label: "Atividades automatizáveis" },
              { value: "+70", label: "Clientes atendidos" },
              { value: "10+", label: "Segmentos de mercado" },
            ].map((stat, idx) => (
              <div key={idx} className="text-center">
                <div className="text-2xl md:text-3xl font-bold gradient-text stat-number">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* McKinsey Data Section - G4 Style */}
      <section className="py-20 md:py-28 relative overflow-hidden">
        <div className="absolute inset-0 bg-radial opacity-50" />
        <div className="container relative z-10">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-coral mb-4">
              <TrendingUp className="w-4 h-4" />
              <span className="text-sm font-medium">Dados McKinsey Global Institute</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              O Momento é <span className="gradient-text">Agora</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              A IA Generativa pode adicionar entre $2.6 e $4.4 trilhões anuais à economia global. Customer Operations e Marketing são as áreas mais impactadas.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: TrendingUp,
                title: "$2.6 - $4.4 Trilhões",
                description: "Potencial anual de impacto econômico da IA Generativa segundo McKinsey.",
                highlight: true,
              },
              {
                icon: Users,
                title: "Customer Operations",
                description: "Uma das 4 áreas com maior potencial: automação, análise de sentimento e personalização.",
              },
              {
                icon: BarChart3,
                title: "60-70% das Atividades",
                description: "Podem ser automatizadas com IA, liberando tempo para atividades de maior valor.",
              },
            ].map((item, idx) => (
              <Card 
                key={idx} 
                className={`program-card rounded-2xl ${item.highlight ? 'border-primary/50 glow' : ''}`}
              >
                <CardContent className="p-8">
                  <div className={`w-14 h-14 rounded-2xl ${item.highlight ? 'bg-primary/20' : 'bg-card'} flex items-center justify-center mb-6`}>
                    <item.icon className={`w-7 h-7 ${item.highlight ? 'text-primary' : 'text-muted-foreground'}`} />
                  </div>
                  <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                  <p className="text-muted-foreground">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Protocolo Vértice Section - G4 Style */}
      <section className="py-20 md:py-28 bg-card/30 relative">
        <div className="container">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-teal mb-4">
              <Award className="w-4 h-4" />
              <span className="text-sm font-medium">Metodologia Exclusiva</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Protocolo <span className="gradient-text">Vértice</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Onde CX, dados e IA viram resultado. O ponto de convergência onde você para de discutir opinião e começa a discutir evidência.
            </p>
          </div>

          {/* Manifesto - G4 Style Card */}
          <div className="max-w-4xl mx-auto mb-16">
            <Card className="program-card rounded-3xl overflow-hidden">
              <CardContent className="p-0">
                <div className="grid md:grid-cols-2">
                  <div className="p-8 md:p-12 bg-gradient-to-br from-primary/10 to-transparent">
                    <h3 className="text-2xl font-bold mb-6">O Manifesto</h3>
                    <div className="space-y-4">
                      <p className="text-muted-foreground">
                        Eu não acredito em CX como "projeto bonito".
                        <br />
                        <span className="text-foreground font-semibold">Eu acredito em CX como sistema.</span>
                      </p>
                      <p className="text-muted-foreground">
                        Eu não acredito em dados como "report".
                        <br />
                        <span className="text-foreground font-semibold">Eu acredito em dados como motor de decisão.</span>
                      </p>
                      <p className="text-muted-foreground">
                        Eu não acredito em IA como mágica.
                        <br />
                        <span className="text-foreground font-semibold">Eu acredito em IA como alavanca — com governança.</span>
                      </p>
                    </div>
                  </div>
                  <div className="p-8 md:p-12 flex flex-col justify-center">
                    <div className="badge-coral inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium w-fit mb-4">
                      <Sparkles className="w-4 h-4" />
                      Tagline
                    </div>
                    <p className="text-2xl font-bold gradient-text mb-4">
                      "Do atrito ao ROI — com método."
                    </p>
                    <p className="text-muted-foreground">
                      O Protocolo Vértice é o caminho prático para transformar complexidade em clareza — e clareza em execução.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 5 Steps - G4 Style */}
          <div className="grid md:grid-cols-5 gap-4">
            {[
              { step: 1, title: "Clareza", description: "Qual problema, pra quem, e como se traduz em negócio?", icon: Target },
              { step: 2, title: "Evidência", description: "Diagnóstico orientado por dados + realidade da operação.", icon: BarChart3 },
              { step: 3, title: "Prioridade", description: "Foco no que muda resultado: impacto × esforço × risco.", icon: Zap },
              { step: 4, title: "Execução", description: "Plano que roda na vida real: dono, cadência, ritual.", icon: CheckCircle2 },
              { step: 5, title: "Escala", description: "IA e automação como alavanca com governança.", icon: Brain },
            ].map((item) => (
              <Card key={item.step} className="program-card card-hover rounded-2xl">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mx-auto mb-4 border border-primary/30">
                    <span className="text-primary font-bold text-lg">{item.step}</span>
                  </div>
                  <item.icon className="w-8 h-8 text-primary mx-auto mb-3" />
                  <h3 className="font-bold mb-2">{item.title}</h3>
                  <p className="text-muted-foreground text-sm">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Programs Section - G4 Style */}
      <section className="py-20 md:py-28 relative">
        <div className="container">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-coral mb-4">
              <Award className="w-4 h-4" />
              <span className="text-sm font-medium">Programas de Mentoria</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Qual é o seu <span className="gradient-text">momento</span>?
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Escolha o caminho que faz mais sentido para você
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                title: "Jovem Profissional",
                subtitle: "18-26 anos",
                description: "Começando a carreira, buscando diferencial e direção",
                link: "/mentoria-jovens",
                badge: "Entrada",
                badgeColor: "badge-teal",
              },
              {
                title: "Gestor",
                subtitle: "Coordenadores e Gerentes",
                description: "Já gere pessoas e rotina, quer aplicar CX/Dados/IA",
                link: "/mentoria-gestores",
                badge: "Popular",
                badgeColor: "badge-coral",
              },
              {
                title: "Executivo",
                subtitle: "Alta Gestão",
                description: "Precisa liderar transformação com clareza",
                link: "/mentoria-executivos",
                badge: "Premium",
                badgeColor: "badge-teal",
              },
              {
                title: "Empresa",
                subtitle: "Diagnóstico & Assessoria",
                description: "Busca ROI e plano estratégico estruturado",
                link: "/empresas",
                badge: "Enterprise",
                badgeColor: "badge-coral",
              },
            ].map((persona, idx) => (
              <Link key={idx} href={persona.link}>
                <Card className="h-full program-card card-hover rounded-2xl cursor-pointer">
                  <CardContent className="p-6">
                    <div className={`${persona.badgeColor} px-3 py-1 rounded-full text-xs font-medium w-fit mb-4`}>
                      {persona.badge}
                    </div>
                    <h3 className="font-bold text-xl mb-1">{persona.title}</h3>
                    <p className="text-primary text-sm mb-3">{persona.subtitle}</p>
                    <p className="text-muted-foreground text-sm mb-6">{persona.description}</p>
                    <div className="flex items-center text-primary text-sm font-semibold group">
                      Saiba mais
                      <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-muted-foreground mb-4">Não sabe qual escolher?</p>
            <Link href="/radar">
              <Button className="btn-coral px-8 h-12 rounded-xl">
                Faça o Radar Vértice e descubra
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials - G4 Style */}
      {testimonials && testimonials.length > 0 && (
        <section className="py-20 md:py-28 bg-card/30">
          <div className="container">
            <div className="text-center mb-16">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-teal mb-4">
                <Star className="w-4 h-4" />
                <span className="text-sm font-medium">Depoimentos</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                O que dizem os <span className="gradient-text">Mentorados</span>
              </h2>
              <p className="text-muted-foreground">
                Resultados reais de quem aplicou o Protocolo Vértice
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {testimonials.slice(0, 3).map((testimonial) => (
                <Card key={testimonial.id} className="testimonial-card rounded-2xl">
                  <CardContent className="p-8">
                    <div className="flex gap-1 mb-6">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 fill-yellow-500 text-yellow-500" />
                      ))}
                    </div>
                    <p className="text-foreground mb-6 text-lg">"{testimonial.content}"</p>
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center">
                        <span className="text-primary font-bold text-lg">
                          {testimonial.name.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <p className="font-semibold">{testimonial.name}</p>
                        <p className="text-muted-foreground text-sm">
                          {testimonial.position} {testimonial.company && `@ ${testimonial.company}`}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Sobre Mim Section - Com fotos reais */}
      <section className="py-20 md:py-28 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-10" />
        <div className="container relative z-10">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-teal mb-4">
              <Award className="w-4 h-4" />
              <span className="text-sm font-medium">Sobre o Mentor</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Quem é <span className="gradient-text">Samuel Rosa</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              +15 anos transformando operações com CX, Dados e IA
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Fotos reais de palestras */}
            <div className="space-y-6">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <img 
                  src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/uUbuoGYMhDGuNGer.jpeg"
                  alt="Samuel Rosa no palco Data CX"
                  className="w-full h-[400px] object-cover object-[center_30%]"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background/90 to-transparent p-6">
                  <p className="text-sm font-medium">Data CX — Protocolo Vértice</p>
                  <p className="text-xs text-muted-foreground">Transformando operações com CX, Dados e IA</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="relative rounded-xl overflow-hidden">
                  <img 
                    src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/kZrSahAUrVlHGLGc.jpeg"
                    alt="Samuel Rosa ao lado do logo DCX"
                    className="w-full h-48 object-cover object-[center_20%]"
                  />
                </div>
                <div className="bg-gradient-to-br from-primary/20 to-accent/10 rounded-xl p-6 flex flex-col justify-center">
                  <div className="text-3xl font-bold text-primary mb-2">+70</div>
                  <div className="text-sm text-muted-foreground">Clientes transformados</div>
                </div>
              </div>
            </div>

            {/* Bio e credenciais */}
            <div className="space-y-6">
              <Card className="program-card rounded-2xl">
                <CardContent className="p-8">
                  <h3 className="text-xl font-bold mb-4">Especialista em CX, Dados & IA</h3>
                  <p className="text-muted-foreground mb-6">
                    Com mais de 15 anos de experiência em operações, tenho ajudado empresas de diversos segmentos 
                    a transformar a experiência do cliente em resultado real. Minha abordagem combina 
                    metodologia prática, dados como motor de decisão e IA como alavanca — sempre com governança.
                  </p>
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="text-center p-4 bg-background/50 rounded-xl">
                      <div className="text-2xl font-bold text-primary">10+</div>
                      <div className="text-xs text-muted-foreground">Segmentos atendidos</div>
                    </div>
                    <div className="text-center p-4 bg-background/50 rounded-xl">
                      <div className="text-2xl font-bold text-primary">15+</div>
                      <div className="text-xs text-muted-foreground">Anos de experiência</div>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <a 
                      href="https://www.linkedin.com/in/samuel-rosa-5a1447b7" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-sm text-primary hover:underline"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                      </svg>
                      LinkedIn
                    </a>
                    <a 
                      href="https://www.instagram.com/srssamuelrosa" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-sm text-primary hover:underline"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                      </svg>
                      Instagram
                    </a>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: "Financeiro", icon: TrendingUp },
                  { label: "Saúde", icon: Shield },
                  { label: "Telecom", icon: Zap },
                ].map((item, idx) => (
                  <div key={idx} className="text-center p-4 bg-card/50 rounded-xl border border-border/50">
                    <item.icon className="w-6 h-6 text-primary mx-auto mb-2" />
                    <div className="text-xs text-muted-foreground">{item.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Segmentos Atendidos - Prova Social */}
      <section className="py-16 bg-card/20">
        <div className="container">
          <p className="text-center text-sm text-muted-foreground uppercase tracking-widest mb-8">+10 segmentos atendidos em todo o Brasil</p>
          <div className="flex flex-wrap justify-center gap-4 md:gap-6 mb-12">
            {[
              { icon: "🏦", name: "Financeiro" },
              { icon: "🏥", name: "Saúde" },
              { icon: "🎓", name: "Educação" },
              { icon: "🛒", name: "Varejo" },
              { icon: "📱", name: "Telecom" },
              { icon: "🚗", name: "Mobilidade" },
              { icon: "🛡️", name: "Seguros" },
              { icon: "💻", name: "Tecnologia" },
              { icon: "🏭", name: "Indústria" },
              { icon: "🍔", name: "Delivery" },
            ].map((seg) => (
              <div key={seg.name} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-card/60 border border-border/40 text-muted-foreground hover:text-foreground hover:border-primary/30 transition-all">
                <span className="text-xl">{seg.icon}</span>
                <span className="text-sm font-medium">{seg.name}</span>
              </div>
            ))}
          </div>

          {/* Trust Badges */}
          <div className="flex flex-wrap justify-center gap-8 md:gap-12 pt-8 border-t border-border/30">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Shield className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm font-semibold">Pagamento Seguro</p>
                <p className="text-xs text-muted-foreground">Stripe + PIX</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Award className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm font-semibold">Certificado Verificável</p>
                <p className="text-xs text-muted-foreground">Código único de validação</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm font-semibold">Acesso Imediato</p>
                <p className="text-xs text-muted-foreground">Após confirmação do pagamento</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Users className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm font-semibold">+70 Profissionais</p>
                <p className="text-xs text-muted-foreground">Carreiras transformadas</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section - G4 Style */}
      <section className="py-20 md:py-28 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-coral/5" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl" />

        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto">
            <Card className="program-card rounded-3xl overflow-hidden border-primary/30">
              <CardContent className="p-8 md:p-16 text-center">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-coral mb-6">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm font-medium">Avaliação Gratuita — 5 minutos</span>
                </div>
                <h2 className="text-3xl md:text-4xl font-bold mb-6">
                  Descubra seu nível de maturidade
                </h2>
                <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
                  O <strong className="text-foreground">Radar Vértice</strong> é uma autoavaliação que mostra onde você está em CX, Dados, IA e Governança — e qual o próximo passo ideal para você.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link href="/radar">
                    <Button size="lg" className="btn-coral px-10 h-14 text-lg rounded-xl">
                      Fazer Radar Vértice
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                  <Link href="/contato">
                    <Button size="lg" variant="outline" className="px-10 h-14 text-lg rounded-xl border-2">
                      Prefiro Conversar
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
