import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { getChallengesForPersona } from "../../../shared/challengeSegments";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { trpc } from "@/lib/trpc";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO, { PAGE_SEO } from "@/components/SEO";
import { trackRadarCompleted } from "@/lib/analytics";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowRight,
  ArrowLeft,
  Target,
  BarChart3,
  Brain,
  Shield,
  CheckCircle2,
  Loader2,
  Download,
  Calendar,
  Sparkles,
  Bot,
  RefreshCw,
} from "lucide-react";
import { Streamdown } from "streamdown";
import { toast } from "sonner";

type Persona = "jovem" | "gestor" | "executivo" | "empresario";
type TeamSize = "1-10" | "11-50" | "51-200" | "200+";
type Urgency = "0-30" | "60" | "90" | "sem-urgencia";
type PreferredFormat = "grupo" | "individual";
type RecommendedLevel = "fundamentos" | "aplicacao" | "escala" | "estrategia";

interface FormData {
  name: string;
  email: string;
  phone: string;
  persona: Persona | "";
  sector: string;
  teamSize: TeamSize | "";
  mainGoal: string;
  mainCost: string;
  urgency: Urgency | "";
  preferredFormat: PreferredFormat | "";
  budgetRange: string;
  challenges: string;
  consentMarketing: boolean;
  consentPrivacy: boolean;
  consentWhatsapp: boolean;
}

interface Answers {
  [key: string]: number;
}

const sectors = [
  "Financeiro",
  "Mobilidade",
  "Saúde",
  "Seguros",
  "Delivery",
  "Telecom",
  "E-commerce",
  "Varejo",
  "Tecnologia",
  "Serviços",
  "Indústria",
  "Educação",
  "Outro",
];

const goals = [
  "Aumentar eficiência",
  "Reduzir atrito",
  "Melhorar conversão",
  "Melhorar retenção",
  "Estruturar área",
  "Aprender e se posicionar",
];

const costs = [
  "Tempo",
  "Dinheiro",
  "Reputação",
  "Equipe",
  "Clientes",
];

const budgetRanges = [
  "Até R$ 1.000",
  "R$ 1.000 - R$ 3.000",
  "R$ 3.000 - R$ 5.000",
  "R$ 5.000 - R$ 10.000",
  "Acima de R$ 10.000",
  "A definir",
];

// Questions organized by block
const questionBlocks = {
  cx: {
    title: "CX - Cliente & Jornada",
    icon: Target,
    questions: [
      { id: "cx1", text: "Eu consigo explicar a jornada do cliente e onde estão os principais atritos." },
      { id: "cx2", text: "Tenho clareza do que é 'boa experiência' no meu contexto (padrão)." },
      { id: "cx3", text: "Eu uso métricas de CX como ferramenta de decisão, não só como apresentação." },
      { id: "cx4", text: "Eu sei diferenciar 'sintoma' (nota/indicador) de 'causa' (driver)." },
      { id: "cx5", text: "Eu consigo transformar VOC/feedback em backlog priorizado." },
    ],
  },
  data: {
    title: "Dados - Métricas & Diagnóstico",
    icon: BarChart3,
    questions: [
      { id: "data1", text: "Eu confio nos números que uso para decidir (fonte, regra, consistência)." },
      { id: "data2", text: "Tenho indicadores bem definidos (conceito, fórmula, dono, meta, frequência)." },
      { id: "data3", text: "Eu sei fazer recortes que explicam variação (segmentação, coortes, perfis)." },
      { id: "data4", text: "Eu consigo ligar indicador a impacto (custo, receita, churn, retrabalho)." },
      { id: "data5", text: "Eu tenho uma rotina de acompanhamento (cadência) com ação e responsável." },
    ],
  },
  ia: {
    title: "IA - Uso & Confiança",
    icon: Brain,
    questions: [
      { id: "ia1", text: "Eu uso IA no meu dia a dia para produtividade (e-mail, síntese, drafts, análise)." },
      { id: "ia2", text: "Eu sei escrever prompts objetivos e revisar criticamente as respostas." },
      { id: "ia3", text: "Eu entendo onde IA ajuda mais: análise, classificação, automação, QA, etc." },
      { id: "ia4", text: "Eu sei os riscos básicos (privacidade, alucinação, compliance) e como mitigar." },
      { id: "ia5", text: "Eu tenho (ou consigo desenhar) um processo de validação humana ('human-in-the-loop')." },
    ],
  },
  governance: {
    title: "Governança & Execução",
    icon: Shield,
    questions: [
      { id: "gov1", text: "Eu tenho prioridades claras (impacto × esforço × risco) e não vivo apagando incêndio." },
      { id: "gov2", text: "Eu tenho rituais de gestão que sustentam evolução (reuniões que decidem)." },
      { id: "gov3", text: "Eu consigo transformar diagnóstico em plano 30/60/90 com donos e marcos." },
      { id: "gov4", text: "Eu tenho padrão de qualidade/execução (checklists, playbooks, calibração)." },
      { id: "gov5", text: "Eu sei medir se a melhoria 'pegou' ou se voltou ao normal." },
    ],
  },
};

const scaleLabels = [
  { value: 1, label: "Não faço / não sei" },
  { value: 2, label: "Faço raramente" },
  { value: 3, label: "Faço às vezes" },
  { value: 4, label: "Faço bem" },
  { value: 5, label: "Faço de forma consistente" },
];

const personaDescriptions = {
  jovem: {
    title: "Jovem Profissional (18-26)",
    description: "Começando a carreira, buscando diferencial e direção",
  },
  gestor: {
    title: "Gestor",
    description: "Já gere pessoas e rotina, quer aplicar CX/Dados/IA no dia a dia",
  },
  executivo: {
    title: "Executivo",
    description: "Alta gestão, precisa liderar transformação com clareza",
  },
  empresario: {
    title: "Empresário",
    description: "Dono de negócio, busca ROI e plano estratégico",
  },
};

export default function RadarVertice() {
  const [step, setStep] = useState(0); // 0: intro, 1: context, 2-5: questions, 6: intent, 7: result
  const [formData, setFormData] = useState<FormData>({
    name: "",
    email: "",
    phone: "",
    persona: "",
    sector: "",
    teamSize: "",
    mainGoal: "",
    mainCost: "",
    urgency: "",
    preferredFormat: "",
    budgetRange: "",
    challenges: "",
    consentMarketing: false,
    consentPrivacy: true,
    consentWhatsapp: false,
  });
  const [answers, setAnswers] = useState<Answers>({});
  const [result, setResult] = useState<{
    scoreCX: number;
    scoreData: number;
    scoreIA: number;
    scoreGovernance: number;
    scoreTotal: number;
    level: RecommendedLevel;
    product: string;
  } | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [aiAnalysisLoading, setAiAnalysisLoading] = useState(false);
  const [aiAnalysisError, setAiAnalysisError] = useState(false);
  const [leadId, setLeadId] = useState<number | null>(null);
  const [emailSent, setEmailSent] = useState(false);

  const saveAnalysisMutation = trpc.radar.saveAnalysis.useMutation();
  const sendEmailMutation = trpc.radar.sendDiagnosticEmail.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        setEmailSent(true);
        toast.success("Diagnóstico enviado para seu e-mail!");
      }
    },
    onError: () => {
      console.error("[Radar] Erro ao enviar email do diagnóstico");
    },
  });

  const analysisMutation = trpc.radar.generateAnalysis.useMutation({
    onSuccess: (data) => {
      setAiAnalysisLoading(false);
      if (data.success && data.analysis) {
        setAiAnalysis(data.analysis);
        // Salvar análise no banco se tiver leadId
        if (leadId) {
          saveAnalysisMutation.mutate({ leadId, analysis: data.analysis });
        }
        // Enviar email automático com diagnóstico completo
        if (leadId && result && !emailSent) {
          sendEmailMutation.mutate({
            leadId,
            email: formData.email,
            name: formData.name,
            persona: formData.persona || 'gestor',
            sector: formData.sector || undefined,
            scoreCX: result.scoreCX,
            scoreData: result.scoreData,
            scoreIA: result.scoreIA,
            scoreGovernance: result.scoreGovernance,
            scoreTotal: result.scoreTotal,
            recommendedLevel: result.level,
            recommendedProduct: result.product,
            aiAnalysis: data.analysis,
          });
        }
      } else {
        setAiAnalysisError(true);
        // Enviar email mesmo sem análise IA
        if (leadId && result && !emailSent) {
          sendEmailMutation.mutate({
            leadId,
            email: formData.email,
            name: formData.name,
            persona: formData.persona || 'gestor',
            sector: formData.sector || undefined,
            scoreCX: result.scoreCX,
            scoreData: result.scoreData,
            scoreIA: result.scoreIA,
            scoreGovernance: result.scoreGovernance,
            scoreTotal: result.scoreTotal,
            recommendedLevel: result.level,
            recommendedProduct: result.product,
          });
        }
      }
    },
    onError: () => {
      setAiAnalysisLoading(false);
      setAiAnalysisError(true);
      // Enviar email mesmo se análise IA falhar
      if (leadId && result && !emailSent) {
        sendEmailMutation.mutate({
          leadId,
          email: formData.email,
          name: formData.name,
          persona: formData.persona || 'gestor',
          sector: formData.sector || undefined,
          scoreCX: result.scoreCX,
          scoreData: result.scoreData,
          scoreIA: result.scoreIA,
          scoreGovernance: result.scoreGovernance,
          scoreTotal: result.scoreTotal,
          recommendedLevel: result.level,
          recommendedProduct: result.product,
        });
      }
    },
  });

  const submitMutation = trpc.radar.submit.useMutation({
    onSuccess: (data: any) => {
      toast.success("Resultado salvo com sucesso!");
      // Capturar o leadId retornado pelo submit
      if (data?.id) {
        setLeadId(data.id);
      }
      // Track radar completion
      if (data?.totalScore) {
        trackRadarCompleted(data.totalScore, data.persona || "");
      }
    },
    onError: () => {
      toast.error("Erro ao salvar resultado. Tente novamente.");
    },
  });

  const totalSteps = 7;
  const progress = (step / totalSteps) * 100;

  const calculateScores = () => {
    const cxQuestions = Object.keys(answers).filter((k) => k.startsWith("cx"));
    const dataQuestions = Object.keys(answers).filter((k) => k.startsWith("data"));
    const iaQuestions = Object.keys(answers).filter((k) => k.startsWith("ia"));
    const govQuestions = Object.keys(answers).filter((k) => k.startsWith("gov"));

    const avg = (keys: string[]) => {
      if (keys.length === 0) return 0;
      const sum = keys.reduce((acc, k) => acc + (answers[k] || 0), 0);
      return sum / keys.length;
    };

    const scoreCX = avg(cxQuestions);
    const scoreData = avg(dataQuestions);
    const scoreIA = avg(iaQuestions);
    const scoreGovernance = avg(govQuestions);
    const scoreTotal = (scoreCX + scoreData + scoreIA + scoreGovernance) / 4;

    // Determine recommendation level
    let level: RecommendedLevel;
    if (scoreTotal <= 2.2) {
      level = "fundamentos";
    } else if (scoreTotal <= 3.4) {
      level = "aplicacao";
    } else if (scoreTotal <= 4.2) {
      level = "escala";
    } else {
      level = "estrategia";
    }

    // Determine recommended product based on persona and level
    let product = "";
    const persona = formData.persona;
    const urgency = formData.urgency;

    if (persona === "empresario" && urgency === "0-30") {
      product = "Diagnóstico Vértice";
    } else if (persona === "executivo" && scoreIA < 2.5) {
      product = "Executive Briefing (2 sessões)";
    } else if (level === "fundamentos") {
      product = "Mentoria Vértice – Fundamentos";
    } else if (level === "aplicacao") {
      product = "Mentoria Vértice – Aplicação";
    } else if (level === "escala") {
      product = formData.preferredFormat === "individual" ? "Mentoria 1:1 (90 dias)" : "Mentoria Vértice Avançada";
    } else {
      product = persona === "empresario" ? "Assessoria Vértice (6 meses)" : "Mentoria Executive 1:1";
    }

    return { scoreCX, scoreData, scoreIA, scoreGovernance, scoreTotal, level, product };
  };

  const handleSubmit = async () => {
    const scores = calculateScores();
    setResult(scores);

    if (formData.persona && formData.consentPrivacy) {
      await submitMutation.mutateAsync({
        name: formData.name,
        email: formData.email,
        phone: formData.phone || undefined,
        persona: formData.persona as Persona,
        sector: formData.sector || undefined,
        teamSize: formData.teamSize as TeamSize || undefined,
        mainGoal: formData.mainGoal || undefined,
        answers,
        scoreCX: scores.scoreCX.toFixed(2),
        scoreData: scores.scoreData.toFixed(2),
        scoreIA: scores.scoreIA.toFixed(2),
        scoreGovernance: scores.scoreGovernance.toFixed(2),
        scoreTotal: scores.scoreTotal.toFixed(2),
        recommendedLevel: scores.level,
        recommendedProduct: scores.product,
        mainCost: formData.mainCost || undefined,
        urgency: formData.urgency as Urgency || undefined,
        preferredFormat: formData.preferredFormat as PreferredFormat || undefined,
        budgetRange: formData.budgetRange || undefined,
        challenges: formData.challenges || undefined,
        consentMarketing: formData.consentMarketing,
        consentPrivacy: formData.consentPrivacy,
        consentWhatsapp: formData.consentWhatsapp,
      });
    }

    setStep(7);

    // Disparar análise IA em paralelo (não bloqueia resultado)
    setAiAnalysisLoading(true);
    setAiAnalysisError(false);
    setAiAnalysis(null);
    analysisMutation.mutate({
      name: formData.name,
      persona: formData.persona as Persona,
      sector: formData.sector || undefined,
      teamSize: formData.teamSize || undefined,
      mainGoal: formData.mainGoal || undefined,
      mainCost: formData.mainCost || undefined,
      urgency: formData.urgency || undefined,
      challenges: formData.challenges || undefined,
      answers,
      scoreCX: scores.scoreCX,
      scoreData: scores.scoreData,
      scoreIA: scores.scoreIA,
      scoreGovernance: scores.scoreGovernance,
      scoreTotal: scores.scoreTotal,
      recommendedLevel: scores.level,
      recommendedProduct: scores.product,
    });
  };

  // Função para gerar e baixar PDF do resultado
  const handleDownloadPDF = async () => {
    if (!result) return;

    // Converter markdown da análise IA para HTML
    let aiAnalysisHtml = '';
    if (aiAnalysis) {
      const { marked } = await import('marked');
      aiAnalysisHtml = await marked.parse(aiAnalysis);
    }

    // Gerar respostas detalhadas por bloco
    const scaleMap: Record<number, string> = {
      1: 'Não faço / não sei',
      2: 'Faço raramente',
      3: 'Faço às vezes',
      4: 'Faço bem',
      5: 'Faço de forma consistente',
    };

    const renderBlock = (blockKey: string) => {
      const block = questionBlocks[blockKey as keyof typeof questionBlocks];
      return block.questions.map(q => {
        const val = answers[q.id] || 0;
        const pct = (val / 5) * 100;
        const color = val <= 2 ? '#ef4444' : val <= 3 ? '#f59e0b' : '#22c55e';
        return `
          <div style="margin-bottom: 12px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
              <span style="font-size: 13px; color: #374151; flex: 1; padding-right: 12px;">${q.text}</span>
              <span style="font-size: 13px; font-weight: 600; color: ${color}; white-space: nowrap;">${val}/5</span>
            </div>
            <div style="background: #e5e7eb; border-radius: 4px; height: 6px; overflow: hidden;">
              <div style="background: ${color}; height: 100%; width: ${pct}%; border-radius: 4px; transition: width 0.3s;"></div>
            </div>
            <div style="font-size: 11px; color: #9ca3af; margin-top: 2px;">${scaleMap[val] || ''}</div>
          </div>
        `;
      }).join('');
    };

    const levelLabel = result.level === 'fundamentos' ? 'Fundamentos' : result.level === 'aplicacao' ? 'Aplicação' : result.level === 'escala' ? 'Escala' : 'Estratégia & Execução';
    const personaLabel = formData.persona === 'jovem' ? 'Jovem Profissional' : formData.persona === 'gestor' ? 'Gestor de CX/CS' : formData.persona === 'executivo' ? 'Executivo C-Level' : 'Empresário/Founder';
    const dateStr = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });

    const scoreColor = (s: number) => s <= 2 ? '#ef4444' : s <= 3 ? '#f59e0b' : '#22c55e';

    const htmlContent = `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <title>Relatório Radar Vértice - ${formData.name}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
          
          * { margin: 0; padding: 0; box-sizing: border-box; }
          
          body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            color: #1f2937;
            background: #ffffff;
            line-height: 1.6;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          
          @page {
            size: A4;
            margin: 15mm 18mm;
          }
          
          .page {
            max-width: 210mm;
            margin: 0 auto;
            padding: 0;
          }
          
          /* Header */
          .header {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0c4a6e 100%);
            color: white;
            padding: 32px 36px;
            border-radius: 12px;
            margin-bottom: 28px;
            position: relative;
            overflow: hidden;
          }
          .header::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, rgba(59,130,246,0.15) 0%, transparent 70%);
            border-radius: 50%;
          }
          .header-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            position: relative;
            z-index: 1;
          }
          .logo-area {
            display: flex;
            align-items: center;
            gap: 12px;
          }
          .logo-box {
            width: 44px;
            height: 44px;
            background: rgba(255,255,255,0.15);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 16px;
            letter-spacing: -0.5px;
          }
          .logo-text {
            font-size: 20px;
            font-weight: 700;
            letter-spacing: -0.3px;
          }
          .logo-sub {
            font-size: 11px;
            opacity: 0.7;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            margin-top: 2px;
          }
          .header-badge {
            background: rgba(255,255,255,0.12);
            border: 1px solid rgba(255,255,255,0.2);
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
          }
          .header-title {
            position: relative;
            z-index: 1;
            margin-top: 20px;
          }
          .header-title h1 {
            font-size: 26px;
            font-weight: 800;
            letter-spacing: -0.5px;
          }
          .header-title p {
            font-size: 14px;
            opacity: 0.8;
            margin-top: 4px;
          }
          
          /* Info Grid */
          .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 28px;
          }
          .info-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 14px 16px;
          }
          .info-label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            color: #94a3b8;
            font-weight: 600;
            margin-bottom: 4px;
          }
          .info-value {
            font-size: 14px;
            font-weight: 600;
            color: #1e293b;
          }
          
          /* Score Total */
          .score-hero {
            background: linear-gradient(135deg, #0f172a, #1e3a5f);
            color: white;
            padding: 28px;
            border-radius: 12px;
            text-align: center;
            margin-bottom: 24px;
            position: relative;
            overflow: hidden;
          }
          .score-hero::after {
            content: '';
            position: absolute;
            bottom: -30%;
            left: -10%;
            width: 200px;
            height: 200px;
            background: radial-gradient(circle, rgba(99,102,241,0.2) 0%, transparent 70%);
            border-radius: 50%;
          }
          .score-hero-value {
            font-size: 56px;
            font-weight: 800;
            letter-spacing: -2px;
            position: relative;
            z-index: 1;
          }
          .score-hero-label {
            font-size: 14px;
            opacity: 0.8;
            margin-top: 4px;
            position: relative;
            z-index: 1;
          }
          .score-hero-badge {
            display: inline-block;
            background: rgba(255,255,255,0.15);
            border: 1px solid rgba(255,255,255,0.25);
            padding: 6px 20px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            margin-top: 12px;
            position: relative;
            z-index: 1;
          }
          
          /* Score Cards */
          .scores-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-bottom: 28px;
          }
          .score-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 18px 14px;
            text-align: center;
          }
          .score-card-value {
            font-size: 28px;
            font-weight: 800;
            letter-spacing: -1px;
          }
          .score-card-bar {
            height: 4px;
            background: #e5e7eb;
            border-radius: 2px;
            margin: 8px 0;
            overflow: hidden;
          }
          .score-card-bar-fill {
            height: 100%;
            border-radius: 2px;
          }
          .score-card-label {
            font-size: 11px;
            color: #64748b;
            font-weight: 500;
          }
          
          /* Sections */
          .section {
            margin-bottom: 28px;
            page-break-inside: avoid;
          }
          .section-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 16px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e2e8f0;
          }
          .section-icon {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
          }
          .section-title {
            font-size: 16px;
            font-weight: 700;
            color: #0f172a;
            letter-spacing: -0.3px;
          }
          
          /* Recommendation */
          .recommendation {
            background: linear-gradient(135deg, #eff6ff, #dbeafe);
            border: 1px solid #bfdbfe;
            border-radius: 10px;
            padding: 22px;
            margin-bottom: 28px;
          }
          .recommendation h3 {
            font-size: 16px;
            font-weight: 700;
            color: #1e40af;
            margin-bottom: 8px;
          }
          .recommendation p {
            font-size: 13px;
            color: #3b82f6;
            line-height: 1.5;
          }
          
          /* AI Analysis */
          .ai-section {
            background: #fefce8;
            border: 1px solid #fde68a;
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 28px;
            page-break-inside: avoid;
          }
          .ai-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid #fde68a;
          }
          .ai-badge {
            background: #f59e0b;
            color: white;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }
          .ai-title {
            font-size: 16px;
            font-weight: 700;
            color: #92400e;
          }
          .ai-content {
            font-size: 13px;
            color: #451a03;
            line-height: 1.7;
          }
          .ai-content h2 {
            font-size: 15px;
            font-weight: 700;
            color: #92400e;
            margin-top: 18px;
            margin-bottom: 8px;
            padding-bottom: 4px;
            border-bottom: 1px solid #fde68a;
          }
          .ai-content h3 {
            font-size: 14px;
            font-weight: 600;
            color: #a16207;
            margin-top: 14px;
            margin-bottom: 6px;
          }
          .ai-content p {
            margin-bottom: 8px;
          }
          .ai-content ul, .ai-content ol {
            margin: 8px 0;
            padding-left: 20px;
          }
          .ai-content li {
            margin-bottom: 4px;
          }
          .ai-content strong {
            color: #78350f;
          }
          
          /* Footer */
          .footer {
            text-align: center;
            padding-top: 20px;
            border-top: 2px solid #e2e8f0;
            margin-top: 32px;
          }
          .footer-brand {
            font-size: 14px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 4px;
          }
          .footer-tagline {
            font-size: 12px;
            color: #64748b;
            margin-bottom: 6px;
          }
          .footer-contact {
            font-size: 11px;
            color: #94a3b8;
          }
          .footer-disclaimer {
            font-size: 10px;
            color: #cbd5e1;
            margin-top: 10px;
            font-style: italic;
          }

          /* Page break helpers */
          .page-break {
            page-break-before: always;
          }

          @media print {
            body { background: white; }
            .page { max-width: none; }
            .header { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .score-hero { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          }
        </style>
      </head>
      <body>
        <div class="page">
          <!-- HEADER -->
          <div class="header">
            <div class="header-top">
              <div class="logo-area">
                <div class="logo-box">DCX</div>
                <div>
                  <div class="logo-text">Data CX</div>
                  <div class="logo-sub">Protocolo Vértice</div>
                </div>
              </div>
              <div class="header-badge">📅 ${dateStr}</div>
            </div>
            <div class="header-title">
              <h1>Relatório Radar Vértice™</h1>
              <p>Diagnóstico de Maturidade em CX, Dados & IA</p>
            </div>
          </div>

          <!-- INFO GRID -->
          <div class="info-grid">
            <div class="info-card">
              <div class="info-label">Participante</div>
              <div class="info-value">${formData.name}</div>
            </div>
            <div class="info-card">
              <div class="info-label">E-mail</div>
              <div class="info-value">${formData.email}</div>
            </div>
            <div class="info-card">
              <div class="info-label">Perfil</div>
              <div class="info-value">${personaLabel}</div>
            </div>
            <div class="info-card">
              <div class="info-label">Setor</div>
              <div class="info-value">${formData.sector || 'Não informado'}</div>
            </div>
            ${formData.teamSize ? `
            <div class="info-card">
              <div class="info-label">Tamanho da Equipe</div>
              <div class="info-value">${formData.teamSize} pessoas</div>
            </div>` : ''}
            ${formData.mainGoal ? `
            <div class="info-card">
              <div class="info-label">Objetivo Principal</div>
              <div class="info-value">${formData.mainGoal}</div>
            </div>` : ''}
          </div>

          <!-- SCORE TOTAL -->
          <div class="score-hero">
            <div class="score-hero-value">${result.scoreTotal.toFixed(1)}</div>
            <div class="score-hero-label">Score Total de Maturidade (de 5.0)</div>
            <div class="score-hero-badge">🎯 Nível: ${levelLabel}</div>
          </div>

          <!-- SCORES POR DIMENSÃO -->
          <div class="scores-grid">
            <div class="score-card">
              <div class="score-card-value" style="color: ${scoreColor(result.scoreCX)}">${result.scoreCX.toFixed(1)}</div>
              <div class="score-card-bar"><div class="score-card-bar-fill" style="width: ${(result.scoreCX/5)*100}%; background: ${scoreColor(result.scoreCX)}"></div></div>
              <div class="score-card-label">CX - Cliente & Jornada</div>
            </div>
            <div class="score-card">
              <div class="score-card-value" style="color: ${scoreColor(result.scoreData)}">${result.scoreData.toFixed(1)}</div>
              <div class="score-card-bar"><div class="score-card-bar-fill" style="width: ${(result.scoreData/5)*100}%; background: ${scoreColor(result.scoreData)}"></div></div>
              <div class="score-card-label">Dados & Analytics</div>
            </div>
            <div class="score-card">
              <div class="score-card-value" style="color: ${scoreColor(result.scoreIA)}">${result.scoreIA.toFixed(1)}</div>
              <div class="score-card-bar"><div class="score-card-bar-fill" style="width: ${(result.scoreIA/5)*100}%; background: ${scoreColor(result.scoreIA)}"></div></div>
              <div class="score-card-label">Inteligência Artificial</div>
            </div>
            <div class="score-card">
              <div class="score-card-value" style="color: ${scoreColor(result.scoreGovernance)}">${result.scoreGovernance.toFixed(1)}</div>
              <div class="score-card-bar"><div class="score-card-bar-fill" style="width: ${(result.scoreGovernance/5)*100}%; background: ${scoreColor(result.scoreGovernance)}"></div></div>
              <div class="score-card-label">Governança & Execução</div>
            </div>
          </div>

          <!-- SPIDER CHART -->
          <div style="text-align:center;margin-bottom:28px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:24px;">
            <h3 style="font-size:16px;font-weight:700;color:#0f172a;margin-bottom:16px;letter-spacing:-0.3px;">📊 Mapa de Maturidade</h3>
            <svg viewBox="0 0 400 400" width="320" height="320" style="margin:0 auto;display:block;">
              <!-- Grid circles -->
              ${[1,2,3,4,5].map(level => {
                const r = (level / 5) * 150;
                return `<circle cx="200" cy="200" r="${r}" fill="none" stroke="#e2e8f0" stroke-width="${level === 5 ? 1.5 : 0.8}" stroke-dasharray="${level < 5 ? '4,4' : 'none'}" />`;
              }).join('')}
              
              <!-- Axis lines -->
              ${(() => {
                const labels = ['CX', 'Dados', 'IA', 'Governança'];
                const angles = labels.map((_, i) => (Math.PI * 2 * i / 4) - Math.PI / 2);
                return angles.map((angle, i) => {
                  const x2 = 200 + Math.cos(angle) * 150;
                  const y2 = 200 + Math.sin(angle) * 150;
                  const labelX = 200 + Math.cos(angle) * 175;
                  const labelY = 200 + Math.sin(angle) * 175;
                  return `<line x1="200" y1="200" x2="${x2}" y2="${y2}" stroke="#cbd5e1" stroke-width="0.8" />
                    <text x="${labelX}" y="${labelY}" text-anchor="middle" dominant-baseline="middle" font-size="12" font-weight="600" fill="#475569" font-family="Inter,sans-serif">${labels[i]}</text>`;
                }).join('');
              })()}
              
              <!-- Scale labels -->
              ${[1,2,3,4,5].map(level => {
                const y = 200 - (level / 5) * 150;
                return `<text x="204" y="${y - 4}" font-size="9" fill="#94a3b8" font-family="Inter,sans-serif">${level}</text>`;
              }).join('')}
              
              <!-- Data polygon -->
              ${(() => {
                const scores = [result.scoreCX, result.scoreData, result.scoreIA, result.scoreGovernance];
                const points = scores.map((s, i) => {
                  const angle = (Math.PI * 2 * i / 4) - Math.PI / 2;
                  const r = (s / 5) * 150;
                  return `${200 + Math.cos(angle) * r},${200 + Math.sin(angle) * r}`;
                }).join(' ');
                return `<polygon points="${points}" fill="rgba(99,102,241,0.15)" stroke="#6366f1" stroke-width="2.5" />`;
              })()}
              
              <!-- Data points -->
              ${(() => {
                const scores = [result.scoreCX, result.scoreData, result.scoreIA, result.scoreGovernance];
                const colors = ['#2563eb', '#16a34a', '#9333ea', '#d97706'];
                return scores.map((s, i) => {
                  const angle = (Math.PI * 2 * i / 4) - Math.PI / 2;
                  const r = (s / 5) * 150;
                  const cx = 200 + Math.cos(angle) * r;
                  const cy = 200 + Math.sin(angle) * r;
                  return `<circle cx="${cx}" cy="${cy}" r="5" fill="${colors[i]}" stroke="white" stroke-width="2" />
                    <text x="${cx + (Math.cos((Math.PI * 2 * i / 4) - Math.PI / 2) > 0 ? 12 : -12)}" y="${cy + (Math.sin((Math.PI * 2 * i / 4) - Math.PI / 2) > 0 ? 14 : -8)}" text-anchor="middle" font-size="13" font-weight="700" fill="${colors[i]}" font-family="Inter,sans-serif">${s.toFixed(1)}</text>`;
                }).join('');
              })()}
            </svg>
          </div>

          <!-- TRILHA RECOMENDADA -->
          <div class="recommendation">
            <h3>🚀 Trilha Recomendada: ${result.product}</h3>
            <p>Baseado no seu perfil de maturidade e objetivos, esta é a trilha ideal para acelerar sua evolução profissional em CX, Dados e IA.</p>
          </div>

          <!-- RESPOSTAS DETALHADAS -->
          <div class="page-break"></div>
          
          <div class="section">
            <div class="section-header">
              <div class="section-icon" style="background: #dbeafe; color: #2563eb;">🎯</div>
              <div class="section-title">CX - Cliente & Jornada (${result.scoreCX.toFixed(1)}/5.0)</div>
            </div>
            ${renderBlock('cx')}
          </div>

          <div class="section">
            <div class="section-header">
              <div class="section-icon" style="background: #dcfce7; color: #16a34a;">📊</div>
              <div class="section-title">Dados & Analytics (${result.scoreData.toFixed(1)}/5.0)</div>
            </div>
            ${renderBlock('data')}
          </div>

          <div class="section">
            <div class="section-header">
              <div class="section-icon" style="background: #f3e8ff; color: #9333ea;">🧠</div>
              <div class="section-title">Inteligência Artificial (${result.scoreIA.toFixed(1)}/5.0)</div>
            </div>
            ${renderBlock('ia')}
          </div>

          <div class="section">
            <div class="section-header">
              <div class="section-icon" style="background: #fef3c7; color: #d97706;">🛡️</div>
              <div class="section-title">Governança & Execução (${result.scoreGovernance.toFixed(1)}/5.0)</div>
            </div>
            ${renderBlock('governance')}
          </div>

          <!-- DESAFIOS E CONTEXTO -->
          ${formData.challenges ? `
          <div class="section" style="margin-top: 24px;">
            <div class="section-header">
              <div class="section-icon" style="background: #e0f2fe; color: #0284c7;">💬</div>
              <div class="section-title">Desafios e Contexto Relatados</div>
            </div>
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-top: 8px;">
              <p style="font-size: 13px; color: #374151; line-height: 1.7; white-space: pre-wrap;">${formData.challenges}</p>
            </div>
          </div>
          ` : ''}

          <!-- ANÁLISE IA -->
          ${aiAnalysisHtml ? `
          <div class="page-break"></div>
          <div class="ai-section">
            <div class="ai-header">
              <div class="ai-badge">🤖 IA</div>
              <div class="ai-title">Diagnóstico Personalizado por IA</div>
            </div>
            <div class="ai-content">
              ${aiAnalysisHtml}
            </div>
          </div>
          ` : ''}

          <!-- FOOTER -->
          <div class="footer">
            <div class="footer-brand">Data CX — Protocolo Vértice™</div>
            <div class="footer-tagline">Dados Inspiram Conquistas</div>
            <div class="footer-contact">www.datacx.com.br | contato@datacx.com.br</div>
            <div class="footer-disclaimer">Este relatório é confidencial e foi gerado automaticamente pelo Radar Vértice™. A análise de IA é complementar e não substitui consultoria profissional.</div>
          </div>
        </div>
      </body>
      </html>
    `;

    // Abrir em nova aba para impressão/salvar como PDF
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      // Aguardar fontes carregarem antes de imprimir
      setTimeout(() => {
        printWindow.print();
      }, 800);
    }

    toast.success("Relatório aberto para impressão/download!");
  };

  const canProceed = () => {
    if (step === 1) {
      return formData.name && formData.email && formData.persona && formData.consentPrivacy;
    }
    if (step >= 2 && step <= 5) {
      const blockKeys = ["cx", "data", "ia", "governance"];
      const currentBlock = blockKeys[step - 2];
      const blockQuestions = questionBlocks[currentBlock as keyof typeof questionBlocks].questions;
      return blockQuestions.every((q) => answers[q.id] !== undefined);
    }
    if (step === 6) {
      return formData.urgency && formData.preferredFormat;
    }
    return true;
  };

  const renderIntro = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="max-w-3xl mx-auto text-center"
    >
      <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-coral mb-6">
        <Sparkles className="w-4 h-4" />
        <span className="text-sm font-medium">Autoavaliação Gratuita</span>
      </div>
      <h1 className="text-4xl md:text-5xl font-bold mb-6">
        Radar <span className="gradient-text">Vértice™</span>
      </h1>
      <p className="text-xl text-muted-foreground mb-8">
        Descubra seu nível de maturidade em <strong className="text-foreground">CX, Dados, IA e Governança</strong> e receba uma recomendação personalizada de trilha.
      </p>

      <div className="grid md:grid-cols-2 gap-6 mb-12">
        <Card className="program-card rounded-2xl text-left">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                <Target className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-bold">5-7 minutos</h3>
            </div>
            <p className="text-muted-foreground">
              Perguntas objetivas sobre seu dia a dia profissional
            </p>
          </CardContent>
        </Card>
        <Card className="program-card rounded-2xl text-left">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-coral/20 flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-coral" />
              </div>
              <h3 className="font-bold">Resultado imediato</h3>
            </div>
            <p className="text-muted-foreground">
              Gráfico radar + recomendação de trilha personalizada
            </p>
          </CardContent>
        </Card>
      </div>

      <Button size="lg" onClick={() => setStep(1)} className="btn-coral px-8 h-14 rounded-xl">
        Começar Avaliação
        <ArrowRight className="w-5 h-5 ml-2" />
      </Button>
    </motion.div>
  );

  const renderContextForm = () => (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="max-w-2xl mx-auto"
    >
      <h2 className="text-2xl font-bold mb-2">Sobre você</h2>
      <p className="text-muted-foreground mb-8">Precisamos de algumas informações para personalizar seu resultado.</p>

      <div className="space-y-6">
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nome completo *</Label>
            <Input
              id="name"
              placeholder="Seu nome"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">E-mail *</Label>
            <Input
              id="email"
              type="email"
              placeholder="seu@email.com"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="phone">WhatsApp</Label>
            <Input
              id="phone"
              placeholder="(11) 99999-9999"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label>Setor/Mercado</Label>
            <select
              className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
              value={formData.sector}
              onChange={(e) => setFormData({ ...formData, sector: e.target.value })}
            >
              <option value="">Selecione...</option>
              {sectors.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="space-y-3">
          <Label>Qual seu perfil hoje? *</Label>
          <div className="grid md:grid-cols-2 gap-3">
            {(Object.keys(personaDescriptions) as Persona[]).map((key) => (
              <Card
                key={key}
                className={`cursor-pointer transition-all ${
                  formData.persona === key
                    ? "border-primary bg-primary/5"
                    : "border-border/50 hover:border-primary/50"
                }`}
                onClick={() => setFormData({ ...formData, persona: key })}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      formData.persona === key ? "border-primary bg-primary" : "border-muted-foreground"
                    }`}>
                      {formData.persona === key && <CheckCircle2 className="w-3 h-3 text-primary-foreground" />}
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">{personaDescriptions[key].title}</h4>
                      <p className="text-xs text-muted-foreground">{personaDescriptions[key].description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Tamanho do time/empresa</Label>
            <select
              className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
              value={formData.teamSize}
              onChange={(e) => setFormData({ ...formData, teamSize: e.target.value as TeamSize })}
            >
              <option value="">Selecione...</option>
              <option value="1-10">1-10 pessoas</option>
              <option value="11-50">11-50 pessoas</option>
              <option value="51-200">51-200 pessoas</option>
              <option value="200+">200+ pessoas</option>
            </select>
          </div>
          <div className="space-y-2">
            <Label>Objetivo principal (90 dias)</Label>
            <select
              className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
              value={formData.mainGoal}
              onChange={(e) => setFormData({ ...formData, mainGoal: e.target.value })}
            >
              <option value="">Selecione...</option>
              {goals.map((g) => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-start gap-3 pt-4">
          <Checkbox
            id="privacy"
            checked={formData.consentPrivacy}
            onCheckedChange={(checked) => setFormData({ ...formData, consentPrivacy: checked as boolean })}
          />
          <Label htmlFor="privacy" className="text-sm text-muted-foreground leading-relaxed">
            Concordo com a <a href="/privacidade" className="text-primary hover:underline">Política de Privacidade</a> e autorizo o tratamento dos meus dados para fins desta avaliação. *
          </Label>
        </div>

        <div className="flex items-start gap-3">
          <Checkbox
            id="marketing"
            checked={formData.consentMarketing}
            onCheckedChange={(checked) => setFormData({ ...formData, consentMarketing: checked as boolean })}
          />
          <Label htmlFor="marketing" className="text-sm text-muted-foreground leading-relaxed">
            Desejo receber conteúdos e novidades sobre CX, Dados e IA por e-mail.
          </Label>
        </div>

        <div className="flex items-start gap-3">
          <Checkbox
            id="whatsapp-consent"
            checked={formData.consentWhatsapp}
            onCheckedChange={(checked) => setFormData({ ...formData, consentWhatsapp: checked as boolean })}
          />
          <Label htmlFor="whatsapp-consent" className="text-sm text-muted-foreground leading-relaxed">
            Autorizo o envio de follow-up e conteúdos personalizados via WhatsApp.
          </Label>
        </div>
      </div>
    </motion.div>
  );

  const renderQuestionBlock = (blockKey: string) => {
    const block = questionBlocks[blockKey as keyof typeof questionBlocks];
    const Icon = block.icon;

    return (
      <motion.div
        key={blockKey}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        className="max-w-3xl mx-auto"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
            <Icon className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">{block.title}</h2>
            <p className="text-muted-foreground text-sm">Avalie cada afirmação de 1 a 5</p>
          </div>
        </div>

        <div className="space-y-6">
          {block.questions.map((question, idx) => (
            <Card key={question.id} className="bg-card/50 border-border/50">
              <CardContent className="p-6">
                <p className="font-medium mb-4">
                  {idx + 1}. {question.text}
                </p>
                <RadioGroup
                  value={answers[question.id]?.toString() || ""}
                  onValueChange={(value) => setAnswers({ ...answers, [question.id]: parseInt(value) })}
                  className="flex flex-wrap gap-2"
                >
                  {scaleLabels.map((scale) => (
                    <div key={scale.value} className="flex items-center">
                      <RadioGroupItem
                        value={scale.value.toString()}
                        id={`${question.id}-${scale.value}`}
                        className="peer sr-only"
                      />
                      <Label
                        htmlFor={`${question.id}-${scale.value}`}
                        className={`px-4 py-2 rounded-lg border cursor-pointer transition-all text-sm ${
                          answers[question.id] === scale.value
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-border hover:border-primary/50"
                        }`}
                      >
                        {scale.value}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>Não faço</span>
                  <span>Faço consistentemente</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </motion.div>
    );
  };

  const renderIntentForm = () => (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="max-w-2xl mx-auto"
    >
      <h2 className="text-2xl font-bold mb-2">Quase lá!</h2>
      <p className="text-muted-foreground mb-8">Algumas perguntas finais para personalizar sua recomendação.</p>

      <div className="space-y-6">
        <div className="space-y-3">
          <Label>Se nada mudar, qual o maior custo hoje?</Label>
          <div className="flex flex-wrap gap-2">
            {costs.map((cost) => (
              <Button
                key={cost}
                variant={formData.mainCost === cost ? "default" : "outline"}
                size="sm"
                onClick={() => setFormData({ ...formData, mainCost: cost })}
              >
                {cost}
              </Button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <Label>Qual seu nível de urgência? *</Label>
          <RadioGroup
            value={formData.urgency}
            onValueChange={(value) => setFormData({ ...formData, urgency: value as Urgency })}
            className="grid grid-cols-2 gap-3"
          >
            {[
              { value: "0-30", label: "0-30 dias" },
              { value: "60", label: "60 dias" },
              { value: "90", label: "90 dias" },
              { value: "sem-urgencia", label: "Sem urgência" },
            ].map((option) => (
              <div key={option.value} className="flex items-center">
                <RadioGroupItem value={option.value} id={`urgency-${option.value}`} className="peer sr-only" />
                <Label
                  htmlFor={`urgency-${option.value}`}
                  className={`w-full p-4 rounded-lg border cursor-pointer transition-all text-center ${
                    formData.urgency === option.value
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary/50"
                  }`}
                >
                  {option.label}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </div>

        <div className="space-y-3">
          <Label>Você prefere aprender em grupo ou com acompanhamento 1:1? *</Label>
          <RadioGroup
            value={formData.preferredFormat}
            onValueChange={(value) => setFormData({ ...formData, preferredFormat: value as PreferredFormat })}
            className="grid grid-cols-2 gap-3"
          >
            <div className="flex items-center">
              <RadioGroupItem value="grupo" id="format-grupo" className="peer sr-only" />
              <Label
                htmlFor="format-grupo"
                className={`w-full p-4 rounded-lg border cursor-pointer transition-all text-center ${
                  formData.preferredFormat === "grupo"
                    ? "border-primary bg-primary/10"
                    : "border-border hover:border-primary/50"
                }`}
              >
                Em grupo
              </Label>
            </div>
            <div className="flex items-center">
              <RadioGroupItem value="individual" id="format-individual" className="peer sr-only" />
              <Label
                htmlFor="format-individual"
                className={`w-full p-4 rounded-lg border cursor-pointer transition-all text-center ${
                  formData.preferredFormat === "individual"
                    ? "border-primary bg-primary/10"
                    : "border-border hover:border-primary/50"
                }`}
              >
                Individual (1:1)
              </Label>
            </div>
          </RadioGroup>
        </div>

        <div className="space-y-2">
          <Label>Você tem orçamento previsto para desenvolvimento/consultoria?</Label>
          <select
            className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
            value={formData.budgetRange}
            onChange={(e) => setFormData({ ...formData, budgetRange: e.target.value })}
          >
            <option value="">Selecione...</option>
            {budgetRanges.map((range) => (
              <option key={range} value={range}>{range}</option>
            ))}
          </select>
        </div>

        <div className="space-y-4">
          <Label className="text-base font-semibold">Quais são seus principais desafios?</Label>
          <p className="text-sm text-muted-foreground">Selecione os que se aplicam e complemente com texto livre abaixo. Isso nos ajuda a personalizar suas recomendações.</p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {getChallengesForPersona(formData.persona || "gestor").map((challenge) => {
              const isSelected = formData.challenges.includes(`[${challenge.label}]`);
              return (
                <button
                  key={challenge.id}
                  type="button"
                  onClick={() => {
                    const tag = `[${challenge.label}]`;
                    if (isSelected) {
                      setFormData({ ...formData, challenges: formData.challenges.replace(tag, "").replace(/\s{2,}/g, " ").trim() });
                    } else {
                      const prefix = formData.challenges.trim();
                      setFormData({ ...formData, challenges: prefix ? `${prefix} ${tag}` : tag });
                    }
                  }}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border text-left text-sm transition-all ${
                    isSelected
                      ? "border-primary bg-primary/10 text-primary font-medium"
                      : "border-border hover:border-primary/50 text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <span className="text-base">{challenge.icon}</span>
                  <span>{challenge.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-2">
            <Label className="text-sm text-muted-foreground mb-2 block">Complemente com mais detalhes (opcional)</Label>
            <textarea
              className="w-full min-h-[100px] px-4 py-3 rounded-lg border border-input bg-background text-sm resize-y placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all"
              placeholder="Ex: Estou tentando implementar uma área de CX na empresa mas não sei por onde começar... / Temos muitos dados mas não conseguimos transformar em ação..."
              value={formData.challenges}
              onChange={(e) => setFormData({ ...formData, challenges: e.target.value })}
              maxLength={2000}
            />
            <p className="text-xs text-muted-foreground text-right mt-1">{formData.challenges.length}/2000</p>
          </div>
        </div>
      </div>
    </motion.div>
  );

  const renderResult = () => {
    if (!result) return null;

    const levelDescriptions = {
      fundamentos: {
        title: "Fundamentos",
        description: "Você está no início da jornada. Foco em construir base sólida.",
        color: "text-blue-400",
      },
      aplicacao: {
        title: "Aplicação",
        description: "Você tem conhecimento, mas precisa de método para aplicar.",
        color: "text-green-400",
      },
      escala: {
        title: "Escala",
        description: "Você já aplica bem, hora de escalar com consistência.",
        color: "text-yellow-400",
      },
      estrategia: {
        title: "Estratégia & Execução",
        description: "Você está avançado, foco em estratégia e governança.",
        color: "text-purple-400",
      },
    };

    const levelInfo = levelDescriptions[result.level];

    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-4xl mx-auto"
      >
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
            <CheckCircle2 className="w-4 h-4" />
            Avaliação Concluída
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            Seu Resultado, <span className="gradient-text">{formData.name.split(" ")[0]}</span>
          </h1>
          <p className="text-muted-foreground">
            Baseado nas suas respostas, identificamos seu nível de maturidade e a trilha ideal.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Radar Chart Visualization */}
          <Card className="bg-card/50 border-border/50">
            <CardHeader>
              <CardTitle>Seu Radar de Maturidade</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative aspect-square max-w-[300px] mx-auto">
                {/* Simple radar visualization */}
                <svg viewBox="0 0 200 200" className="w-full h-full">
                  {/* Background grid */}
                  {[1, 2, 3, 4, 5].map((level) => (
                    <polygon
                      key={level}
                      points={`100,${100 - level * 18} ${100 + level * 18},100 100,${100 + level * 18} ${100 - level * 18},100`}
                      fill="none"
                      stroke="currentColor"
                      strokeOpacity={0.1}
                      className="text-muted-foreground"
                    />
                  ))}
                  {/* Axes */}
                  <line x1="100" y1="10" x2="100" y2="190" stroke="currentColor" strokeOpacity={0.2} className="text-muted-foreground" />
                  <line x1="10" y1="100" x2="190" y2="100" stroke="currentColor" strokeOpacity={0.2} className="text-muted-foreground" />
                  {/* Data polygon */}
                  <polygon
                    points={`
                      100,${100 - result.scoreCX * 18}
                      ${100 + result.scoreData * 18},100
                      100,${100 + result.scoreIA * 18}
                      ${100 - result.scoreGovernance * 18},100
                    `}
                    fill="currentColor"
                    fillOpacity={0.2}
                    stroke="currentColor"
                    strokeWidth={2}
                    className="text-primary"
                  />
                  {/* Labels */}
                  <text x="100" y="5" textAnchor="middle" className="text-xs fill-current text-muted-foreground">CX</text>
                  <text x="195" y="105" textAnchor="start" className="text-xs fill-current text-muted-foreground">Dados</text>
                  <text x="100" y="198" textAnchor="middle" className="text-xs fill-current text-muted-foreground">IA</text>
                  <text x="5" y="105" textAnchor="end" className="text-xs fill-current text-muted-foreground">Gov.</text>
                </svg>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-6">
                <div className="text-center p-3 rounded-lg bg-background/50">
                  <div className="text-2xl font-bold text-primary">{result.scoreCX.toFixed(1)}</div>
                  <div className="text-xs text-muted-foreground">CX</div>
                </div>
                <div className="text-center p-3 rounded-lg bg-background/50">
                  <div className="text-2xl font-bold text-primary">{result.scoreData.toFixed(1)}</div>
                  <div className="text-xs text-muted-foreground">Dados</div>
                </div>
                <div className="text-center p-3 rounded-lg bg-background/50">
                  <div className="text-2xl font-bold text-primary">{result.scoreIA.toFixed(1)}</div>
                  <div className="text-xs text-muted-foreground">IA</div>
                </div>
                <div className="text-center p-3 rounded-lg bg-background/50">
                  <div className="text-2xl font-bold text-primary">{result.scoreGovernance.toFixed(1)}</div>
                  <div className="text-xs text-muted-foreground">Governança</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recommendation */}
          <div className="space-y-6">
            <Card className="bg-gradient-to-br from-primary/10 to-accent/10 border-primary/30">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center">
                    <span className="text-3xl font-bold text-primary">{result.scoreTotal.toFixed(1)}</span>
                  </div>
                  <div>
                    <h3 className={`text-xl font-bold ${levelInfo.color}`}>{levelInfo.title}</h3>
                    <p className="text-sm text-muted-foreground">Seu nível de maturidade</p>
                  </div>
                </div>
                <p className="text-muted-foreground">{levelInfo.description}</p>
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-primary" />
                  Trilha Recomendada
                </CardTitle>
              </CardHeader>
              <CardContent>
                <h3 className="text-xl font-bold mb-2">{result.product}</h3>
                <p className="text-muted-foreground text-sm mb-6">
                  Baseado no seu perfil de {personaDescriptions[formData.persona as Persona]?.title.toLowerCase()} e nível de maturidade.
                </p>
                <div className="flex flex-col gap-3">
                  <Link href="/contato">
                    <Button className="w-full bg-primary hover:bg-primary/90">
                      <Calendar className="w-4 h-4 mr-2" />
                      Agendar Conversa
                    </Button>
                  </Link>
                  <Link href="/ofertas">
                    <Button variant="outline" className="w-full">
                      Ver Todas as Ofertas
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Seção de Análise IA */}
        <Card className="bg-card/50 border-primary/20 mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                <Bot className="w-5 h-5 text-primary" />
              </div>
              <div>
                <span>Diagnóstico Personalizado</span>
                <p className="text-sm font-normal text-muted-foreground mt-0.5">Análise gerada por IA com base nas suas respostas</p>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {aiAnalysisLoading && (
              <div className="flex flex-col items-center justify-center py-12 gap-4">
                <div className="relative">
                  <div className="w-16 h-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
                  <Bot className="w-6 h-6 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                </div>
                <div className="text-center">
                  <p className="text-foreground font-medium">Analisando seu perfil...</p>
                  <p className="text-sm text-muted-foreground mt-1">A IA está cruzando suas respostas para gerar insights personalizados</p>
                </div>
              </div>
            )}
            {aiAnalysisError && !aiAnalysisLoading && (
              <div className="flex flex-col items-center justify-center py-8 gap-4">
                <p className="text-muted-foreground text-center">Não foi possível gerar a análise neste momento.</p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (!result || !formData.persona) return;
                    setAiAnalysisLoading(true);
                    setAiAnalysisError(false);
                    analysisMutation.mutate({
                      name: formData.name,
                      persona: formData.persona as Persona,
                      sector: formData.sector || undefined,
                      teamSize: formData.teamSize || undefined,
                      mainGoal: formData.mainGoal || undefined,
                      mainCost: formData.mainCost || undefined,
                      urgency: formData.urgency || undefined,
                      answers,
                      scoreCX: result.scoreCX,
                      scoreData: result.scoreData,
                      scoreIA: result.scoreIA,
                      scoreGovernance: result.scoreGovernance,
                      scoreTotal: result.scoreTotal,
                      recommendedLevel: result.level,
                      recommendedProduct: result.product,
                    });
                  }}
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Tentar Novamente
                </Button>
              </div>
            )}
            {aiAnalysis && !aiAnalysisLoading && (
              <div className="prose prose-sm dark:prose-invert max-w-none prose-headings:text-foreground prose-headings:font-semibold prose-p:text-muted-foreground prose-li:text-muted-foreground prose-strong:text-foreground prose-h2:text-lg prose-h2:mt-6 prose-h2:mb-3 prose-h3:text-base prose-h3:mt-4 prose-h3:mb-2 prose-ul:my-2 prose-li:my-0.5">
                <Streamdown>{aiAnalysis}</Streamdown>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-card/30 border-border/50">
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground mb-4">
              Enviamos uma cópia do seu resultado para <strong className="text-foreground">{formData.email}</strong>
            </p>
            <Button variant="outline" size="sm" onClick={handleDownloadPDF}>
              <Download className="w-4 h-4 mr-2" />
              Baixar Relatório PDF
            </Button>
          </CardContent>
        </Card>
      </motion.div>
    );
  };

  const blockKeys = ["cx", "data", "ia", "governance"];

  return (
    <div className="min-h-screen bg-background bg-navy-gradient">
      <SEO title={PAGE_SEO.radar.title} description={PAGE_SEO.radar.description} path="/radar" />
      <Navbar />

      <section className="pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="absolute inset-0 bg-radial" />
        <div className="absolute inset-0 bg-radial-coral" />

        <div className="container relative z-10">
          {/* Progress bar */}
          {step > 0 && step < 7 && (
            <div className="max-w-3xl mx-auto mb-8">
              <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
                <span>Progresso</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}

          <AnimatePresence mode="wait">
            {step === 0 && renderIntro()}
            {step === 1 && renderContextForm()}
            {step >= 2 && step <= 5 && renderQuestionBlock(blockKeys[step - 2])}
            {step === 6 && renderIntentForm()}
            {step === 7 && renderResult()}
          </AnimatePresence>

          {/* Navigation buttons */}
          {step > 0 && step < 7 && (
            <div className="max-w-3xl mx-auto mt-8 flex justify-between">
              <Button variant="outline" onClick={() => setStep(step - 1)}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
              {step < 6 ? (
                <Button
                  onClick={() => setStep(step + 1)}
                  disabled={!canProceed()}
                  className="btn-coral rounded-xl"
                >
                  Próximo
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  disabled={!canProceed() || submitMutation.isPending}
                  className="btn-coral rounded-xl"
                >
                  {submitMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processando...
                    </>
                  ) : (
                    <>
                      Ver Resultado
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
              )}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
