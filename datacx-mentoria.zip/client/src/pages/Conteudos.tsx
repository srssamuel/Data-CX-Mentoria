'use client';

import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '@/_core/hooks/useAuth';
// Auth redirect uses /login route
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import DashboardLayout from '@/components/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Play, 
  FileText, 
  BookOpen, 
  Clock, 
  CheckCircle2, 
  Lock,
  Search,
  Filter,
  Volume2,
  Video,
  Zap
} from 'lucide-react';
import { toast } from 'sonner';

interface ContentWithProgress {
  id: number;
  title: string;
  description: string | null;
  type: 'playbook' | 'template' | 'video' | 'document' | 'link';
  fileUrl: string | null;
  fileKey?: string | null;
  mimeType?: string | null;
  fileSize?: number | null;
  thumbnailUrl: string | null;
  programId: number | null;
  sortOrder: number;
  completed?: boolean;
  durationMinutes?: number;
  createdAt?: Date;
  updatedAt?: Date;
}

export default function Conteudos() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [selectedProgram, setSelectedProgram] = useState<number | null>(null);

  // Fetch user's enrollments
  const { data: enrollments = [] } = trpc.enrollments.myEnrollments.useQuery(
    undefined,
    { enabled: !!user }
  );

  // Fetch available contents
  const { data: allContents = [] } = trpc.contents.list.useQuery(
    undefined,
    { enabled: !!user }
  );

  // Fetch programs for context
  const { data: programs = [] } = trpc.programs.list.useQuery();

  // Filter contents based on user's enrollments and search
  const availableContents = useMemo(() => {
    const enrolledProgramIds = enrollments
      .filter((e: any) => e.status === 'active')
      .map((e: any) => e.programId);

    return allContents
      .filter((content: any) => {
        // Check if user has access to this content
        if (content.programId && !enrolledProgramIds.includes(content.programId)) {
          return false;
        }
        
        // Apply search filter
        if (searchTerm && !content.title.toLowerCase().includes(searchTerm.toLowerCase())) {
          return false;
        }

        // Apply type filter
        if (selectedType && content.type !== selectedType) {
          return false;
        }

        // Apply program filter
        if (selectedProgram && content.programId !== selectedProgram) {
          return false;
        }

        return true;
      })
      .sort((a: any, b: any) => a.sortOrder - b.sortOrder);
  }, [allContents, enrollments, searchTerm, selectedType, selectedProgram]);

  // Group contents by program
  const contentsByProgram = useMemo(() => {
    const grouped: Record<number, ContentWithProgress[]> = {};
    
    availableContents.forEach((content: any) => {
      const programId = content.programId || 0;
      if (!grouped[programId]) {
        grouped[programId] = [];
      }
      grouped[programId].push(content as ContentWithProgress);
    });

    return grouped;
  }, [availableContents]);

  const getContentIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Video className="w-5 h-5" />;
      case 'playbook':
        return <BookOpen className="w-5 h-5" />;
      case 'template':
        return <FileText className="w-5 h-5" />;
      case 'document':
        return <FileText className="w-5 h-5" />;
      default:
        return <Play className="w-5 h-5" />;
    }
  };

  const getContentBadgeColor = (type: string) => {
    switch (type) {
      case 'video':
        return 'bg-red-500/20 text-red-400';
      case 'playbook':
        return 'bg-blue-500/20 text-blue-400';
      case 'template':
        return 'bg-purple-500/20 text-purple-400';
      case 'document':
        return 'bg-green-500/20 text-green-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      video: 'Vídeo',
      playbook: 'Playbook',
      template: 'Template',
      document: 'Documento',
      link: 'Link'
    };
    return labels[type] || type;
  };

  const handleContentClick = (content: ContentWithProgress) => {
    if (content.fileUrl) {
      window.open(content.fileUrl, '_blank');
    } else {
      toast.info('Conteúdo em breve disponível');
    }
  };

  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-3xl font-bold mb-4">Acesso Restrito</h1>
          <p className="text-muted-foreground mb-8">Você precisa estar logado para acessar os conteúdos.</p>
          <a href="/login">
            <Button>Fazer Login</Button>
          </a>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-4xl font-bold">Minha Biblioteca</h1>
          <p className="text-muted-foreground">
            Acesse todos os conteúdos dos seus programas de mentoria
          </p>
        </div>

        {/* Search and Filters */}
        <div className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Buscar conteúdos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button
                variant={selectedType === null ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedType(null)}
              >
                <Filter className="w-4 h-4 mr-2" />
                Todos
              </Button>
              {['video', 'playbook', 'document', 'template'].map(type => (
                <Button
                  key={type}
                  variant={selectedType === type ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedType(type)}
                >
                  {getTypeLabel(type)}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Content Grid - Netflix Style */}
        {Object.entries(contentsByProgram).length === 0 ? (
          <Card className="bg-card/50 border-border/50">
            <CardContent className="p-12 text-center">
              <Lock className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Nenhum conteúdo disponível</h3>
              <p className="text-muted-foreground mb-6">
                Você ainda não tem acesso a nenhum programa. Confira nossas ofertas!
              </p>
              <Button onClick={() => setLocation('/ofertas')}>
                Ver Programas Disponíveis
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-12">
            {Object.entries(contentsByProgram).map(([programId, contents]) => {
              const program = programs.find(p => p.id === parseInt(programId));
              const enrollment = enrollments.find(e => e.programId === parseInt(programId));
              const daysRemaining = enrollment?.endDate 
                ? Math.ceil((new Date(enrollment.endDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
                : null;

              return (
                <motion.div
                  key={programId}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-4"
                >
                  {/* Program Header */}
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-bold">{program?.name || 'Conteúdos'}</h2>
                      {daysRemaining !== null && (
                        <p className="text-sm text-muted-foreground mt-1">
                          <Clock className="w-4 h-4 inline mr-1" />
                          {daysRemaining > 0 
                            ? `Acesso por mais ${daysRemaining} dias`
                            : 'Acesso expirado'}
                        </p>
                      )}
                    </div>
                    <Badge variant="secondary">
                      {contents.length} conteúdo{contents.length !== 1 ? 's' : ''}
                    </Badge>
                  </div>

                  {/* Content Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {contents.map((content, idx) => (
                      <motion.div
                        key={content.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: idx * 0.05 }}
                      >
                        <Card 
                          className="group cursor-pointer overflow-hidden transition-all hover:shadow-lg hover:border-primary/50 h-full flex flex-col bg-card/50 border-border/50"
                          onClick={() => handleContentClick(content)}
                        >
                          {/* Thumbnail */}
                          <div className="relative overflow-hidden bg-gradient-to-br from-primary/20 to-accent/20 aspect-video flex items-center justify-center">
                            {content.thumbnailUrl ? (
                              <img
                                src={content.thumbnailUrl}
                                alt={content.title}
                                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                              />
                            ) : (
                              <div className="flex flex-col items-center justify-center gap-2">
                                {getContentIcon(content.type)}
                                <span className="text-xs text-muted-foreground">
                                  {getTypeLabel(content.type)}
                                </span>
                              </div>
                            )}

                            {/* Overlay on hover */}
                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <div className="flex flex-col items-center gap-2">
                                <Play className="w-12 h-12 text-white" />
                                <span className="text-white text-sm font-semibold">Abrir</span>
                              </div>
                            </div>

                            {/* Completion Badge */}
                            {content.completed && (
                              <div className="absolute top-2 right-2 bg-green-500/90 rounded-full p-1">
                                <CheckCircle2 className="w-4 h-4 text-white" />
                              </div>
                            )}

                            {/* Type Badge */}
                            <div className={`absolute bottom-2 left-2 ${getContentBadgeColor(content.type)} px-2 py-1 rounded text-xs font-semibold flex items-center gap-1`}>
                              {getContentIcon(content.type)}
                              {getTypeLabel(content.type)}
                            </div>
                          </div>

                          {/* Content Info */}
                          <CardContent className="p-4 flex-1 flex flex-col">
                            <h3 className="font-semibold text-sm line-clamp-2 mb-2 group-hover:text-primary transition-colors">
                              {content.title}
                            </h3>
                            {content.description && (
                              <p className="text-xs text-muted-foreground line-clamp-2 mb-4 flex-1">
                                {content.description}
                              </p>
                            )}
                            
                            {/* Duration */}
                            {content.durationMinutes && (
                              <div className="text-xs text-muted-foreground flex items-center gap-1 mt-auto">
                                <Clock className="w-3 h-3" />
                                {content.durationMinutes} min
                              </div>
                            )}
                          </CardContent>

                          {/* Action Button */}
                          <div className="px-4 pb-4">
                            <Button 
                              size="sm" 
                              className="w-full"
                              variant={content.completed ? 'outline' : 'default'}
                            >
                              {content.completed ? (
                                <>
                                  <CheckCircle2 className="w-4 h-4 mr-2" />
                                  Concluído
                                </>
                              ) : (
                                <>
                                  <Play className="w-4 h-4 mr-2" />
                                  Acessar
                                </>
                              )}
                            </Button>
                          </div>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}

        {/* Progress Summary */}
        {enrollments.length > 0 && (
          <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-primary" />
                Seu Progresso
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {enrollments.map(enrollment => {
                  const programContents = contentsByProgram[enrollment.programId] || [];
                  const completedCount = programContents.filter(c => c.completed).length;
                  const totalCount = programContents.length;
                  const percentage = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;

                  return (
                    <div key={enrollment.id} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-semibold">
                          {programs.find(p => p.id === enrollment.programId)?.name || 'Programa'}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          {completedCount}/{totalCount}
                        </span>
                      </div>
                      <div className="w-full bg-background/50 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-primary to-accent h-2 rounded-full transition-all duration-300"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {Math.round(percentage)}% concluído
                      </p>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
