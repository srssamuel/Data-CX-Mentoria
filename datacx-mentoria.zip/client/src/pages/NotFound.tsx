import { Button } from "@/components/ui/button";
import { Home, ArrowLeft, Search } from "lucide-react";
import { useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO from "@/components/SEO";

export default function NotFound() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background bg-navy-gradient">
      <SEO title="Página não encontrada | Data CX" description="A página que você procura não foi encontrada." path="/404" />
      <Navbar />

      <section className="pt-32 pb-20 min-h-[70vh] flex items-center">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center">
            {/* 404 Grande */}
            <div className="relative mb-8">
              <span className="text-[10rem] md:text-[14rem] font-extrabold leading-none text-primary/10 select-none">
                404
              </span>
              <div className="absolute inset-0 flex items-center justify-center">
                <Search className="w-20 h-20 text-primary/40" />
              </div>
            </div>

            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              Página não encontrada
            </h1>

            <p className="text-muted-foreground text-lg mb-10 max-w-md mx-auto">
              A página que você procura não existe, foi movida ou está temporariamente indisponível.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={() => window.history.back()}
                variant="outline"
                size="lg"
                className="gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Voltar
              </Button>
              <Button
                onClick={() => setLocation("/")}
                size="lg"
                className="btn-coral gap-2"
              >
                <Home className="w-4 h-4" />
                Ir para o Início
              </Button>
            </div>

            {/* Links úteis */}
            <div className="mt-16 pt-8 border-t border-border/30">
              <p className="text-sm text-muted-foreground mb-4">Links úteis:</p>
              <div className="flex flex-wrap gap-4 justify-center">
                <button onClick={() => setLocation("/ofertas")} className="text-sm text-primary hover:underline">
                  Programas
                </button>
                <button onClick={() => setLocation("/radar")} className="text-sm text-primary hover:underline">
                  Radar Vértice
                </button>
                <button onClick={() => setLocation("/sobre")} className="text-sm text-primary hover:underline">
                  Sobre
                </button>
                <button onClick={() => setLocation("/contato")} className="text-sm text-primary hover:underline">
                  Contato
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
