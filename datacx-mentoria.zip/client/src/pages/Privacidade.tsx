import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO, { PAGE_SEO } from "@/components/SEO";
import { Shield, Lock, Eye, UserCheck, FileText, Mail, Phone, Calendar } from "lucide-react";

export default function Privacidade() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a1628] via-[#0d1e36] to-[#0a1628]">
      <SEO title={PAGE_SEO.privacidade.title} description={PAGE_SEO.privacidade.description} path="/privacidade" />
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-teal-500/10 border border-teal-400/20 rounded-full px-4 py-2 mb-6">
              <Shield className="w-4 h-4 text-teal-400" />
              <span className="text-teal-400 text-sm font-medium">Conformidade LGPD</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Política de <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-cyan-400">Privacidade</span>
            </h1>
            <p className="text-gray-400 text-lg">
              Última atualização: {new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}
            </p>
          </div>

          {/* Content */}
          <div className="space-y-8">
            {/* Introdução */}
            <section className="bg-white/5 border border-white/10 rounded-2xl p-6 md:p-8">
              <h2 className="text-2xl font-semibold text-white mb-4 flex items-center gap-3">
                <FileText className="w-6 h-6 text-teal-400" />
                1. Introdução
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  A <strong className="text-white">Data CX Mentoria</strong>, operada por Samuel Rosa ("nós", "nosso" ou "Controlador"), 
                  está comprometida em proteger a privacidade e os dados pessoais de nossos usuários, clientes e visitantes 
                  ("você" ou "Titular").
                </p>
                <p>
                  Esta Política de Privacidade descreve como coletamos, usamos, armazenamos e protegemos seus dados pessoais 
                  em conformidade com a Lei Geral de Proteção de Dados (Lei nº 13.709/2018 - LGPD) e demais legislações aplicáveis.
                </p>
                <p>
                  Ao utilizar nossos serviços, você concorda com as práticas descritas nesta política. Recomendamos a leitura 
                  atenta deste documento.
                </p>
              </div>
            </section>

            {/* Dados Coletados */}
            <section className="bg-white/5 border border-white/10 rounded-2xl p-6 md:p-8">
              <h2 className="text-2xl font-semibold text-white mb-4 flex items-center gap-3">
                <Eye className="w-6 h-6 text-teal-400" />
                2. Dados Pessoais Coletados
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>Coletamos os seguintes tipos de dados pessoais:</p>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="bg-white/5 rounded-xl p-4">
                    <h3 className="text-white font-medium mb-2">Dados de Identificação</h3>
                    <ul className="text-sm space-y-1 text-gray-400">
                      <li>• Nome completo</li>
                      <li>• Endereço de e-mail</li>
                      <li>• Número de telefone/WhatsApp</li>
                      <li>• Cargo e empresa</li>
                    </ul>
                  </div>
                  
                  <div className="bg-white/5 rounded-xl p-4">
                    <h3 className="text-white font-medium mb-2">Dados Profissionais</h3>
                    <ul className="text-sm space-y-1 text-gray-400">
                      <li>• Segmento de atuação</li>
                      <li>• Tamanho da empresa</li>
                      <li>• Desafios e objetivos profissionais</li>
                      <li>• Respostas a questionários (Radar Vértice)</li>
                    </ul>
                  </div>
                  
                  <div className="bg-white/5 rounded-xl p-4">
                    <h3 className="text-white font-medium mb-2">Dados de Navegação</h3>
                    <ul className="text-sm space-y-1 text-gray-400">
                      <li>• Endereço IP</li>
                      <li>• Tipo de navegador</li>
                      <li>• Páginas visitadas</li>
                      <li>• Tempo de permanência</li>
                    </ul>
                  </div>
                  
                  <div className="bg-white/5 rounded-xl p-4">
                    <h3 className="text-white font-medium mb-2">Dados de Pagamento</h3>
                    <ul className="text-sm space-y-1 text-gray-400">
                      <li>• Dados de transação (via Stripe)</li>
                      <li>• Histórico de compras</li>
                      <li>• Não armazenamos dados de cartão</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            {/* Finalidade */}
            <section className="bg-white/5 border border-white/10 rounded-2xl p-6 md:p-8">
              <h2 className="text-2xl font-semibold text-white mb-4 flex items-center gap-3">
                <UserCheck className="w-6 h-6 text-teal-400" />
                3. Finalidade do Tratamento
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>Utilizamos seus dados pessoais para as seguintes finalidades:</p>
                
                <div className="space-y-3">
                  <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4">
                    <div className="w-8 h-8 rounded-lg bg-teal-500/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-teal-400 font-semibold">1</span>
                    </div>
                    <div>
                      <h3 className="text-white font-medium">Prestação de Serviços</h3>
                      <p className="text-sm text-gray-400">Fornecer acesso aos programas de mentoria, conteúdos exclusivos e materiais adquiridos.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4">
                    <div className="w-8 h-8 rounded-lg bg-teal-500/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-teal-400 font-semibold">2</span>
                    </div>
                    <div>
                      <h3 className="text-white font-medium">Comunicação</h3>
                      <p className="text-sm text-gray-400">Enviar informações sobre seus programas, atualizações, novidades e suporte ao cliente.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4">
                    <div className="w-8 h-8 rounded-lg bg-teal-500/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-teal-400 font-semibold">3</span>
                    </div>
                    <div>
                      <h3 className="text-white font-medium">Personalização</h3>
                      <p className="text-sm text-gray-400">Personalizar sua experiência e recomendar conteúdos relevantes com base no seu perfil.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4">
                    <div className="w-8 h-8 rounded-lg bg-teal-500/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-teal-400 font-semibold">4</span>
                    </div>
                    <div>
                      <h3 className="text-white font-medium">Marketing (com consentimento)</h3>
                      <p className="text-sm text-gray-400">Enviar comunicações promocionais sobre novos programas e ofertas, apenas se você autorizar.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4">
                    <div className="w-8 h-8 rounded-lg bg-teal-500/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-teal-400 font-semibold">5</span>
                    </div>
                    <div>
                      <h3 className="text-white font-medium">Obrigações Legais</h3>
                      <p className="text-sm text-gray-400">Cumprir obrigações legais, fiscais e regulatórias aplicáveis.</p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Base Legal */}
            <section className="bg-white/5 border border-white/10 rounded-2xl p-6 md:p-8">
              <h2 className="text-2xl font-semibold text-white mb-4 flex items-center gap-3">
                <Lock className="w-6 h-6 text-teal-400" />
                4. Base Legal para Tratamento
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>O tratamento dos seus dados pessoais é realizado com base nas seguintes hipóteses legais previstas na LGPD:</p>
                
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span><strong className="text-white">Consentimento (Art. 7º, I):</strong> Para envio de comunicações de marketing e newsletters.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span><strong className="text-white">Execução de Contrato (Art. 7º, V):</strong> Para prestação dos serviços de mentoria contratados.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span><strong className="text-white">Legítimo Interesse (Art. 7º, IX):</strong> Para melhorar nossos serviços e personalizar sua experiência.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span><strong className="text-white">Cumprimento de Obrigação Legal (Art. 7º, II):</strong> Para atender exigências fiscais e regulatórias.</span>
                  </li>
                </ul>
              </div>
            </section>

            {/* Direitos do Titular */}
            <section className="bg-white/5 border border-white/10 rounded-2xl p-6 md:p-8">
              <h2 className="text-2xl font-semibold text-white mb-4 flex items-center gap-3">
                <UserCheck className="w-6 h-6 text-teal-400" />
                5. Seus Direitos como Titular
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>De acordo com a LGPD, você possui os seguintes direitos em relação aos seus dados pessoais:</p>
                
                <div className="grid md:grid-cols-2 gap-3">
                  {[
                    { title: "Confirmação", desc: "Confirmar a existência de tratamento de seus dados" },
                    { title: "Acesso", desc: "Acessar seus dados pessoais tratados por nós" },
                    { title: "Correção", desc: "Corrigir dados incompletos, inexatos ou desatualizados" },
                    { title: "Anonimização", desc: "Solicitar anonimização ou bloqueio de dados desnecessários" },
                    { title: "Portabilidade", desc: "Solicitar a portabilidade dos dados a outro fornecedor" },
                    { title: "Eliminação", desc: "Solicitar a eliminação dos dados tratados com consentimento" },
                    { title: "Informação", desc: "Ser informado sobre compartilhamento de dados" },
                    { title: "Revogação", desc: "Revogar o consentimento a qualquer momento" },
                  ].map((right, index) => (
                    <div key={index} className="bg-white/5 rounded-xl p-3">
                      <h3 className="text-white font-medium text-sm">{right.title}</h3>
                      <p className="text-xs text-gray-400">{right.desc}</p>
                    </div>
                  ))}
                </div>
                
                <p className="text-sm">
                  Para exercer qualquer um desses direitos, entre em contato conosco através dos canais indicados na seção de Contato.
                </p>
              </div>
            </section>

            {/* Compartilhamento */}
            <section className="bg-white/5 border border-white/10 rounded-2xl p-6 md:p-8">
              <h2 className="text-2xl font-semibold text-white mb-4 flex items-center gap-3">
                <Shield className="w-6 h-6 text-teal-400" />
                6. Compartilhamento de Dados
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>Seus dados pessoais podem ser compartilhados com:</p>
                
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span><strong className="text-white">Processadores de Pagamento:</strong> Stripe, para processamento seguro de transações financeiras.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span><strong className="text-white">Plataformas de Comunicação:</strong> Para envio de e-mails e mensagens relacionadas aos serviços.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span><strong className="text-white">Autoridades Competentes:</strong> Quando exigido por lei ou ordem judicial.</span>
                  </li>
                </ul>
                
                <p className="text-sm bg-teal-500/10 border border-teal-400/20 rounded-xl p-4">
                  <strong className="text-teal-400">Importante:</strong> Não vendemos, alugamos ou comercializamos seus dados pessoais com terceiros para fins de marketing.
                </p>
              </div>
            </section>

            {/* Segurança */}
            <section className="bg-white/5 border border-white/10 rounded-2xl p-6 md:p-8">
              <h2 className="text-2xl font-semibold text-white mb-4 flex items-center gap-3">
                <Lock className="w-6 h-6 text-teal-400" />
                7. Segurança dos Dados
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>Implementamos medidas técnicas e organizacionais apropriadas para proteger seus dados pessoais, incluindo:</p>
                
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span>Criptografia de dados em trânsito (HTTPS/TLS)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span>Armazenamento seguro em servidores protegidos</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span>Controle de acesso restrito aos dados</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span>Monitoramento contínuo de segurança</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span>Processamento de pagamentos via Stripe (certificado PCI-DSS)</span>
                  </li>
                </ul>
              </div>
            </section>

            {/* Retenção */}
            <section className="bg-white/5 border border-white/10 rounded-2xl p-6 md:p-8">
              <h2 className="text-2xl font-semibold text-white mb-4 flex items-center gap-3">
                <Calendar className="w-6 h-6 text-teal-400" />
                8. Retenção de Dados
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  Seus dados pessoais serão mantidos pelo tempo necessário para cumprir as finalidades para as quais foram coletados, 
                  incluindo obrigações legais, contratuais, de prestação de contas ou requisição de autoridades competentes.
                </p>
                <p>
                  Após o término do período de retenção, os dados serão eliminados ou anonimizados, salvo quando houver 
                  necessidade de mantê-los para cumprimento de obrigação legal ou regulatória.
                </p>
              </div>
            </section>

            {/* Cookies */}
            <section className="bg-white/5 border border-white/10 rounded-2xl p-6 md:p-8">
              <h2 className="text-2xl font-semibold text-white mb-4 flex items-center gap-3">
                <Eye className="w-6 h-6 text-teal-400" />
                9. Cookies e Tecnologias Similares
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  Utilizamos cookies e tecnologias similares para melhorar sua experiência em nosso site. 
                  Os cookies são pequenos arquivos de texto armazenados em seu dispositivo que nos ajudam a:
                </p>
                
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span>Manter você conectado à sua conta</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span>Lembrar suas preferências</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-teal-400">•</span>
                    <span>Analisar o uso do site para melhorias</span>
                  </li>
                </ul>
                
                <p className="text-sm">
                  Você pode configurar seu navegador para recusar cookies, mas isso pode afetar algumas funcionalidades do site.
                </p>
              </div>
            </section>

            {/* Contato */}
            <section className="bg-gradient-to-r from-teal-500/20 to-cyan-500/20 border border-teal-400/30 rounded-2xl p-6 md:p-8">
              <h2 className="text-2xl font-semibold text-white mb-4 flex items-center gap-3">
                <Mail className="w-6 h-6 text-teal-400" />
                10. Contato do Encarregado (DPO)
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  Para exercer seus direitos, esclarecer dúvidas ou fazer solicitações relacionadas à privacidade 
                  e proteção de dados, entre em contato com nosso Encarregado de Proteção de Dados:
                </p>
                
                <div className="bg-white/5 rounded-xl p-4 space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-teal-500/20 flex items-center justify-center">
                      <UserCheck className="w-5 h-5 text-teal-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Samuel Rosa</p>
                      <p className="text-sm text-gray-400">Encarregado de Proteção de Dados</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-teal-400" />
                    <a href="mailto:contato@datacx.com.br" className="text-teal-400 hover:underline">
                      contato@datacx.com.br
                    </a>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-teal-400" />
                    <a href="https://wa.me/5584991278513" className="text-teal-400 hover:underline">
                      +55 (84) 99127-8513
                    </a>
                  </div>
                </div>
                
                <p className="text-sm">
                  Responderemos sua solicitação no prazo de 15 (quinze) dias, conforme estabelecido pela LGPD.
                </p>
              </div>
            </section>

            {/* Alterações */}
            <section className="bg-white/5 border border-white/10 rounded-2xl p-6 md:p-8">
              <h2 className="text-2xl font-semibold text-white mb-4 flex items-center gap-3">
                <FileText className="w-6 h-6 text-teal-400" />
                11. Alterações nesta Política
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  Esta Política de Privacidade pode ser atualizada periodicamente para refletir mudanças em nossas práticas 
                  ou por exigências legais. Recomendamos que você revise esta página regularmente.
                </p>
                <p>
                  Em caso de alterações significativas, notificaremos você por e-mail ou através de um aviso em nosso site.
                </p>
              </div>
            </section>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
