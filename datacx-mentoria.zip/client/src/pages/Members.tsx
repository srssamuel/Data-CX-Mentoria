import { useState, useMemo } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { cn } from "@/lib/utils";
import SEO, { PAGE_SEO } from "@/components/SEO";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import MembersSidebar from "@/components/MembersSidebar";
import RadarHistorySection from "@/components/RadarHistorySection";
import OnboardingWelcome from "@/components/OnboardingWelcome";
import Footer from "@/components/Footer";
import Navbar from "@/components/Navbar";
import { 
  Search, Play, CheckCircle2, Lock, Clock, BookOpen, 
  ChevronRight, Star, Award, TrendingUp, Filter,
  GraduationCap, BarChart3, Brain, Lightbulb, ArrowRight,
  Loader2, Headphones, Eye, Zap, Download, FileText,
  Trophy, Sparkles, Target, Rocket, ExternalLink, Radar, History,
  CalendarClock, FolderOpen, ListChecks, Milestone, AlertCircle, CircleCheck, CircleDot, Package, Route
} from "lucide-react";

const PILAR_CONFIG: Record<string, { name: string; shortName: string; color: string; bg: string; icon: React.ReactNode; gradient: string; bannerUrl: string }> = {
  INTRO: { 
    name: "Introdução ao Protocolo Vértice", 
    shortName: "Intro",
    color: "text-blue-400", 
    bg: "bg-blue-500/20 border-blue-500/30", 
    icon: <Lightbulb className="w-5 h-5" />,
    gradient: "from-blue-600 to-blue-800",
    bannerUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/XunHAjtWgyKXCvBD.jpg"
  },
  CX: { 
    name: "Customer Experience", 
    shortName: "CX",
    color: "text-emerald-400", 
    bg: "bg-emerald-500/20 border-emerald-500/30", 
    icon: <Star className="w-5 h-5" />,
    gradient: "from-emerald-600 to-emerald-800",
    bannerUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/fnCGGgkpGccVakVf.jpg"
  },
  DADOS: { 
    name: "Dados & Analytics", 
    shortName: "Dados",
    color: "text-purple-400", 
    bg: "bg-purple-500/20 border-purple-500/30", 
    icon: <BarChart3 className="w-5 h-5" />,
    gradient: "from-purple-600 to-purple-800",
    bannerUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/DYWRkNxXoWZpxDSE.jpg"
  },
  IA: { 
    name: "Inteligência Artificial", 
    shortName: "IA",
    color: "text-amber-400", 
    bg: "bg-amber-500/20 border-amber-500/30", 
    icon: <Brain className="w-5 h-5" />,
    gradient: "from-amber-600 to-amber-800",
    bannerUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/rJaKSdxQGhlCNmBA.jpg"
  },
};

// Soluções (templates, checklists, recursos prontos)
const SOLUCOES_DATA = [
  { id: "s1", title: "Checklist de Diagnóstico CX", description: "Avalie a maturidade CX da sua operação em 15 minutos", category: "CX", type: "checklist", level: "Fundamentos", time: "15 min", action: "Baixar" },
  { id: "s2", title: "Template de Mapa de Jornada", description: "Modelo pronto para mapear a jornada do cliente end-to-end", category: "CX", type: "template", level: "Aplicação", time: "30 min", action: "Baixar" },
  { id: "s3", title: "Dashboard de KPIs de CX", description: "Planilha com os 12 KPIs essenciais de Customer Experience", category: "Dados", type: "template", level: "Aplicação", time: "20 min", action: "Baixar" },
  { id: "s4", title: "Script de Análise de Sentimento", description: "Prompt pronto para análise de sentimento com IA em feedbacks", category: "IA", type: "prompt", level: "Escala", time: "10 min", action: "Aplicar" },
  { id: "s5", title: "Modelo de Governança de Dados", description: "Framework completo para governança de dados em CX", category: "Dados", type: "template", level: "Escala", time: "45 min", action: "Baixar" },
  { id: "s6", title: "Prompt Pack: Atendimento IA", description: "10 prompts testados para automatizar atendimento com IA", category: "IA", type: "prompt", level: "Aplicação", time: "15 min", action: "Aplicar" },
  { id: "s7", title: "Checklist de Implantação NPS", description: "Passo a passo para implementar NPS na sua empresa", category: "CX", type: "checklist", level: "Fundamentos", time: "20 min", action: "Baixar" },
  { id: "s8", title: "Template de Relatório Executivo", description: "Modelo de relatório CX para apresentar à diretoria", category: "Gestão", type: "template", level: "Escala", time: "30 min", action: "Baixar" },
  { id: "s9", title: "Guia de Métricas de Retenção", description: "As 8 métricas que todo gestor de CX precisa acompanhar", category: "Dados", type: "document", level: "Fundamentos", time: "25 min", action: "Abrir" },
  { id: "s10", title: "Prompt Pack: Análise de Dados", description: "Prompts para extrair insights de dados com ChatGPT/Claude", category: "IA", type: "prompt", level: "Aplicação", time: "10 min", action: "Aplicar" },
  { id: "s11", title: "Matriz de Priorização CX", description: "Ferramenta para priorizar iniciativas de CX por impacto e esforço", category: "CX", type: "template", level: "Aplicação", time: "20 min", action: "Baixar" },
  { id: "s12", title: "Script de Automação WhatsApp", description: "Modelo de fluxo automatizado para atendimento via WhatsApp", category: "IA", type: "prompt", level: "Escala", time: "30 min", action: "Aplicar" },
];

const SOLUCOES_CATEGORIES = ["Todas", "CX", "Dados", "IA", "Gestão"];
const SOLUCOES_TABS = ["Todas", "Mais usadas", "Novas", "Recomendadas"];

const TYPE_ICONS: Record<string, React.ReactNode> = {
  checklist: <CheckCircle2 className="w-3.5 h-3.5" />,
  template: <FileText className="w-3.5 h-3.5" />,
  prompt: <Sparkles className="w-3.5 h-3.5" />,
  document: <BookOpen className="w-3.5 h-3.5" />,
};

const CATEGORY_COLORS: Record<string, string> = {
  CX: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
  Dados: "bg-purple-500/20 text-purple-400 border-purple-500/30",
  IA: "bg-amber-500/20 text-amber-400 border-amber-500/30",
  Gestão: "bg-blue-500/20 text-blue-400 border-blue-500/30",
};

const LEVEL_COLORS: Record<string, string> = {
  Fundamentos: "bg-blue-500/10 text-blue-400",
  "Aplicação": "bg-emerald-500/10 text-emerald-400",
  Escala: "bg-purple-500/10 text-purple-400",
};


export default function Members() {
  const { user, isAuthenticated, loading } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPilar, setSelectedPilar] = useState<string>("all");
  const [selectedSection, setSelectedSection] = useState("dashboard");
  const [solucoesCategory, setSolucoesCategory] = useState("Todas");
  const [solucoesTab, setSolucoesTab] = useState("Todas");
  const [showOnboarding, setShowOnboarding] = useState(() => {
    if (typeof window !== "undefined") {
      return !localStorage.getItem("datacx_onboarding_dismissed");
    }
    return true;
  });

  const { data: modulesWithProgress, isLoading: modulesLoading } = trpc.contents.withProgress.useQuery(
    undefined, { enabled: isAuthenticated }
  );
  const { data: progressData } = trpc.progress.myProgress.useQuery(undefined, { enabled: isAuthenticated });
  const { data: accessData } = trpc.contents.accessibleModules.useQuery(undefined, { enabled: isAuthenticated });
  const { data: radarHistory } = trpc.radar.getHistory.useQuery(undefined, { enabled: isAuthenticated });

  // Group modules by pilar
  const trails = useMemo(() => {
    if (!modulesWithProgress) return [];
    const grouped: Record<string, typeof modulesWithProgress> = {};
    modulesWithProgress.forEach(mod => {
      const pilar = mod.pilar || "INTRO";
      if (!grouped[pilar]) grouped[pilar] = [];
      grouped[pilar].push(mod);
    });
    const pilarOrder = ["INTRO", "CX", "DADOS", "IA"];
    return pilarOrder
      .filter(p => grouped[p])
      .map(pilar => ({
        pilar,
        config: PILAR_CONFIG[pilar] || PILAR_CONFIG.INTRO,
        modules: (grouped[pilar] || []).sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0)),
        completedCount: (grouped[pilar] || []).filter(m => m.isCompleted).length,
      }));
  }, [modulesWithProgress]);

  // In-progress module IDs set
  const inProgressIdSet = useMemo(() => {
    if (!progressData) return new Set<number>();
    return new Set(progressData.filter(p => !p.completed).map(p => p.contentId));
  }, [progressData]);

  // Continue watching - recently started but not completed
  const continueWatching = useMemo(() => {
    if (!modulesWithProgress) return [];
    return modulesWithProgress
      .filter(m => inProgressIdSet.has(m.id))
      .slice(0, 4);
  }, [modulesWithProgress, inProgressIdSet]);

  // Search & filter
  const filteredModules = useMemo(() => {
    if (!modulesWithProgress) return [];
    let result = [...modulesWithProgress];
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(m =>
        m.title.toLowerCase().includes(q) ||
        (m.description || "").toLowerCase().includes(q) ||
        (m.moduleCode || "").toLowerCase().includes(q)
      );
    }
    if (selectedPilar !== "all") {
      result = result.filter(m => m.pilar === selectedPilar);
    }
    return result;
  }, [modulesWithProgress, searchQuery, selectedPilar]);

  const isSearching = searchQuery.trim() || selectedPilar !== "all";

  // Stats
  const totalModules = modulesWithProgress?.length || 0;
  const completedModules = modulesWithProgress?.filter(m => m.isCompleted).length || 0;
  const progressPercent = totalModules > 0 ? Math.round((completedModules / totalModules) * 100) : 0;

  // Filtered soluções
  const filteredSolucoes = useMemo(() => {
    let items = [...SOLUCOES_DATA];
    if (solucoesCategory !== "Todas") {
      items = items.filter(s => s.category === solucoesCategory);
    }
    if (solucoesTab === "Mais usadas") {
      items = items.slice(0, 6);
    } else if (solucoesTab === "Novas") {
      items = items.slice(-4);
    } else if (solucoesTab === "Recomendadas") {
      items = items.filter(s => s.level === "Fundamentos" || s.level === "Aplicação").slice(0, 6);
    }
    return items;
  }, [solucoesCategory, solucoesTab]);

  // Handle sidebar section changes
  const handleSectionChange = (section: string) => {
    setSelectedSection(section);
    if (section === "trilhas") {
      setSelectedPilar("all");
      setSearchQuery("");
    } else if (section.startsWith("trilha-")) {
      const pilar = section.replace("trilha-", "");
      setSelectedPilar(pilar);
      setSelectedSection("trilhas");
      setSearchQuery("");
    } else if (section === "certificados") {
      window.location.href = "/certificados";
    } else if (section === "comunidade") {
      window.location.href = "/comunidade";
    } else if (section === "suporte") {
      window.location.href = "/ajuda";
    } else if (section === "historico-radar") {
      // Handled inline
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-32 pb-20 flex items-center justify-center min-h-[80vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
        <Footer />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <section className="pt-32 pb-20 min-h-[80vh] flex items-center">
          <div className="container">
            <div className="max-w-lg mx-auto text-center">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                <Lock className="w-10 h-10 text-primary" />
              </div>
              <h1 className="text-3xl font-bold mb-4">Área Exclusiva para Membros</h1>
              <p className="text-muted-foreground mb-8">
                Faça login para acessar seus materiais, playbooks e acompanhar seu progresso na mentoria.
              </p>
              <a href="/login">
                <Button className="bg-primary hover:bg-primary/90">
                  Fazer Login
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </a>
            </div>
          </div>
        </section>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <SEO title={PAGE_SEO.membros.title} description={PAGE_SEO.membros.description} path="/membros" noindex />
      
      <div className="flex">
        {/* Sidebar */}
        <MembersSidebar
          stats={{
            totalModules,
            completedModules,
            totalTemplates: SOLUCOES_DATA.length,
            totalQuizzes: 0,
            totalCertificates: 0,
            radarCount: radarHistory?.length || 0,
            newCount: 3,
          }}
          trails={trails}
          selectedSection={selectedSection}
          onSectionChange={handleSectionChange}
          userName={user?.name?.split(" ")[0]}
        />

        {/* Main Content */}
        <div className="flex-1 min-w-0">
          {/* Top Bar */}
          <div className="sticky top-0 z-40 bg-background/95 backdrop-blur-sm border-b border-border/50">
            <div className="flex items-center gap-4 px-6 py-3">
              {/* Search */}
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar módulos, soluções, quizzes..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-10 h-9 bg-muted/30"
                />
              </div>

              {/* Quick actions */}
              <div className="flex items-center gap-2">
                <Link href="/certificados">
                  <Button variant="ghost" size="sm" className="text-xs gap-1.5">
                    <GraduationCap className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Certificados</span>
                  </Button>
                </Link>
                <Link href="/perfil">
                  <Button variant="ghost" size="sm" className="text-xs gap-1.5">
                    <Award className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Perfil</span>
                  </Button>
                </Link>
              </div>
            </div>
          </div>

          {/* Content Area */}
          <div className="p-6 space-y-8">
            
            {/* ===== DASHBOARD (Início) ===== */}
            {selectedSection === "dashboard" && (
              <>
                {/* Onboarding Welcome (novos alunos) */}
                {showOnboarding && completedModules === 0 && (
                  <OnboardingWelcome
                    userName={user?.name?.split(" ")[0] || "Mentorado"}
                    onDismiss={() => {
                      setShowOnboarding(false);
                      localStorage.setItem("datacx_onboarding_dismissed", "true");
                    }}
                    onNavigate={handleSectionChange}
                  />
                )}

                {/* Welcome + Progress */}
                <div>
                  <h1 className="text-2xl font-bold mb-1">
                    Olá, <span className="gradient-text">{user?.name?.split(" ")[0] || "Mentorado"}</span>! 👋
                  </h1>
                  <p className="text-sm text-muted-foreground">Continue sua jornada de transformação</p>
                </div>

                {/* Progress Card */}
                <div className="bg-card/50 rounded-xl p-5 border border-border/50">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-primary" />
                      <span className="text-sm font-medium">Progresso Geral</span>
                    </div>
                    <span className="text-sm font-bold text-primary">{progressPercent}%</span>
                  </div>
                  <div className="w-full bg-muted/30 rounded-full h-2.5 mb-3">
                    <div
                      className="bg-gradient-to-r from-primary to-accent h-2.5 rounded-full transition-all duration-500"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                  <div className="flex items-center gap-4 flex-wrap">
                    {trails.map(trail => (
                      <button
                        key={trail.pilar}
                        onClick={() => handleSectionChange(`trilha-${trail.pilar}`)}
                        className="flex items-center gap-1.5 text-xs hover:text-primary transition-colors cursor-pointer"
                      >
                        <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${trail.config.gradient}`} />
                        <span className="text-muted-foreground">{trail.config.shortName}:</span>
                        <span className="font-medium">{trail.completedCount}/{trail.modules.length}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Continue Watching */}
                {continueWatching.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <Play className="w-5 h-5 text-primary" />
                      <h2 className="text-lg font-semibold">Continuar de Onde Parei</h2>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                      {continueWatching.map(mod => (
                        <ModuleCard key={mod.id} module={mod} accessData={accessData} isInProgress />
                      ))}
                    </div>
                  </div>
                )}

                {/* Quick Access Cards */}
                <div>
                  <h2 className="text-lg font-semibold mb-4">Acesso Rápido</h2>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                    <button onClick={() => setSelectedSection("trilhas")} className="bg-card/50 border border-border/50 rounded-xl p-4 hover:border-primary/50 transition-all text-left group">
                      <BookOpen className="w-6 h-6 text-blue-400 mb-2" />
                      <p className="text-sm font-medium group-hover:text-primary transition-colors">Trilhas</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{totalModules} módulos</p>
                    </button>
                    <button onClick={() => setSelectedSection("solucoes")} className="bg-card/50 border border-border/50 rounded-xl p-4 hover:border-emerald-500/50 transition-all text-left group">
                      <Zap className="w-6 h-6 text-emerald-400 mb-2" />
                      <p className="text-sm font-medium group-hover:text-emerald-400 transition-colors">Soluções</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{SOLUCOES_DATA.length} recursos</p>
                    </button>
                    <Link href="/certificados">
                      <div className="bg-card/50 border border-border/50 rounded-xl p-4 hover:border-amber-500/50 transition-all text-left group h-full">
                        <GraduationCap className="w-6 h-6 text-amber-400 mb-2" />
                        <p className="text-sm font-medium group-hover:text-amber-400 transition-colors">Certificados</p>
                        <p className="text-xs text-muted-foreground mt-0.5">Suas conquistas</p>
                      </div>
                    </Link>
                    <button onClick={() => setSelectedSection("historico-radar")} className="bg-card/50 border border-border/50 rounded-xl p-4 hover:border-cyan-500/50 transition-all text-left group">
                      <Radar className="w-6 h-6 text-cyan-400 mb-2" />
                      <p className="text-sm font-medium group-hover:text-cyan-400 transition-colors">Histórico Radar</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{radarHistory?.length || 0} diagnósticos</p>
                    </button>
                    <Link href="/ajuda">
                      <div className="bg-card/50 border border-border/50 rounded-xl p-4 hover:border-purple-500/50 transition-all text-left group h-full">
                        <Target className="w-6 h-6 text-purple-400 mb-2" />
                        <p className="text-sm font-medium group-hover:text-purple-400 transition-colors">Suporte</p>
                        <p className="text-xs text-muted-foreground mt-0.5">FAQ & ajuda</p>
                      </div>
                    </Link>
                  </div>
                </div>

                {/* Trail Rows - Netflix Style */}
                {!modulesLoading && trails.map(trail => (
                  <div key={trail.pilar}>
                    <div className="relative rounded-xl overflow-hidden mb-4 h-28 sm:h-32">
                      <img
                        src={trail.config.bannerUrl}
                        alt={trail.config.name}
                        className="absolute inset-0 w-full h-full object-cover"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent" />
                      <div className="relative h-full flex items-center justify-between px-5 sm:px-6">
                        <div className="flex items-center gap-3">
                          <div className={`p-2.5 rounded-lg bg-gradient-to-br ${trail.config.gradient} text-white shadow-lg`}>
                            {trail.config.icon}
                          </div>
                          <div>
                            <h2 className="text-lg sm:text-xl font-bold text-white drop-shadow-md">{trail.config.name}</h2>
                            <p className="text-xs sm:text-sm text-white/70">
                              {trail.completedCount}/{trail.modules.length} módulos concluídos
                            </p>
                            <div className="w-32 sm:w-40 bg-white/20 rounded-full h-1.5 mt-1.5">
                              <div
                                className={`h-1.5 rounded-full transition-all duration-700 bg-gradient-to-r ${trail.config.gradient}`}
                                style={{ width: `${trail.modules.length > 0 ? Math.round((trail.completedCount / trail.modules.length) * 100) : 0}%` }}
                              />
                            </div>
                          </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-white/80 hover:text-white hover:bg-white/10"
                          onClick={() => handleSectionChange(`trilha-${trail.pilar}`)}
                        >
                          Ver Todos <ChevronRight className="w-4 h-4 ml-1" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex gap-4 overflow-x-auto pb-3 -mx-2 px-2 custom-scrollbar">
                      {trail.modules.map(mod => (
                        <div key={mod.id} className="min-w-[240px] max-w-[240px] flex-shrink-0">
                          <ModuleCard module={mod} accessData={accessData} compact isInProgress={inProgressIdSet.has(mod.id)} />
                        </div>
                      ))}
                    </div>
                  </div>
                ))}

                {modulesLoading && (
                  <div className="flex justify-center py-12">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                  </div>
                )}
              </>
            )}

            {/* ===== TRILHAS ===== */}
            {selectedSection === "trilhas" && (
              <>
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-2xl font-bold">Trilhas de Aprendizado</h1>
                    <p className="text-sm text-muted-foreground mt-1">{totalModules} módulos disponíveis</p>
                  </div>
                </div>

                {/* Pilar filter tabs */}
                <Tabs value={selectedPilar} onValueChange={setSelectedPilar}>
                  <TabsList>
                    <TabsTrigger value="all" className="text-xs">Todos</TabsTrigger>
                    {Object.entries(PILAR_CONFIG).map(([key, config]) => (
                      <TabsTrigger key={key} value={key} className="text-xs">
                        {config.shortName}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </Tabs>

                {modulesLoading && (
                  <div className="flex justify-center py-12">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                  </div>
                )}

                {/* Search Results or Trail View */}
                {!modulesLoading && (isSearching ? (
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <Filter className="w-5 h-5 text-muted-foreground" />
                      <h2 className="text-lg font-semibold">
                        {filteredModules.length} resultado{filteredModules.length !== 1 ? "s" : ""}
                      </h2>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                      {filteredModules.map(mod => (
                        <ModuleCard key={mod.id} module={mod} accessData={accessData} isInProgress={inProgressIdSet.has(mod.id)} />
                      ))}
                    </div>
                    {filteredModules.length === 0 && (
                      <div className="text-center py-12">
                        <Search className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                        <p className="text-muted-foreground">Nenhum módulo encontrado</p>
                      </div>
                    )}
                  </div>
                ) : (
                  trails.map(trail => (
                    <div key={trail.pilar}>
                      <div className="relative rounded-xl overflow-hidden mb-4 h-28 sm:h-32">
                        <img
                          src={trail.config.bannerUrl}
                          alt={trail.config.name}
                          className="absolute inset-0 w-full h-full object-cover"
                          loading="lazy"
                        />
                        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent" />
                        <div className="relative h-full flex items-center justify-between px-5 sm:px-6">
                          <div className="flex items-center gap-3">
                            <div className={`p-2.5 rounded-lg bg-gradient-to-br ${trail.config.gradient} text-white shadow-lg`}>
                              {trail.config.icon}
                            </div>
                            <div>
                              <h2 className="text-lg sm:text-xl font-bold text-white drop-shadow-md">{trail.config.name}</h2>
                              <p className="text-xs sm:text-sm text-white/70">
                                {trail.completedCount}/{trail.modules.length} módulos concluídos
                              </p>
                              <div className="w-32 sm:w-40 bg-white/20 rounded-full h-1.5 mt-1.5">
                                <div
                                  className={`h-1.5 rounded-full transition-all duration-700 bg-gradient-to-r ${trail.config.gradient}`}
                                  style={{ width: `${trail.modules.length > 0 ? Math.round((trail.completedCount / trail.modules.length) * 100) : 0}%` }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                        {trail.modules.map(mod => (
                          <ModuleCard key={mod.id} module={mod} accessData={accessData} isInProgress={inProgressIdSet.has(mod.id)} />
                        ))}
                      </div>
                    </div>
                  ))
                ))}
              </>
            )}

            {/* ===== SOLUÇÕES ===== */}
            {selectedSection === "solucoes" && (
              <>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Zap className="w-6 h-6 text-emerald-400" />
                    <h1 className="text-2xl font-bold">Soluções</h1>
                    <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 text-[10px]">Novo</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">Templates, checklists, prompts e modelos prontos para aplicar agora</p>
                </div>

                {/* Tabs */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <Tabs value={solucoesTab} onValueChange={setSolucoesTab}>
                    <TabsList>
                      {SOLUCOES_TABS.map(tab => (
                        <TabsTrigger key={tab} value={tab} className="text-xs">{tab}</TabsTrigger>
                      ))}
                    </TabsList>
                  </Tabs>
                  <div className="flex gap-1.5 flex-wrap">
                    {SOLUCOES_CATEGORIES.map(cat => (
                      <Button
                        key={cat}
                        variant={solucoesCategory === cat ? "default" : "outline"}
                        size="sm"
                        className="text-xs h-7 px-2.5"
                        onClick={() => setSolucoesCategory(cat)}
                      >
                        {cat}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Solutions Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredSolucoes.map(sol => (
                    <Card key={sol.id} className="bg-card/50 border-border/50 hover:border-primary/50 transition-all duration-300 group cursor-pointer">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <div className={`p-1.5 rounded-md ${CATEGORY_COLORS[sol.category] || "bg-muted"}`}>
                              {TYPE_ICONS[sol.type] || <FileText className="w-3.5 h-3.5" />}
                            </div>
                            <Badge variant="outline" className={`text-[9px] px-1.5 ${CATEGORY_COLORS[sol.category] || ""}`}>
                              {sol.category}
                            </Badge>
                          </div>
                          <Badge className={`text-[9px] px-1.5 py-0 ${LEVEL_COLORS[sol.level] || ""}`}>
                            {sol.level}
                          </Badge>
                        </div>
                        <h3 className="font-semibold text-sm mb-1.5 group-hover:text-primary transition-colors">
                          {sol.title}
                        </h3>
                        <p className="text-xs text-muted-foreground line-clamp-2 mb-3">
                          {sol.description}
                        </p>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {sol.time}
                          </span>
                          <Button size="sm" className="h-7 text-xs gap-1">
                            {sol.action === "Baixar" && <Download className="w-3 h-3" />}
                            {sol.action === "Aplicar" && <Sparkles className="w-3 h-3" />}
                            {sol.action === "Abrir" && <ExternalLink className="w-3 h-3" />}
                            {sol.action}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {filteredSolucoes.length === 0 && (
                  <div className="text-center py-12">
                    <Zap className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                    <p className="text-muted-foreground">Nenhuma solução encontrada nesta categoria</p>
                  </div>
                )}
              </>
            )}

            {/* ===== QUIZZES ===== */}
            {selectedSection === "quizzes" && (
              <div className="text-center py-20">
                <Trophy className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
                <h2 className="text-xl font-bold mb-2">Quizzes em Breve</h2>
                <p className="text-muted-foreground text-sm max-w-md mx-auto">
                  Os quizzes estão sendo preparados. Em breve você poderá testar seus conhecimentos e ganhar pontos.
                </p>
                <Button variant="outline" className="mt-6" onClick={() => setSelectedSection("dashboard")}>
                  Voltar ao Início
                </Button>
              </div>
            )}

            {/* ===== PROGRESSO ===== */}
            {selectedSection === "progresso" && (
              <>
                <div>
                  <h1 className="text-2xl font-bold">Meu Progresso</h1>
                  <p className="text-sm text-muted-foreground mt-1">Acompanhe sua evolução em cada trilha</p>
                </div>

                {/* Overall Stats */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="bg-card/50 border border-border/50 rounded-xl p-4 text-center">
                    <p className="text-3xl font-bold text-primary">{completedModules}</p>
                    <p className="text-xs text-muted-foreground mt-1">Módulos Concluídos</p>
                  </div>
                  <div className="bg-card/50 border border-border/50 rounded-xl p-4 text-center">
                    <p className="text-3xl font-bold text-blue-400">{totalModules - completedModules}</p>
                    <p className="text-xs text-muted-foreground mt-1">Pendentes</p>
                  </div>
                  <div className="bg-card/50 border border-border/50 rounded-xl p-4 text-center">
                    <p className="text-3xl font-bold text-emerald-400">{progressPercent}%</p>
                    <p className="text-xs text-muted-foreground mt-1">Progresso Total</p>
                  </div>
                  <div className="bg-card/50 border border-border/50 rounded-xl p-4 text-center">
                    <p className="text-3xl font-bold text-amber-400">{trails.length}</p>
                    <p className="text-xs text-muted-foreground mt-1">Trilhas Ativas</p>
                  </div>
                </div>

                {/* Per-trail progress */}
                <div className="space-y-4">
                  {trails.map(trail => {
                    const trailPercent = trail.modules.length > 0 ? Math.round((trail.completedCount / trail.modules.length) * 100) : 0;
                    return (
                      <div key={trail.pilar} className="bg-card/50 border border-border/50 rounded-xl p-5">
                        <div className="flex items-center gap-3 mb-3">
                          <div className={`p-2 rounded-lg bg-gradient-to-br ${trail.config.gradient} text-white`}>
                            {trail.config.icon}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <h3 className="font-semibold">{trail.config.name}</h3>
                              <span className="text-sm font-bold">{trailPercent}%</span>
                            </div>
                            <p className="text-xs text-muted-foreground">{trail.completedCount} de {trail.modules.length} módulos</p>
                          </div>
                        </div>
                        <div className="w-full bg-muted/30 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full transition-all duration-700 bg-gradient-to-r ${trail.config.gradient}`}
                            style={{ width: `${trailPercent}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </>
            )}

            {/* ===== JORNADA CONSULTORIA ===== */}
            {selectedSection === "jornada-consultoria" && (
              <JornadaDashboard />
            )}

            {/* ===== HISTÓRICO RADAR ===== */}
            {selectedSection === "historico-radar" && (
              <RadarHistorySection history={radarHistory || []} />  
            )}
          </div>
        </div>
      </div>
    </div>
  );
}


// ===== MODULE CARD COMPONENT =====
interface ModuleCardProps {
  module: {
    id: number;
    title: string;
    description?: string | null;
    moduleCode?: string | null;
    pilar?: string | null;
    nivel?: string | null;
    duracao?: string | null;
    thumbnailUrl?: string | null;
    isCompleted?: boolean;
    type?: string;
    isReleased?: boolean;
    releaseDate?: string | Date | null;
  };
  accessData?: { planSlug: string | null; moduleCodes: string[]; isAdmin?: boolean; hasActivePlan?: boolean } | null;
  compact?: boolean;
  isInProgress?: boolean;
}

function ModuleCard({ module, accessData, compact, isInProgress }: ModuleCardProps) {
  const pilar = module.pilar || "INTRO";
  const config = PILAR_CONFIG[pilar] || PILAR_CONFIG.INTRO;
  const FREE_PREVIEW_MODULES = ["INT-01"];
  const isAdmin = (accessData as any)?.isAdmin === true;
  const hasActivePlan = (accessData as any)?.hasActivePlan === true;
  const isLocked = isAdmin ? false
    : hasActivePlan && module.moduleCode
      ? !accessData!.moduleCodes.includes(module.moduleCode)
      : !hasActivePlan && module.moduleCode
        ? !FREE_PREVIEW_MODULES.includes(module.moduleCode)
        : false;
  const isScheduled = module.isReleased === false;
  const releaseFormatted = module.releaseDate
    ? new Date(module.releaseDate).toLocaleDateString("pt-BR", { day: "2-digit", month: "short" })
    : null;

  const cardContent = (
    <Card className={`group bg-card/50 border-border/50 hover:border-primary/50 transition-all duration-300 cursor-pointer overflow-hidden h-full relative ${
      module.isCompleted ? "border-primary/30 bg-primary/5" : ""
    } ${isLocked ? "opacity-60" : ""}`}>
      {/* Thumbnail Cover */}
      {module.thumbnailUrl ? (
        <>
          <div className="relative aspect-[16/10] overflow-hidden">
            <img
              src={module.thumbnailUrl}
              alt={module.title}
              className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
              loading="lazy"
            />
            {/* Hover overlay */}
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
              <Play className="w-10 h-10 text-white drop-shadow-lg" />
            </div>
            {/* Status badge */}
            {module.isCompleted ? (
              <div className="absolute top-2 right-2 bg-green-500/90 rounded-full p-1.5 z-[5]">
                <CheckCircle2 className="w-4 h-4 text-white" />
              </div>
            ) : isInProgress ? (
              <div className="absolute top-2 right-2 bg-blue-500/90 rounded-full p-1.5 z-[5]">
                <Play className="w-3.5 h-3.5 text-white" />
              </div>
            ) : null}

            {/* Progress bar at bottom of thumbnail */}
            {!isLocked && !isScheduled && (module.isCompleted || isInProgress) && (
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/30 z-[5]">
                <div className={`h-full transition-all duration-500 ${
                  module.isCompleted ? "bg-green-500 w-full" : "bg-blue-500 w-1/3"
                }`} />
              </div>
            )}
          </div>
          {/* Info section below thumbnail */}
          <div className="p-3">
            <div className="flex items-start justify-between gap-1 mb-1">
              <Badge variant="outline" className={`${config.bg} ${config.color} text-[9px] border flex-shrink-0`}>
                {module.moduleCode}
              </Badge>
              {module.isCompleted ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-green-500 flex-shrink-0 mt-0.5" />
              ) : isInProgress ? (
                <Play className="w-3.5 h-3.5 text-blue-400 flex-shrink-0 mt-0.5" />
              ) : null}
            </div>
            <h3 className={`font-semibold text-xs leading-snug line-clamp-2 mt-1 ${isLocked ? "" : "group-hover:text-primary transition-colors"}`}>
              {module.title}
            </h3>
            <div className="flex items-center gap-2 mt-1.5">
              {module.duracao && (
                <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                  <Clock className="w-2.5 h-2.5" />
                  {module.duracao}
                </span>
              )}
              {module.nivel && (
                <span className="text-[10px] text-muted-foreground">
                  {module.nivel === "fundamentos" ? "Fundamentos" : module.nivel === "aplicacao" ? "Aplicação" : "Escala"}
                </span>
              )}
            </div>
            {!isLocked && !isScheduled && (module.isCompleted || isInProgress) && (
              <div className="mt-2">
                <div className="w-full bg-muted/30 rounded-full h-1">
                  <div className={`h-1 rounded-full transition-all duration-500 ${
                    module.isCompleted ? "bg-green-500 w-full" : "bg-blue-500 w-1/3"
                  }`} />
                </div>
              </div>
            )}
          </div>
        </>
      ) : (
        <>
          <div className={`h-1.5 bg-gradient-to-r ${config.gradient} ${isLocked ? "opacity-40" : ""}`} />
          <CardContent className={`${compact ? "p-3" : "p-4"}`}>
            <div className="flex items-start justify-between mb-2">
              <Badge variant="outline" className={`${config.bg} ${config.color} text-[10px] border`}>
                {module.moduleCode}
              </Badge>
              {module.isCompleted ? (
                <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
              ) : isInProgress ? (
                <Play className="w-4 h-4 text-blue-400 flex-shrink-0" />
              ) : isLocked ? (
                <Lock className="w-4 h-4 text-muted-foreground/30 flex-shrink-0" />
              ) : (
                <Play className="w-4 h-4 text-muted-foreground/30 group-hover:text-primary transition-colors flex-shrink-0" />
              )}
            </div>
            <h3 className={`font-semibold text-sm line-clamp-2 ${isLocked ? "" : "group-hover:text-primary transition-colors"}`}>
              {module.title}
            </h3>
            {!compact && module.description && (
              <p className="text-xs text-muted-foreground line-clamp-2 mt-1.5">{module.description}</p>
            )}
            {!isLocked && !isScheduled && (module.isCompleted || isInProgress) && (
              <div className="mt-2">
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-[10px] font-medium ${module.isCompleted ? "text-green-400" : "text-blue-400"}`}>
                    {module.isCompleted ? "Concluído" : "Em andamento"}
                  </span>
                </div>
                <div className="w-full bg-muted/30 rounded-full h-1.5">
                  <div className={`h-1.5 rounded-full transition-all duration-500 ${
                    module.isCompleted ? "bg-green-500 w-full" : "bg-blue-500 w-1/3"
                  }`} />
                </div>
              </div>
            )}
            <div className="flex items-center gap-2 mt-3">
              {module.duracao && (
                <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {module.duracao}
                </span>
              )}
            </div>
          </CardContent>
        </>
      )}
      
      {/* Lock Overlay */}
      {isLocked && !isScheduled && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-background/60 backdrop-blur-[1px]">
          <Lock className="w-6 h-6 text-muted-foreground mb-2" />
          <span className="text-[10px] text-muted-foreground font-medium">
            {hasActivePlan ? "Fora do seu plano" : "Plano necessário"}
          </span>
          <Link href={hasActivePlan ? "/upgrade" : "/ofertas"}>
            <Button size="sm" variant="outline" className="mt-2 text-[10px] h-6 px-2">
              {hasActivePlan ? "Fazer Upgrade" : "Ver Programas"}
            </Button>
          </Link>
        </div>
      )}
      {/* Scheduled Overlay */}
      {isScheduled && !isLocked && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-background/70 backdrop-blur-[2px]">
          <Clock className="w-6 h-6 text-amber-400 mb-2" />
          <span className="text-[10px] text-amber-400 font-semibold">Disponível em</span>
          <span className="text-sm text-amber-300 font-bold mt-0.5">{releaseFormatted}</span>
        </div>
      )}
      {isScheduled && isLocked && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-background/60 backdrop-blur-[1px]">
          <Lock className="w-6 h-6 text-muted-foreground mb-2" />
          <span className="text-[10px] text-muted-foreground font-medium">
            {hasActivePlan ? "Fora do seu plano" : "Plano necessário"}
          </span>
          <Link href={hasActivePlan ? "/upgrade" : "/ofertas"}>
            <Button size="sm" variant="outline" className="mt-2 text-[10px] h-6 px-2">
              {hasActivePlan ? "Fazer Upgrade" : "Ver Programas"}
            </Button>
          </Link>
        </div>
      )}
    </Card>
  );

  if (isLocked || isScheduled) {
    return cardContent;
  }

  return (
    <Link href={`/membros/conteudo/${module.id}`}>
      {cardContent}
    </Link>
  );
}


// ===== JORNADA DASHBOARD COMPONENT =====
function JornadaDashboard() {
  const { data: journey, isLoading } = trpc.consulting.journeyDashboard.useQuery();
  const [expandedProject, setExpandedProject] = useState<number | null>(null);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
        <span className="ml-2 text-muted-foreground">Carregando sua jornada...</span>
      </div>
    );
  }

  if (!journey || journey.projects.length === 0) {
    return (
      <div className="text-center py-16 space-y-4">
        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
          <Route className="w-8 h-8 text-primary" />
        </div>
        <h2 className="text-xl font-bold">Sua Jornada Começa Aqui</h2>
        <p className="text-muted-foreground max-w-md mx-auto">
          Quando você iniciar uma consultoria ou mentoria, sua jornada completa aparecerá aqui com etapas, 
          entregas, prazos e progresso em tempo real.
        </p>
        <Link href="/ofertas">
          <Button className="mt-4">
            <Rocket className="w-4 h-4 mr-2" />
            Ver Programas Disponíveis
          </Button>
        </Link>
      </div>
    );
  }

  const { summary, projects } = journey;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">Minha Jornada</h1>
        <p className="text-sm text-muted-foreground mt-1">Acompanhe o progresso da sua consultoria e mentoria</p>
      </div>

      {/* Overall Progress Ring + Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Progress Ring */}
        <div className="md:col-span-1 bg-card/50 border border-border/50 rounded-xl p-6 flex flex-col items-center justify-center">
          <div className="relative w-32 h-32">
            <svg className="w-32 h-32 -rotate-90" viewBox="0 0 120 120">
              <circle cx="60" cy="60" r="52" fill="none" stroke="currentColor" strokeWidth="8" className="text-muted/20" />
              <circle
                cx="60" cy="60" r="52" fill="none" strokeWidth="8"
                strokeDasharray={`${2 * Math.PI * 52}`}
                strokeDashoffset={`${2 * Math.PI * 52 * (1 - summary.overallProgress / 100)}`}
                strokeLinecap="round"
                className="text-primary transition-all duration-1000"
                stroke="currentColor"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-bold">{summary.overallProgress}%</span>
              <span className="text-[10px] text-muted-foreground">Concluído</span>
            </div>
          </div>
          <p className="text-sm font-medium mt-3">Progresso Geral</p>
        </div>

        {/* Stats Grid */}
        <div className="md:col-span-2 grid grid-cols-2 sm:grid-cols-3 gap-3">
          <StatCard icon={<FolderOpen className="w-4 h-4" />} value={summary.activeProjects} label="Projetos Ativos" color="text-blue-400" />
          <StatCard icon={<ListChecks className="w-4 h-4" />} value={`${summary.completedStages}/${summary.totalStages}`} label="Etapas" color="text-emerald-400" />
          <StatCard icon={<Target className="w-4 h-4" />} value={`${summary.completedTasks}/${summary.totalTasks}`} label="Tarefas" color="text-amber-400" />
          <StatCard icon={<Milestone className="w-4 h-4" />} value={`${summary.completedMilestones}/${summary.totalMilestones}`} label="Marcos" color="text-purple-400" />
          <StatCard icon={<Package className="w-4 h-4" />} value={`${summary.approvedDeliverables}/${summary.totalDeliverables}`} label="Entregas" color="text-cyan-400" />
          <StatCard icon={<CircleCheck className="w-4 h-4" />} value={summary.completedProjects} label="Concluídos" color="text-green-400" />
        </div>
      </div>

      {/* Upcoming Deadlines */}
      {summary.upcomingDeadlines.length > 0 && (
        <div className="bg-card/50 border border-border/50 rounded-xl p-5">
          <h3 className="font-semibold flex items-center gap-2 mb-4">
            <CalendarClock className="w-4 h-4 text-amber-400" />
            Próximos Prazos
          </h3>
          <div className="space-y-2">
            {summary.upcomingDeadlines.slice(0, 5).map((deadline, i) => {
              const daysLeft = Math.ceil((new Date(deadline.dueDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
              const isUrgent = daysLeft <= 3;
              const isWarning = daysLeft <= 7;
              return (
                <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-muted/20 hover:bg-muted/30 transition-colors">
                  <div className={cn(
                    "w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0",
                    isUrgent ? "bg-red-500/20 text-red-400" : isWarning ? "bg-amber-500/20 text-amber-400" : "bg-blue-500/20 text-blue-400"
                  )}>
                    {deadline.type === 'stage' ? <ListChecks className="w-4 h-4" /> :
                     deadline.type === 'task' ? <Target className="w-4 h-4" /> :
                     <Milestone className="w-4 h-4" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{deadline.title}</p>
                    <p className="text-[10px] text-muted-foreground">{deadline.projectName}</p>
                  </div>
                  <div className={cn(
                    "text-xs font-medium px-2 py-1 rounded-full flex-shrink-0",
                    isUrgent ? "bg-red-500/20 text-red-400" : isWarning ? "bg-amber-500/20 text-amber-400" : "bg-blue-500/20 text-blue-400"
                  )}>
                    {daysLeft <= 0 ? "Hoje" : daysLeft === 1 ? "Amanhã" : `${daysLeft} dias`}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Projects */}
      <div className="space-y-4">
        <h3 className="font-semibold text-lg">Meus Projetos</h3>
        {projects.map((project: any) => {
          const isExpanded = expandedProject === project.id;
          const projectProgress = project.stagesTotal > 0
            ? Math.round((project.stagesCompleted / project.stagesTotal) * 100)
            : project.progress;
          const statusConfig: Record<string, { label: string; color: string; bg: string }> = {
            discovery: { label: "Descoberta", color: "text-blue-400", bg: "bg-blue-500/20" },
            planning: { label: "Planejamento", color: "text-purple-400", bg: "bg-purple-500/20" },
            in_progress: { label: "Em Andamento", color: "text-amber-400", bg: "bg-amber-500/20" },
            review: { label: "Revisão", color: "text-cyan-400", bg: "bg-cyan-500/20" },
            completed: { label: "Concluído", color: "text-emerald-400", bg: "bg-emerald-500/20" },
            on_hold: { label: "Pausado", color: "text-gray-400", bg: "bg-gray-500/20" },
          };
          const status = statusConfig[project.status] || statusConfig.in_progress;

          return (
            <div key={project.id} className="bg-card/50 border border-border/50 rounded-xl overflow-hidden">
              {/* Project Header */}
              <button
                onClick={() => setExpandedProject(isExpanded ? null : project.id)}
                className="w-full p-5 text-left hover:bg-muted/20 transition-colors"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-semibold truncate">{project.name}</h4>
                      <Badge className={cn("text-[10px] px-1.5 py-0 h-4", status.bg, status.color)}>
                        {status.label}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground line-clamp-1">{project.description}</p>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <div className="text-right">
                      <p className="text-lg font-bold">{projectProgress}%</p>
                      <p className="text-[10px] text-muted-foreground">Progresso</p>
                    </div>
                    <ChevronRight className={cn("w-5 h-5 text-muted-foreground transition-transform", isExpanded && "rotate-90")} />
                  </div>
                </div>
                {/* Progress bar */}
                <div className="mt-3 w-full bg-muted/30 rounded-full h-2">
                  <div
                    className="h-2 rounded-full bg-gradient-to-r from-primary to-cyan-400 transition-all duration-700"
                    style={{ width: `${projectProgress}%` }}
                  />
                </div>
                {/* Quick stats */}
                <div className="mt-3 flex gap-4 text-[11px] text-muted-foreground">
                  <span>{project.stagesCompleted}/{project.stagesTotal} etapas</span>
                  <span>{project.tasksCompleted}/{project.tasksTotal} tarefas</span>
                  <span>{project.milestonesCompleted}/{project.milestonesTotal} marcos</span>
                  <span>{project.deliverablesApproved}/{project.deliverablesTotal} entregas</span>
                </div>
              </button>

              {/* Expanded Detail */}
              {isExpanded && (
                <div className="border-t border-border/50 p-5 space-y-5">
                  {/* Stages Timeline */}
                  {project.stages && project.stages.length > 0 && (
                    <div>
                      <h5 className="text-sm font-semibold mb-3 flex items-center gap-2">
                        <ListChecks className="w-4 h-4 text-primary" />
                        Etapas da Jornada
                      </h5>
                      <div className="space-y-1">
                        {project.stages.map((stage: any, idx: number) => {
                          const stageStatusMap: Record<string, { icon: React.ReactNode; color: string; bg: string; label: string }> = {
                            completed: { icon: <CircleCheck className="w-4 h-4" />, color: "text-emerald-400", bg: "bg-emerald-500/20", label: "Concluída" },
                            in_progress: { icon: <CircleDot className="w-4 h-4" />, color: "text-amber-400", bg: "bg-amber-500/20", label: "Em Andamento" },
                            available: { icon: <CircleDot className="w-4 h-4" />, color: "text-blue-400", bg: "bg-blue-500/20", label: "Disponível" },
                            locked: { icon: <Lock className="w-4 h-4" />, color: "text-gray-500", bg: "bg-gray-500/20", label: "Bloqueada" },
                          };
                          const stageStatus = stageStatusMap[stage.status] || stageStatusMap.locked;
                          const isLast = idx === project.stages.length - 1;

                          return (
                            <div key={stage.id} className="flex gap-3">
                              {/* Timeline line */}
                              <div className="flex flex-col items-center">
                                <div className={cn("w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0", stageStatus.bg, stageStatus.color)}>
                                  {stageStatus.icon}
                                </div>
                                {!isLast && <div className="w-0.5 flex-1 bg-border/50 my-1" />}
                              </div>
                              {/* Content */}
                              <div className={cn("pb-4 flex-1", isLast && "pb-0")}>
                                <div className="flex items-center gap-2">
                                  <p className={cn("text-sm font-medium", stage.status === 'locked' && "text-muted-foreground")}>{stage.title}</p>
                                  <Badge className={cn("text-[9px] px-1.5 py-0 h-4", stageStatus.bg, stageStatus.color)}>
                                    {stageStatus.label}
                                  </Badge>
                                </div>
                                {stage.description && (
                                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{stage.description}</p>
                                )}
                                {stage.dueDate && (
                                  <p className="text-[10px] text-muted-foreground mt-1 flex items-center gap-1">
                                    <CalendarClock className="w-3 h-3" />
                                    Prazo: {new Date(stage.dueDate).toLocaleDateString('pt-BR')}
                                  </p>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Next Stage Highlight */}
                  {project.nextStage && (
                    <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
                      <h5 className="text-sm font-semibold flex items-center gap-2 text-primary mb-2">
                        <ArrowRight className="w-4 h-4" />
                        Próxima Etapa
                      </h5>
                      <p className="text-sm font-medium">{project.nextStage.title}</p>
                      {project.nextStage.description && (
                        <p className="text-xs text-muted-foreground mt-1">{project.nextStage.description}</p>
                      )}
                      {project.pendingTasks > 0 && (
                        <p className="text-xs text-amber-400 mt-2 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {project.pendingTasks} tarefa{project.pendingTasks > 1 ? 's' : ''} pendente{project.pendingTasks > 1 ? 's' : ''}
                        </p>
                      )}
                    </div>
                  )}

                  {/* Milestones */}
                  {project.milestones && project.milestones.length > 0 && (
                    <div>
                      <h5 className="text-sm font-semibold mb-3 flex items-center gap-2">
                        <Milestone className="w-4 h-4 text-purple-400" />
                        Marcos do Projeto
                      </h5>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {project.milestones.map((ms: any) => (
                          <div key={ms.id} className={cn(
                            "flex items-center gap-3 p-3 rounded-lg border",
                            ms.status === 'completed' ? "bg-emerald-500/5 border-emerald-500/20" : "bg-muted/10 border-border/50"
                          )}>
                            {ms.status === 'completed' ? (
                              <CircleCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                            ) : (
                              <CircleDot className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                            )}
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium truncate">{ms.title}</p>
                              {ms.dueDate && (
                                <p className="text-[10px] text-muted-foreground">
                                  {new Date(ms.dueDate).toLocaleDateString('pt-BR')}
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Link to full workspace */}
                  <div className="pt-2">
                    <Link href={`/workspace?project=${project.id}`}>
                      <Button variant="outline" size="sm" className="text-xs">
                        <ExternalLink className="w-3.5 h-3.5 mr-1.5" />
                        Abrir Workspace Completo
                      </Button>
                    </Link>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Recent Activity */}
      {summary.recentActivity.length > 0 && (
        <div className="bg-card/50 border border-border/50 rounded-xl p-5">
          <h3 className="font-semibold flex items-center gap-2 mb-4">
            <History className="w-4 h-4 text-muted-foreground" />
            Atividade Recente
          </h3>
          <div className="space-y-2">
            {summary.recentActivity.slice(0, 8).map((activity: any, i: number) => {
              const activityConfig: Record<string, { icon: React.ReactNode; color: string }> = {
                stage_completed: { icon: <CircleCheck className="w-3.5 h-3.5" />, color: "text-emerald-400" },
                task_completed: { icon: <Target className="w-3.5 h-3.5" />, color: "text-blue-400" },
                deliverable_approved: { icon: <Package className="w-3.5 h-3.5" />, color: "text-cyan-400" },
                deliverable_uploaded: { icon: <Download className="w-3.5 h-3.5" />, color: "text-amber-400" },
                document_added: { icon: <FileText className="w-3.5 h-3.5" />, color: "text-purple-400" },
              };
              const config = activityConfig[activity.type] || { icon: <CircleDot className="w-3.5 h-3.5" />, color: "text-muted-foreground" };
              return (
                <div key={i} className="flex items-center gap-3 py-2">
                  <div className={cn("flex-shrink-0", config.color)}>
                    {config.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs">
                      <span className="font-medium">{activity.title}</span>
                      <span className="text-muted-foreground"> — {activity.projectName}</span>
                    </p>
                  </div>
                  <span className="text-[10px] text-muted-foreground flex-shrink-0">
                    {new Date(activity.date).toLocaleDateString('pt-BR')}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ===== STAT CARD COMPONENT =====
function StatCard({ icon, value, label, color }: { icon: React.ReactNode; value: string | number; label: string; color: string }) {
  return (
    <div className="bg-card/50 border border-border/50 rounded-xl p-4 text-center">
      <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center mx-auto mb-2", color, "bg-current/10")} style={{ backgroundColor: 'color-mix(in srgb, currentColor 10%, transparent)' }}>
        {icon}
      </div>
      <p className={cn("text-xl font-bold", color)}>{value}</p>
      <p className="text-[10px] text-muted-foreground mt-0.5">{label}</p>
    </div>
  );
}
