import { useState, useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useParams, useLocation } from "wouter";
import { Send, MessageSquare, ArrowLeft, Search } from "lucide-react";

export default function Mensagens() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const params = useParams<{ recipientId?: string }>();
  const recipientId = params.recipientId ? parseInt(params.recipientId) : null;

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Acesso Restrito</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Faça login para acessar suas mensagens.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (recipientId) {
    return <Conversation recipientId={recipientId} />;
  }

  return <ConversationList />;
}

function ConversationList() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const { data: conversations, isLoading } = trpc.dm.getConversations.useQuery();
  const { data: unreadCount } = trpc.dm.unreadCount.useQuery();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-8">
        <div className="container max-w-2xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-muted rounded w-1/3" />
            <div className="h-16 bg-muted rounded-lg" />
            <div className="h-16 bg-muted rounded-lg" />
            <div className="h-16 bg-muted rounded-lg" />
          </div>
        </div>
      </div>
    );
  }

  const filteredConversations = conversations?.filter(
    (conv) => conv.name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="container max-w-2xl">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-3xl font-bold">Mensagens</h1>
            {unreadCount && unreadCount > 0 && (
              <Badge variant="destructive">{unreadCount} não lidas</Badge>
            )}
          </div>
          <p className="text-muted-foreground">
            Converse com outros membros da comunidade
          </p>
        </div>

        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar conversas..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="space-y-2">
          {filteredConversations?.map((conv) => (
            <Card 
              key={conv.id} 
              className="cursor-pointer hover:bg-muted/50 transition-colors"
              onClick={() => navigate(`/mensagens/${conv.id}`)}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <Avatar>
                    <AvatarImage src={conv.avatarUrl || undefined} />
                    <AvatarFallback>
                      {conv.name?.charAt(0).toUpperCase() || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="font-medium">{conv.name || "Usuário"}</div>
                    <div className="text-sm text-muted-foreground">
                      {conv.company || "Membro da comunidade"}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {(!filteredConversations || filteredConversations.length === 0) && (
            <Card className="text-center py-12">
              <CardContent>
                <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhuma conversa</h3>
                <p className="text-muted-foreground">
                  Você ainda não iniciou nenhuma conversa. Visite a comunidade para conhecer outros membros!
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

function Conversation({ recipientId }: { recipientId: number }) {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [newMessage, setNewMessage] = useState("");

  const { data: messages, isLoading } = trpc.dm.getMessages.useQuery(
    { otherUserId: recipientId },
    { refetchInterval: 5000 } // Poll every 5 seconds
  );

  const sendMessage = trpc.dm.send.useMutation({
    onSuccess: () => {
      setNewMessage("");
      utils.dm.getMessages.invalidate({ otherUserId: recipientId });
    },
  });

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!newMessage.trim()) return;
    sendMessage.mutate({ receiverId: recipientId, message: newMessage });
  };

  // Get recipient info from first message
  const recipientName = messages?.[0]?.senderId === recipientId 
    ? "Usuário" 
    : messages?.[0]?.receiverId === recipientId 
    ? "Usuário" 
    : "Usuário";

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-8">
        <div className="container max-w-2xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-muted rounded w-1/3" />
            <div className="h-96 bg-muted rounded-lg" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="border-b p-4">
        <div className="container max-w-2xl">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/mensagens")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <Avatar>
              <AvatarFallback>U</AvatarFallback>
            </Avatar>
            <div>
              <div className="font-medium">{recipientName}</div>
              <div className="text-sm text-muted-foreground">Membro da comunidade</div>
            </div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="container max-w-2xl space-y-4">
          {messages?.map((msg) => (
            <div 
              key={msg.id} 
              className={`flex ${msg.senderId === user?.id ? "justify-end" : "justify-start"}`}
            >
              <div className={`max-w-[70%] p-3 rounded-lg ${
                msg.senderId === user?.id 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-muted"
              }`}>
                <div className="text-sm whitespace-pre-wrap">{msg.message}</div>
                <div className="text-xs opacity-70 mt-1">
                  {new Date(msg.createdAt).toLocaleTimeString("pt-BR", { 
                    hour: "2-digit", 
                    minute: "2-digit" 
                  })}
                </div>
              </div>
            </div>
          ))}
          
          {(!messages || messages.length === 0) && (
            <div className="text-center py-12 text-muted-foreground">
              Nenhuma mensagem ainda. Inicie a conversa!
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className="border-t p-4">
        <div className="container max-w-2xl">
          <div className="flex gap-2">
            <Input
              placeholder="Digite sua mensagem..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
            />
            <Button onClick={handleSend} disabled={sendMessage.isPending}>
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
