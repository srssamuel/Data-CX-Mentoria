import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO, { PAGE_SEO } from "@/components/SEO";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  Target,
  Brain,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Crown,
  TrendingUp,
  Shield,
  Star,
  Zap,
  Building2,
} from "lucide-react";

const benefits = [
  {
    icon: Crown,
    title: "Visão Estratégica",
    description: "Lidere transformação de CX com clareza e autoridade",
  },
  {
    icon: Brain,
    title: "IA para Decisão",
    description: "Use IA como ferramenta executiva, não operacional",
  },
  {
    icon: TrendingUp,
    title: "ROI Comprovado",
    description: "Conecte iniciativas de CX a resultados de negócio",
  },
  {
    icon: Shield,
    title: "Governança Executiva",
    description: "Estruture accountability e cadência de alta gestão",
  },
];

const formats = [
  {
    name: "Executive Briefing",
    duration: "2 sessões",
    description: "Imersão rápida para executivos que precisam de clareza imediata",
    price: "R$ 3.500",
    features: [
      "2 sessões de 2h cada",
      "Diagnóstico executivo",
      "Plano de ação priorizado",
      "Material de referência",
    ],
  },
  {
    name: "Mentoria Executive 1:1",
    duration: "90 dias",
    description: "Acompanhamento estratégico para transformação sustentável",
    price: "R$ 12.000",
    features: [
      "12 sessões individuais",
      "Acesso direto ao mentor",
      "Suporte a decisões críticas",
      "Revisão de apresentações",
      "Preparação para boards",
    ],
    highlight: true,
  },
];

const testimonials = [
  {
    name: "Carlos Mendes",
    role: "VP de Operações",
    company: "Fintech",
    content: "Samuel me ajudou a estruturar a estratégia de CX para o board. Conseguimos aprovar o budget de transformação.",
  },
  {
    name: "Ana Beatriz",
    role: "Diretora de CX",
    company: "Telecom",
    content: "A clareza de método fez toda diferença. Hoje lidero a área com confiança e resultados mensuráveis.",
  },
];

export default function MentoriaExecutivos() {
  return (
    <div className="min-h-screen bg-background">
      <SEO title={PAGE_SEO.mentoriaExecutivos.title} description={PAGE_SEO.mentoriaExecutivos.description} path="/mentoria-executivos" />
      <Navbar />

      {/* Hero Section */}
      <section className="pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="absolute inset-0 bg-radial" />

        <div className="container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-500/10 text-purple-400 text-sm font-medium mb-6">
              <Crown className="w-4 h-4" />
              Para Executivos e Alta Gestão
            </div>

            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Lidere a transformação.{" "}
              <span className="gradient-text">Com método.</span>
            </h1>

            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Você precisa liderar CX, Dados e IA na sua organização.
              Ganhe clareza estratégica e ferramentas para tomar decisões com confiança.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contato">
                <Button size="lg" className="bg-primary hover:bg-primary/90 px-8">
                  <Sparkles className="w-5 h-5 mr-2" />
                  Agendar Conversa Executiva
                </Button>
              </Link>
              <Link href="/radar">
                <Button size="lg" variant="outline" className="px-8">
                  Fazer Diagnóstico
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Os desafios da alta gestão
              </h2>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-6">
              {[
                "Pressão por resultados de CX sem clareza de como medir",
                "IA é pauta obrigatória mas falta entendimento prático",
                "Dificuldade em priorizar entre tantas iniciativas",
                "Times entregam relatórios mas não resultado",
                "Board cobra transformação digital sem roadmap claro",
                "Falta de tempo para se aprofundar nos temas",
              ].map((problem, idx) => (
                <Card key={idx} className="bg-red-500/5 border-red-500/20">
                  <CardContent className="p-4 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-red-500/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-red-400 text-sm">✗</span>
                    </div>
                    <p className="text-muted-foreground">{problem}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              O que você ganha
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
              >
                <Card className="h-full bg-card/50 border-border/50 hover:border-primary/50 transition-all">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                      <benefit.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="font-semibold mb-2">{benefit.title}</h3>
                    <p className="text-sm text-muted-foreground">{benefit.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Formats Section */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">Formatos para Executivos</h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {formats.map((format, idx) => (
              <Card
                key={idx}
                className={format.highlight
                  ? "bg-gradient-to-br from-primary/10 to-accent/10 border-primary/30"
                  : "bg-card/50 border-border/50"
                }
              >
                <CardContent className="p-8">
                  {format.highlight && (
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/20 text-primary text-sm font-medium mb-4">
                      <Zap className="w-4 h-4" />
                      Mais Popular
                    </div>
                  )}
                  <h3 className="text-2xl font-bold mb-2">{format.name}</h3>
                  <p className="text-muted-foreground text-sm mb-4">{format.duration}</p>
                  <p className="text-muted-foreground mb-6">{format.description}</p>
                  
                  <div className="mb-6">
                    <span className="text-3xl font-bold">{format.price}</span>
                  </div>

                  <div className="space-y-3 mb-8">
                    {format.features.map((feature, fidx) => (
                      <div key={fidx} className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <Link href="/contato">
                    <Button
                      className={`w-full ${format.highlight ? "bg-primary hover:bg-primary/90" : ""}`}
                      variant={format.highlight ? "default" : "outline"}
                    >
                      Agendar Conversa
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">
            Executivos que lideram com método
          </h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {testimonials.map((testimonial, idx) => (
              <Card key={idx} className="bg-card/50 border-border/50">
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4">"{testimonial.content}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-primary font-semibold">{testimonial.name[0]}</span>
                    </div>
                    <div>
                      <p className="font-medium text-sm">{testimonial.name}</p>
                      <p className="text-xs text-muted-foreground">{testimonial.role} • {testimonial.company}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <Building2 className="w-16 h-16 text-primary mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Precisa de algo para sua empresa?
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              Conheça o Diagnóstico Vértice e a Assessoria para empresas que buscam
              transformação estruturada com acompanhamento contínuo.
            </p>
            <Link href="/empresas">
              <Button size="lg" variant="outline" className="px-8">
                Ver Soluções para Empresas
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
