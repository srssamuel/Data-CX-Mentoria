import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO, { PAGE_SEO } from "@/components/SEO";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  Target,
  TrendingUp,
  Brain,
  Users,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  BarChart3,
  Shield,
  Star,
  Clock,
  Zap,
} from "lucide-react";

const benefits = [
  {
    icon: BarChart3,
    title: "Decisão por Dados",
    description: "Transforme métricas em argumentos que convencem stakeholders",
  },
  {
    icon: Brain,
    title: "IA na Rotina",
    description: "Use IA para automatizar análises e ganhar produtividade",
  },
  {
    icon: Shield,
    title: "Governança de CX",
    description: "Estruture rituais e processos que sustentam evolução",
  },
  {
    icon: Users,
    title: "Liderança Técnica",
    description: "Lidere times com clareza de método e priorização",
  },
];

const modules = [
  "Diagnóstico de Jornada: mapeamento e priorização de atritos",
  "Métricas de CX: NPS, CSAT, CES e indicadores de negócio",
  "Análise de Dados: segmentação, coortes e drivers",
  "IA para Gestores: automação de análises e relatórios",
  "Governança: rituais, cadência e accountability",
  "Comunicação Executiva: storytelling com dados",
  "Gestão de Backlog: impacto × esforço × risco",
  "Plano 30/60/90: implementação estruturada",
];

const testimonials = [
  {
    name: "Rodrigo Almeida",
    role: "Gerente de CX",
    company: "Banco Digital",
    content: "Consegui estruturar toda a área de CX em 90 dias. O método é prático e direto ao ponto.",
  },
  {
    name: "Patrícia Santos",
    role: "Coordenadora de Dados",
    company: "Varejo",
    content: "Aprendi a traduzir dados em ação. Minha equipe agora entrega resultado, não só relatório.",
  },
];

export default function MentoriaGestores() {
  return (
    <div className="min-h-screen bg-background">
      <SEO title={PAGE_SEO.mentoriaGestores.title} description={PAGE_SEO.mentoriaGestores.description} path="/mentoria-gestores" />
      <Navbar />

      {/* Hero Section */}
      <section className="pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="absolute inset-0 bg-radial" />

        <div className="container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/10 text-green-400 text-sm font-medium mb-6">
              <Target className="w-4 h-4" />
              Para Gestores e Coordenadores
            </div>

            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Pare de apagar incêndio.{" "}
              <span className="gradient-text">Comece a liderar.</span>
            </h1>

            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Você já gere pessoas e rotina. Agora precisa de método para aplicar CX, Dados e IA
              no dia a dia e entregar resultado consistente.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/radar">
                <Button size="lg" className="bg-primary hover:bg-primary/90 px-8">
                  <Sparkles className="w-5 h-5 mr-2" />
                  Fazer Diagnóstico Gratuito
                </Button>
              </Link>
              <Link href="/contato">
                <Button size="lg" variant="outline" className="px-8">
                  Agendar Conversa
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Você se reconhece?
              </h2>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-6">
              {[
                "Vive apagando incêndio e não consegue estruturar a área",
                "Tem dados mas não sabe transformar em ação",
                "Dificuldade em priorizar: tudo parece urgente",
                "Stakeholders cobram resultado mas não dão recursos",
                "Equipe executa tarefas mas não entrega valor",
                "Não consegue provar ROI das iniciativas de CX",
              ].map((problem, idx) => (
                <Card key={idx} className="bg-red-500/5 border-red-500/20">
                  <CardContent className="p-4 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-red-500/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-red-400 text-sm">✗</span>
                    </div>
                    <p className="text-muted-foreground">{problem}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="py-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              A Mentoria Vértice para <span className="gradient-text">Gestores</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              8 semanas para estruturar sua área e entregar resultado com método
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {benefits.map((benefit, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
              >
                <Card className="h-full bg-card/50 border-border/50 hover:border-primary/50 transition-all">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                      <benefit.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="font-semibold mb-2">{benefit.title}</h3>
                    <p className="text-sm text-muted-foreground">{benefit.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Modules */}
          <div className="max-w-3xl mx-auto">
            <h3 className="text-2xl font-bold mb-8 text-center">O que você vai dominar</h3>
            <div className="grid md:grid-cols-2 gap-4">
              {modules.map((module, idx) => (
                <div key={idx} className="flex items-center gap-3 p-4 rounded-lg bg-card/50 border border-border/50">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
                  <span className="text-sm">{module}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">
            Gestores que transformaram suas áreas
          </h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {testimonials.map((testimonial, idx) => (
              <Card key={idx} className="bg-card/50 border-border/50">
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4">"{testimonial.content}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-primary font-semibold">{testimonial.name[0]}</span>
                    </div>
                    <div>
                      <p className="font-medium text-sm">{testimonial.name}</p>
                      <p className="text-xs text-muted-foreground">{testimonial.role} • {testimonial.company}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Options */}
      <section className="py-20">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">Escolha seu formato</h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Group */}
            <Card className="bg-card/50 border-border/50">
              <CardContent className="p-8">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
                  <Users className="w-4 h-4" />
                  Em Grupo
                </div>
                <h3 className="text-2xl font-bold mb-2">Mentoria Vértice</h3>
                <p className="text-muted-foreground mb-6">8 semanas • Grupo de até 12 gestores</p>
                
                <div className="mb-6">
                  <span className="text-4xl font-bold">R$ 2.997</span>
                  <span className="text-muted-foreground"> ou 12x R$ 297</span>
                </div>

                <div className="space-y-3 mb-8">
                  {[
                    "8 encontros ao vivo (2h)",
                    "Playbooks e templates",
                    "Comunidade de gestores",
                    "Certificado",
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                      <span className="text-sm">{item}</span>
                    </div>
                  ))}
                </div>

                <Link href="/radar">
                  <Button className="w-full" variant="outline">
                    Começar pelo Diagnóstico
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Individual */}
            <Card className="bg-gradient-to-br from-primary/10 to-accent/10 border-primary/30">
              <CardContent className="p-8">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/20 text-primary text-sm font-medium mb-4">
                  <Zap className="w-4 h-4" />
                  Individual
                </div>
                <h3 className="text-2xl font-bold mb-2">Mentoria 1:1</h3>
                <p className="text-muted-foreground mb-6">90 dias • Acompanhamento personalizado</p>
                
                <div className="mb-6">
                  <span className="text-4xl font-bold">R$ 5.997</span>
                  <span className="text-muted-foreground"> ou 12x R$ 597</span>
                </div>

                <div className="space-y-3 mb-8">
                  {[
                    "12 sessões individuais (1h)",
                    "Diagnóstico personalizado",
                    "Acesso direto via WhatsApp",
                    "Plano 30/60/90 customizado",
                    "Tudo do grupo incluído",
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                      <span className="text-sm">{item}</span>
                    </div>
                  ))}
                </div>

                <Link href="/contato">
                  <Button size="lg" className="w-full bg-primary hover:bg-primary/90">
                    Agendar Conversa
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Descubra seu nível de maturidade
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              O Radar Vértice vai mostrar onde você está e qual o próximo passo.
              Gratuito e em 5 minutos.
            </p>
            <Link href="/radar">
              <Button size="lg" className="bg-primary hover:bg-primary/90 px-8">
                <Sparkles className="w-5 h-5 mr-2" />
                Fazer Diagnóstico Gratuito
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
