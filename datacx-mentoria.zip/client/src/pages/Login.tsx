import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLocation, useSearch } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO, { PAGE_SEO } from "@/components/SEO";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  Lock,
  ArrowRight,
  Shield,
  Sparkles,
  BookOpen,
  Video,
  FileText,
  CheckCircle2,
  Loader2,
  Eye,
  EyeOff,
  Mail,
  User,
  ArrowLeft,
} from "lucide-react";

type AuthMode = "login" | "register" | "forgot-password";

export default function Login() {
  const { isAuthenticated, loading, refresh } = useAuth();
  const [, setLocation] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);
  const initialMode = params.get("mode") === "register" ? "register" : "login";

  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    phone: "",
    company: "",
    position: "",
  });

  const loginMutation = trpc.auth.login.useMutation({
    onSuccess: async () => {
      toast.success("Login realizado com sucesso!");
      await refresh();
      setLocation("/membros");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const registerMutation = trpc.auth.register.useMutation({
    onSuccess: async () => {
      toast.success("Conta criada com sucesso! Bem-vindo(a)!");
      await refresh();
      setLocation("/membros");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const resetMutation = trpc.auth.requestPasswordReset.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      setMode("login");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  // Redirect to members area if already authenticated
  useEffect(() => {
    if (isAuthenticated && !loading) {
      setLocation("/membros");
    }
  }, [isAuthenticated, loading, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-32 pb-20 flex items-center justify-center min-h-[80vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
        <Footer />
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (mode === "login") {
      loginMutation.mutate({
        email: formData.email,
        password: formData.password,
      });
    } else if (mode === "register") {
      if (formData.password !== formData.confirmPassword) {
        toast.error("As senhas não coincidem");
        return;
      }
      if (formData.password.length < 6) {
        toast.error("A senha deve ter pelo menos 6 caracteres");
        return;
      }
      registerMutation.mutate({
        name: formData.name,
        email: formData.email,
        password: formData.password,
        phone: formData.phone || undefined,
        company: formData.company || undefined,
        position: formData.position || undefined,
      });
    } else if (mode === "forgot-password") {
      resetMutation.mutate({
        email: formData.email,
        origin: window.location.origin,
      });
    }
  };

  const isSubmitting =
    loginMutation.isPending ||
    registerMutation.isPending ||
    resetMutation.isPending;

  const benefits = [
    {
      icon: BookOpen,
      title: "Playbooks Exclusivos",
      description: "Acesse playbooks completos de CX, Dados e IA",
    },
    {
      icon: Video,
      title: "Conteúdos em Vídeo",
      description: "Aulas gravadas e materiais complementares",
    },
    {
      icon: FileText,
      title: "Templates Prontos",
      description: "Frameworks e templates para aplicar na prática",
    },
    {
      icon: Sparkles,
      title: "Assistente IA",
      description: "Tire dúvidas com nosso mentor virtual 24/7",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <SEO title={PAGE_SEO.login.title} description={PAGE_SEO.login.description} path="/login" noindex />
      <Navbar />

      <section className="pt-32 pb-20 min-h-[80vh]">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Side - Auth Card */}
            <div className="order-2 lg:order-1">
              <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
                <CardContent className="p-8 md:p-10">
                  {/* Header */}
                  <div className="text-center mb-8">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mx-auto mb-5">
                      {mode === "register" ? (
                        <User className="w-8 h-8 text-primary" />
                      ) : mode === "forgot-password" ? (
                        <Mail className="w-8 h-8 text-primary" />
                      ) : (
                        <Lock className="w-8 h-8 text-primary" />
                      )}
                    </div>
                    <h1 className="text-2xl font-bold mb-2">
                      {mode === "login" && (
                        <>
                          Área de <span className="gradient-text">Membros</span>
                        </>
                      )}
                      {mode === "register" && (
                        <>
                          Criar <span className="gradient-text">Conta</span>
                        </>
                      )}
                      {mode === "forgot-password" && (
                        <>
                          Recuperar <span className="gradient-text">Senha</span>
                        </>
                      )}
                    </h1>
                    <p className="text-sm text-muted-foreground">
                      {mode === "login" &&
                        "Faça login para acessar seus materiais exclusivos"}
                      {mode === "register" &&
                        "Preencha seus dados para criar sua conta"}
                      {mode === "forgot-password" &&
                        "Informe seu e-mail para receber o link de recuperação"}
                    </p>
                  </div>

                  {/* Form */}
                  <form onSubmit={handleSubmit} className="space-y-4">
                    {/* Name - only for register */}
                    {mode === "register" && (
                      <div className="space-y-2">
                        <Label htmlFor="name">Nome completo</Label>
                        <Input
                          id="name"
                          type="text"
                          placeholder="Seu nome completo"
                          value={formData.name}
                          onChange={(e) =>
                            setFormData({ ...formData, name: e.target.value })
                          }
                          required
                          className="h-11 bg-background/50"
                        />
                      </div>
                    )}

                    {/* Email */}
                    <div className="space-y-2">
                      <Label htmlFor="email">E-mail</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="seu@email.com"
                        value={formData.email}
                        onChange={(e) =>
                          setFormData({ ...formData, email: e.target.value })
                        }
                        required
                        className="h-11 bg-background/50"
                      />
                    </div>

                    {/* Password - not for forgot-password */}
                    {mode !== "forgot-password" && (
                      <div className="space-y-2">
                        <Label htmlFor="password">Senha</Label>
                        <div className="relative">
                          <Input
                            id="password"
                            type={showPassword ? "text" : "password"}
                            placeholder={
                              mode === "register"
                                ? "Mínimo 6 caracteres"
                                : "Sua senha"
                            }
                            value={formData.password}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                password: e.target.value,
                              })
                            }
                            required
                            className="h-11 bg-background/50 pr-10"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                          >
                            {showPassword ? (
                              <EyeOff className="w-4 h-4" />
                            ) : (
                              <Eye className="w-4 h-4" />
                            )}
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Confirm Password - only for register */}
                    {mode === "register" && (
                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword">Confirmar senha</Label>
                        <Input
                          id="confirmPassword"
                          type={showPassword ? "text" : "password"}
                          placeholder="Repita a senha"
                          value={formData.confirmPassword}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              confirmPassword: e.target.value,
                            })
                          }
                          required
                          className="h-11 bg-background/50"
                        />
                      </div>
                    )}

                    {/* Extra fields for register */}
                    {mode === "register" && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="phone">
                            Telefone{" "}
                            <span className="text-muted-foreground text-xs">
                              (opcional)
                            </span>
                          </Label>
                          <Input
                            id="phone"
                            type="tel"
                            placeholder="(84) 99999-9999"
                            value={formData.phone}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                phone: e.target.value,
                              })
                            }
                            className="h-11 bg-background/50"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="company">
                            Empresa{" "}
                            <span className="text-muted-foreground text-xs">
                              (opcional)
                            </span>
                          </Label>
                          <Input
                            id="company"
                            type="text"
                            placeholder="Sua empresa"
                            value={formData.company}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                company: e.target.value,
                              })
                            }
                            className="h-11 bg-background/50"
                          />
                        </div>
                      </div>
                    )}

                    {/* Forgot password link */}
                    {mode === "login" && (
                      <div className="text-right">
                        <button
                          type="button"
                          onClick={() => setMode("forgot-password")}
                          className="text-sm text-primary hover:text-primary/80 transition-colors"
                        >
                          Esqueceu a senha?
                        </button>
                      </div>
                    )}

                    {/* Submit button */}
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-primary hover:bg-primary/90 h-12 text-base font-medium"
                    >
                      {isSubmitting ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <>
                          {mode === "login" && "Entrar"}
                          {mode === "register" && "Criar Conta"}
                          {mode === "forgot-password" && "Enviar Link"}
                          <ArrowRight className="w-5 h-5 ml-2" />
                        </>
                      )}
                    </Button>
                  </form>

                  {/* Footer links */}
                  <div className="mt-6 pt-6 border-t border-border/50 space-y-3">
                    {mode === "login" && (
                      <>
                        <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                          <Shield className="w-4 h-4 text-primary" />
                          <span>Login seguro com criptografia</span>
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-muted-foreground">
                            Ainda não tem conta?{" "}
                            <button
                              type="button"
                              onClick={() => setMode("register")}
                              className="text-primary hover:text-primary/80 font-medium transition-colors"
                            >
                              Criar conta gratuita
                            </button>
                          </p>
                        </div>
                      </>
                    )}
                    {mode === "register" && (
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground">
                          Já tem uma conta?{" "}
                          <button
                            type="button"
                            onClick={() => setMode("login")}
                            className="text-primary hover:text-primary/80 font-medium transition-colors"
                          >
                            Fazer login
                          </button>
                        </p>
                      </div>
                    )}
                    {mode === "forgot-password" && (
                      <div className="text-center">
                        <button
                          type="button"
                          onClick={() => setMode("login")}
                          className="text-sm text-primary hover:text-primary/80 font-medium transition-colors inline-flex items-center gap-1"
                        >
                          <ArrowLeft className="w-4 h-4" />
                          Voltar ao login
                        </button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Side - Benefits */}
            <div className="order-1 lg:order-2">
              <div className="mb-8">
                <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
                  <Sparkles className="w-4 h-4" />
                  Protocolo Vértice
                </span>
                <h2 className="text-4xl md:text-5xl font-bold mb-4">
                  Acesse Conteúdos
                  <br />
                  <span className="gradient-text">Exclusivos</span>
                </h2>
                <p className="text-lg text-muted-foreground">
                  Como membro, você tem acesso a materiais premium desenvolvidos
                  por Samuel Rosa para acelerar sua jornada em CX, Dados e IA.
                </p>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                {benefits.map((benefit, index) => (
                  <div
                    key={index}
                    className="p-4 rounded-xl bg-card/30 border border-border/50 hover:border-primary/30 transition-all"
                  >
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-3">
                      <benefit.icon className="w-5 h-5 text-primary" />
                    </div>
                    <h3 className="font-semibold mb-1">{benefit.title}</h3>
                    <p className="text-sm text-muted-foreground">
                      {benefit.description}
                    </p>
                  </div>
                ))}
              </div>

              <div className="mt-8 p-4 rounded-xl bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary mt-0.5" />
                  <div>
                    <p className="font-medium">Acesso Imediato</p>
                    <p className="text-sm text-muted-foreground">
                      Após a compra, seus materiais são liberados
                      automaticamente na área de membros.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
