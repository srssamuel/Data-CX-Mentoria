import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useLocation, useParams } from "wouter";
import { 
  Briefcase, 
  CheckCircle2, 
  Clock, 
  FileText, 
  ListTodo, 
  MessageSquare, 
  Plus, 
  Users,
  Calendar,
  Upload,
  Send,
  Target,
  ArrowLeft,
  Lock,
  Play,
  Eye,
  Download,
  ChevronDown,
  ChevronUp,
  Paperclip,
  Video,
  ExternalLink,
  Milestone
} from "lucide-react";
import { Streamdown } from "streamdown";
import JornadaManager from "@/components/JornadaManager";

export default function Workspace() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const params = useParams<{ projectId?: string }>();
  const projectId = params.projectId ? parseInt(params.projectId) : null;

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Acesso Restrito</CardTitle>
            <CardDescription>Faça login para acessar seu workspace de consultoria.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  if (projectId) {
    return <ProjectDetail projectId={projectId} />;
  }

  return <ProjectList />;
}

function ProjectList() {
  const { data: projects, isLoading } = trpc.consulting.listProjects.useQuery();
  const [, navigate] = useLocation();

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      planning: "bg-blue-500/20 text-blue-400",
      discovery: "bg-purple-500/20 text-purple-400",
      execution: "bg-yellow-500/20 text-yellow-400",
      review: "bg-orange-500/20 text-orange-400",
      completed: "bg-green-500/20 text-green-400",
      on_hold: "bg-gray-500/20 text-gray-400",
    };
    return colors[status] || "bg-gray-500/20 text-gray-400";
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      planning: "Planejamento",
      discovery: "Descoberta",
      execution: "Execução",
      review: "Revisão",
      completed: "Concluído",
      on_hold: "Pausado",
    };
    return labels[status] || status;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-8">
        <div className="container max-w-6xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-muted rounded w-1/3" />
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-48 bg-muted rounded-lg" />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="container max-w-6xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Workspace de Consultoria</h1>
          <p className="text-muted-foreground">
            Acompanhe o progresso dos seus projetos de consultoria
          </p>
        </div>

        {!projects || projects.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <Briefcase className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhum projeto encontrado</h3>
              <p className="text-muted-foreground">
                Você ainda não possui projetos de consultoria ativos.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {projects.map((project) => (
              <Card 
                key={project.id} 
                className="cursor-pointer hover:border-primary/50 transition-colors"
                onClick={() => navigate(`/workspace/${project.id}`)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{project.name}</CardTitle>
                      <CardDescription className="mt-1">
                        {project.type === "diagnostic" && "Diagnóstico"}
                        {project.type === "consulting" && "Consultoria"}
                        {project.type === "advisory_6m" && "Advisory 6 meses"}
                        {project.type === "advisory_12m" && "Advisory 12 meses"}
                      </CardDescription>
                    </div>
                    <Badge className={getStatusColor(project.status)}>
                      {getStatusLabel(project.status)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-muted-foreground">Progresso</span>
                        <span className="font-medium">{project.progress}%</span>
                      </div>
                      <Progress value={project.progress} className="h-2" />
                    </div>
                    
                    {project.currentPhase && (
                      <div className="flex items-center gap-2 text-sm">
                        <Target className="h-4 w-4 text-primary" />
                        <span className="text-muted-foreground">Fase atual:</span>
                        <span>{project.currentPhase}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ProjectDetail({ projectId }: { projectId: number }) {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const utils = trpc.useUtils();
  
  const { data: project, isLoading: projectLoading } = trpc.consulting.getProject.useQuery({ id: projectId });
  const { data: tasks } = trpc.consulting.getTasks.useQuery({ projectId });
  const { data: documents } = trpc.consulting.getDocuments.useQuery({ projectId });
  const { data: meetings } = trpc.consulting.getMeetings.useQuery({ projectId });
  const { data: chatMessages } = trpc.consulting.getChatMessages.useQuery({ projectId });
  const { data: milestones } = trpc.consulting.getMilestones.useQuery({ projectId });
  const { data: stages } = trpc.consulting.getStages.useQuery({ projectId });

  const createTask = trpc.consulting.createTask.useMutation({
    onSuccess: () => utils.consulting.getTasks.invalidate({ projectId }),
  });
  const updateTask = trpc.consulting.updateTask.useMutation({
    onSuccess: () => utils.consulting.getTasks.invalidate({ projectId }),
  });
  const sendMessage = trpc.consulting.sendChatMessage.useMutation({
    onSuccess: () => utils.consulting.getChatMessages.invalidate({ projectId }),
  });

  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newMessage, setNewMessage] = useState("");
  const [activeTab, setActiveTab] = useState("jornada");

  if (projectLoading) {
    return (
      <div className="min-h-screen bg-background p-8">
        <div className="container max-w-6xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-muted rounded w-1/3" />
            <div className="h-64 bg-muted rounded-lg" />
          </div>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-background p-8">
        <div className="container max-w-6xl">
          <Card className="text-center py-12">
            <CardContent>
              <h3 className="text-lg font-semibold mb-2">Projeto não encontrado</h3>
              <Button onClick={() => navigate("/workspace")}>Voltar</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const handleCreateTask = () => {
    if (!newTaskTitle.trim()) return;
    createTask.mutate({ projectId, title: newTaskTitle });
    setNewTaskTitle("");
  };

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    sendMessage.mutate({ projectId, message: newMessage });
    setNewMessage("");
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      backlog: "bg-gray-500/20 text-gray-400",
      todo: "bg-blue-500/20 text-blue-400",
      in_progress: "bg-yellow-500/20 text-yellow-400",
      review: "bg-purple-500/20 text-purple-400",
      done: "bg-green-500/20 text-green-400",
    };
    return colors[status] || "bg-gray-500/20 text-gray-400";
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="container max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" onClick={() => navigate("/workspace")} className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar aos projetos
          </Button>
          
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">{project.name}</h1>
              <p className="text-muted-foreground">{project.description}</p>
            </div>
            <div className="text-right">
              <div className="text-sm text-muted-foreground mb-1">Progresso geral</div>
              <div className="text-2xl font-bold text-primary">{project.progress}%</div>
            </div>
          </div>
          
          <Progress value={project.progress} className="h-3 mt-4" />
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="jornada">Jornada</TabsTrigger>
            <TabsTrigger value="overview">Visão Geral</TabsTrigger>
            <TabsTrigger value="tasks">Tarefas</TabsTrigger>
            <TabsTrigger value="documents">Documentos</TabsTrigger>
            <TabsTrigger value="meetings">Reuniões</TabsTrigger>
            <TabsTrigger value="chat">Chat</TabsTrigger>
          </TabsList>

          {/* Jornada Tab */}
          <TabsContent value="jornada">
            <JornadaManager projectId={projectId} stages={stages || []} isAdmin={user?.role === 'admin'} />
          </TabsContent>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid gap-6 md:grid-cols-2">
              {/* Milestones */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    Marcos do Projeto
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {milestones && milestones.length > 0 ? (
                    <div className="space-y-4">
                      {milestones.map((milestone, index) => (
                        <div key={milestone.id} className="flex items-start gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            milestone.status === "completed" 
                              ? "bg-green-500/20 text-green-400" 
                              : milestone.status === "in_progress"
                              ? "bg-yellow-500/20 text-yellow-400"
                              : "bg-muted text-muted-foreground"
                          }`}>
                            {milestone.status === "completed" ? (
                              <CheckCircle2 className="h-4 w-4" />
                            ) : (
                              <span>{index + 1}</span>
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="font-medium">{milestone.title}</div>
                            {milestone.description && (
                              <div className="text-sm text-muted-foreground">{milestone.description}</div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground text-center py-4">
                      Nenhum marco definido ainda
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    Atividade Recente
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {tasks?.slice(0, 5).map((task) => (
                      <div key={task.id} className="flex items-center gap-3">
                        <ListTodo className="h-4 w-4 text-muted-foreground" />
                        <div className="flex-1">
                          <div className="text-sm">{task.title}</div>
                          <Badge className={`${getStatusColor(task.status)} text-xs`}>
                            {task.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    {(!tasks || tasks.length === 0) && (
                      <p className="text-muted-foreground text-center py-4">
                        Nenhuma atividade recente
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Tasks Tab */}
          <TabsContent value="tasks">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Backlog de Tarefas</CardTitle>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Nova tarefa..."
                      value={newTaskTitle}
                      onChange={(e) => setNewTaskTitle(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleCreateTask()}
                      className="w-64"
                    />
                    <Button onClick={handleCreateTask} disabled={createTask.isPending}>
                      <Plus className="h-4 w-4 mr-2" />
                      Adicionar
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {tasks && tasks.length > 0 ? (
                  <div className="space-y-3">
                    {tasks.map((task) => (
                      <div 
                        key={task.id} 
                        className="flex items-center gap-4 p-3 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                      >
                        <Select
                          value={task.status}
                          onValueChange={(value) => updateTask.mutate({ 
                            id: task.id, 
                            data: { status: value as any } 
                          })}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="backlog">Backlog</SelectItem>
                            <SelectItem value="todo">A Fazer</SelectItem>
                            <SelectItem value="in_progress">Em Progresso</SelectItem>
                            <SelectItem value="review">Revisão</SelectItem>
                            <SelectItem value="done">Concluído</SelectItem>
                          </SelectContent>
                        </Select>
                        
                        <div className="flex-1">
                          <div className="font-medium">{task.title}</div>
                          {task.description && (
                            <div className="text-sm text-muted-foreground">{task.description}</div>
                          )}
                        </div>
                        
                        {task.dueDate && (
                          <div className="text-sm text-muted-foreground flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {new Date(task.dueDate).toLocaleDateString("pt-BR")}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-8">
                    Nenhuma tarefa criada ainda. Adicione sua primeira tarefa acima.
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Documents Tab */}
          <TabsContent value="documents">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Repositório de Documentos</CardTitle>
                  <Button>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {documents && documents.length > 0 ? (
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {documents.map((doc) => (
                      <Card key={doc.id} className="cursor-pointer hover:bg-muted/50">
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <FileText className="h-8 w-8 text-primary" />
                            <div>
                              <div className="font-medium">{doc.name}</div>
                              <div className="text-sm text-muted-foreground">
                                {new Date(doc.createdAt).toLocaleDateString("pt-BR")}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-8">
                    Nenhum documento enviado ainda.
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Meetings Tab */}
          <TabsContent value="meetings">
            <Card>
              <CardHeader>
                <CardTitle>Registro de Reuniões</CardTitle>
              </CardHeader>
              <CardContent>
                {meetings && meetings.length > 0 ? (
                  <div className="space-y-4">
                    {meetings.map((meeting) => (
                      <Card key={meeting.id}>
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="font-medium">{meeting.title}</div>
                              <div className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                                <Calendar className="h-4 w-4" />
                                {new Date(meeting.date).toLocaleDateString("pt-BR")}
                              </div>
                            </div>
                            <Button variant="outline" size="sm">Ver Ata</Button>
                          </div>
                          {meeting.notes && (
                            <p className="text-sm text-muted-foreground mt-3 line-clamp-2">
                              {meeting.notes}
                            </p>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-8">
                    Nenhuma reunião registrada ainda.
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Chat Tab */}
          <TabsContent value="chat">
            <Card className="h-[600px] flex flex-col">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Chat do Projeto
                </CardTitle>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col">
                <div className="flex-1 overflow-y-auto space-y-4 mb-4">
                  {chatMessages && chatMessages.length > 0 ? (
                    chatMessages.map((msg) => (
                      <div 
                        key={msg.id} 
                        className={`flex ${msg.userId === user?.id ? "justify-end" : "justify-start"}`}
                      >
                        <div className={`max-w-[70%] p-3 rounded-lg ${
                          msg.userId === user?.id 
                            ? "bg-primary text-primary-foreground" 
                            : "bg-muted"
                        }`}>
                          <div className="text-sm">{msg.message}</div>
                          <div className="text-xs opacity-70 mt-1">
                            {new Date(msg.createdAt).toLocaleTimeString("pt-BR", { 
                              hour: "2-digit", 
                              minute: "2-digit" 
                            })}
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-muted-foreground text-center py-8">
                      Nenhuma mensagem ainda. Inicie a conversa!
                    </p>
                  )}
                </div>
                
                <div className="flex gap-2">
                  <Input
                    placeholder="Digite sua mensagem..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                  />
                  <Button onClick={handleSendMessage} disabled={sendMessage.isPending}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

