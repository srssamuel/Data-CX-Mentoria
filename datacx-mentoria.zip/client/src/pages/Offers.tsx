import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import SEO, { PAGE_SEO } from "@/components/SEO";
import Footer from "@/components/Footer";
// Auth redirect uses /login route
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  Loader2,
  ArrowRight,
  CheckCircle2,
  Users,
  User,
  Search,
  Clock,
  Calendar,
  Zap,
  Star,
  Shield,
  BookOpen,
  Sparkles,
  Ticket,
  X,
  Check,
  Gift,
  ShieldCheck,
  PartyPopper,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState, useMemo } from "react";
import { trackCouponApplied, trackCouponFailed, trackCheckoutStarted, trackPageView } from "@/lib/analytics";

// NOVO: Plano Introdutório
const introductoryPlan = {
  title: "Playbook Vértice",
  subtitle: "Fundamentos de CX, Dados e IA",
  description: "Acesso imediato ao playbook completo com teoria e prática sobre CX, Dados e IA. Ideal para quem quer começar a entender os conceitos antes de investir em mentoria.",
  price: "R$ 377",
  priceNote: "Pagamento único",
  features: [
    "Playbook teórico completo (PDF)",
    "Playbook técnico com frameworks",
    "Templates e checklists prontos",
    "Guia de implementação passo a passo",
    "Acesso vitalício ao material",
    "Atualizações futuras incluídas",
  ],
  cta: "Comprar Playbook",
  badge: "Entrada",
};

const groupMentorship = {
  title: "Mentoria em Grupo",
  subtitle: "Protocolo Vértice Coletivo",
  description: "Programa de 8 semanas com encontros semanais ao vivo para aplicar o Protocolo Vértice no seu contexto, com apoio de uma comunidade de profissionais.",
  duration: "8 semanas",
  format: "Encontros semanais ao vivo",
  price: "R$ 1.497",
  priceNote: "ou 12x de R$ 147",
  features: [
    "8 encontros ao vivo de 2h cada",
    "Aplicação prática do Protocolo Vértice",
    "Comunidade exclusiva no WhatsApp",
    "Materiais e playbooks completos",
    "Certificado de conclusão",
    "Acesso às gravações por 1 ano",
    "Sessão de Q&A individual (30min)",
    "Templates e frameworks prontos",
  ],
  highlights: [
    { icon: Users, label: "Turmas de até 15 pessoas" },
    { icon: Calendar, label: "Encontros às terças, 19h" },
    { icon: Clock, label: "2h por encontro" },
  ],
  cta: "Entrar na Lista de Espera",
  popular: true,
};

const individualMentorship = {
  title: "Mentoria Individual 1:1",
  subtitle: "Acompanhamento Personalizado",
  description: "Mentoria exclusiva e personalizada para acelerar sua evolução em CX, dados e IA com acompanhamento direto do Samuel Rosa.",
  plans: [
    {
      name: "Sprint",
      duration: "4 semanas",
      sessions: "4 sessões de 1h",
      price: "R$ 1.997",
      priceNote: "ou 6x de R$ 367",
      pricePerSession: "R$ 499/sessão",
      features: [
        "4 sessões individuais de 1h",
        "Diagnóstico inicial completo",
        "Plano de ação personalizado",
        "Suporte via WhatsApp",
        "Acesso aos materiais",
      ],
      ideal: "Ideal para resolver um desafio específico",
    },
    {
      name: "90 Dias",
      duration: "12 semanas",
      sessions: "12 sessões de 1h",
      price: "R$ 4.997",
      priceNote: "ou 12x de R$ 467",
      pricePerSession: "R$ 416/sessão",
      features: [
        "12 sessões individuais de 1h",
        "Diagnóstico profundo do cenário",
        "Implementação do Protocolo Vértice",
        "Suporte prioritário via WhatsApp",
        "Acesso vitalício aos materiais",
        "2 sessões de follow-up",
      ],
      ideal: "Ideal para transformação completa",
      popular: true,
    },
    {
      name: "Executive",
      duration: "6 meses",
      sessions: "24 sessões de 1h",
      price: "R$ 9.997",
      priceNote: "ou 12x de R$ 897",
      pricePerSession: "R$ 416/sessão",
      features: [
        "24 sessões individuais de 1h",
        "Mentoria estratégica de carreira",
        "Implementação completa + escala",
        "Suporte VIP ilimitado",
        "Acesso vitalício aos materiais",
        "4 sessões de follow-up",
        "Participação em cases exclusivos",
      ],
      ideal: "Ideal para líderes e executivos",
    },
  ],
};

const diagnostic = {
  title: "Diagnóstico 360º",
  subtitle: "Raio-X da sua Operação",
  description: "Análise completa do seu cenário atual de CX, dados e IA com entrega de relatório executivo e roadmap de evolução.",
  duration: "2-3 semanas",
  format: "Análise + Entrega de Relatório",
  price: "R$ 2.997",
  priceNote: "ou 6x de R$ 547",
  features: [
    "Entrevistas com stakeholders",
    "Análise de indicadores e processos",
    "Mapeamento de jornadas críticas",
    "Avaliação de maturidade em dados/IA",
    "Relatório executivo completo",
    "Roadmap de evolução priorizado",
    "Apresentação para liderança",
    "Sessão de alinhamento (2h)",
  ],
  deliverables: [
    "Relatório de Diagnóstico (PDF)",
    "Matriz de Maturidade CX/Dados/IA",
    "Roadmap 30/60/90 dias",
    "Quick Wins identificados",
    "Recomendações priorizadas",
  ],
  cta: "Solicitar Diagnóstico",
};

export default function Offers() {
  const { isAuthenticated } = useAuth();
  const checkoutMutation = trpc.stripe.createCheckout.useMutation();
  
  // Estado do cupom
  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<{
    code: string;
    name: string;
    discountType: "percentage" | "fixed";
    discountValue: number;
    maxDiscountAmount: number | null;
    applicableProducts?: string[] | null;
  } | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);
  const [isValidatingCoupon, setIsValidatingCoupon] = useState(false);
  
  const validateCouponMutation = trpc.coupons.validate.useQuery(
    { code: couponCode },
    { enabled: false }
  );

  // Verifica se o cupom é 100% OFF
  const isFreeWithCoupon = useMemo(() => {
    if (!appliedCoupon) return false;
    return appliedCoupon.discountType === "percentage" && appliedCoupon.discountValue >= 100;
  }, [appliedCoupon]);

  const handleValidateCoupon = async () => {
    if (!couponCode.trim()) {
      setCouponError("Digite um código de cupom");
      return;
    }
    
    setIsValidatingCoupon(true);
    setCouponError(null);
    
    try {
      const result = await validateCouponMutation.refetch();
      if (result.data?.valid && result.data.coupon) {
        const coupon = result.data.coupon as any;
        setAppliedCoupon(coupon);
        trackCouponApplied(couponCode, coupon.discountType, coupon.discountValue);
        const isFull = coupon.discountType === "percentage" && coupon.discountValue >= 100;
        if (isFull) {
          toast.success("Cupom aplicado: 100% OFF! Inscrição gratuita.", { duration: 5000 });
        } else {
          const discountText = coupon.discountType === "percentage" 
            ? `${coupon.discountValue}% de desconto` 
            : `R$ ${coupon.discountValue.toFixed(2)} de desconto`;
          toast.success(`Cupom aplicado: ${discountText}`);
        }
      } else {
        const errorMsg = result.data?.error || "Cupom inválido";
        // Mensagens de erro específicas e claras
        const friendlyErrors: Record<string, string> = {
          "Cupom não encontrado": "Cupom não encontrado. Verifique se digitou corretamente.",
          "Cupom inativo": "Este cupom não está mais ativo.",
          "Cupom expirado": "Este cupom já expirou.",
          "Limite de uso do cupom atingido": "Este cupom já atingiu o limite máximo de usos.",
          "Cupom não aplicável a este produto": "Este cupom não é válido para este produto.",
          "Cupom ainda não está válido": "Este cupom ainda não está disponível.",
        };
        setCouponError(friendlyErrors[errorMsg] || errorMsg);
        setAppliedCoupon(null);
        trackCouponFailed(couponCode, errorMsg);
      }
    } catch (error) {
      setCouponError("Erro ao validar cupom. Tente novamente.");
      setAppliedCoupon(null);
      trackCouponFailed(couponCode, "network_error");
    } finally {
      setIsValidatingCoupon(false);
    }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode("");
    setCouponError(null);
  };

  const calculateDiscount = (originalPrice: number) => {
    if (!appliedCoupon) return { discount: 0, finalPrice: originalPrice };
    
    let discount = 0;
    if (appliedCoupon.discountType === "percentage") {
      discount = (originalPrice * appliedCoupon.discountValue) / 100;
    } else {
      discount = appliedCoupon.discountValue;
    }
    
    // Aplicar limite máximo de desconto
    if (appliedCoupon.maxDiscountAmount && discount > appliedCoupon.maxDiscountAmount) {
      discount = appliedCoupon.maxDiscountAmount;
    }
    
    // Garantir que o desconto não exceda o preço original
    if (discount > originalPrice) {
      discount = originalPrice;
    }
    
    return {
      discount,
      finalPrice: originalPrice - discount,
    };
  };

  // Determina o texto do botão de checkout baseado no cupom
  const getCheckoutButtonText = (productId: string, defaultText: string) => {
    if (checkoutMutation.isPending) return null; // will show spinner
    if (isFreeWithCoupon) {
      const { finalPrice } = calculateDiscount(getProductPrice(productId));
      if (finalPrice === 0) return "Confirmar inscrição gratuita";
    }
    return defaultText;
  };

  // Helper para obter preço do produto
  const getProductPrice = (productId: string): number => {
    const prices: Record<string, number> = {
      playbook_vertice: 377,
      mentoria_grupo: 1497,
      mentoria_sprint: 1997,
      mentoria_90dias: 4997,
      mentoria_executive: 9997,
      diagnostico_360: 2997,
      assessoria_mensal: 9977,
    };
    return prices[productId] || 0;
  };

  const handleCheckout = async (productId: string) => {
    if (!isAuthenticated) {
      window.location.href = "/login";
      return;
    }

    const { finalPrice } = calculateDiscount(getProductPrice(productId));
    const isFreeCheckout = finalPrice === 0 && isFreeWithCoupon;
    trackCheckoutStarted(productId, finalPrice, isFreeCheckout);
    
    try {
      if (isFreeCheckout) {
        toast.info("Processando sua inscrição gratuita...");
      } else {
        toast.info("Redirecionando para o checkout...");
      }
      const result = await checkoutMutation.mutateAsync({ 
        productId,
        couponCode: appliedCoupon?.code,
      });
      if (result.url) {
        window.open(result.url, "_blank");
      }
    } catch (error: any) {
      console.error("Erro ao criar checkout:", error);
      toast.error(error.message || "Erro ao processar. Tente novamente.");
    }
  };

  return (
    <div className="min-h-screen bg-background bg-navy-gradient">
      <SEO title={PAGE_SEO.ofertas.title} description={PAGE_SEO.ofertas.description} path="/ofertas" />
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="absolute inset-0 bg-radial" />
        <div className="absolute inset-0 bg-radial-coral" />

        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-coral mb-6">
              <Sparkles className="w-4 h-4" />
              <span className="text-sm font-medium">Programas de Mentoria</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Escolha o caminho para{" "}
              <span className="gradient-text">transformar sua operação</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              Do playbook introdutório à mentoria executiva. Encontre o formato ideal para aplicar o Protocolo Vértice no seu contexto.
            </p>

            {/* Cupom de Desconto */}
            <div className="mt-10 max-w-md mx-auto">
              <Card className="bg-card/80 backdrop-blur border-primary/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Ticket className="w-4 h-4 text-primary" />
                    <span className="text-sm font-medium">Tem um cupom de desconto?</span>
                  </div>
                  
                  {appliedCoupon ? (
                    <div className="space-y-3">
                      <div className={`p-4 rounded-lg border ${
                        isFreeWithCoupon 
                          ? "bg-green-500/15 border-green-500/30" 
                          : "bg-green-500/10 border-green-500/20"
                      }`}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            {isFreeWithCoupon ? (
                              <PartyPopper className="w-5 h-5 text-green-500" />
                            ) : (
                              <Check className="w-4 h-4 text-green-500" />
                            )}
                            <div>
                              <p className="text-sm font-semibold text-green-500">
                                {isFreeWithCoupon ? "Cupom aplicado: 100% OFF" : `Cupom aplicado: ${appliedCoupon.name}`}
                              </p>
                              <p className="text-xs text-green-400/80">
                                {appliedCoupon.discountType === "percentage" 
                                  ? `${appliedCoupon.discountValue}% de desconto em todos os produtos elegíveis`
                                  : `R$ ${appliedCoupon.discountValue.toFixed(2)} de desconto`
                                }
                              </p>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={removeCoupon}
                            className="text-muted-foreground hover:text-destructive h-8 w-8 p-0"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      
                      {/* Microtexto de confiança para 100% OFF */}
                      {isFreeWithCoupon && (
                        <div className="flex items-center gap-2 px-1">
                          <ShieldCheck className="w-4 h-4 text-green-500/70 flex-shrink-0" />
                          <p className="text-xs text-muted-foreground">
                            Você não será cobrado. Inscrição gratuita confirmada com cupom.
                          </p>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <Input
                          placeholder="Digite o código do cupom"
                          value={couponCode}
                          onChange={(e) => {
                            setCouponCode(e.target.value.toUpperCase());
                            setCouponError(null);
                          }}
                          onKeyDown={(e) => e.key === "Enter" && handleValidateCoupon()}
                          className="bg-background/50"
                        />
                        <Button
                          onClick={handleValidateCoupon}
                          disabled={isValidatingCoupon || !couponCode.trim()}
                          variant="outline"
                        >
                          {isValidatingCoupon ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            "Aplicar"
                          )}
                        </Button>
                      </div>
                      {couponError && (
                        <div className="flex items-start gap-2 p-2 rounded-md bg-destructive/10 border border-destructive/20">
                          <X className="w-4 h-4 text-destructive flex-shrink-0 mt-0.5" />
                          <p className="text-xs text-destructive">{couponError}</p>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Introductory Plan - NEW */}
      <section id="playbook" className="py-20 scroll-mt-24">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <Card className="program-card rounded-3xl overflow-hidden border-primary/30">
              <CardContent className="p-0">
                <div className="grid md:grid-cols-2">
                  <div className="p-8 md:p-10">
                    <Badge className="mb-4 bg-primary/20 text-primary">
                      <BookOpen className="w-3 h-3 mr-1" />
                      {introductoryPlan.badge}
                    </Badge>
                    <h2 className="text-2xl md:text-3xl font-bold mb-2">{introductoryPlan.title}</h2>
                    <p className="text-primary font-medium mb-4">{introductoryPlan.subtitle}</p>
                    <p className="text-muted-foreground mb-6">{introductoryPlan.description}</p>

                    <div className="space-y-3">
                      {introductoryPlan.features.map((feature, index) => (
                        <div key={index} className="flex items-center gap-3">
                          <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-card/50 p-8 md:p-10 flex flex-col justify-center">
                    <div className="text-center mb-6">
                      {appliedCoupon ? (
                        <>
                          <div className="text-2xl text-muted-foreground line-through mb-1">
                            {introductoryPlan.price}
                          </div>
                          {calculateDiscount(377).finalPrice === 0 ? (
                            <div className="text-5xl font-bold text-green-500 mb-2">Grátis</div>
                          ) : (
                            <div className="text-5xl font-bold text-green-500 mb-2">
                              R$ {(calculateDiscount(377).finalPrice).toFixed(0)}
                            </div>
                          )}
                          <Badge className="bg-green-500/20 text-green-500 mb-2">
                            <Ticket className="w-3 h-3 mr-1" />
                            {appliedCoupon.discountType === "percentage"
                              ? `${appliedCoupon.discountValue}% OFF`
                              : `R$ ${appliedCoupon.discountValue} OFF`
                            }
                          </Badge>
                        </>
                      ) : (
                        <div className="text-5xl font-bold text-primary mb-2">{introductoryPlan.price}</div>
                      )}
                      <p className="text-muted-foreground">
                        {calculateDiscount(377).finalPrice === 0 ? "Inscrição gratuita com cupom" : introductoryPlan.priceNote}
                      </p>
                    </div>

                    <Button 
                      size="lg" 
                      className={`w-full h-14 rounded-xl ${calculateDiscount(377).finalPrice === 0 ? "bg-green-600 hover:bg-green-700 text-white" : "btn-coral"}`}
                      onClick={() => handleCheckout("playbook_vertice")}
                      disabled={checkoutMutation.isPending}
                    >
                      {checkoutMutation.isPending ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : calculateDiscount(377).finalPrice === 0 ? (
                        <>
                          <Gift className="w-5 h-5 mr-2" />
                          Confirmar inscrição gratuita
                        </>
                      ) : (
                        <>
                          {introductoryPlan.cta}
                          <ArrowRight className="w-5 h-5 ml-2" />
                        </>
                      )}
                    </Button>

                    {calculateDiscount(377).finalPrice === 0 && (
                      <p className="text-center text-green-500/80 text-xs mt-3 flex items-center justify-center gap-1">
                        <ShieldCheck className="w-3 h-3" />
                        Nenhum pagamento será cobrado
                      </p>
                    )}

                    <p className="text-center text-muted-foreground text-xs mt-4">
                      Acesso imediato após confirmação do pagamento
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Group Mentorship */}
      <section id="grupo" className="py-20 bg-card/20 scroll-mt-24">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <div>
              <Badge className="mb-4 bg-coral/20 text-coral">
                <Users className="w-3 h-3 mr-1" />
                Mais Popular
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-2">{groupMentorship.title}</h2>
              <p className="text-primary font-medium mb-4">{groupMentorship.subtitle}</p>
              <p className="text-muted-foreground text-lg mb-6">{groupMentorship.description}</p>

              <div className="flex flex-wrap gap-4 mb-8">
                {groupMentorship.highlights.map((item, index) => (
                  <div key={index} className="flex items-center gap-2 text-sm">
                    <item.icon className="w-4 h-4 text-primary" />
                    <span className="text-muted-foreground">{item.label}</span>
                  </div>
                ))}
              </div>

              <div className="space-y-3 mb-8">
                {groupMentorship.features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            <Card className="program-card rounded-3xl border-coral/30 sticky top-24">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  {appliedCoupon ? (
                    <>
                      <div className="text-xl text-muted-foreground line-through mb-1">
                        {groupMentorship.price}
                      </div>
                      {calculateDiscount(1497).finalPrice === 0 ? (
                        <div className="text-4xl font-bold text-green-500 mb-1">Grátis</div>
                      ) : (
                        <div className="text-4xl font-bold text-green-500 mb-1">
                          R$ {(calculateDiscount(1497).finalPrice).toFixed(0)}
                        </div>
                      )}
                      <Badge className="bg-green-500/20 text-green-500 mb-2">
                        <Ticket className="w-3 h-3 mr-1" />
                        {appliedCoupon.discountType === "percentage"
                          ? `${appliedCoupon.discountValue}% OFF`
                          : `R$ ${appliedCoupon.discountValue} OFF`
                        }
                      </Badge>
                    </>
                  ) : (
                    <div className="text-4xl font-bold text-coral mb-1">{groupMentorship.price}</div>
                  )}
                  <p className="text-muted-foreground text-sm">
                    {calculateDiscount(1497).finalPrice === 0 ? "Inscrição gratuita com cupom" : groupMentorship.priceNote}
                  </p>
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex items-center justify-between py-3 border-b border-border/50">
                    <span className="text-muted-foreground">Duração</span>
                    <span className="font-medium">{groupMentorship.duration}</span>
                  </div>
                  <div className="flex items-center justify-between py-3 border-b border-border/50">
                    <span className="text-muted-foreground">Formato</span>
                    <span className="font-medium">{groupMentorship.format}</span>
                  </div>
                </div>

                <Button 
                  className={`w-full h-12 rounded-xl ${calculateDiscount(1497).finalPrice === 0 ? "bg-green-600 hover:bg-green-700 text-white" : "btn-coral"}`}
                  onClick={() => handleCheckout("mentoria_grupo")}
                  disabled={checkoutMutation.isPending}
                >
                  {checkoutMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : calculateDiscount(1497).finalPrice === 0 ? (
                    <>
                      <Gift className="w-4 h-4 mr-2" />
                      Confirmar inscrição gratuita
                    </>
                  ) : (
                    <>
                      {groupMentorship.cta}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>

                {calculateDiscount(1497).finalPrice === 0 && (
                  <p className="text-center text-green-500/80 text-xs mt-3 flex items-center justify-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    Nenhum pagamento será cobrado
                  </p>
                )}

                <p className="text-center text-muted-foreground text-xs mt-4">
                  Próxima turma: Março 2026
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Individual Mentorship */}
      <section id="individual" className="py-20 scroll-mt-24">
        <div className="container">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-primary/20 text-primary">
              <User className="w-3 h-3 mr-1" />
              Personalizado
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-2">{individualMentorship.title}</h2>
            <p className="text-primary font-medium mb-4">{individualMentorship.subtitle}</p>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              {individualMentorship.description}
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {individualMentorship.plans.map((plan, index) => (
              <Card
                key={index}
                className={`program-card rounded-2xl relative ${
                  plan.popular ? "border-coral/50" : ""
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className="bg-coral text-white">
                      <Star className="w-3 h-3 mr-1" />
                      Mais Escolhido
                    </Badge>
                  </div>
                )}
                <CardHeader className="text-center pb-4">
                  <CardTitle className="text-xl">{plan.name}</CardTitle>
                  <p className="text-muted-foreground text-sm">{plan.duration}</p>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="text-center mb-6">
                    <div className="text-3xl font-bold text-primary mb-1">{plan.price}</div>
                    <p className="text-muted-foreground text-xs">{plan.priceNote}</p>
                    {plan.pricePerSession && (
                      <p className="text-xs text-primary/70 mt-1 font-medium">{plan.pricePerSession}</p>
                    )}
                  </div>

                  <p className="text-sm text-muted-foreground text-center mb-4 py-2 px-3 rounded-lg bg-card/50">
                    {plan.ideal}
                  </p>

                  <div className="space-y-2 mb-6">
                    {plan.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>

                  <Button
                    className={`w-full rounded-xl ${
                      plan.popular ? "btn-coral" : ""
                    }`}
                    variant={plan.popular ? "default" : "outline"}
                    onClick={() => handleCheckout(
                      index === 0 ? "mentoria_sprint" : 
                      index === 1 ? "mentoria_90dias" : "mentoria_executive"
                    )}
                    disabled={checkoutMutation.isPending}
                  >
                    {checkoutMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      "Quero essa Mentoria"
                    )}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Diagnostic */}
      <section id="diagnostico" className="py-20 bg-card/20 scroll-mt-24">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <Card className="program-card rounded-3xl border-primary/30 sticky top-24 order-2 lg:order-1">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <div className="text-4xl font-bold text-primary mb-1">{diagnostic.price}</div>
                  <p className="text-muted-foreground text-sm">{diagnostic.priceNote}</p>
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex items-center justify-between py-3 border-b border-border/50">
                    <span className="text-muted-foreground">Duração</span>
                    <span className="font-medium">{diagnostic.duration}</span>
                  </div>
                  <div className="flex items-center justify-between py-3 border-b border-border/50">
                    <span className="text-muted-foreground">Formato</span>
                    <span className="font-medium">{diagnostic.format}</span>
                  </div>
                </div>

                <h4 className="font-semibold mb-3">Entregáveis:</h4>
                <div className="space-y-2 mb-6">
                  {diagnostic.deliverables.map((item, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm">
                      <Shield className="w-4 h-4 text-primary" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>

                <Button 
                  className="w-full bg-primary hover:bg-primary/90 h-12 rounded-xl"
                  onClick={() => handleCheckout("diagnostico_360")}
                  disabled={checkoutMutation.isPending}
                >
                  {checkoutMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      {diagnostic.cta}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            <div className="order-1 lg:order-2">
              <Badge className="mb-4 bg-primary/20 text-primary">
                <Search className="w-3 h-3 mr-1" />
                Para Empresas
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-2">{diagnostic.title}</h2>
              <p className="text-primary font-medium mb-4">{diagnostic.subtitle}</p>
              <p className="text-muted-foreground text-lg mb-6">{diagnostic.description}</p>

              <div className="space-y-3 mb-8">
                {diagnostic.features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>

              <Card className="program-card rounded-xl">
                <CardContent className="p-6">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Zap className="w-4 h-4 text-coral" />
                    Ideal para:
                  </h4>
                  <ul className="text-muted-foreground text-sm space-y-1">
                    <li>• Empresas que querem entender seu nível de maturidade</li>
                    <li>• Líderes assumindo novas áreas de CX/Qualidade</li>
                    <li>• Organizações planejando transformação digital</li>
                    <li>• Times que precisam de direcionamento estratégico</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Comparison Table */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Compare as <span className="gradient-text">Modalidades</span>
            </h2>
            <p className="text-muted-foreground">
              Escolha a opção que melhor se encaixa no seu momento
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border/50">
                  <th className="text-left py-4 px-4 font-medium text-muted-foreground">Característica</th>
                  <th className="text-center py-4 px-4 font-medium">Playbook</th>
                  <th className="text-center py-4 px-4 font-medium">Grupo</th>
                  <th className="text-center py-4 px-4 font-medium">Individual</th>
                  <th className="text-center py-4 px-4 font-medium">Diagnóstico</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { feature: "Investimento", playbook: "R$ 377", grupo: "R$ 1.497", individual: "A partir de R$ 1.997", diagnostico: "R$ 2.997" },
                  { feature: "Formato", playbook: "Material digital", grupo: "Encontros ao vivo", individual: "Sessões 1:1", diagnostico: "Análise + Relatório" },
                  { feature: "Duração", playbook: "Acesso vitalício", grupo: "8 semanas", individual: "4 sem a 6 meses", diagnostico: "2-3 semanas" },
                  { feature: "Suporte", playbook: "—", grupo: "Comunidade WhatsApp", individual: "WhatsApp direto", diagnostico: "Durante projeto" },
                  { feature: "Materiais", playbook: "Playbooks PDF", grupo: "Completos", individual: "Completos", diagnostico: "Relatório executivo" },
                  { feature: "Personalização", playbook: "—", grupo: "Moderada", individual: "Total", diagnostico: "Total" },
                  { feature: "Ideal para", playbook: "Iniciantes", grupo: "Profissionais", individual: "Líderes", diagnostico: "Empresas" },
                ].map((row, index) => (
                  <tr key={index} className="border-b border-border/30">
                    <td className="py-4 px-4 font-medium">{row.feature}</td>
                    <td className="py-4 px-4 text-center text-muted-foreground">{row.playbook}</td>
                    <td className="py-4 px-4 text-center text-muted-foreground">{row.grupo}</td>
                    <td className="py-4 px-4 text-center text-muted-foreground">{row.individual}</td>
                    <td className="py-4 px-4 text-center text-muted-foreground">{row.diagnostico}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Depoimentos / Prova Social */}
      <section className="py-20 bg-card/20">
        <div className="container">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-primary/20 text-primary">
              <Star className="w-3 h-3 mr-1" />
              Resultados Reais
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              O que dizem nossos <span className="gradient-text">mentorados</span>
            </h2>
            <p className="text-muted-foreground text-lg">
              Profissionais que transformaram suas operações com o Protocolo Vértice
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                name: "Mariana Costa",
                role: "Head de CX · Fintech",
                text: "Em 90 dias, saí de um NPS de 32 para 67. O Protocolo Vértice me deu clareza sobre onde focar e como medir o impacto real das ações.",
                rating: 5,
              },
              {
                name: "Rafael Oliveira",
                role: "Gerente de Dados · Varejo",
                text: "Finalmente consegui conectar métricas de CX com resultados financeiros. Meu board agora entende o valor do investimento em experiência do cliente.",
                rating: 5,
              },
              {
                name: "Camila Santos",
                role: "Diretora de Operações · SaaS",
                text: "A mentoria individual foi transformadora. O Samuel tem uma capacidade única de traduzir conceitos complexos em ações práticas e mensuráveis.",
                rating: 5,
              },
            ].map((testimonial, index) => (
              <Card key={index} className="program-card rounded-2xl">
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-4">
                    {Array.from({ length: testimonial.rating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-500 text-yellow-500" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4 italic">
                    "{testimonial.text}"
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                      <span className="text-sm font-bold text-primary">
                        {testimonial.name.split(" ").map(n => n[0]).join("")}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium text-sm">{testimonial.name}</p>
                      <p className="text-xs text-muted-foreground">{testimonial.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Garantia de Satisfação */}
      <section className="py-16">
        <div className="container">
          <Card className="max-w-3xl mx-auto program-card rounded-3xl border-primary/20">
            <CardContent className="p-8 md:p-10 text-center">
              <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-6">
                <ShieldCheck className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-3">Garantia de 7 Dias</h3>
              <p className="text-muted-foreground text-lg mb-4">
                Se em até 7 dias após a compra você sentir que o programa não é para você, devolvemos 100% do seu investimento. Sem perguntas, sem burocracia.
              </p>
              <p className="text-sm text-muted-foreground">
                Válido para Playbook Vértice e Mentoria em Grupo. Mentorias individuais possuem política específica.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-card/20">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Perguntas <span className="gradient-text">Frequentes</span>
            </h2>
          </div>

          <div className="max-w-3xl mx-auto space-y-4">
            {[
              {
                q: "Preciso ter experiência prévia em CX ou Dados?",
                a: "Não. O Playbook Vértice é ideal para iniciantes, e os programas de mentoria se adaptam ao seu nível. O Radar Vértice gratuito identifica seu ponto de partida."
              },
              {
                q: "Qual a diferença entre a mentoria em grupo e individual?",
                a: "Na mentoria em grupo, você aprende com uma turma de até 15 profissionais em encontros semanais. Na individual, o acompanhamento é 100% personalizado ao seu contexto e desafios específicos."
              },
              {
                q: "Como funciona o pagamento?",
                a: "Aceitamos cartão de crédito (parcelamento disponível) e PIX. Todos os pagamentos são processados pela Stripe, com total segurança. Cupons de desconto podem ser aplicados no checkout."
              },
              {
                q: "Posso trocar de plano depois?",
                a: "Sim. Se você começar pelo Playbook e quiser evoluir para uma mentoria, o valor investido pode ser abatido (consulte condições)."
              },
              {
                q: "O que é o Protocolo Vértice?",
                a: "É a metodologia proprietária da Data CX que integra CX, Dados e IA em um framework prático de evolução. Ele mapeia seu nível de maturidade e cria um plano de ação personalizado para cada pilar."
              },
              {
                q: "Os materiais ficam disponíveis por quanto tempo?",
                a: "O Playbook Vértice tem acesso vitalício. Na mentoria em grupo, as gravações ficam disponíveis por 1 ano. Na mentoria individual, o acesso aos materiais é vitalício."
              },
              {
                q: "Emitem nota fiscal?",
                a: "Sim. A nota fiscal é emitida automaticamente após a confirmação do pagamento e enviada para o e-mail cadastrado."
              },
            ].map((faq, index) => (
              <Card key={index} className="program-card rounded-xl">
                <CardContent className="p-6">
                  <h4 className="font-semibold mb-2">{faq.q}</h4>
                  <p className="text-muted-foreground text-sm">{faq.a}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-card/20">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Não sabe qual escolher?
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Faça o Radar Vértice gratuitamente e receba uma recomendação personalizada baseada no seu nível de maturidade.
            </p>
            <Link href="/radar">
              <Button size="lg" className="btn-coral px-10 h-14 text-lg rounded-xl">
                Fazer Radar Vértice (Gratuito)
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
