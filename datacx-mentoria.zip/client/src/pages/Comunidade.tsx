import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
// Auth redirect uses /login route
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useState, useMemo } from "react";
import { trackCommunityPostCreated } from "@/lib/analytics";
import { 
  MessageSquare, 
  Send, 
  Plus,
  Trophy,
  Star,
  Users,
  TrendingUp,
  Award,
  Zap,
  MessageCircle,
  ThumbsUp,
  Pin,
  HelpCircle,
  Megaphone,
  FileText,
  Trash2,
  GraduationCap,
  Briefcase,
  Building2,
  Sparkles,
  Hash,
} from "lucide-react";

const SPACES = [
  { id: "geral", label: "Geral", icon: Hash, description: "Discussões abertas para toda a comunidade", color: "text-blue-400", bg: "bg-blue-500/20" },
  { id: "jovens", label: "Jovens Profissionais", icon: GraduationCap, description: "Início de carreira em CX e dados", color: "text-emerald-400", bg: "bg-emerald-500/20" },
  { id: "gestores", label: "Gestores", icon: Briefcase, description: "Liderança e gestão de equipes de CX", color: "text-purple-400", bg: "bg-purple-500/20" },
  { id: "executivos", label: "Executivos", icon: Star, description: "Estratégia e governança de CX", color: "text-amber-400", bg: "bg-amber-500/20" },
  { id: "empresas", label: "Empresários", icon: Building2, description: "Escala, cultura e transformação digital", color: "text-rose-400", bg: "bg-rose-500/20" },
];
import { motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";

export default function Comunidade() {
  const { user, isAuthenticated } = useAuth();
  const [activeSpace, setActiveSpace] = useState("geral");
  const [newPostOpen, setNewPostOpen] = useState(false);
  const [newPostTitle, setNewPostTitle] = useState("");
  const [newPostContent, setNewPostContent] = useState("");
  const [newPostType, setNewPostType] = useState<"discussion" | "question" | "resource">("discussion");
  const [selectedPostId, setSelectedPostId] = useState<number | null>(null);
  const [newComment, setNewComment] = useState("");

  const queryInput = useMemo(() => ({ space: activeSpace }), [activeSpace]);

  const { data: posts, refetch: refetchPosts } = trpc.community.listPosts.useQuery(queryInput, {
    enabled: isAuthenticated,
  });
  const { data: myPoints } = trpc.gamification.myPoints.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const { data: leaderboard } = trpc.gamification.leaderboard.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const { data: myBadges } = trpc.gamification.myBadges.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const createPost = trpc.community.createPost.useMutation({
    onSuccess: () => {
      toast.success("Post criado com sucesso! +10 pontos");
      trackCommunityPostCreated(newPostType || "discussion");
      setNewPostOpen(false);
      setNewPostTitle("");
      setNewPostContent("");
      refetchPosts();
    },
  });

  const toggleLike = trpc.community.toggleLike.useMutation({
    onSuccess: () => {
      refetchPosts();
    },
  });

  const createComment = trpc.community.createComment.useMutation({
    onSuccess: () => {
      toast.success("Comentário adicionado! +5 pontos");
      setNewComment("");
      refetchPosts();
    },
  });

  // Moderação Admin
  const deletePostMutation = trpc.community.deletePost.useMutation({
    onSuccess: () => {
      toast.success("Post excluído com sucesso");
      refetchPosts();
    },
    onError: () => toast.error("Erro ao excluir post"),
  });

  const togglePinMutation = trpc.community.togglePin.useMutation({
    onSuccess: (data) => {
      toast.success(data.isPinned ? "Post fixado" : "Post desafixado");
      refetchPosts();
    },
    onError: () => toast.error("Erro ao fixar/desafixar post"),
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background bg-navy-gradient">
        <Navbar />
        <div className="container py-20">
          <div className="max-w-2xl mx-auto text-center">
            <MessageSquare className="w-16 h-16 text-primary mx-auto mb-6" />
            <h1 className="text-3xl font-bold mb-4">Comunidade Vértice</h1>
            <p className="text-muted-foreground mb-8">
              Conecte-se com outros profissionais, compartilhe experiências e aprenda junto.
            </p>
            <Button asChild className="btn-coral">
              <a href="/login">Entrar para Participar</a>
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "question": return <HelpCircle className="w-4 h-4" />;
      case "announcement": return <Megaphone className="w-4 h-4" />;
      case "resource": return <FileText className="w-4 h-4" />;
      default: return <MessageCircle className="w-4 h-4" />;
    }
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case "question": return "bg-yellow-500/20 text-yellow-400";
      case "announcement": return "bg-red-500/20 text-red-400";
      case "resource": return "bg-green-500/20 text-green-400";
      default: return "bg-blue-500/20 text-blue-400";
    }
  };

  return (
    <div className="min-h-screen bg-background bg-navy-gradient">
      <Navbar />

      <div className="container py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Spaces Navigation */}
            <Card className="program-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-primary" />
                  Spaces
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-1">
                {SPACES.map((space) => {
                  const Icon = space.icon;
                  const isActive = activeSpace === space.id;
                  return (
                    <button
                      key={space.id}
                      onClick={() => setActiveSpace(space.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all ${
                        isActive
                          ? `${space.bg} ${space.color} font-semibold`
                          : "text-muted-foreground hover:bg-muted/50 hover:text-foreground"
                      }`}
                    >
                      <Icon className="w-4 h-4 flex-shrink-0" />
                      <span className="text-sm truncate">{space.label}</span>
                    </button>
                  );
                })}
              </CardContent>
            </Card>

            {/* Meu Perfil */}
            <Card className="program-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-yellow-500" />
                  Meu Perfil
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-2xl font-bold">
                    {user?.name?.charAt(0) || "?"}
                  </div>
                  <div>
                    <p className="font-semibold">{user?.name}</p>
                    <p className="text-sm text-primary">{myPoints?.levelName || "Iniciante"}</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Pontos</span>
                    <span className="font-bold text-primary">{myPoints?.points || 0}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Nível</span>
                    <span className="font-bold">{myPoints?.level || 1}</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2 mt-2">
                    <div 
                      className="bg-gradient-to-r from-primary to-accent h-2 rounded-full transition-all"
                      style={{ width: `${Math.min(((myPoints?.totalPointsEarned || 0) % 100), 100)}%` }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Leaderboard */}
            <Card className="program-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-500" />
                  Ranking
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {leaderboard?.slice(0, 5).map((entry: any, idx: number) => (
                    <div key={entry.id} className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                        idx === 0 ? "bg-yellow-500 text-black" :
                        idx === 1 ? "bg-gray-400 text-black" :
                        idx === 2 ? "bg-amber-600 text-white" :
                        "bg-muted text-muted-foreground"
                      }`}>
                        {idx + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{entry.levelName}</p>
                        <p className="text-xs text-muted-foreground">{entry.totalPointsEarned} pts</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Badges */}
            {myBadges && myBadges.length > 0 && (
              <Card className="program-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Award className="w-5 h-5 text-purple-500" />
                    Minhas Conquistas
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {myBadges.map((badge: any) => (
                      <div 
                        key={badge.id} 
                        className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center"
                        title={badge.badgeId.toString()}
                      >
                        <Star className="w-6 h-6 text-yellow-500" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Main Content - Posts */}
          <div className="lg:col-span-3 space-y-6">
            {/* Space Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {(() => { const SpaceIcon = (SPACES.find(s => s.id === activeSpace) || SPACES[0]).icon; const space = SPACES.find(s => s.id === activeSpace) || SPACES[0]; return (
                  <div className={`w-10 h-10 rounded-xl ${space.bg} flex items-center justify-center`}>
                    <SpaceIcon className={`w-5 h-5 ${space.color}`} />
                  </div>
                ); })()}
                <div>
                  <h1 className="text-2xl font-bold">{(SPACES.find(s => s.id === activeSpace) || SPACES[0]).label}</h1>
                  <p className="text-sm text-muted-foreground">{(SPACES.find(s => s.id === activeSpace) || SPACES[0]).description}</p>
                </div>
              </div>
              <Dialog open={newPostOpen} onOpenChange={setNewPostOpen}>
                <DialogTrigger asChild>
                  <Button className="btn-coral">
                    <Plus className="w-4 h-4 mr-2" />
                    Novo Post
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Criar Post em {(SPACES.find(s => s.id === activeSpace) || SPACES[0]).label}</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <Select value={newPostType} onValueChange={(v: any) => setNewPostType(v)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Tipo de post" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="discussion">Discussão</SelectItem>
                        <SelectItem value="question">Pergunta</SelectItem>
                        <SelectItem value="resource">Recurso</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      placeholder="Título do post"
                      value={newPostTitle}
                      onChange={(e) => setNewPostTitle(e.target.value)}
                    />
                    <Textarea
                      placeholder="Escreva seu post..."
                      value={newPostContent}
                      onChange={(e) => setNewPostContent(e.target.value)}
                      rows={5}
                    />
                    <Button 
                      className="w-full btn-coral"
                      onClick={() => createPost.mutate({
                        title: newPostTitle,
                        content: newPostContent,
                        type: newPostType,
                        space: activeSpace,
                      })}
                      disabled={!newPostTitle || !newPostContent || createPost.isPending}
                    >
                      {createPost.isPending ? "Publicando..." : "Publicar (+10 pts)"}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {/* Posts List */}
            <div className="space-y-4">
              {posts?.map((post: any) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <Card className="program-card">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center flex-shrink-0">
                          <Users className="w-6 h-6 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            {post.isPinned && (
                              <Pin className="w-4 h-4 text-yellow-500" />
                            )}
                            <span className={`px-2 py-0.5 rounded-full text-xs ${getTypeBadge(post.type)}`}>
                              {getTypeIcon(post.type)}
                            </span>
                            {post.space && post.space !== "geral" && activeSpace === "geral" && (
                              <span className={`px-2 py-0.5 rounded-full text-xs ${
                                SPACES.find(s => s.id === post.space)?.bg || "bg-muted"
                              } ${SPACES.find(s => s.id === post.space)?.color || "text-muted-foreground"}`}>
                                {SPACES.find(s => s.id === post.space)?.label || post.space}
                              </span>
                            )}
                            <span className="text-xs text-muted-foreground">
                              {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true, locale: ptBR })}
                            </span>
                          </div>
                          {post.title && (
                            <h3 className="font-semibold text-lg mb-2">{post.title}</h3>
                          )}
                          <p className="text-muted-foreground whitespace-pre-wrap">{post.content}</p>
                          
                          <div className="flex items-center gap-4 mt-4">
                            <button 
                              className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors"
                              onClick={() => toggleLike.mutate({ postId: post.id })}
                            >
                              <ThumbsUp className="w-4 h-4" />
                              {post.likesCount}
                            </button>
                            <button 
                              className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors"
                              onClick={() => setSelectedPostId(selectedPostId === post.id ? null : post.id)}
                            >
                              <MessageCircle className="w-4 h-4" />
                              {post.commentsCount}
                            </button>
                            {/* Moderação Admin */}
                            {user?.role === "admin" && (
                              <>
                                <button
                                  className="flex items-center gap-1 text-sm text-muted-foreground hover:text-yellow-500 transition-colors ml-auto"
                                  onClick={() => {
                                    togglePinMutation.mutate({ postId: post.id });
                                  }}
                                  title={post.isPinned ? "Desafixar" : "Fixar"}
                                >
                                  <Pin className={`w-4 h-4 ${post.isPinned ? "text-yellow-500" : ""}`} />
                                  {post.isPinned ? "Fixado" : "Fixar"}
                                </button>
                                <button
                                  className="flex items-center gap-1 text-sm text-muted-foreground hover:text-destructive transition-colors"
                                  onClick={() => {
                                    if (confirm("Tem certeza que deseja excluir este post?")) {
                                      deletePostMutation.mutate({ postId: post.id });
                                    }
                                  }}
                                  title="Excluir post"
                                >
                                  <Trash2 className="w-4 h-4" />
                                  Excluir
                                </button>
                              </>
                            )}
                          </div>

                          {/* Comments Section */}
                          {selectedPostId === post.id && (
                            <div className="mt-4 pt-4 border-t border-border space-y-4">
                              <div className="flex gap-2">
                                <Input
                                  placeholder="Escreva um comentário..."
                                  value={newComment}
                                  onChange={(e) => setNewComment(e.target.value)}
                                  className="flex-1"
                                />
                                <Button 
                                  size="icon"
                                  onClick={() => {
                                    createComment.mutate({ postId: post.id, content: newComment });
                                  }}
                                  disabled={!newComment || createComment.isPending}
                                >
                                  <Send className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}

              {(!posts || posts.length === 0) && (
                <Card className="program-card">
                  <CardContent className="p-12 text-center">
                    <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="font-semibold mb-2">Nenhum post em {(SPACES.find(s => s.id === activeSpace) || SPACES[0]).label}</h3>
                    <p className="text-muted-foreground mb-4">Seja o primeiro a compartilhar algo neste space!</p>
                    <Button onClick={() => setNewPostOpen(true)} className="btn-coral">
                      Criar Primeiro Post
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
