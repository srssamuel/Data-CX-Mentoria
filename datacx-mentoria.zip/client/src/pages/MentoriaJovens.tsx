import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO, { PAGE_SEO } from "@/components/SEO";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  Rocket,
  Target,
  TrendingUp,
  Brain,
  Users,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  GraduationCap,
  Briefcase,
  Star,
} from "lucide-react";

const benefits = [
  {
    icon: Target,
    title: "Clareza de Carreira",
    description: "Entenda onde CX, Dados e IA se encaixam no mercado e como se posicionar",
  },
  {
    icon: Brain,
    title: "Fundamentos Sólidos",
    description: "Aprenda os conceitos essenciais que diferenciam profissionais no mercado",
  },
  {
    icon: TrendingUp,
    title: "Aceleração de Carreira",
    description: "Ganhe 2-3 anos de experiência em 8 semanas com método estruturado",
  },
  {
    icon: Users,
    title: "Networking Estratégico",
    description: "Conecte-se com outros jovens talentos e profissionais experientes",
  },
];

const modules = [
  "Fundamentos de CX: jornada, métricas e VOC",
  "Introdução a Dados: indicadores e análise básica",
  "IA para Produtividade: prompts e ferramentas",
  "Governança Pessoal: organização e priorização",
  "Comunicação com Stakeholders",
  "Construção de Portfólio e LinkedIn",
  "Preparação para Entrevistas",
  "Plano de Carreira 12 meses",
];

const testimonials = [
  {
    name: "Marina Costa",
    role: "Analista de CX Jr.",
    company: "Fintech",
    content: "Em 3 meses após a mentoria, fui promovida. O método me deu clareza e confiança.",
  },
  {
    name: "Lucas Ferreira",
    role: "Trainee",
    company: "E-commerce",
    content: "Saí da faculdade sem direção. Hoje lidero projetos de dados na minha área.",
  },
];

export default function MentoriaJovens() {
  return (
    <div className="min-h-screen bg-background">
      <SEO title={PAGE_SEO.mentoriaJovens.title} description={PAGE_SEO.mentoriaJovens.description} path="/mentoria-jovens" />
      <Navbar />

      {/* Hero Section */}
      <section className="pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="absolute inset-0 bg-radial" />

        <div className="container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 text-blue-400 text-sm font-medium mb-6">
              <GraduationCap className="w-4 h-4" />
              Para Jovens Profissionais (18-26 anos)
            </div>

            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Comece sua carreira com{" "}
              <span className="gradient-text">diferencial real</span>
            </h1>

            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Enquanto outros estão perdidos, você vai dominar CX, Dados e IA com método.
              Ganhe anos de experiência em semanas.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/radar">
                <Button size="lg" className="bg-primary hover:bg-primary/90 px-8">
                  <Sparkles className="w-5 h-5 mr-2" />
                  Fazer Diagnóstico Gratuito
                </Button>
              </Link>
              <Link href="/contato">
                <Button size="lg" variant="outline" className="px-8">
                  Falar com Samuel
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                O mercado mudou. Você está preparado?
              </h2>
              <p className="text-muted-foreground text-lg">
                A maioria dos jovens profissionais enfrenta esses desafios:
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-6">
              {[
                "Faculdade não ensina o que o mercado precisa",
                "Não sabe por onde começar em CX, Dados ou IA",
                "Falta de clareza sobre qual caminho seguir",
                "Dificuldade em se destacar em processos seletivos",
                "Síndrome do impostor ao falar com gestores",
                "Não consegue mostrar valor além de tarefas operacionais",
              ].map((problem, idx) => (
                <Card key={idx} className="bg-red-500/5 border-red-500/20">
                  <CardContent className="p-4 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-red-500/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-red-400 text-sm">✗</span>
                    </div>
                    <p className="text-muted-foreground">{problem}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="py-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              A Mentoria Vértice para <span className="gradient-text">Jovens</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              8 semanas de imersão para construir base sólida e se posicionar no mercado
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {benefits.map((benefit, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
              >
                <Card className="h-full bg-card/50 border-border/50 hover:border-primary/50 transition-all">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                      <benefit.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="font-semibold mb-2">{benefit.title}</h3>
                    <p className="text-sm text-muted-foreground">{benefit.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Modules */}
          <div className="max-w-3xl mx-auto">
            <h3 className="text-2xl font-bold mb-8 text-center">O que você vai aprender</h3>
            <div className="grid md:grid-cols-2 gap-4">
              {modules.map((module, idx) => (
                <div key={idx} className="flex items-center gap-3 p-4 rounded-lg bg-card/50 border border-border/50">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
                  <span className="text-sm">{module}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">
            Quem já passou por aqui
          </h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {testimonials.map((testimonial, idx) => (
              <Card key={idx} className="bg-card/50 border-border/50">
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4">"{testimonial.content}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-primary font-semibold">{testimonial.name[0]}</span>
                    </div>
                    <div>
                      <p className="font-medium text-sm">{testimonial.name}</p>
                      <p className="text-xs text-muted-foreground">{testimonial.role} • {testimonial.company}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20">
        <div className="container">
          <div className="max-w-lg mx-auto">
            <Card className="bg-gradient-to-br from-primary/10 to-accent/10 border-primary/30">
              <CardContent className="p-8 text-center">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/20 text-primary text-sm font-medium mb-4">
                  <Rocket className="w-4 h-4" />
                  Mentoria em Grupo
                </div>
                <h3 className="text-2xl font-bold mb-2">Mentoria Vértice Jovens</h3>
                <p className="text-muted-foreground mb-6">8 semanas • Encontros semanais • Grupo de até 12 pessoas</p>
                
                <div className="mb-6">
                  <span className="text-4xl font-bold">R$ 1.497</span>
                  <span className="text-muted-foreground"> ou 12x R$ 149</span>
                </div>

                <div className="space-y-3 mb-8 text-left">
                  {[
                    "8 encontros ao vivo (2h cada)",
                    "Acesso aos playbooks e templates",
                    "Comunidade exclusiva",
                    "Certificado de conclusão",
                    "1 sessão individual de carreira",
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                      <span className="text-sm">{item}</span>
                    </div>
                  ))}
                </div>

                <Link href="/radar">
                  <Button size="lg" className="w-full bg-primary hover:bg-primary/90">
                    Começar pelo Diagnóstico
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Não sabe se é pra você?
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              Faça o Radar Vértice gratuito e descubra seu nível de maturidade.
              Em 5 minutos você terá clareza sobre seu próximo passo.
            </p>
            <Link href="/radar">
              <Button size="lg" className="bg-primary hover:bg-primary/90 px-8">
                <Sparkles className="w-5 h-5 mr-2" />
                Fazer Diagnóstico Gratuito
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
