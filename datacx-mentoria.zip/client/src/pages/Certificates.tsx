import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import SEO, { PAGE_SEO } from "@/components/SEO";
import { trackCertificateGenerated, trackCertificateDownloaded, trackCertificateSharedLinkedIn } from "@/lib/analytics";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { 
  Award, 
  Download, 
  ExternalLink, 
  CheckCircle2, 
  Lock, 
  Sparkles,
  BookOpen,
  Users,
  Database,
  Brain,
  Share2,
  Copy,
  Calendar,
  Shield,
  Loader2,
  AlertCircle,
  Star,
  Crown,
  Trophy,
  Linkedin,
  Info,
  ArrowRight,
} from "lucide-react";

const categoryConfig: Record<string, { 
  name: string; 
  icon: React.ElementType; 
  color: string; 
  bgColor: string;
  description: string;
}> = {
  introducao: { 
    name: "Introdução ao Protocolo Vértice", 
    icon: BookOpen, 
    color: "text-blue-400",
    bgColor: "bg-blue-500/10",
    description: "Fundamentos e conceitos essenciais para iniciar sua jornada de transformação digital."
  },
  cx: { 
    name: "Customer Experience (CX)", 
    icon: Users, 
    color: "text-green-400",
    bgColor: "bg-green-500/10",
    description: "Estratégias e práticas para criar experiências excepcionais para seus clientes."
  },
  dados: { 
    name: "Gestão de Dados", 
    icon: Database, 
    color: "text-purple-400",
    bgColor: "bg-purple-500/10",
    description: "Técnicas e ferramentas para coletar, analisar e utilizar dados de forma estratégica."
  },
  ia: { 
    name: "Inteligência Artificial", 
    icon: Brain, 
    color: "text-orange-400",
    bgColor: "bg-orange-500/10",
    description: "Aplicações práticas de IA para automatizar processos e gerar insights."
  },
};

export default function Certificates() {
  const { user, isAuthenticated, loading } = useAuth();
  const [generatingCategory, setGeneratingCategory] = useState<string | null>(null);
  
  const { data: certificates, isLoading: certsLoading, refetch: refetchCerts } = trpc.certificates.myCertificates.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );
  
  const { data: categoryProgress, isLoading: progressLoading } = trpc.certificates.getCategoryProgress.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );
  
  const { data: enrollments } = trpc.enrollments.myEnrollments.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );
  
  const generateCertificate = trpc.certificates.generateCategory.useMutation({
    onSuccess: () => {
      toast.success("Certificado gerado com sucesso!", {
        description: "Seu certificado está pronto para download."
      });
      refetchCerts();
      setGeneratingCategory(null);
    },
    onError: (error) => {
      toast.error("Erro ao gerar certificado", {
        description: error.message
      });
      setGeneratingCategory(null);
    }
  });
  
  const generateProgramCertificate = trpc.certificates.generate.useMutation({
    onSuccess: () => {
      toast.success("Certificado gerado com sucesso!");
      refetchCerts();
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao gerar certificado");
    },
  });
  
  const handleGenerateCertificate = (category: string) => {
    setGeneratingCategory(category);
    trackCertificateGenerated(category);
    generateCertificate.mutate({ category: category as any });
  };
  
  const handleDownloadCertificate = (certId: number) => {
    trackCertificateDownloaded(certId);
    window.open(`/api/certificates/${certId}/pdf`, '_blank');
  };
  
  const handleShareCertificate = async (cert: any) => {
    const verifyUrl = `${window.location.origin}/verificar-certificado?code=${cert.verificationCode}`;
    const isGeneral = cert.type === "general";
    const categoryName = isGeneral 
      ? "Protocolo Vértice — Formação Completa" 
      : (cert.category ? categoryConfig[cert.category]?.name : "Programa Completo");
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Certificado - ${categoryName}`,
          text: `Conquistei o certificado de ${categoryName} no Data CX - Protocolo Vértice! Verifique: ${verifyUrl}`,
          url: verifyUrl,
        });
      } catch (err) {
        // User cancelled or error
      }
    } else {
      await navigator.clipboard.writeText(verifyUrl);
      toast.success("Link copiado!", {
        description: "O link de verificação foi copiado para a área de transferência."
      });
    }
  };

  const handleShareLinkedIn = (cert: any) => {
    const isGeneral = cert.type === "general";
    const categoryName = isGeneral 
      ? "Protocolo Vértice — Formação Completa" 
      : (cert.category ? categoryConfig[cert.category]?.name : "Programa Completo");
    trackCertificateSharedLinkedIn(categoryName);
    const verifyUrl = `${window.location.origin}/verificar-certificado?code=${cert.verificationCode}`;
    const linkedInUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(verifyUrl)}&title=${encodeURIComponent(`Certificado: ${categoryName}`)}&summary=${encodeURIComponent(`Conquistei o certificado de ${categoryName} no Data CX - Protocolo Vértice! Uma formação completa em CX, Dados e IA aplicados.`)}`;
    window.open(linkedInUrl, '_blank', 'width=600,height=400');
  };
  
  const getCertificateForCategory = (category: string) => {
    return certificates?.find(c => c.category === category && c.type === "category");
  };
  
  const getCategoryProgressData = (category: string) => {
    return categoryProgress?.progress.find(p => p.category === category);
  };
  
  if (loading || certsLoading || progressLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <AlertCircle className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h1 className="text-2xl font-bold mb-4">Acesso Restrito</h1>
          <p className="text-muted-foreground mb-6">Faça login para ver seus certificados.</p>
          <Button asChild>
            <a href="/login">Fazer Login</a>
          </Button>
        </div>
        <Footer />
      </div>
    );
  }
  
  const categoryCertificates = certificates?.filter(c => c.type === "category") || [];
  const generalCertificate = certificates?.find(c => c.type === "general");
  const programCertificates = certificates?.filter(c => c.type === "program") || [];
  const totalCategories = Object.keys(categoryConfig).length;
  const completedCategoryCount = categoryCertificates.length;
  const activeEnrollments = enrollments?.filter(e => e.status === "active" && e.paymentStatus === "paid") || [];
  
  return (
    <div className="min-h-screen bg-background">
      <SEO title={PAGE_SEO.certificados.title} description={PAGE_SEO.certificados.description} path="/certificados" noindex />
      <Navbar />
      
      <div className="container py-12">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
            <Award className="w-8 h-8 text-primary" />
            Meus Certificados
          </h1>
          <p className="text-muted-foreground">
            Complete todos os conteúdos de uma categoria para gerar seu certificado.
          </p>
        </div>
        
        {/* ═══ GENERAL CERTIFICATE HERO ═══ */}
        {generalCertificate ? (
          <Card className="mb-8 relative overflow-hidden border-yellow-500/40 bg-gradient-to-br from-yellow-500/10 via-amber-900/10 to-background">
            {/* Gold accent line */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-yellow-600 via-yellow-400 to-yellow-600" />
            
            <CardContent className="pt-8 pb-8">
              <div className="flex flex-col md:flex-row items-center gap-6">
                {/* Seal */}
                <div className="relative shrink-0">
                  <div className="w-28 h-28 rounded-full bg-gradient-to-br from-yellow-500/20 to-amber-700/20 flex items-center justify-center border-2 border-yellow-500/40">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-yellow-500/30 to-amber-600/30 flex items-center justify-center border border-yellow-500/50">
                      <Trophy className="w-10 h-10 text-yellow-500" />
                    </div>
                  </div>
                  <div className="absolute -top-1 -right-1 w-8 h-8 rounded-full bg-yellow-500 flex items-center justify-center">
                    <Star className="w-4 h-4 text-black fill-black" />
                  </div>
                </div>
                
                {/* Info */}
                <div className="flex-1 text-center md:text-left">
                  <Badge className="bg-yellow-500/20 text-yellow-500 border-yellow-500/30 mb-2">
                    <Crown className="w-3 h-3 mr-1" />
                    Certificado de Excelência
                  </Badge>
                  <h2 className="text-2xl font-bold text-yellow-500 mb-1">
                    Protocolo Vértice — Formação Completa
                  </h2>
                  <p className="text-muted-foreground mb-3">
                    Conclusão integral de todas as 4 trilhas · 120 horas de formação
                  </p>
                  
                  {/* 4 trail badges */}
                  <div className="flex flex-wrap gap-2 justify-center md:justify-start mb-4">
                    {Object.entries(categoryConfig).map(([key, config]) => (
                      <Badge key={key} variant="outline" className="border-yellow-500/30 text-yellow-500/80 gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        {config.name.split(" ")[0]}
                      </Badge>
                    ))}
                  </div>
                  
                  {/* Certificate details */}
                  <div className="flex flex-wrap gap-4 text-sm text-muted-foreground justify-center md:justify-start">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {new Date(generalCertificate.completionDate).toLocaleDateString('pt-BR')}
                    </span>
                    <span className="flex items-center gap-1 font-mono text-xs">
                      <Shield className="w-3.5 h-3.5" />
                      {generalCertificate.certificateNumber}
                    </span>
                  </div>
                </div>
                
                {/* Actions */}
                <div className="flex flex-col gap-2 shrink-0">
                  <Button 
                    className="gap-2 bg-gradient-to-r from-yellow-600 to-amber-600 hover:from-yellow-500 hover:to-amber-500 text-black font-semibold"
                    onClick={() => handleDownloadCertificate(generalCertificate.id)}
                  >
                    <Download className="h-4 w-4" />
                    Baixar PDF Premium
                  </Button>
                  <Button 
                    variant="outline"
                    className="gap-2 border-yellow-500/30 text-yellow-500 hover:bg-yellow-500/10"
                    onClick={() => handleShareCertificate(generalCertificate)}
                  >
                    <Share2 className="h-4 w-4" />
                    Compartilhar
                  </Button>
                  <Button
                    variant="outline"
                    className="gap-2 border-blue-500/30 text-blue-400 hover:bg-blue-500/10"
                    onClick={() => handleShareLinkedIn(generalCertificate)}
                  >
                    <Linkedin className="h-4 w-4" />
                    LinkedIn
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="gap-1 text-xs text-muted-foreground"
                    onClick={() => {
                      navigator.clipboard.writeText(generalCertificate.verificationCode);
                      toast.success("Código copiado!");
                    }}
                  >
                    <Copy className="h-3 w-3" />
                    Copiar código de verificação
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : completedCategoryCount === totalCategories ? (
          /* All categories done but general cert not yet generated - show CTA */
          <Card className="mb-8 border-yellow-500/30 bg-gradient-to-br from-yellow-500/5 to-background">
            <CardContent className="pt-6 pb-6 text-center">
              <Trophy className="w-12 h-12 mx-auto mb-3 text-yellow-500" />
              <h2 className="text-xl font-bold mb-2 text-yellow-500">Parabéns! Todas as trilhas concluídas!</h2>
              <p className="text-muted-foreground mb-4">
                Seu certificado premium "Protocolo Vértice — Formação Completa" será gerado automaticamente.
              </p>
              <Loader2 className="w-6 h-6 animate-spin mx-auto text-yellow-500" />
            </CardContent>
          </Card>
        ) : completedCategoryCount > 0 ? (
          /* Partial progress toward general certificate */
          <Card className="mb-8 border-border/50 bg-muted/20">
            <CardContent className="pt-6 pb-6">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-yellow-500/10 flex items-center justify-center shrink-0">
                  <Trophy className="w-7 h-7 text-yellow-500/50" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-sm text-muted-foreground mb-1">Certificado de Excelência</h3>
                  <p className="text-xs text-muted-foreground mb-2">
                    Complete todas as 4 trilhas para conquistar o certificado premium
                  </p>
                  <div className="flex items-center gap-2">
                    <Progress value={(completedCategoryCount / totalCategories) * 100} className="h-2 flex-1" />
                    <span className="text-xs font-medium text-muted-foreground">{completedCategoryCount}/{totalCategories}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : null}
        
        {/* Stats */}
        <div className="grid gap-6 md:grid-cols-3 mb-8">
          <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Certificados por Categoria</p>
                  <p className="text-3xl font-bold">{completedCategoryCount}/{totalCategories}</p>
                </div>
                <Award className="h-10 w-10 text-primary opacity-80" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Conteúdos Concluídos</p>
                  <p className="text-3xl font-bold">
                    {categoryProgress?.progress.reduce((acc, p) => acc + p.completed, 0) || 0}/
                    {categoryProgress?.progress.reduce((acc, p) => acc + p.total, 0) || 0}
                  </p>
                </div>
                <CheckCircle2 className="h-10 w-10 text-green-500 opacity-80" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Categorias Completas</p>
                  <p className="text-3xl font-bold">{categoryProgress?.completedCategories.length || 0}</p>
                </div>
                <Sparkles className="h-10 w-10 text-yellow-500 opacity-80" />
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="categories" className="space-y-6">
          <TabsList>
            <TabsTrigger value="categories">Por Categoria</TabsTrigger>
            <TabsTrigger value="programs">Por Programa</TabsTrigger>
          </TabsList>
          
          {/* Category Certificates */}
          <TabsContent value="categories">
            <div className="grid gap-6 md:grid-cols-2">
              {Object.entries(categoryConfig).map(([key, config]) => {
                const Icon = config.icon;
                const progress = getCategoryProgressData(key);
                const certificate = getCertificateForCategory(key);
                const isComplete = progress?.isComplete || false;
                const progressPercent = progress ? (progress.completed / progress.total) * 100 : 0;
                
                return (
                  <Card 
                    key={key} 
                    className={`relative overflow-hidden transition-all ${
                      certificate ? 'border-primary/50 bg-primary/5' : ''
                    }`}
                  >
                    {certificate && (
                      <div className="absolute top-4 right-4">
                        <Badge className="bg-primary text-primary-foreground gap-1">
                          <CheckCircle2 className="h-3 w-3" />
                          Conquistado
                        </Badge>
                      </div>
                    )}
                    
                    <CardHeader>
                      <div className="flex items-start gap-4">
                        <div className={`p-3 rounded-lg ${config.bgColor}`}>
                          <Icon className={`h-6 w-6 ${config.color}`} />
                        </div>
                        <div className="flex-1">
                          <CardTitle className="text-lg">{config.name}</CardTitle>
                          <CardDescription className="mt-1">
                            {config.description}
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      {/* Progress */}
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Progresso</span>
                          <span className="font-medium">
                            {progress?.completed || 0}/{progress?.total || 0} conteúdos
                          </span>
                        </div>
                        <Progress value={progressPercent} className="h-2" />
                      </div>
                      
                      {/* Actions */}
                      {certificate ? (
                        <div className="space-y-2">
                          <div className="flex gap-2">
                            <Button 
                              className="flex-1 gap-2"
                              onClick={() => handleDownloadCertificate(certificate.id)}
                            >
                              <Download className="h-4 w-4" />
                              Baixar PDF
                            </Button>
                            <Button 
                              variant="outline"
                              size="icon"
                              onClick={() => handleShareCertificate(certificate)}
                              title="Compartilhar"
                            >
                              <Share2 className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="outline"
                              size="icon"
                              onClick={() => handleShareLinkedIn(certificate)}
                              title="Compartilhar no LinkedIn"
                              className="border-blue-500/30 text-blue-400 hover:bg-blue-500/10"
                            >
                              <Linkedin className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ) : isComplete ? (
                        <Button 
                          className="w-full gap-2"
                          onClick={() => handleGenerateCertificate(key)}
                          disabled={generatingCategory === key}
                        >
                          {generatingCategory === key ? (
                            <>
                              <Loader2 className="h-4 w-4 animate-spin" />
                              Gerando...
                            </>
                          ) : (
                            <>
                              <Award className="h-4 w-4" />
                              Gerar Certificado
                            </>
                          )}
                        </Button>
                      ) : (
                        <Button variant="outline" className="w-full gap-2" disabled>
                          <Lock className="h-4 w-4" />
                          Complete {progress?.total ? progress.total - (progress?.completed || 0) : 0} conteúdos restantes
                        </Button>
                      )}
                      
                      {/* Certificate Info */}
                      {certificate && (
                        <div className="pt-4 border-t border-border/50 space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Número</span>
                            <span className="font-mono">{certificate.certificateNumber}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Data</span>
                            <span>{new Date(certificate.completionDate).toLocaleDateString('pt-BR')}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">Verificação</span>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-auto py-1 px-2 gap-1 text-xs"
                              onClick={() => {
                                navigator.clipboard.writeText(certificate.verificationCode);
                                toast.success("Código copiado!");
                              }}
                            >
                              <Copy className="h-3 w-3" />
                              {certificate.verificationCode.substring(0, 12)}...
                            </Button>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
          
          {/* Program Certificates */}
          <TabsContent value="programs">
            {programCertificates.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                {programCertificates.map((cert) => (
                  <Card key={cert.id} className="bg-card/50 border-border/50 overflow-hidden">
                    <div className="h-2 bg-gradient-to-r from-primary to-primary/50" />
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                          <Award className="w-6 h-6 text-primary" />
                        </div>
                        <Badge className="bg-green-500/10 text-green-500">
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          Válido
                        </Badge>
                      </div>
                      <CardTitle className="mt-4">Certificado de Conclusão</CardTitle>
                      <CardDescription>Programa #{cert.programId}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Calendar className="w-4 h-4" />
                          Emitido em: {new Date(cert.completionDate).toLocaleDateString("pt-BR")}
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Shield className="w-4 h-4" />
                          Código: {cert.certificateNumber}
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          className="flex-1"
                          onClick={() => handleDownloadCertificate(cert.id)}
                        >
                          <Download className="w-4 h-4 mr-2" />
                          Baixar PDF
                        </Button>
                        <Button asChild variant="outline" size="sm">
                          <Link href={`/verificar-certificado?code=${cert.verificationCode}`}>
                            <ExternalLink className="w-4 h-4" />
                          </Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="bg-card/50 border-border/50">
                <CardContent className="py-12 text-center">
                  <Award className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                  <h3 className="text-xl font-semibold mb-2">Nenhum certificado de programa ainda</h3>
                  <p className="text-muted-foreground mb-6">
                    Complete todos os módulos e quizzes de um programa para gerar seu certificado.
                  </p>
                </CardContent>
              </Card>
            )}
            
            {/* Programs Available for Certification */}
            {activeEnrollments.length > 0 && (
              <div className="mt-8">
                <h2 className="text-xl font-bold mb-4">Programas em Andamento</h2>
                <div className="grid md:grid-cols-2 gap-6">
                  {activeEnrollments.map((enrollment) => {
                    const hasCertificate = programCertificates.some(c => c.programId === enrollment.programId);
                    
                    return (
                      <Card key={enrollment.id} className="bg-card/50 border-border/50">
                        <CardHeader>
                          <CardTitle className="text-lg">Programa #{enrollment.programId}</CardTitle>
                          <CardDescription>
                            Matrícula ativa desde {new Date(enrollment.startDate || enrollment.createdAt).toLocaleDateString("pt-BR")}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          {hasCertificate ? (
                            <Badge className="bg-green-500/10 text-green-500">
                              <CheckCircle2 className="w-3 h-3 mr-1" />
                              Certificado Emitido
                            </Badge>
                          ) : (
                            <Button
                              onClick={() => generateProgramCertificate.mutate({ programId: enrollment.programId })}
                              disabled={generateProgramCertificate.isPending}
                              size="sm"
                            >
                              {generateProgramCertificate.isPending ? (
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              ) : (
                                <Award className="w-4 h-4 mr-2" />
                              )}
                              Gerar Certificado
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        {/* Rules Section - Regras visíveis */}
        <Card className="mt-8 bg-muted/30 border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4 mb-6">
              <div className="p-3 rounded-lg bg-primary/10">
                <Info className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Como funcionam os certificados?</h3>
                <p className="text-sm text-muted-foreground">
                  Siga as regras abaixo para conquistar seus certificados.
                </p>
              </div>
            </div>
            
            <div className="grid md:grid-cols-2 gap-4">
              {/* Regra 1 */}
              <div className="p-4 rounded-lg bg-card/50 border border-border/30">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">1</div>
                  <h4 className="font-medium text-sm">Complete todos os conteúdos</h4>
                </div>
                <p className="text-xs text-muted-foreground">
                  Marque cada módulo como concluído na Área de Membros. O progresso é atualizado automaticamente.
                </p>
              </div>
              
              {/* Regra 2 */}
              <div className="p-4 rounded-lg bg-card/50 border border-border/30">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">2</div>
                  <h4 className="font-medium text-sm">Gere o certificado da trilha</h4>
                </div>
                <p className="text-xs text-muted-foreground">
                  Ao completar 100% de uma trilha, o botão "Gerar Certificado" será habilitado. Clique para emitir.
                </p>
              </div>
              
              {/* Regra 3 */}
              <div className="p-4 rounded-lg bg-card/50 border border-border/30">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">3</div>
                  <h4 className="font-medium text-sm">Compartilhe no LinkedIn</h4>
                </div>
                <p className="text-xs text-muted-foreground">
                  Use o botão <Linkedin className="w-3 h-3 inline text-blue-400" /> para publicar diretamente no seu perfil profissional.
                </p>
              </div>
              
              {/* Regra 4 */}
              <div className="p-4 rounded-lg bg-yellow-500/5 border border-yellow-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 rounded-full bg-yellow-500/20 flex items-center justify-center text-xs font-bold text-yellow-500">
                    <Star className="w-3 h-3" />
                  </div>
                  <h4 className="font-medium text-sm text-yellow-500">Certificado de Excelência</h4>
                </div>
                <p className="text-xs text-muted-foreground">
                  Complete as 4 trilhas (Introdução, CX, Dados e IA) para ganhar o certificado premium com design exclusivo em ouro.
                </p>
              </div>
            </div>
            
            <div className="mt-4 p-3 rounded-lg bg-primary/5 border border-primary/10 flex items-center gap-3">
              <Shield className="w-5 h-5 text-primary flex-shrink-0" />
              <p className="text-xs text-muted-foreground">
                <strong className="text-foreground">Verificação:</strong> Cada certificado possui um código único. Qualquer pessoa pode verificar a autenticidade em{" "}
                <Link href="/verificar-certificado" className="text-primary hover:underline">/verificar-certificado</Link>.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Footer />
    </div>
  );
}
