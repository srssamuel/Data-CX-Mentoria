import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO, { PAGE_SEO } from "@/components/SEO";
import {
  ArrowRight,
  CheckCircle2,
  Building2,
  Users,
  Award,
  Target,
  Briefcase,
  Quote,
} from "lucide-react";

const segments = [
  "Financeiro",
  "Mobilidade",
  "Saúde",
  "Seguros",
  "Delivery",
  "Telecom",
  "E-commerce",
  "Varejo",
  "Tecnologia",
  "Serviços",
];

const pillars = [
  {
    title: "CX é sistema, não projeto",
    description: "Experiência do cliente melhora com métrica certa, dono claro, rotina de calibração e priorização.",
    icon: Target,
  },
  {
    title: "Dados são motor, não estética",
    description: "Dashboard não é vitrine. É cockpit. Dado vira decisão e ação.",
    icon: Building2,
  },
  {
    title: "IA é escala, não mágica",
    description: "IA reduz custo, amplia leitura e acelera insight, mas sempre com curadoria e controle.",
    icon: Award,
  },
  {
    title: "Governança separa piloto de resultado",
    description: "Quase todo mundo consegue testar. Pouca gente sabe operar.",
    icon: Briefcase,
  },
];

const quotes = [
  "Sem achismo. Com evidência.",
  "Indicador é sensor, não troféu.",
  "IA é alavanca. Governança é freio e volante.",
  "CX bom é o que reduz atrito e aumenta confiança.",
  "Clareza pra decidir. Cadência pra executar.",
  "Menos slide. Mais sistema.",
];

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      <SEO title={PAGE_SEO.sobre.title} description={PAGE_SEO.sobre.description} path="/sobre" />
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="absolute inset-0 bg-radial" />

        <div className="container relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
                Sobre o Mentor
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                Samuel <span className="gradient-text">Rosa</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-6">
                Executivo de Qualidade e Customer Experience que opera no ponto raro onde poucas pessoas conseguem ficar confortáveis: <strong className="text-foreground">negócio + operação + dados + tecnologia</strong>.
              </p>
              <p className="text-muted-foreground mb-8">
                Não sou "evangelista de ferramenta" e nem "consultor de slide". Minha reputação vem do mundo real: volume alto, pressão por meta, time grande, contratos exigentes, e decisões que precisam funcionar na prática.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/ofertas">
                  <Button className="bg-primary hover:bg-primary/90">
                    Conhecer as Mentorias
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
                <Link href="/contato">
                  <Button variant="outline">
                    Agendar Conversa
                  </Button>
                </Link>
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-3xl blur-3xl" />
              <Card className="relative bg-card border-border/50 overflow-hidden">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center overflow-hidden">
                    <img 
                      src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/MtNKHhWTMcGIDMFy.jpeg" 
                      alt="Samuel Rosa - Executivo de CX & Qualidade"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="font-semibold text-lg mb-1">Samuel Rosa</h3>
                    <p className="text-muted-foreground text-sm mb-4">Executivo de CX & Qualidade</p>
                    <div className="flex gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-primary">+70</div>
                        <div className="text-xs text-muted-foreground">Clientes</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-primary">+10</div>
                        <div className="text-xs text-muted-foreground">Segmentos</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-primary">15+</div>
                        <div className="text-xs text-muted-foreground">Anos</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Specialty */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Especialidade: <span className="gradient-text">Transformar Caos em Sistema</span>
            </h2>
            <p className="text-muted-foreground text-lg">
              Onde muita gente vê "problema de atendimento", eu enxergo um ecossistema: jornada quebrada, indicador mal definido, ruído de processo, falha de comunicação, dado sem granularidade e governança fraca.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {pillars.map((pillar, index) => (
              <Card key={index} className="bg-card/50 border-border/50 hover:border-primary/50 transition-all">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                    <pillar.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">{pillar.title}</h3>
                  <p className="text-muted-foreground text-sm">{pillar.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Experience */}
      <section className="py-20">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Experiência em <span className="gradient-text">+70 Clientes</span>
              </h2>
              <p className="text-muted-foreground mb-6">
                Atuação em ambientes de alta exigência e alta escala, com foco em provar valor com evidência. Experiência prática em diversos segmentos do mercado brasileiro.
              </p>

              <div className="flex flex-wrap gap-2 mb-8">
                {segments.map((segment) => (
                  <span
                    key={segment}
                    className="px-4 py-2 rounded-lg bg-secondary text-secondary-foreground text-sm"
                  >
                    {segment}
                  </span>
                ))}
              </div>

              <div className="space-y-3">
                {[
                  "Operações de alta escala com milhões de interações",
                  "Implementação de governança de dados e IA",
                  "Transformação de áreas de CX e Qualidade",
                  "Criação de modelos de maturidade e roadmaps",
                ].map((item, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
                    <span className="text-foreground">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: Users, label: "Clientes Atendidos", value: "+70" },
                { icon: Building2, label: "Segmentos", value: "+10" },
                { icon: Award, label: "Anos de Experiência", value: "15+" },
                { icon: Target, label: "Projetos Entregues", value: "+100" },
              ].map((stat, index) => (
                <Card key={index} className="bg-card/50 border-border/50">
                  <CardContent className="p-6 text-center">
                    <stat.icon className="w-8 h-8 text-primary mx-auto mb-3" />
                    <div className="text-3xl font-bold text-primary mb-1">{stat.value}</div>
                    <div className="text-muted-foreground text-sm">{stat.label}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Quotes */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Frases <span className="gradient-text">Assinatura</span>
            </h2>
            <p className="text-muted-foreground">
              Princípios que guiam minha atuação
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {quotes.map((quote, index) => (
              <Card key={index} className="bg-card/50 border-border/50 hover:border-primary/50 transition-colors">
                <CardContent className="p-6">
                  <Quote className="w-8 h-8 text-primary/30 mb-3" />
                  <p className="text-lg font-medium">{quote}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Text */}
      <section className="py-20">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <Card className="bg-gradient-to-br from-card to-card/50 border-primary/20">
              <CardContent className="p-8 md:p-12">
                <h3 className="text-2xl font-bold mb-6">Sobre Mim</h3>
                <div className="prose prose-invert max-w-none">
                  <p className="text-muted-foreground text-lg leading-relaxed">
                    Sou Samuel Rosa, executivo de Qualidade e CX, com atuação prática em operações de alta escala, conectando experiência do cliente, dados e IA para gerar eficiência e resultado real.
                  </p>
                  <p className="text-muted-foreground text-lg leading-relaxed mt-4">
                    Eu ajudo pessoas e empresas a saírem do "relatório bonito" e entrarem no modo sistema: indicadores que explicam causa, governança que sustenta rotina e tecnologia que escala com controle.
                  </p>
                  <p className="text-foreground text-lg leading-relaxed mt-4 font-medium">
                    Meu trabalho é transformar complexidade em clareza — e clareza em execução.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/10" />
        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Pronto para trabalhar comigo?
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              Escolha a modalidade de mentoria que melhor se encaixa no seu momento e vamos transformar sua operação juntos.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/ofertas">
                <Button size="lg" className="bg-primary hover:bg-primary/90 px-8">
                  Ver Ofertas de Mentoria
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link href="/contato">
                <Button size="lg" variant="outline" className="px-8">
                  Agendar Diagnóstico Gratuito
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
