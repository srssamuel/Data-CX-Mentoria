import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { trpc } from "@/lib/trpc";
import {
  User,
  Mail,
  Calendar,
  Shield,
  BookOpen,
  ArrowRight,
  Lock,
  Loader2,
  LogOut,
  CheckCircle2,
  Trophy,
  Star,
  Target,
  Zap,
  Award,
  TrendingUp,
  Clock,
  Share2,
  Medal,
  Flame,
  Crown,
  Sparkles,
  GraduationCap,
  Brain,
  Database,
  BarChart3,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import ShareBadgeModal from "@/components/ShareBadgeModal";

// Progress Ring Component
function ProgressRing({ progress, size = 120, strokeWidth = 8 }: { progress: number; size?: number; strokeWidth?: number }) {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg className="transform -rotate-90" width={size} height={size}>
        <circle
          className="text-muted/20"
          strokeWidth={strokeWidth}
          stroke="currentColor"
          fill="transparent"
          r={radius}
          cx={size / 2}
          cy={size / 2}
        />
        <circle
          className="text-primary transition-all duration-500"
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          stroke="currentColor"
          fill="transparent"
          r={radius}
          cx={size / 2}
          cy={size / 2}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-2xl font-bold">{progress}%</span>
        <span className="text-xs text-muted-foreground">Concluído</span>
      </div>
    </div>
  );
}

// Badge Card Component
function BadgeCard({ badge, earned, onShare }: { badge: any; earned: boolean; onShare?: (badge: any) => void }) {
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "progress": return <Target className="w-5 h-5" />;
      case "engagement": return <Flame className="w-5 h-5" />;
      case "achievement": return <Trophy className="w-5 h-5" />;
      case "special": return <Crown className="w-5 h-5" />;
      default: return <Medal className="w-5 h-5" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "progress": return "from-blue-500 to-cyan-500";
      case "engagement": return "from-orange-500 to-red-500";
      case "achievement": return "from-purple-500 to-pink-500";
      case "special": return "from-yellow-500 to-amber-500";
      default: return "from-gray-500 to-slate-500";
    }
  };

  return (
    <div
      className={`relative p-4 rounded-xl border transition-all duration-300 ${
        earned
          ? "bg-gradient-to-br from-primary/10 to-accent/10 border-primary/30 shadow-lg shadow-primary/10"
          : "bg-card/30 border-border/30 opacity-50 grayscale"
      }`}
    >
      {earned && (
        <div className="absolute -top-2 -right-2">
          <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">
            <CheckCircle2 className="w-4 h-4 text-white" />
          </div>
        </div>
      )}
      <div className="flex flex-col items-center text-center gap-3">
        <div
          className={`w-16 h-16 rounded-full bg-gradient-to-br ${getCategoryColor(badge.category)} flex items-center justify-center text-white shadow-lg`}
        >
          {getCategoryIcon(badge.category)}
        </div>
        <div>
          <h4 className="font-semibold text-sm">{badge.name}</h4>
          <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{badge.description}</p>
        </div>
        {badge.pointsReward > 0 && (
          <Badge variant="secondary" className="text-xs">
            +{badge.pointsReward} pts
          </Badge>
        )}
        {earned && badge.earnedAt && (
          <p className="text-xs text-muted-foreground">
            Conquistada em {new Date(badge.earnedAt).toLocaleDateString("pt-BR")}
          </p>
        )}
        {earned && onShare && (
          <Button 
            variant="ghost" 
            size="sm" 
            className="mt-2 text-xs h-7"
            onClick={(e) => {
              e.stopPropagation();
              onShare(badge);
            }}
          >
            <Share2 className="w-3 h-3 mr-1" />
            Compartilhar
          </Button>
        )}
      </div>
    </div>
  );
}

// Level Badge Component
function LevelBadge({ level, levelName, points }: { level: number; levelName: string; points: number }) {
  const getLevelColor = (level: number) => {
    switch (level) {
      case 1: return "from-slate-400 to-slate-600";
      case 2: return "from-green-400 to-emerald-600";
      case 3: return "from-blue-400 to-indigo-600";
      case 4: return "from-purple-400 to-violet-600";
      case 5: return "from-orange-400 to-red-600";
      case 6: return "from-yellow-400 to-amber-600";
      case 7: return "from-pink-400 to-rose-600";
      default: return "from-gray-400 to-gray-600";
    }
  };

  const getNextLevelPoints = (level: number) => {
    const levels = [0, 100, 300, 600, 1000, 2000, 5000, Infinity];
    return levels[level] || Infinity;
  };

  const nextLevelPoints = getNextLevelPoints(level);
  const currentLevelPoints = getNextLevelPoints(level - 1);
  const progressToNext = nextLevelPoints === Infinity 
    ? 100 
    : Math.round(((points - currentLevelPoints) / (nextLevelPoints - currentLevelPoints)) * 100);

  return (
    <div className="flex items-center gap-4 p-4 rounded-xl bg-gradient-to-r from-card to-card/50 border border-border/50">
      <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${getLevelColor(level)} flex items-center justify-center text-white shadow-lg`}>
        <span className="text-2xl font-bold">{level}</span>
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1">
          <h3 className="font-bold text-lg">{levelName}</h3>
          <Sparkles className="w-4 h-4 text-yellow-500" />
        </div>
        <p className="text-sm text-muted-foreground mb-2">
          {points.toLocaleString()} pontos totais
        </p>
        {nextLevelPoints !== Infinity && (
          <div className="space-y-1">
            <Progress value={progressToNext} className="h-2" />
            <p className="text-xs text-muted-foreground">
              {nextLevelPoints - points} pontos para o próximo nível
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

// Category Progress Card
function CategoryProgressCard({ 
  category, 
  completed, 
  total, 
  icon: Icon, 
  color 
}: { 
  category: string; 
  completed: number; 
  total: number; 
  icon: any; 
  color: string;
}) {
  const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;

  return (
    <div className="p-4 rounded-xl bg-card/50 border border-border/50">
      <div className="flex items-center gap-3 mb-3">
        <div className={`w-10 h-10 rounded-lg ${color} flex items-center justify-center`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        <div>
          <h4 className="font-medium">{category}</h4>
          <p className="text-xs text-muted-foreground">{completed}/{total} conteúdos</p>
        </div>
      </div>
      <Progress value={percentage} className="h-2" />
      <p className="text-xs text-muted-foreground mt-1 text-right">{percentage}%</p>
    </div>
  );
}

export default function Profile() {
  const { user, isAuthenticated, loading, logout } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");
  const [shareBadge, setShareBadge] = useState<any>(null);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  const handleShareBadge = (badge: any) => {
    setShareBadge(badge);
    setIsShareModalOpen(true);
  };
  
  const { data: stats, isLoading: statsLoading } = trpc.gamification.myStats.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const handleLogout = async () => {
    await logout();
    window.location.href = "/";
  };

  const handleShareProfile = async () => {
    const shareData = {
      title: `Perfil de ${user?.name} - Data CX`,
      text: `Confira meu progresso no Protocolo Vértice! Nível ${stats?.points?.level}: ${stats?.points?.levelName} com ${stats?.progress?.completed} conteúdos concluídos.`,
      url: window.location.href,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.log("Share cancelled");
      }
    } else {
      await navigator.clipboard.writeText(shareData.url);
      toast.success("Link copiado para a área de transferência!");
    }
  };

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-32 pb-20 flex items-center justify-center min-h-[80vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
        <Footer />
      </div>
    );
  }

  // Not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <section className="pt-32 pb-20 min-h-[80vh] flex items-center">
          <div className="container">
            <div className="max-w-lg mx-auto text-center">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                <Lock className="w-10 h-10 text-primary" />
              </div>
              <h1 className="text-3xl font-bold mb-4">Acesso Restrito</h1>
              <p className="text-muted-foreground mb-8">
                Faça login para acessar seu perfil.
              </p>
              <a href={getLoginUrl()}>
                <Button className="bg-primary hover:bg-primary/90">
                  Fazer Login
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </a>
            </div>
          </div>
        </section>
        <Footer />
      </div>
    );
  }

  const earnedBadges = stats?.badges?.filter((b: any) => b.earned) || [];
  const lockedBadges = stats?.badges?.filter((b: any) => !b.earned) || [];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Header */}
      <section className="pt-32 pb-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="absolute inset-0 bg-radial" />

        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row items-center gap-6 mb-8">
              <div className="relative">
                <Avatar className="w-28 h-28 border-4 border-primary/30">
                  <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-white text-4xl">
                    {user?.name?.charAt(0) || "U"}
                  </AvatarFallback>
                </Avatar>
                {stats?.points && (
                  <div className="absolute -bottom-2 -right-2 w-10 h-10 rounded-full bg-gradient-to-br from-yellow-400 to-amber-600 flex items-center justify-center text-white font-bold shadow-lg">
                    {stats.points.level}
                  </div>
                )}
              </div>
              <div className="text-center md:text-left flex-1">
                <h1 className="text-3xl font-bold mb-1">{user?.name || "Usuário"}</h1>
                <p className="text-muted-foreground mb-2">{user?.email}</p>
                <div className="flex gap-2 flex-wrap justify-center md:justify-start">
                  <Badge className={user?.role === "admin" ? "bg-primary/10 text-primary" : ""}>
                    {user?.role === "admin" ? "Administrador" : "Membro"}
                  </Badge>
                  {stats?.points && (
                    <Badge variant="outline" className="border-yellow-500/50 text-yellow-500">
                      <Star className="w-3 h-3 mr-1" />
                      {stats.points.levelName}
                    </Badge>
                  )}
                  <Badge variant="outline">
                    <Calendar className="w-3 h-3 mr-1" />
                    Desde {user?.createdAt ? new Date(user.createdAt).toLocaleDateString("pt-BR", { month: "short", year: "numeric" }) : "-"}
                  </Badge>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleShareProfile}>
                  <Share2 className="w-4 h-4 mr-2" />
                  Compartilhar
                </Button>
              </div>
            </div>

            {/* Quick Stats */}
            {statsLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-primary" />
              </div>
            ) : stats && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card className="bg-card/50 border-border/50">
                  <CardContent className="p-4 text-center">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                      <Zap className="w-5 h-5 text-primary" />
                    </div>
                    <p className="text-2xl font-bold">{stats.points?.points?.toLocaleString() || 0}</p>
                    <p className="text-xs text-muted-foreground">Pontos</p>
                  </CardContent>
                </Card>
                <Card className="bg-card/50 border-border/50">
                  <CardContent className="p-4 text-center">
                    <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-2">
                      <CheckCircle2 className="w-5 h-5 text-green-500" />
                    </div>
                    <p className="text-2xl font-bold">{stats.progress?.completed || 0}</p>
                    <p className="text-xs text-muted-foreground">Concluídos</p>
                  </CardContent>
                </Card>
                <Card className="bg-card/50 border-border/50">
                  <CardContent className="p-4 text-center">
                    <div className="w-10 h-10 rounded-full bg-yellow-500/10 flex items-center justify-center mx-auto mb-2">
                      <Trophy className="w-5 h-5 text-yellow-500" />
                    </div>
                    <p className="text-2xl font-bold">{stats.earnedBadgesCount || 0}</p>
                    <p className="text-xs text-muted-foreground">Medalhas</p>
                  </CardContent>
                </Card>
                <Card className="bg-card/50 border-border/50">
                  <CardContent className="p-4 text-center">
                    <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center mx-auto mb-2">
                      <BookOpen className="w-5 h-5 text-blue-500" />
                    </div>
                    <p className="text-2xl font-bold">{stats.enrollments || 0}</p>
                    <p className="text-xs text-muted-foreground">Mentorias</p>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-4 bg-card/50">
                <TabsTrigger value="overview">Visão Geral</TabsTrigger>
                <TabsTrigger value="badges">Medalhas</TabsTrigger>
                <TabsTrigger value="progress">Progresso</TabsTrigger>
                <TabsTrigger value="account">Conta</TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-6">
                {stats && (
                  <>
                    {/* Level Card */}
                    <LevelBadge 
                      level={stats.points?.level || 1} 
                      levelName={stats.points?.levelName || "Iniciante"} 
                      points={stats.points?.totalPointsEarned || 0} 
                    />

                    {/* Progress Overview */}
                    <Card className="bg-card/50 border-border/50">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <TrendingUp className="w-5 h-5" />
                          Progresso Geral
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex flex-col md:flex-row items-center gap-8">
                          <ProgressRing progress={stats.progress?.percentage || 0} size={140} strokeWidth={10} />
                          <div className="flex-1 grid grid-cols-2 gap-4">
                            <CategoryProgressCard
                              category="Introdução"
                              completed={stats.progress?.byCategory?.introducao?.completed || 0}
                              total={stats.progress?.byCategory?.introducao?.total || 0}
                              icon={GraduationCap}
                              color="bg-blue-500"
                            />
                            <CategoryProgressCard
                              category="CX"
                              completed={stats.progress?.byCategory?.cx?.completed || 0}
                              total={stats.progress?.byCategory?.cx?.total || 0}
                              icon={Target}
                              color="bg-green-500"
                            />
                            <CategoryProgressCard
                              category="Dados"
                              completed={stats.progress?.byCategory?.dados?.completed || 0}
                              total={stats.progress?.byCategory?.dados?.total || 0}
                              icon={Database}
                              color="bg-purple-500"
                            />
                            <CategoryProgressCard
                              category="IA"
                              completed={stats.progress?.byCategory?.ia?.completed || 0}
                              total={stats.progress?.byCategory?.ia?.total || 0}
                              icon={Brain}
                              color="bg-orange-500"
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Recent Badges */}
                    {earnedBadges.length > 0 && (
                      <Card className="bg-card/50 border-border/50">
                        <CardHeader>
                          <CardTitle className="flex items-center justify-between">
                            <span className="flex items-center gap-2">
                              <Trophy className="w-5 h-5 text-yellow-500" />
                              Medalhas Recentes
                            </span>
                            <Button variant="ghost" size="sm" onClick={() => setActiveTab("badges")}>
                              Ver todas
                              <ArrowRight className="w-4 h-4 ml-1" />
                            </Button>
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            {earnedBadges.slice(0, 4).map((badge: any) => (
                              <BadgeCard key={badge.id} badge={badge} earned={true} onShare={handleShareBadge} />
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Recent Activity */}
                    {stats.recentActivity && stats.recentActivity.length > 0 && (
                      <Card className="bg-card/50 border-border/50">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <Clock className="w-5 h-5" />
                            Atividade Recente
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            {stats.recentActivity.slice(0, 5).map((activity: any, index: number) => (
                              <div key={index} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                                <div className="flex items-center gap-3">
                                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                    activity.type === "earned" ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                                  }`}>
                                    {activity.type === "earned" ? <TrendingUp className="w-4 h-4" /> : <TrendingUp className="w-4 h-4 rotate-180" />}
                                  </div>
                                  <div>
                                    <p className="text-sm font-medium">{activity.reason}</p>
                                    <p className="text-xs text-muted-foreground">
                                      {new Date(activity.createdAt).toLocaleDateString("pt-BR")}
                                    </p>
                                  </div>
                                </div>
                                <Badge variant={activity.type === "earned" ? "default" : "destructive"}>
                                  {activity.type === "earned" ? "+" : ""}{activity.points} pts
                                </Badge>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </>
                )}
              </TabsContent>

              {/* Badges Tab */}
              <TabsContent value="badges" className="space-y-6">
                {/* Earned Badges */}
                <Card className="bg-card/50 border-border/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Trophy className="w-5 h-5 text-yellow-500" />
                      Medalhas Conquistadas ({earnedBadges.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {earnedBadges.length > 0 ? (
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {earnedBadges.map((badge: any) => (
                          <BadgeCard key={badge.id} badge={badge} earned={true} onShare={handleShareBadge} />
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <Medal className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                        <p className="text-muted-foreground">Você ainda não conquistou nenhuma medalha.</p>
                        <p className="text-sm text-muted-foreground mt-2">Complete conteúdos e participe da comunidade para ganhar medalhas!</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Locked Badges */}
                {lockedBadges.length > 0 && (
                  <Card className="bg-card/50 border-border/50">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Lock className="w-5 h-5 text-muted-foreground" />
                        Medalhas Disponíveis ({lockedBadges.length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {lockedBadges.map((badge: any) => (
                          <BadgeCard key={badge.id} badge={badge} earned={false} />
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              {/* Progress Tab */}
              <TabsContent value="progress" className="space-y-6">
                {stats && (
                  <>
                    <Card className="bg-card/50 border-border/50">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <BarChart3 className="w-5 h-5" />
                          Progresso Detalhado
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex flex-col items-center gap-8">
                          <ProgressRing progress={stats.progress?.percentage || 0} size={180} strokeWidth={12} />
                          <div className="text-center">
                            <p className="text-lg font-medium">
                              {stats.progress?.completed || 0} de {stats.progress?.total || 0} conteúdos concluídos
                            </p>
                            <p className="text-muted-foreground">
                              Faltam {(stats.progress?.total || 0) - (stats.progress?.completed || 0)} conteúdos para completar sua jornada
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <div className="grid md:grid-cols-2 gap-4">
                      <Card className="bg-card/50 border-border/50">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base flex items-center gap-2">
                            <GraduationCap className="w-4 h-4 text-blue-500" />
                            Introdução
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>{stats.progress?.byCategory?.introducao?.completed || 0} concluídos</span>
                              <span className="text-muted-foreground">{stats.progress?.byCategory?.introducao?.total || 0} total</span>
                            </div>
                            <Progress 
                              value={stats.progress?.byCategory?.introducao?.total ? 
                                (stats.progress.byCategory.introducao.completed / stats.progress.byCategory.introducao.total) * 100 : 0} 
                              className="h-3"
                            />
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="bg-card/50 border-border/50">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base flex items-center gap-2">
                            <Target className="w-4 h-4 text-green-500" />
                            Customer Experience
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>{stats.progress?.byCategory?.cx?.completed || 0} concluídos</span>
                              <span className="text-muted-foreground">{stats.progress?.byCategory?.cx?.total || 0} total</span>
                            </div>
                            <Progress 
                              value={stats.progress?.byCategory?.cx?.total ? 
                                (stats.progress.byCategory.cx.completed / stats.progress.byCategory.cx.total) * 100 : 0} 
                              className="h-3"
                            />
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="bg-card/50 border-border/50">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base flex items-center gap-2">
                            <Database className="w-4 h-4 text-purple-500" />
                            Dados
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>{stats.progress?.byCategory?.dados?.completed || 0} concluídos</span>
                              <span className="text-muted-foreground">{stats.progress?.byCategory?.dados?.total || 0} total</span>
                            </div>
                            <Progress 
                              value={stats.progress?.byCategory?.dados?.total ? 
                                (stats.progress.byCategory.dados.completed / stats.progress.byCategory.dados.total) * 100 : 0} 
                              className="h-3"
                            />
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="bg-card/50 border-border/50">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base flex items-center gap-2">
                            <Brain className="w-4 h-4 text-orange-500" />
                            Inteligência Artificial
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>{stats.progress?.byCategory?.ia?.completed || 0} concluídos</span>
                              <span className="text-muted-foreground">{stats.progress?.byCategory?.ia?.total || 0} total</span>
                            </div>
                            <Progress 
                              value={stats.progress?.byCategory?.ia?.total ? 
                                (stats.progress.byCategory.ia.completed / stats.progress.byCategory.ia.total) * 100 : 0} 
                              className="h-3"
                            />
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="text-center">
                      <Link href="/membros">
                        <Button>
                          <BookOpen className="w-4 h-4 mr-2" />
                          Continuar Estudando
                        </Button>
                      </Link>
                    </div>
                  </>
                )}
              </TabsContent>

              {/* Account Tab */}
              <TabsContent value="account" className="space-y-6">
                <Card className="bg-card/50 border-border/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <User className="w-5 h-5" />
                      Informações da Conta
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between py-3 border-b border-border">
                      <div className="flex items-center gap-3">
                        <User className="w-4 h-4 text-muted-foreground" />
                        <span className="text-muted-foreground">Nome</span>
                      </div>
                      <span className="font-medium">{user?.name || "-"}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-border">
                      <div className="flex items-center gap-3">
                        <Mail className="w-4 h-4 text-muted-foreground" />
                        <span className="text-muted-foreground">E-mail</span>
                      </div>
                      <span className="font-medium">{user?.email || "-"}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-border">
                      <div className="flex items-center gap-3">
                        <Shield className="w-4 h-4 text-muted-foreground" />
                        <span className="text-muted-foreground">Tipo de Conta</span>
                      </div>
                      <Badge className={user?.role === "admin" ? "bg-primary/10 text-primary" : ""}>
                        {user?.role === "admin" ? "Administrador" : "Membro"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between py-3">
                      <div className="flex items-center gap-3">
                        <Calendar className="w-4 h-4 text-muted-foreground" />
                        <span className="text-muted-foreground">Membro desde</span>
                      </div>
                      <span className="font-medium">
                        {user?.createdAt
                          ? new Date(user.createdAt).toLocaleDateString("pt-BR", {
                              day: "numeric",
                              month: "long",
                              year: "numeric",
                            })
                          : "-"}
                      </span>
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Links */}
                <Card className="bg-card/50 border-border/50">
                  <CardHeader>
                    <CardTitle>Acesso Rápido</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Link href="/membros">
                      <Button variant="ghost" className="w-full justify-start">
                        <BookOpen className="w-4 h-4 mr-2" />
                        Área de Membros
                        <ArrowRight className="w-4 h-4 ml-auto" />
                      </Button>
                    </Link>
                    <Link href="/ofertas">
                      <Button variant="ghost" className="w-full justify-start">
                        <Shield className="w-4 h-4 mr-2" />
                        Ver Ofertas de Mentoria
                        <ArrowRight className="w-4 h-4 ml-auto" />
                      </Button>
                    </Link>
                    <Link href="/certificados">
                      <Button variant="ghost" className="w-full justify-start">
                        <Award className="w-4 h-4 mr-2" />
                        Meus Certificados
                        <ArrowRight className="w-4 h-4 ml-auto" />
                      </Button>
                    </Link>
                    {user?.role === "admin" && (
                      <Link href="/admin">
                        <Button variant="ghost" className="w-full justify-start">
                          <Shield className="w-4 h-4 mr-2" />
                          Painel Administrativo
                          <ArrowRight className="w-4 h-4 ml-auto" />
                        </Button>
                      </Link>
                    )}
                  </CardContent>
                </Card>

                {/* Logout */}
                <Card className="bg-card/50 border-border/50">
                  <CardContent className="p-6">
                    <Button
                      variant="outline"
                      className="w-full text-destructive hover:text-destructive hover:bg-destructive/10"
                      onClick={handleLogout}
                    >
                      <LogOut className="w-4 h-4 mr-2" />
                      Sair da Conta
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>

      <Footer />

      {/* Share Badge Modal */}
      <ShareBadgeModal
        badge={shareBadge}
        userName={user?.name || "Usuário"}
        isOpen={isShareModalOpen}
        onClose={() => {
          setIsShareModalOpen(false);
          setShareBadge(null);
        }}
      />
    </div>
  );
}
