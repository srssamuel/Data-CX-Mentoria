import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO, { PAGE_SEO } from "@/components/SEO";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  Target,
  Brain,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Building2,
  TrendingUp,
  Shield,
  Star,
  Zap,
  BarChart3,
  Users,
  Clock,
  FileText,
} from "lucide-react";

const services = [
  {
    icon: Target,
    name: "Diagnóstico Vértice",
    duration: "2-4 semanas",
    description: "Análise profunda de CX, Dados e IA com plano de ação priorizado",
    price: "A partir de R$ 15.000",
    features: [
      "Imersão na operação (entrevistas + dados)",
      "Mapeamento de jornada e atritos",
      "Diagnóstico de maturidade",
      "Benchmark de mercado",
      "Plano de ação priorizado",
      "Apresentação executiva",
    ],
  },
  {
    icon: Shield,
    name: "Assessoria Vértice",
    duration: "6 ou 12 meses",
    description: "Acompanhamento contínuo para transformação sustentável",
    price: "A partir de R$ 8.000/mês",
    features: [
      "Diagnóstico inicial completo",
      "Reuniões quinzenais de acompanhamento",
      "Suporte a decisões estratégicas",
      "Capacitação de lideranças",
      "Revisão de indicadores e rituais",
      "Acesso direto ao consultor",
    ],
    highlight: true,
  },
];

const deliverables = [
  {
    icon: FileText,
    title: "Relatório Executivo",
    description: "Documento completo com diagnóstico, análises e recomendações",
  },
  {
    icon: BarChart3,
    title: "Dashboard de Indicadores",
    description: "Painel visual com métricas-chave e acompanhamento",
  },
  {
    icon: Target,
    title: "Plano de Ação",
    description: "Roadmap priorizado com quick wins e frentes estruturantes",
  },
  {
    icon: Users,
    title: "Capacitação",
    description: "Workshops e treinamentos para times internos",
  },
];

const sectors = [
  "Financeiro",
  "Telecom",
  "Varejo",
  "E-commerce",
  "Saúde",
  "Seguros",
  "Mobilidade",
  "Delivery",
  "Tecnologia",
  "Serviços",
];

const testimonials = [
  {
    name: "Diretor de Operações",
    company: "Fintech Top 10",
    content: "O diagnóstico revelou problemas que não conseguíamos ver. Em 6 meses, reduzimos churn em 23%.",
  },
  {
    name: "VP de CX",
    company: "Telecom",
    content: "A assessoria nos ajudou a estruturar a área do zero. Hoje temos governança e resultado.",
  },
];

export default function Empresas() {
  return (
    <div className="min-h-screen bg-background">
      <SEO title={PAGE_SEO.empresas.title} description={PAGE_SEO.empresas.description} path="/empresas" />
      <Navbar />

      {/* Hero Section */}
      <section className="pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="absolute inset-0 bg-radial" />

        <div className="container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 text-amber-400 text-sm font-medium mb-6">
              <Building2 className="w-4 h-4" />
              Para Empresas e Empresários
            </div>

            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Transformação de CX{" "}
              <span className="gradient-text">com resultado</span>
            </h1>

            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Diagnóstico profundo e assessoria contínua para empresas que querem
              sair do achismo e construir CX, Dados e IA com método.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contato">
                <Button size="lg" className="bg-primary hover:bg-primary/90 px-8">
                  <Sparkles className="w-5 h-5 mr-2" />
                  Solicitar Proposta
                </Button>
              </Link>
              <Link href="/radar">
                <Button size="lg" variant="outline" className="px-8">
                  Fazer Diagnóstico Rápido
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-card/30">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            {[
              { value: "70+", label: "Clientes atendidos" },
              { value: "10+", label: "Segmentos" },
              { value: "15+", label: "Anos de experiência" },
              { value: "R$ 2.6T", label: "Potencial de IA (McKinsey)" },
            ].map((stat, idx) => (
              <div key={idx} className="text-center">
                <div className="text-3xl md:text-4xl font-bold gradient-text mb-2">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Soluções para sua empresa
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Do diagnóstico pontual à transformação contínua
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {services.map((service, idx) => (
              <Card
                key={idx}
                className={service.highlight
                  ? "bg-gradient-to-br from-primary/10 to-accent/10 border-primary/30"
                  : "bg-card/50 border-border/50"
                }
              >
                <CardContent className="p-8">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center">
                      <service.icon className="w-7 h-7 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">{service.name}</h3>
                      <p className="text-sm text-muted-foreground">{service.duration}</p>
                    </div>
                  </div>

                  <p className="text-muted-foreground mb-6">{service.description}</p>
                  
                  <div className="mb-6">
                    <span className="text-2xl font-bold">{service.price}</span>
                  </div>

                  <div className="space-y-3 mb-8">
                    {service.features.map((feature, fidx) => (
                      <div key={fidx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <Link href="/contato">
                    <Button
                      className={`w-full ${service.highlight ? "bg-primary hover:bg-primary/90" : ""}`}
                      variant={service.highlight ? "default" : "outline"}
                    >
                      Solicitar Proposta
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Deliverables */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">O que você recebe</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
            {deliverables.map((item, idx) => (
              <Card key={idx} className="bg-card/50 border-border/50">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <item.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Sectors */}
      <section className="py-20">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-8">Experiência em diversos segmentos</h2>
            <div className="flex flex-wrap justify-center gap-3">
              {sectors.map((sector, idx) => (
                <span
                  key={idx}
                  className="px-4 py-2 rounded-full bg-card border border-border/50 text-sm"
                >
                  {sector}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">
            Empresas que transformaram CX
          </h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {testimonials.map((testimonial, idx) => (
              <Card key={idx} className="bg-card/50 border-border/50">
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4">"{testimonial.content}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <Building2 className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{testimonial.name}</p>
                      <p className="text-xs text-muted-foreground">{testimonial.company}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-20">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">Como funciona</h2>
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-4 gap-6">
              {[
                { step: 1, title: "Conversa Inicial", desc: "Entendemos seu contexto e desafios" },
                { step: 2, title: "Proposta", desc: "Desenhamos escopo e investimento" },
                { step: 3, title: "Imersão", desc: "Diagnóstico profundo na operação" },
                { step: 4, title: "Entrega", desc: "Plano de ação e acompanhamento" },
              ].map((item, idx) => (
                <div key={idx} className="text-center">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <span className="text-primary font-bold">{item.step}</span>
                  </div>
                  <h3 className="font-semibold mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-br from-primary/10 to-accent/10">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Vamos conversar sobre sua empresa?
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              Agende uma conversa sem compromisso para entendermos seu contexto
              e desenharmos a melhor solução.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contato">
                <Button size="lg" className="bg-primary hover:bg-primary/90 px-8">
                  <Sparkles className="w-5 h-5 mr-2" />
                  Agendar Conversa
                </Button>
              </Link>
              <a href="mailto:contato@datacx.com.br">
                <Button size="lg" variant="outline" className="px-8">
                  contato@datacx.com.br
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
