import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO, { PAGE_SEO } from "@/components/SEO";
import {
  ArrowRight,
  TrendingUp,
  Target,
  Users,
  BarChart3,
  Brain,
  CheckCircle2,
  Award,
  Sparkles,
  Calendar,
  Building2,
  GraduationCap,
  LineChart,
  Zap,
  Clock,
  ChevronRight,
} from "lucide-react";
import { motion } from "framer-motion";

const fadeInUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
};

export default function CaseFCO() {
  return (
    <div className="min-h-screen bg-background bg-navy-gradient">
      <SEO title={PAGE_SEO.case.title} description={PAGE_SEO.case.description} path="/case" />
      <Navbar />

      {/* Hero Section */}
      <section className="relative py-20 md:py-28 overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="absolute inset-0 bg-radial" />
        
        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-coral mb-6"
            >
              <Award className="w-4 h-4" />
              <span className="text-sm font-medium">Case de Sucesso</span>
            </motion.div>

            {/* Main Headline */}
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-[1.1] mb-6"
            >
              <span className="gradient-text">120 Matrículas</span>
              <br />
              através de CX, Dados e IA
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8"
            >
              Como transformamos a operação de uma <strong className="text-foreground">Instituição de Ensino</strong> e 
              entregamos resultados reais com o <strong className="text-foreground">Protocolo Vértice</strong>
            </motion.p>

            {/* CTA */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <Link href="/radar">
                <Button size="lg" className="btn-coral px-8 h-14 text-base rounded-xl">
                  Quero Resultados Assim
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Métricas de Impacto */}
      <section className="py-16 bg-card/30">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { value: "120", label: "Matrículas Geradas", icon: GraduationCap },
              { value: "+340%", label: "Aumento em Conversão", icon: TrendingUp },
              { value: "3x", label: "ROI do Projeto", icon: LineChart },
              { value: "6", label: "Meses de Projeto", icon: Calendar },
            ].map((metric, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="program-card text-center p-6">
                  <CardContent className="p-0">
                    <metric.icon className="w-8 h-8 text-primary mx-auto mb-3" />
                    <div className="text-3xl md:text-4xl font-bold text-primary mb-2">{metric.value}</div>
                    <div className="text-sm text-muted-foreground">{metric.label}</div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* O Desafio */}
      <section className="py-20">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-teal mb-6">
                <Target className="w-4 h-4" />
                <span className="text-sm font-medium">O Desafio</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Uma operação educacional <span className="gradient-text">sem previsibilidade</span>
              </h2>
              <p className="text-muted-foreground mb-6">
                A instituição enfrentava desafios comuns no setor educacional: baixa conversão de leads em matrículas, 
                falta de visibilidade sobre a jornada do aluno, processos manuais e decisões baseadas em achismo.
              </p>
              <ul className="space-y-4">
                {[
                  "Taxa de conversão abaixo da média do mercado",
                  "Leads perdidos por falta de follow-up estruturado",
                  "Nenhuma análise preditiva de evasão",
                  "Processos manuais e demorados",
                  "Decisões sem base em dados",
                ].map((item, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-destructive/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-destructive text-sm">✕</span>
                    </div>
                    <span className="text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-destructive/10 to-transparent rounded-3xl blur-3xl" />
              <Card className="relative program-card rounded-2xl overflow-hidden">
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <Building2 className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-xl font-bold mb-2">Cenário Antes</h3>
                    <p className="text-sm text-muted-foreground">Operação fragmentada e reativa</p>
                  </div>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 bg-background/50 rounded-lg">
                      <span className="text-sm">Taxa de Conversão</span>
                      <span className="text-destructive font-semibold">8%</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-background/50 rounded-lg">
                      <span className="text-sm">Tempo de Resposta</span>
                      <span className="text-destructive font-semibold">48h</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-background/50 rounded-lg">
                      <span className="text-sm">Leads Qualificados</span>
                      <span className="text-destructive font-semibold">23%</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-background/50 rounded-lg">
                      <span className="text-sm">Previsibilidade</span>
                      <span className="text-destructive font-semibold">Baixa</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* A Solução - Protocolo Vértice */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-coral mb-4">
              <Zap className="w-4 h-4" />
              <span className="text-sm font-medium">A Solução</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Implementação do <span className="gradient-text">Protocolo Vértice</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Uma abordagem estruturada em 5 etapas para transformar a operação
            </p>
          </div>

          <div className="grid md:grid-cols-5 gap-4">
            {[
              { step: "01", title: "Diagnóstico", desc: "Mapeamento completo da jornada e identificação de gaps", icon: Target },
              { step: "02", title: "Estratégia", desc: "Definição de métricas, KPIs e plano de ação", icon: BarChart3 },
              { step: "03", title: "Dados", desc: "Estruturação de dados e dashboards em tempo real", icon: LineChart },
              { step: "04", title: "IA", desc: "Automações inteligentes e predição de comportamento", icon: Brain },
              { step: "05", title: "Governança", desc: "Rituais, cadência e melhoria contínua", icon: CheckCircle2 },
            ].map((phase, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="program-card h-full">
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl font-bold text-primary/30 mb-4">{phase.step}</div>
                    <phase.icon className="w-10 h-10 text-primary mx-auto mb-4" />
                    <h3 className="font-bold mb-2">{phase.title}</h3>
                    <p className="text-xs text-muted-foreground">{phase.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* O Resultado */}
      <section className="py-20">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent rounded-3xl blur-3xl" />
                <Card className="relative program-card rounded-2xl overflow-hidden">
                  <CardContent className="p-8">
                    <div className="text-center mb-6">
                      <Award className="w-16 h-16 text-primary mx-auto mb-4" />
                      <h3 className="text-xl font-bold mb-2">Cenário Depois</h3>
                      <p className="text-sm text-muted-foreground">Operação orientada a dados e resultados</p>
                    </div>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center p-3 bg-background/50 rounded-lg">
                        <span className="text-sm">Taxa de Conversão</span>
                        <span className="text-primary font-semibold">35%</span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-background/50 rounded-lg">
                        <span className="text-sm">Tempo de Resposta</span>
                        <span className="text-primary font-semibold">2h</span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-background/50 rounded-lg">
                        <span className="text-sm">Leads Qualificados</span>
                        <span className="text-primary font-semibold">67%</span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-background/50 rounded-lg">
                        <span className="text-sm">Previsibilidade</span>
                        <span className="text-primary font-semibold">Alta</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-teal mb-6">
                <TrendingUp className="w-4 h-4" />
                <span className="text-sm font-medium">O Resultado</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                <span className="gradient-text">120 matrículas</span> em 6 meses
              </h2>
              <p className="text-muted-foreground mb-6">
                Com a implementação do Protocolo Vértice, a instituição transformou sua operação e alcançou 
                resultados que antes pareciam impossíveis. A combinação de CX, Dados e IA criou uma 
                máquina de conversão previsível e escalável.
              </p>
              <ul className="space-y-4">
                {[
                  "Aumento de 340% na taxa de conversão",
                  "Redução de 96% no tempo de resposta",
                  "Qualificação automática de leads com IA",
                  "Dashboards em tempo real para tomada de decisão",
                  "Previsibilidade de receita mês a mês",
                ].map((item, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                    </div>
                    <span className="text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Timeline do Projeto */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full badge-teal mb-4">
              <Clock className="w-4 h-4" />
              <span className="text-sm font-medium">Timeline</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              A Jornada de <span className="gradient-text">Transformação</span>
            </h2>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              {[
                { month: "Mês 1", title: "Diagnóstico e Mapeamento", desc: "Análise completa da operação, identificação de gaps e definição de métricas" },
                { month: "Mês 2", title: "Estruturação de Dados", desc: "Implementação de CRM, integração de fontes e criação de dashboards" },
                { month: "Mês 3", title: "Automações e IA", desc: "Chatbots, qualificação automática e réguas de relacionamento" },
                { month: "Mês 4", title: "Otimização de Jornada", desc: "Refinamento de touchpoints e personalização de comunicação" },
                { month: "Mês 5", title: "Escala e Governança", desc: "Rituais de acompanhamento e expansão das automações" },
                { month: "Mês 6", title: "Resultado: 120 Matrículas", desc: "Meta atingida com operação sustentável e escalável" },
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex gap-6"
                >
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">
                      {index + 1}
                    </div>
                    {index < 5 && <div className="w-0.5 h-full bg-primary/20 mt-2" />}
                  </div>
                  <Card className="program-card flex-1">
                    <CardContent className="p-6">
                      <div className="text-xs text-primary font-semibold mb-2">{item.month}</div>
                      <h3 className="font-bold mb-2">{item.title}</h3>
                      <p className="text-sm text-muted-foreground">{item.desc}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20">
        <div className="container">
          <Card className="program-card rounded-3xl overflow-hidden">
            <CardContent className="p-12 text-center">
              <Sparkles className="w-12 h-12 text-primary mx-auto mb-6" />
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Quer resultados assim na <span className="gradient-text">sua operação</span>?
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
                Descubra seu nível de maturidade em CX, Dados e IA com o Radar Vértice gratuito 
                e receba um diagnóstico personalizado para sua operação.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/radar">
                  <Button size="lg" className="btn-coral px-8 h-14 text-base rounded-xl">
                    Fazer Diagnóstico Gratuito
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                <Link href="/contato">
                  <Button size="lg" variant="outline" className="px-8 h-14 text-base rounded-xl border-2">
                    Falar com Especialista
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
}
