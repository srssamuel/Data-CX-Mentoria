import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Link, useSearch } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SEO from "@/components/SEO";
import { useState, useEffect } from "react";
import {
  CheckCircle2,
  ArrowRight,
  BookOpen,
  Mail,
  MessageCircle,
  Sparkles,
  PartyPopper,
  Gift,
  Users,
  Download,
  GraduationCap,
  Clock,
  Shield,
  Rocket,
  ChevronRight,
} from "lucide-react";
import { trackPaymentSuccessViewed, trackOnboardingStepViewed } from "@/lib/analytics";

// Dados contextuais por produto
const productInfo: Record<string, {
  name: string;
  tagline: string;
  includes: string[];
  nextSteps: { icon: React.ElementType; title: string; description: string; link?: string; linkText?: string }[];
  estimatedStart: string;
}> = {
  playbook_vertice: {
    name: "Playbook Vértice",
    tagline: "Seu guia completo de CX, Dados e IA",
    includes: [
      "Playbook teórico completo (PDF)",
      "Playbook técnico com frameworks",
      "Templates e checklists prontos",
      "Guia de implementação passo a passo",
      "Acesso vitalício ao material",
    ],
    nextSteps: [
      { icon: BookOpen, title: "Acesse seus materiais", description: "Seus playbooks já estão disponíveis na Área de Membros para download e estudo.", link: "/membros", linkText: "Ir para Área de Membros" },
      { icon: Download, title: "Baixe os PDFs", description: "Faça o download dos playbooks para estudar offline quando quiser." },
      { icon: GraduationCap, title: "Complete as trilhas", description: "Siga as trilhas de aprendizado para ganhar seus certificados.", link: "/certificados", linkText: "Ver Certificados" },
    ],
    estimatedStart: "Acesso imediato",
  },
  mentoria_grupo: {
    name: "Mentoria Vértice em Grupo",
    tagline: "8 semanas de transformação coletiva",
    includes: [
      "8 encontros ao vivo de 2h cada",
      "Comunidade exclusiva no WhatsApp",
      "Materiais e playbooks completos",
      "Certificado de conclusão",
      "Acesso às gravações por 1 ano",
    ],
    nextSteps: [
      { icon: BookOpen, title: "Acesse a Área de Membros", description: "Seus materiais complementares já estão disponíveis.", link: "/membros", linkText: "Ir para Área de Membros" },
      { icon: Users, title: "Grupo do WhatsApp", description: "O link do grupo exclusivo será enviado por e-mail em até 24 horas." },
      { icon: Clock, title: "Primeiro encontro", description: "Você receberá o calendário com datas e horários dos encontros por e-mail." },
    ],
    estimatedStart: "Próxima turma: Março 2026",
  },
  mentoria_sprint: {
    name: "Mentoria Sprint 1:1",
    tagline: "4 sessões intensivas para resultados rápidos",
    includes: [
      "4 sessões individuais de 1h",
      "Diagnóstico personalizado",
      "Plano de ação customizado",
      "Suporte via WhatsApp",
      "Acesso aos materiais",
    ],
    nextSteps: [
      { icon: BookOpen, title: "Acesse a Área de Membros", description: "Seus materiais de apoio já estão disponíveis.", link: "/membros", linkText: "Ir para Área de Membros" },
      { icon: MessageCircle, title: "Agendamento", description: "Samuel Rosa entrará em contato em até 48h para agendar sua primeira sessão." },
      { icon: Shield, title: "Diagnóstico inicial", description: "Prepare-se respondendo o Radar Vértice antes da primeira sessão.", link: "/radar", linkText: "Fazer Radar Vértice" },
    ],
    estimatedStart: "Contato em até 48h",
  },
  mentoria_90dias: {
    name: "Mentoria Vértice 90 Dias",
    tagline: "Transformação completa em 3 meses",
    includes: [
      "12 sessões individuais de 1h",
      "Diagnóstico completo 360º",
      "Plano estratégico personalizado",
      "Suporte prioritário via WhatsApp",
      "Acesso vitalício aos materiais",
    ],
    nextSteps: [
      { icon: BookOpen, title: "Acesse a Área de Membros", description: "Seus materiais de apoio já estão disponíveis.", link: "/membros", linkText: "Ir para Área de Membros" },
      { icon: MessageCircle, title: "Agendamento", description: "Samuel Rosa entrará em contato em até 48h para agendar sua primeira sessão." },
      { icon: Shield, title: "Diagnóstico 360º", description: "Seu diagnóstico completo será realizado na primeira sessão." },
    ],
    estimatedStart: "Contato em até 48h",
  },
  mentoria_executive: {
    name: "Mentoria Executive",
    tagline: "Programa premium para líderes",
    includes: [
      "24 sessões individuais de 1h",
      "Diagnóstico empresarial completo",
      "Estratégia de transformação digital",
      "Suporte VIP 24/7",
      "Acesso a todos os materiais",
    ],
    nextSteps: [
      { icon: BookOpen, title: "Acesse a Área de Membros", description: "Todos os materiais premium estão disponíveis.", link: "/membros", linkText: "Ir para Área de Membros" },
      { icon: MessageCircle, title: "Onboarding VIP", description: "Samuel Rosa entrará em contato em até 24h para seu onboarding exclusivo." },
      { icon: Rocket, title: "Kick-off estratégico", description: "Sua primeira sessão será um kick-off com diagnóstico empresarial completo." },
    ],
    estimatedStart: "Contato VIP em até 24h",
  },
  diagnostico_360: {
    name: "Diagnóstico Vértice 360º",
    tagline: "Raio-X completo da sua operação",
    includes: [
      "Análise de 2-4 semanas",
      "Entrevistas com stakeholders",
      "Relatório executivo completo",
      "Roadmap de implementação",
      "Apresentação para liderança",
    ],
    nextSteps: [
      { icon: MessageCircle, title: "Kick-off do projeto", description: "Samuel Rosa entrará em contato em até 48h para alinhar o escopo e cronograma." },
      { icon: Users, title: "Stakeholders", description: "Prepare uma lista dos principais stakeholders para as entrevistas." },
      { icon: BookOpen, title: "Materiais de apoio", description: "Acesse materiais complementares na Área de Membros.", link: "/membros", linkText: "Ir para Área de Membros" },
    ],
    estimatedStart: "Kick-off em até 48h",
  },
  assessoria_mensal: {
    name: "Assessoria Vértice",
    tagline: "Acompanhamento contínuo mensal",
    includes: [
      "4 sessões mensais de consultoria",
      "Suporte contínuo via WhatsApp",
      "Revisão de métricas e KPIs",
      "Treinamento da equipe",
      "Acesso a todos os materiais",
    ],
    nextSteps: [
      { icon: MessageCircle, title: "Onboarding", description: "Samuel Rosa entrará em contato em até 24h para iniciar o acompanhamento." },
      { icon: BookOpen, title: "Acesse a Área de Membros", description: "Todos os materiais estão disponíveis.", link: "/membros", linkText: "Ir para Área de Membros" },
      { icon: Rocket, title: "Primeira sessão", description: "Sua primeira sessão de consultoria será agendada na primeira semana." },
    ],
    estimatedStart: "Contato em até 24h",
  },
};

const defaultProduct = {
  name: "Programa Vértice",
  tagline: "Sua jornada de transformação começa agora",
  includes: ["Acesso à Área de Membros", "Materiais exclusivos", "Suporte dedicado"],
  nextSteps: [
    { icon: BookOpen, title: "Acesse a Área de Membros", description: "Seus materiais já estão disponíveis.", link: "/membros", linkText: "Ir para Área de Membros" },
    { icon: Mail, title: "Verifique seu e-mail", description: "Enviamos um e-mail de confirmação com instruções." },
    { icon: MessageCircle, title: "Precisa de ajuda?", description: "Entre em contato pelo WhatsApp ou e-mail." },
  ],
  estimatedStart: "Acesso imediato",
};

export default function PaymentSuccess() {
  const { user } = useAuth();
  const searchString = useSearch();
  const params = new URLSearchParams(searchString);
  const productId = params.get("product");
  const isFree = params.get("free") === "true";

  const product = productId ? (productInfo[productId] || defaultProduct) : defaultProduct;

  // Animação de progresso do onboarding
  const [currentStep, setCurrentStep] = useState(0);
  const [showConfetti, setShowConfetti] = useState(true);

  useEffect(() => {
    // Track page view
    trackPaymentSuccessViewed(productId || "unknown", isFree);
    
    // Auto-advance steps com timer
    const timers = product.nextSteps.map((step, index) =>
      setTimeout(() => {
        setCurrentStep(index);
        trackOnboardingStepViewed(index + 1, step.title);
      }, index * 2000 + 1000)
    );
    // Remover confetti após 5s
    const confettiTimer = setTimeout(() => setShowConfetti(false), 5000);
    return () => {
      timers.forEach(clearTimeout);
      clearTimeout(confettiTimer);
    };
  }, [product.nextSteps.length, productId, isFree]);

  const progressPercent = ((currentStep + 1) / product.nextSteps.length) * 100;

  return (
    <div className="min-h-screen bg-background">
      <SEO 
        title={`Inscrição Confirmada - ${product.name}`} 
        description="Sua inscrição foi confirmada com sucesso. Confira os próximos passos." 
        path="/pagamento-sucesso" 
        noindex 
      />
      <Navbar />

      <section className="pt-32 pb-20 min-h-[80vh] flex items-center">
        <div className="container">
          <div className="max-w-2xl mx-auto space-y-6">
            
            {/* Success Header */}
            <Card className="bg-card/50 border-border/50 backdrop-blur-sm overflow-hidden">
              <div className={`p-8 text-center border-b border-border/50 ${
                isFree 
                  ? "bg-gradient-to-r from-green-500/20 to-emerald-500/20" 
                  : "bg-gradient-to-r from-primary/20 to-accent/20"
              }`}>
                <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 ${
                  showConfetti ? "animate-bounce" : ""
                } ${isFree ? "bg-green-500/20" : "bg-primary/20"}`}>
                  {isFree ? (
                    <Gift className="w-10 h-10 text-green-500" />
                  ) : (
                    <CheckCircle2 className="w-10 h-10 text-primary" />
                  )}
                </div>
                <div className="flex items-center justify-center gap-2 mb-2">
                  <PartyPopper className="w-6 h-6 text-accent" />
                  <h1 className="text-3xl font-bold">
                    {isFree ? "Inscrição Gratuita Confirmada!" : "Pagamento Confirmado!"}
                  </h1>
                  <PartyPopper className="w-6 h-6 text-accent" />
                </div>
                <p className="text-muted-foreground">
                  Bem-vindo ao <span className={`font-medium ${isFree ? "text-green-500" : "text-primary"}`}>{product.name}</span>
                </p>
                <p className="text-sm text-muted-foreground/80 mt-1">{product.tagline}</p>
              </div>

              <CardContent className="p-8">
                {/* Welcome */}
                <div className="text-center mb-6">
                  <p className="text-lg">
                    Olá, <span className="font-semibold">{user?.name?.split(" ")[0] || "Mentorado"}</span>!
                  </p>
                  <p className="text-muted-foreground mt-1 text-sm">
                    {isFree 
                      ? "Sua inscrição gratuita foi processada com sucesso. Você já pode acessar seus materiais."
                      : "Sua compra foi processada com sucesso. Você já pode acessar seus materiais na área de membros."
                    }
                  </p>
                </div>

                {/* O que você recebe */}
                <div className="mb-6 p-4 rounded-xl bg-muted/30 border border-border/50">
                  <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-primary" />
                    O que você recebe:
                  </h3>
                  <div className="grid gap-2">
                    {product.includes.map((item, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span className="text-muted-foreground">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Próximos Passos com progresso */}
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-sm flex items-center gap-2">
                      <Rocket className="w-4 h-4 text-primary" />
                      Próximos Passos
                    </h3>
                    <Badge variant="outline" className="text-xs">
                      <Clock className="w-3 h-3 mr-1" />
                      {product.estimatedStart}
                    </Badge>
                  </div>
                  
                  <Progress value={progressPercent} className="h-1.5 mb-4" />
                  
                  <div className="space-y-3">
                    {product.nextSteps.map((step, index) => {
                      const StepIcon = step.icon;
                      const isActive = index <= currentStep;
                      return (
                        <div 
                          key={index} 
                          className={`flex items-start gap-3 p-4 rounded-lg border transition-all duration-500 ${
                            isActive 
                              ? "bg-card/80 border-primary/30 shadow-sm" 
                              : "bg-card/30 border-border/30 opacity-60"
                          }`}
                        >
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition-colors duration-500 ${
                            isActive ? "bg-primary/20" : "bg-muted/30"
                          }`}>
                            <StepIcon className={`w-4 h-4 ${isActive ? "text-primary" : "text-muted-foreground"}`} />
                          </div>
                          <div className="flex-1">
                            <p className="font-medium text-sm">{step.title}</p>
                            <p className="text-xs text-muted-foreground mt-0.5">{step.description}</p>
                            {step.link && isActive && (
                              <Link href={step.link}>
                                <Button variant="link" size="sm" className="h-auto p-0 mt-1 text-xs text-primary">
                                  {step.linkText} <ChevronRight className="w-3 h-3 ml-0.5" />
                                </Button>
                              </Link>
                            )}
                          </div>
                          {isActive && (
                            <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0 mt-1" />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* CTA Buttons */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <Link href="/membros" className="flex-1">
                    <Button className="w-full bg-primary hover:bg-primary/90 h-11">
                      <BookOpen className="w-4 h-4 mr-2" />
                      Acessar Área de Membros
                    </Button>
                  </Link>
                  <Link href="/ajuda" className="flex-1">
                    <Button variant="outline" className="w-full h-11">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Central de Ajuda
                    </Button>
                  </Link>
                </div>

                {/* Support */}
                <div className="mt-6 pt-4 border-t border-border/50 text-center">
                  <p className="text-xs text-muted-foreground mb-2">
                    Dúvidas? Estamos aqui para ajudar!
                  </p>
                  <div className="flex items-center justify-center gap-4 text-xs">
                    <a href="mailto:contato@datacx.com.br" className="flex items-center gap-1 text-primary hover:underline">
                      <Mail className="w-3 h-3" />
                      contato@datacx.com.br
                    </a>
                    <a href="https://wa.me/5584991278513" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-primary hover:underline">
                      <MessageCircle className="w-3 h-3" />
                      WhatsApp
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
