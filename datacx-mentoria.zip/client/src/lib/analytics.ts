/**
 * Instrumentação de Eventos do Funil
 * 
 * Eventos rastreados:
 * - page_view: Visualização de página
 * - coupon_applied: Cupom aplicado com sucesso
 * - coupon_failed: Tentativa de cupom falhou
 * - checkout_started: Início do checkout
 * - checkout_free_completed: Checkout gratuito (100% OFF) concluído
 * - payment_success_viewed: Página de sucesso visualizada
 * - certificate_generated: Certificado gerado
 * - certificate_downloaded: Certificado baixado
 * - certificate_shared_linkedin: Certificado compartilhado no LinkedIn
 * - help_search: Busca na central de ajuda
 * - help_faq_opened: FAQ aberto
 * - onboarding_step_viewed: Step do onboarding visualizado
 */

interface AnalyticsEvent {
  event: string;
  properties?: Record<string, string | number | boolean | null>;
  timestamp: number;
}

// Buffer de eventos para envio em batch
let eventBuffer: AnalyticsEvent[] = [];
let flushTimer: ReturnType<typeof setTimeout> | null = null;

/**
 * Rastreia um evento do funil
 */
export function trackEvent(event: string, properties?: Record<string, string | number | boolean | null>) {
  const analyticsEvent: AnalyticsEvent = {
    event,
    properties: {
      ...properties,
      url: window.location.pathname,
      referrer: document.referrer || null,
    },
    timestamp: Date.now(),
  };

  eventBuffer.push(analyticsEvent);

  // Log no console em dev
  if (import.meta.env.DEV) {
    console.log(`[Analytics] ${event}`, properties || {});
  }

  // Flush após 2 segundos de inatividade ou quando buffer chegar a 10 eventos
  if (flushTimer) clearTimeout(flushTimer);
  if (eventBuffer.length >= 10) {
    flushEvents();
  } else {
    flushTimer = setTimeout(flushEvents, 2000);
  }
}

/**
 * Envia eventos acumulados para o servidor
 */
async function flushEvents() {
  if (eventBuffer.length === 0) return;

  const events = [...eventBuffer];
  eventBuffer = [];

  try {
    // Enviar para o endpoint de analytics (se existir)
    const analyticsEndpoint = import.meta.env.VITE_ANALYTICS_ENDPOINT;
    if (analyticsEndpoint) {
      await fetch(`${analyticsEndpoint}/api/collect`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ events }),
      }).catch(() => {
        // Silently fail - analytics should never break the app
      });
    }
  } catch {
    // Analytics failures are non-critical
  }
}

// Flush ao sair da página
if (typeof window !== "undefined") {
  window.addEventListener("beforeunload", flushEvents);
  window.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
      flushEvents();
    }
  });
}

// ═══ Convenience helpers ═══

export function trackPageView(pageName: string) {
  trackEvent("page_view", { page: pageName });
}

export function trackCouponApplied(code: string, discountType: string, discountValue: number) {
  trackEvent("coupon_applied", { code, discountType, discountValue });
}

export function trackCouponFailed(code: string, error: string) {
  trackEvent("coupon_failed", { code, error });
}

export function trackCheckoutStarted(productId: string, amount: number, isFree: boolean) {
  trackEvent("checkout_started", { productId, amount, isFree });
}

export function trackCheckoutFreeCompleted(productId: string) {
  trackEvent("checkout_free_completed", { productId });
}

export function trackPaymentSuccessViewed(productId: string, isFree: boolean) {
  trackEvent("payment_success_viewed", { productId, isFree });
}

export function trackCertificateGenerated(category: string) {
  trackEvent("certificate_generated", { category });
}

export function trackCertificateDownloaded(certId: number) {
  trackEvent("certificate_downloaded", { certId });
}

export function trackCertificateSharedLinkedIn(category: string) {
  trackEvent("certificate_shared_linkedin", { category });
}

export function trackHelpSearch(query: string, resultsCount: number) {
  trackEvent("help_search", { query, resultsCount });
}

export function trackHelpFaqOpened(question: string) {
  trackEvent("help_faq_opened", { question });
}

export function trackOnboardingStepViewed(step: number, stepTitle: string) {
  trackEvent("onboarding_step_viewed", { step, stepTitle });
}

export function trackFirstLogin() {
  trackEvent("first_login", {});
}

export function trackModuleStarted(moduleCode: string, pilar: string) {
  trackEvent("module_started", { moduleCode, pilar });
}

export function trackModuleCompleted(moduleCode: string, pilar: string) {
  trackEvent("module_completed", { moduleCode, pilar });
}

export function trackQuizCompleted(moduleCode: string, score: number, total: number) {
  trackEvent("quiz_completed", { moduleCode, score, total });
}

export function trackRadarCompleted(totalScore: number, persona: string) {
  trackEvent("radar_completed", { totalScore, persona });
}

export function trackCommunityPostCreated(category: string) {
  trackEvent("community_post_created", { category });
}

export function trackSolutionDownloaded(solutionId: string, category: string) {
  trackEvent("solution_downloaded", { solutionId, category });
}
