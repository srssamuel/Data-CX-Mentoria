import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Rocket, BookOpen, Radar, Users, Star, ArrowRight, X, Sparkles,
  CheckCircle2, GraduationCap, MessageSquare
} from "lucide-react";

interface OnboardingWelcomeProps {
  userName: string;
  onDismiss: () => void;
  onNavigate: (section: string) => void;
}

const STEPS = [
  {
    icon: <Radar className="w-8 h-8" />,
    title: "Faça o Radar Vértice",
    description: "Descubra seu nível de maturidade em CX, Dados e IA com nosso diagnóstico gratuito.",
    action: "radar",
    actionLabel: "Fazer Diagnóstico",
    color: "from-cyan-500 to-blue-600",
    bgColor: "bg-cyan-500/10",
  },
  {
    icon: <BookOpen className="w-8 h-8" />,
    title: "Explore as Trilhas",
    description: "Comece pela Introdução ao Protocolo Vértice e avance para CX, Dados e IA.",
    action: "trilhas",
    actionLabel: "Ver Trilhas",
    color: "from-emerald-500 to-teal-600",
    bgColor: "bg-emerald-500/10",
  },
  {
    icon: <Users className="w-8 h-8" />,
    title: "Junte-se à Comunidade",
    description: "Conecte-se com outros profissionais, tire dúvidas e compartilhe experiências.",
    action: "comunidade",
    actionLabel: "Acessar Comunidade",
    color: "from-purple-500 to-violet-600",
    bgColor: "bg-purple-500/10",
  },
];

export default function OnboardingWelcome({ userName, onDismiss, onNavigate }: OnboardingWelcomeProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  const handleDismiss = () => {
    setIsVisible(false);
    onDismiss();
  };

  const handleAction = (action: string) => {
    if (action === "radar") {
      window.location.href = "/radar";
    } else if (action === "comunidade") {
      window.location.href = "/comunidade";
    } else {
      onNavigate(action);
    }
    handleDismiss();
  };

  return (
    <div className="relative mb-8 animate-in fade-in slide-in-from-top-4 duration-500">
      <Card className="overflow-hidden border-primary/30 bg-gradient-to-br from-card via-card to-primary/5">
        <button
          onClick={handleDismiss}
          className="absolute top-4 right-4 z-10 p-1.5 rounded-full bg-muted/50 hover:bg-muted transition-colors"
          aria-label="Fechar"
        >
          <X className="w-4 h-4 text-muted-foreground" />
        </button>

        <CardContent className="p-6 md:p-8">
          {/* Header */}
          <div className="flex items-start gap-4 mb-6">
            <div className="p-3 rounded-2xl bg-gradient-to-br from-primary to-accent text-white shadow-lg">
              <Rocket className="w-7 h-7" />
            </div>
            <div>
              <h2 className="text-xl md:text-2xl font-bold mb-1">
                Bem-vindo(a), <span className="gradient-text">{userName}</span>! <Sparkles className="w-5 h-5 inline text-yellow-500" />
              </h2>
              <p className="text-muted-foreground text-sm md:text-base">
                Preparamos um roteiro para você começar sua jornada de transformação em CX, Dados e IA.
              </p>
            </div>
          </div>

          {/* Steps */}
          <div className="grid md:grid-cols-3 gap-4 mb-6">
            {STEPS.map((step, index) => (
              <button
                key={index}
                onClick={() => handleAction(step.action)}
                className={`text-left p-4 rounded-xl border transition-all group hover:border-primary/50 hover:shadow-md ${
                  currentStep === index ? "border-primary/40 bg-primary/5" : "border-border/50 bg-card/50"
                }`}
                onMouseEnter={() => setCurrentStep(index)}
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className={`p-2 rounded-lg bg-gradient-to-br ${step.color} text-white`}>
                    {step.icon}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-muted-foreground/60">PASSO {index + 1}</span>
                  </div>
                </div>
                <h3 className="font-semibold text-sm mb-1 group-hover:text-primary transition-colors">
                  {step.title}
                </h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {step.description}
                </p>
                <div className="mt-3 flex items-center gap-1 text-xs font-medium text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                  {step.actionLabel}
                  <ArrowRight className="w-3 h-3" />
                </div>
              </button>
            ))}
          </div>

          {/* Quick tips */}
          <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-primary" />
              <span>Radar Vértice é gratuito</span>
            </div>
            <div className="flex items-center gap-1.5">
              <GraduationCap className="w-3.5 h-3.5 text-primary" />
              <span>Certificados ao concluir trilhas</span>
            </div>
            <div className="flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-primary" />
              <span>Chat IA em cada módulo</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
