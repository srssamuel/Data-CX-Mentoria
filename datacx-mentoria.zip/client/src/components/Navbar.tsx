import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { Menu, X, User, LogOut, LayoutDashboard, ChevronDown, Compass, Award } from "lucide-react";
import { useState, useEffect } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const navLinks = [
  { href: "/", label: "Início" },
  { href: "/radar", label: "Radar Vértice", highlight: true },
  { href: "/ofertas", label: "Programas" },
  { href: "/cases/120-matriculas", label: "Case", icon: "award" },
  { href: "/sobre", label: "Sobre" },
  { href: "/contato", label: "Contato" },
];

export default function Navbar() {
  const { user, isAuthenticated, logout } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLogout = async () => {
    await logout();
    window.location.href = "/";
  };

  return (
    <nav 
      role="navigation"
      aria-label="Navegação principal"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled 
          ? "glass shadow-lg shadow-black/10" 
          : "bg-transparent"
      }`}
    >
      <div className="container">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo DCX Oficial */}
          <Link href="/" className="flex items-center gap-3">
            <img 
              src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/yiFXtpCIREJMAdgt.png" 
              alt="Data CX - Protocolo Vértice" 
              className="h-8 w-auto"
            />
            <div className="hidden sm:block">
              <span className="font-bold text-lg tracking-tight">Data CX</span>
              <span className="text-muted-foreground text-xs block tracking-wide">PROTOCOLO VÉRTICE</span>
            </div>
          </Link>

          {/* Desktop Navigation - G4 Style */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <Button
                  variant="ghost"
                  className={`text-sm font-medium rounded-lg px-4 ${
                    location === link.href
                      ? "text-primary bg-primary/10"
                      : link.highlight
                      ? "text-coral hover:text-coral hover:bg-coral/10"
                      : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                  }`}
                >
                  {link.highlight && <Compass className="w-4 h-4 mr-1.5" />}
                  {link.label}
                </Button>
              </Link>
            ))}
          </div>

          {/* Auth Section - G4 Style */}
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <>
                {user?.role === "admin" && (
                  <Link href="/admin" className="hidden lg:block">
                    <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                      <LayoutDashboard className="w-4 h-4 mr-2" />
                      Admin
                    </Button>
                  </Link>
                )}
                <Link href="/membros" className="hidden md:block">
                  <Button size="sm" className="btn-coral rounded-lg">
                    Área de Membros
                  </Button>
                </Link>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="rounded-full p-0 w-10 h-10">
                      <Avatar className="w-9 h-9 border-2 border-primary/30">
                        <AvatarFallback className="bg-gradient-to-br from-primary/30 to-accent/30 text-primary font-semibold">
                          {user?.name?.charAt(0) || "U"}
                        </AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56 glass rounded-xl p-2">
                    <div className="px-3 py-2 mb-2">
                      <p className="font-semibold">{user?.name}</p>
                      <p className="text-xs text-muted-foreground">{user?.email}</p>
                    </div>
                    <DropdownMenuSeparator className="bg-border/50" />
                    <Link href="/perfil">
                      <DropdownMenuItem className="rounded-lg cursor-pointer">
                        <User className="w-4 h-4 mr-3" />
                        Meu Perfil
                      </DropdownMenuItem>
                    </Link>
                    <Link href="/membros">
                      <DropdownMenuItem className="rounded-lg cursor-pointer">
                        <LayoutDashboard className="w-4 h-4 mr-3" />
                        Área de Membros
                      </DropdownMenuItem>
                    </Link>
                    <Link href="/comunidade">
                      <DropdownMenuItem className="rounded-lg cursor-pointer">
                        <User className="w-4 h-4 mr-3" />
                        Comunidade
                      </DropdownMenuItem>
                    </Link>
                    <Link href="/conteudos">
                      <DropdownMenuItem className="rounded-lg cursor-pointer">
                        <LayoutDashboard className="w-4 h-4 mr-3" />
                        Conteúdos
                      </DropdownMenuItem>
                    </Link>
                    {user?.role === "admin" && (
                      <Link href="/admin">
                        <DropdownMenuItem className="rounded-lg cursor-pointer">
                          <LayoutDashboard className="w-4 h-4 mr-3" />
                          Painel Admin
                        </DropdownMenuItem>
                      </Link>
                    )}
                    <DropdownMenuSeparator className="bg-border/50" />
                    <DropdownMenuItem 
                      onClick={handleLogout} 
                      className="rounded-lg cursor-pointer text-destructive focus:text-destructive"
                    >
                      <LogOut className="w-4 h-4 mr-3" />
                      Sair
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <Link href="/login">
                <Button size="sm" className="btn-coral rounded-lg px-6">
                  Entrar
                </Button>
              </Link>
            )}

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden rounded-lg"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label={mobileMenuOpen ? "Fechar menu" : "Abrir menu"}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu - G4 Style */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-border/50">
            <div className="flex flex-col gap-1">
              {navLinks.map((link) => (
                <Link key={link.href} href={link.href} onClick={() => setMobileMenuOpen(false)}>
                  <Button
                    variant="ghost"
                    className={`w-full justify-start rounded-lg ${
                      location === link.href 
                        ? "text-primary bg-primary/10" 
                        : link.highlight
                        ? "text-coral"
                        : "text-muted-foreground"
                    }`}
                  >
                    {link.highlight && <Compass className="w-4 h-4 mr-2" />}
                    {link.label}
                  </Button>
                </Link>
              ))}
              <div className="h-px bg-border/50 my-2" />
              {isAuthenticated && (
                <>
                  <Link href="/membros" onClick={() => setMobileMenuOpen(false)}>
                    <Button className="w-full btn-coral rounded-lg">
                      Área de Membros
                    </Button>
                  </Link>
                  {user?.role === "admin" && (
                    <Link href="/admin" onClick={() => setMobileMenuOpen(false)}>
                      <Button variant="ghost" className="w-full justify-start rounded-lg mt-1">
                        <LayoutDashboard className="w-4 h-4 mr-2" />
                        Painel Admin
                      </Button>
                    </Link>
                  )}
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
