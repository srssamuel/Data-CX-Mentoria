import { Link, useLocation } from "wouter";
import { Linkedin, Instagram, Mail, ArrowRight, Compass } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Footer() {
  const [location] = useLocation();
  const isRadarPage = location === "/radar";

  return (
    <footer role="contentinfo" aria-label="Rodapé" className="border-t border-border/50 bg-card/30 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl -translate-x-1/2 translate-y-1/2" />
      <div className="absolute top-0 right-0 w-64 h-64 bg-coral/5 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2" />
      
      <div className="container py-16 md:py-20 relative z-10">
        {/* CTA Banner - Esconde na página do Radar */}
        {!isRadarPage && (
          <div className="mb-16 p-8 md:p-12 rounded-3xl bg-gradient-to-r from-primary/10 via-card to-coral/10 border border-border/50">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div>
                <h3 className="text-2xl md:text-3xl font-bold mb-2">
                  Pronto para transformar sua operação?
                </h3>
                <p className="text-muted-foreground">
                  Faça o Radar Vértice e descubra seu nível de maturidade em CX, Dados e IA.
                </p>
              </div>
              <Link href="/radar">
                <Button size="lg" className="btn-coral rounded-xl px-8 h-14 whitespace-nowrap">
                  <Compass className="w-5 h-5 mr-2" />
                  Fazer Radar Vértice
                </Button>
              </Link>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-12 gap-12">
          {/* Brand */}
          <div className="md:col-span-5">
            <div className="flex items-center gap-3 mb-6">
              <img 
                src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/yiFXtpCIREJMAdgt.png" 
                alt="Data CX - Protocolo Vértice" 
                className="h-10 w-auto"
              />
              <div>
                <span className="font-bold text-xl tracking-tight">Data CX</span>
                <span className="text-muted-foreground text-xs block tracking-wide">PROTOCOLO VÉRTICE</span>
              </div>
            </div>
            <p className="text-muted-foreground mb-6 max-w-md leading-relaxed">
              Transformando CX, dados e IA em resultado real. Metodologia prática para tirar a operação do achismo e acelerar decisões com evidência.
            </p>
            <div className="flex gap-3">
              <a
                href="https://linkedin.com/in/samuel-rosa-5a1447b7"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="LinkedIn de Samuel Rosa"
                className="w-11 h-11 rounded-xl bg-card border border-border/50 flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/50 hover:bg-primary/5 transition-all"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="https://instagram.com/srssamuelrosa"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram de Samuel Rosa"
                className="w-11 h-11 rounded-xl bg-card border border-border/50 flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/50 hover:bg-primary/5 transition-all"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="mailto:contato@datacx.com.br"
                aria-label="Enviar e-mail para Data CX"
                className="w-11 h-11 rounded-xl bg-card border border-border/50 flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/50 hover:bg-primary/5 transition-all"
              >
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Links */}
          <div className="md:col-span-2">
            <h4 className="font-bold text-sm uppercase tracking-wider text-muted-foreground mb-6">Navegação</h4>
            <ul className="space-y-4">
              {[
                { href: "/", label: "Início" },
                { href: "/sobre", label: "Sobre" },
                { href: "/ofertas", label: "Programas" },
                { href: "/contato", label: "Contato" },
              ].map((link) => (
                <li key={link.href}>
                  <Link 
                    href={link.href} 
                    className="text-foreground hover:text-primary transition-colors flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 opacity-0 -ml-5 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Mentoria */}
          <div className="md:col-span-2">
            <h4 className="font-bold text-sm uppercase tracking-wider text-muted-foreground mb-6">Programas</h4>
            <ul className="space-y-4">
              {[
                { href: "/mentoria-jovens", label: "Jovens" },
                { href: "/mentoria-gestores", label: "Gestores" },
                { href: "/mentoria-executivos", label: "Executivos" },
                { href: "/empresas", label: "Empresas" },
              ].map((link) => (
                <li key={link.href}>
                  <Link 
                    href={link.href} 
                    className="text-foreground hover:text-primary transition-colors flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 opacity-0 -ml-5 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Recursos */}
          <div className="md:col-span-3">
            <h4 className="font-bold text-sm uppercase tracking-wider text-muted-foreground mb-6">Recursos</h4>
            <ul className="space-y-4">
              {[
                { href: "/radar", label: "Radar Vértice", highlight: true },
                { href: "/cases/fco", label: "Case: 120 Matrículas" },
                { href: "/membros", label: "Área de Membros" },
                { href: "/contato", label: "Sessão Diagnóstica" },
                { href: "/privacidade", label: "Política de Privacidade" },
              ].map((link) => (
                <li key={link.href}>
                  <Link 
                    href={link.href} 
                    className={`transition-colors flex items-center gap-2 group ${
                      link.highlight ? "text-coral hover:text-coral/80" : "text-foreground hover:text-primary"
                    }`}
                  >
                    <ArrowRight className="w-3 h-3 opacity-0 -ml-5 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-16 pt-8 border-t border-border/50 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-muted-foreground text-sm">
            © {new Date().getFullYear()} Data CX. Todos os direitos reservados.
          </p>
          <div className="flex items-center gap-4">
            <Link href="/privacidade" className="text-muted-foreground text-sm hover:text-primary transition-colors">
              Política de Privacidade
            </Link>
            <span className="text-muted-foreground">|</span>
            <p className="text-muted-foreground text-sm">
              <span className="gradient-text font-semibold">Protocolo Vértice®</span> — Do atrito ao ROI, com método.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
