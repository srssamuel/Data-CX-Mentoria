import { useEffect } from "react";

interface SEOProps {
  title?: string;
  description?: string;
  path?: string;
  type?: string;
  image?: string;
  noindex?: boolean;
}

const BASE_TITLE = "Data CX - Protocolo Vértice";
const DEFAULT_IMAGE = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/yiFXtpCIREJMAdgt.png";
const SITE_NAME = "Data CX - Protocolo Vértice";

function getBaseUrl() {
  if (typeof window === "undefined") return "";
  return window.location.origin;
}

export default function SEO({ title, description, path, type = "website", image, noindex }: SEOProps) {
  useEffect(() => {
    const baseUrl = getBaseUrl();
    const fullTitle = title ? `${title} | ${BASE_TITLE}` : `${BASE_TITLE} | Mentoria em CX, Dados e IA`;
    const ogImage = image || DEFAULT_IMAGE;
    const canonicalUrl = path ? `${baseUrl}${path}` : baseUrl;

    // Title
    document.title = fullTitle;

    // Helper to set/create meta tags
    const setMeta = (attr: string, key: string, content: string) => {
      let el = document.querySelector(`meta[${attr}="${key}"]`);
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr, key);
        document.head.appendChild(el);
      }
      el.setAttribute("content", content);
    };

    // Standard meta tags
    if (description) setMeta("name", "description", description);
    if (noindex) {
      setMeta("name", "robots", "noindex, nofollow");
    } else {
      setMeta("name", "robots", "index, follow");
    }

    // Open Graph
    setMeta("property", "og:title", fullTitle);
    if (description) setMeta("property", "og:description", description);
    setMeta("property", "og:url", canonicalUrl);
    setMeta("property", "og:type", type);
    setMeta("property", "og:image", ogImage);
    setMeta("property", "og:site_name", SITE_NAME);
    setMeta("property", "og:locale", "pt_BR");

    // Twitter Card
    setMeta("name", "twitter:card", "summary_large_image");
    setMeta("name", "twitter:title", fullTitle);
    if (description) setMeta("name", "twitter:description", description);
    setMeta("name", "twitter:image", ogImage);

    // Canonical URL
    let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
    if (!canonical) {
      canonical = document.createElement("link");
      canonical.setAttribute("rel", "canonical");
      document.head.appendChild(canonical);
    }
    canonical.setAttribute("href", canonicalUrl);

    return () => {
      // Cleanup canonical on unmount to avoid stale links
      const existingCanonical = document.querySelector('link[rel="canonical"]');
      if (existingCanonical) existingCanonical.remove();
    };
  }, [title, description, path, type, image, noindex]);

  return null;
}

// SEO data for each page
export const PAGE_SEO: Record<string, { title: string; description: string }> = {
  home: {
    title: "Mentoria em CX, Dados e IA",
    description: "Transforme sua operação com o Protocolo Vértice. Mentoria e consultoria em Customer Experience, Dados e Inteligência Artificial com Samuel Rosa. +70 profissionais transformados.",
  },
  sobre: {
    title: "Sobre Samuel Rosa",
    description: "Conheça Samuel Rosa, especialista em CX, Dados e IA com +15 anos de experiência e +70 clientes atendidos em +10 segmentos de mercado.",
  },
  ofertas: {
    title: "Programas de Mentoria",
    description: "Do playbook introdutório à mentoria executiva. Encontre o formato ideal para aplicar o Protocolo Vértice na sua operação. Playbook, Mentoria em Grupo, Individual e Diagnóstico 360°.",
  },
  contato: {
    title: "Contato",
    description: "Entre em contato com a Data CX para agendar uma sessão diagnóstica gratuita. Mentoria e consultoria em CX, Dados e IA.",
  },
  radar: {
    title: "Radar Vértice - Autoavaliação",
    description: "Descubra seu nível de maturidade em CX, Dados e IA com o Radar Vértice. Avaliação gratuita com recomendação personalizada de programa.",
  },
  case: {
    title: "Case de Sucesso - 120 Matrículas",
    description: "Como transformamos a operação de uma Instituição de Ensino e geramos 120 matrículas usando CX, Dados e IA. +340% de aumento em conversão.",
  },
  membros: {
    title: "Área de Membros",
    description: "Acesse seus módulos de aprendizagem, trilhas de CX, Dados e IA, e acompanhe seu progresso no Protocolo Vértice.",
  },
  certificados: {
    title: "Certificados",
    description: "Seus certificados de conclusão das trilhas do Protocolo Vértice. Certificados verificáveis com código único.",
  },
  privacidade: {
    title: "Política de Privacidade",
    description: "Política de privacidade e termos de uso da plataforma Data CX - Protocolo Vértice. Conformidade com LGPD.",
  },
  mentoriaJovens: {
    title: "Mentoria para Jovens Profissionais",
    description: "Programa de mentoria em CX, Dados e IA para jovens de 18-26 anos. Construa sua carreira com as habilidades mais demandadas do mercado.",
  },
  mentoriaGestores: {
    title: "Mentoria para Gestores",
    description: "Programa de mentoria em CX, Dados e IA para gestores. Transforme sua equipe e operação com decisões baseadas em dados.",
  },
  mentoriaExecutivos: {
    title: "Mentoria para Executivos",
    description: "Programa de mentoria executiva em CX, Dados e IA. Visão estratégica para C-Level e diretores que lideram transformação digital.",
  },
  empresas: {
    title: "Empresas e Empresários",
    description: "Diagnóstico 360° e assessoria em CX, Dados e IA para empresas. Transforme sua operação com o Protocolo Vértice.",
  },
  login: {
    title: "Entrar",
    description: "Acesse sua conta na plataforma Data CX - Protocolo Vértice para acessar seus módulos e certificados.",
  },
  upgrade: {
    title: "Upgrade de Plano",
    description: "Faça upgrade do seu plano para acessar mais módulos e trilhas do Protocolo Vértice.",
  },
  jornada: {
    title: "Jornada de Descoberta",
    description: "Descubra qual programa do Protocolo Vértice é ideal para você. Quiz interativo com recomendação personalizada.",
  },
};
