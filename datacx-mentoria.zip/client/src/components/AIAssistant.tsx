import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { trpc } from "@/lib/trpc";
import { Streamdown } from "streamdown";
import {
  MessageCircle,
  Send,
  X,
  Bot,
  User,
  Loader2,
  Sparkles,
  Minimize2,
  Maximize2,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface AIAssistantProps {
  context?: "general" | "course";
  courseTitle?: string;
  courseContent?: string;
}

export default function AIAssistant({ 
  context = "general", 
  courseTitle,
  courseContent 
}: AIAssistantProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const chatMutation = trpc.ai.chat.useMutation();

  const systemPrompt = context === "course" 
    ? `Você é o Mentor Virtual do Protocolo Vértice, especializado em CX, Dados e IA. 
       Você está ajudando um aluno no curso "${courseTitle}".
       ${courseContent ? `Contexto do curso: ${courseContent}` : ""}
       
       Responda de forma didática, prática e conectada com a metodologia do Protocolo Vértice.
       Use exemplos reais quando possível e sempre conecte com os 5 passos: Clareza, Evidência, Prioridade, Execução e Escala.
       Seja encorajador mas direto ao ponto.`
    : `Você é o Assistente Virtual do Protocolo Vértice, a metodologia de Samuel Rosa para transformar CX, dados e IA em resultado real.
       
       Você pode ajudar com:
       - Dúvidas sobre o Protocolo Vértice e seus 5 passos (Clareza, Evidência, Prioridade, Execução, Escala)
       - Informações sobre os programas de mentoria disponíveis
       - Orientações sobre CX, análise de dados e IA aplicada
       - Como fazer o Radar Vértice para descobrir seu nível de maturidade
       
       Seja profissional, didático e sempre conecte as respostas com a metodologia Vértice.
       Quando apropriado, sugira que o usuário faça o Radar Vértice ou agende uma sessão diagnóstica.`;

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    if (isOpen && !isMinimized && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen, isMinimized]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      const response = await chatMutation.mutateAsync({
        message: input.trim(),
        systemPrompt,
        history: messages.slice(-10).map((m) => ({
          role: m.role,
          content: m.content,
        })),
      });

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: typeof response.reply === 'string' ? response.reply : String(response.reply),
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "Desculpe, ocorreu um erro ao processar sua mensagem. Por favor, tente novamente.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Floating Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="fixed bottom-6 right-6 z-50"
          >
            <Button
              onClick={() => setIsOpen(true)}
              className="w-14 h-14 rounded-full bg-gradient-to-r from-primary to-teal-400 hover:from-primary/90 hover:to-teal-400/90 shadow-lg shadow-primary/25"
            >
              <MessageCircle className="w-6 h-6" />
            </Button>
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-coral rounded-full animate-pulse" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              scale: 1,
              height: isMinimized ? "auto" : "500px"
            }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 w-[380px] max-w-[calc(100vw-3rem)]"
          >
            <Card className="bg-card border-border/50 shadow-2xl overflow-hidden h-full flex flex-col">
              {/* Header */}
              <CardHeader className="p-4 bg-gradient-to-r from-primary/10 to-teal-400/10 border-b border-border/50 flex-shrink-0">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full overflow-hidden">
                      <img 
                        src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/gSTtvvumzIPDHDry.png" 
                        alt="Daniel - Assistente Virtual"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <CardTitle className="text-base">
                        {context === "course" ? "Daniel - Mentor" : "Daniel"}
                      </CardTitle>
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <span className="w-2 h-2 bg-green-500 rounded-full" />
                        Online
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setIsMinimized(!isMinimized)}
                    >
                      {isMinimized ? (
                        <Maximize2 className="w-4 h-4" />
                      ) : (
                        <Minimize2 className="w-4 h-4" />
                      )}
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setIsOpen(false)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>

              {!isMinimized && (
                <>
                  {/* Messages */}
                  <CardContent className="flex-1 p-0 overflow-hidden">
                    <ScrollArea className="h-[340px] p-4" ref={scrollRef}>
                      {messages.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-full text-center p-4">
                          <div className="w-16 h-16 rounded-full bg-gradient-to-r from-primary/20 to-teal-400/20 flex items-center justify-center mb-4">
                            <Sparkles className="w-8 h-8 text-primary" />
                          </div>
<h3 className="font-semibold mb-2">
                                            {context === "course" 
                                              ? "Olá! Sou o Daniel, seu Mentor Virtual" 
                                              : "Olá! Sou o Daniel"}
                                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {context === "course"
                              ? "Estou aqui para ajudar com suas dúvidas sobre o conteúdo do curso."
                              : "Posso ajudar com dúvidas sobre o Protocolo Vértice, mentorias e CX, Dados e IA."}
                          </p>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {messages.map((message) => (
                            <div
                              key={message.id}
                              className={`flex gap-3 ${
                                message.role === "user" ? "flex-row-reverse" : ""
                              }`}
                            >
                              <div
                                className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                                  message.role === "user"
                                    ? "bg-coral/20"
                                    : "bg-gradient-to-r from-primary to-teal-400"
                                }`}
                              >
                                {message.role === "user" ? (
                                  <User className="w-4 h-4 text-coral" />
                                ) : (
                                              <img 
                                                src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/gSTtvvumzIPDHDry.png" 
                                                alt="Daniel"
                                                className="w-full h-full object-cover rounded-full"
                                              />
                                )}
                              </div>
                              <div
                                className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                                  message.role === "user"
                                    ? "bg-coral text-white rounded-tr-none"
                                    : "bg-muted rounded-tl-none"
                                }`}
                              >
                                {message.role === "assistant" ? (
                                  <Streamdown className="text-sm prose prose-sm dark:prose-invert max-w-none">
                                    {message.content}
                                  </Streamdown>
                                ) : (
                                  <p className="text-sm">{message.content}</p>
                                )}
                              </div>
                            </div>
                          ))}
                          {isLoading && (
                            <div className="flex gap-3">
                              <div className="w-8 h-8 rounded-full overflow-hidden">
                                <img 
                                  src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/gSTtvvumzIPDHDry.png" 
                                  alt="Daniel"
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="bg-muted rounded-2xl rounded-tl-none px-4 py-3">
                                <Loader2 className="w-4 h-4 animate-spin" />
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </ScrollArea>
                  </CardContent>

                  {/* Input */}
                  <div className="p-4 border-t border-border/50 flex-shrink-0">
                    <div className="flex gap-2">
                      <Input
                        ref={inputRef}
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyPress={handleKeyPress}
                        placeholder="Digite sua mensagem..."
                        className="flex-1 bg-muted/50"
                        disabled={isLoading}
                      />
                      <Button
                        onClick={handleSend}
                        disabled={!input.trim() || isLoading}
                        className="bg-gradient-to-r from-primary to-teal-400 hover:from-primary/90 hover:to-teal-400/90"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </>
              )}
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
