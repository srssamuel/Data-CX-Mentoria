import { useEffect, useRef } from "react";

interface JsonLdProps {
  data: Record<string, unknown>;
}

export default function JsonLd({ data }: JsonLdProps) {
  const scriptRef = useRef<HTMLScriptElement | null>(null);

  useEffect(() => {
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.text = JSON.stringify(data);
    const typeStr = String(data["@type"] || "generic").replace(/\s+/g, "-");
    script.id = `jsonld-${typeStr}-${Math.random().toString(36).slice(2, 8)}`;
    document.head.appendChild(script);
    scriptRef.current = script;

    return () => {
      if (scriptRef.current && scriptRef.current.parentNode) {
        scriptRef.current.remove();
      }
    };
  }, [data]);

  return null;
}

function getBaseUrl() {
  if (typeof window === "undefined") return "";
  return window.location.origin;
}

// Pre-built structured data
export const ORGANIZATION_LD = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "Data CX - Protocolo Vértice",
  alternateName: "Data CX",
  description: "Mentoria e consultoria em Customer Experience, Dados e Inteligência Artificial. Metodologia Protocolo Vértice para transformar operações com governança, cadência e execução.",
  url: getBaseUrl(),
  logo: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/yiFXtpCIREJMAdgt.png",
  image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/UhtZnSJroZcyyuqb.png",
  founder: {
    "@type": "Person",
    name: "Samuel Rosa",
    jobTitle: "Especialista em CX, Dados e IA",
    description: "+15 anos transformando operações com Customer Experience, Dados e Inteligência Artificial",
    sameAs: [
      "https://linkedin.com/in/samuel-rosa-5a1447b7",
      "https://instagram.com/srssamuelrosa",
    ],
  },
  contactPoint: {
    "@type": "ContactPoint",
    email: "contato@datacx.com.br",
    telephone: "+55-84-99127-8513",
    contactType: "customer service",
    availableLanguage: "Portuguese",
    areaServed: "BR",
  },
  sameAs: [
    "https://linkedin.com/in/samuel-rosa-5a1447b7",
    "https://instagram.com/srssamuelrosa",
  ],
  areaServed: {
    "@type": "Country",
    name: "Brazil",
  },
  knowsAbout: [
    "Customer Experience",
    "Data Analytics",
    "Artificial Intelligence",
    "Digital Transformation",
    "Business Intelligence",
  ],
};

export const COURSE_LD = {
  "@context": "https://schema.org",
  "@type": "Course",
  name: "Protocolo Vértice - Formação em CX, Dados e IA",
  description: "Programa completo de formação em Customer Experience, Dados e Inteligência Artificial. 4 trilhas com 60 módulos: Introdução, CX, Dados e IA. Playbooks práticos, certificados e mentoria.",
  provider: {
    "@type": "Organization",
    name: "Data CX - Protocolo Vértice",
    url: getBaseUrl(),
  },
  instructor: {
    "@type": "Person",
    name: "Samuel Rosa",
    jobTitle: "Especialista em CX, Dados e IA",
  },
  inLanguage: "pt-BR",
  isAccessibleForFree: false,
  offers: [
    {
      "@type": "Offer",
      name: "Playbook Vértice",
      price: "377.00",
      priceCurrency: "BRL",
      availability: "https://schema.org/InStock",
      category: "Online Course",
    },
    {
      "@type": "Offer",
      name: "Mentoria em Grupo",
      price: "1497.00",
      priceCurrency: "BRL",
      availability: "https://schema.org/InStock",
      category: "Online Mentorship",
    },
  ],
  hasCourseInstance: [
    {
      "@type": "CourseInstance",
      name: "Trilha Introdução",
      courseMode: "online",
      courseWorkload: "6 módulos",
    },
    {
      "@type": "CourseInstance",
      name: "Trilha CX",
      courseMode: "online",
      courseWorkload: "18 módulos",
    },
    {
      "@type": "CourseInstance",
      name: "Trilha Dados",
      courseMode: "online",
      courseWorkload: "18 módulos",
    },
    {
      "@type": "CourseInstance",
      name: "Trilha IA",
      courseMode: "online",
      courseWorkload: "18 módulos",
    },
  ],
  numberOfCredits: 4,
  educationalLevel: "Beginner to Advanced",
  about: [
    "Customer Experience",
    "Data Analytics",
    "Artificial Intelligence",
    "Business Transformation",
  ],
};

export const FAQ_LD = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: [
    {
      "@type": "Question",
      name: "O que é o Protocolo Vértice?",
      acceptedAnswer: {
        "@type": "Answer",
        text: "O Protocolo Vértice é uma metodologia estruturada em 5 pilares (Clareza, Evidência, Prioridade, Execução e Escala) para transformar operações usando CX, Dados e IA. Desenvolvida por Samuel Rosa com base em +15 anos de experiência e +70 clientes atendidos.",
      },
    },
    {
      "@type": "Question",
      name: "Para quem é a mentoria Data CX?",
      acceptedAnswer: {
        "@type": "Answer",
        text: "A mentoria é para jovens profissionais (18-26 anos), gestores, executivos e empresas que querem transformar suas operações com Customer Experience, Dados e Inteligência Artificial. Há programas específicos para cada perfil.",
      },
    },
    {
      "@type": "Question",
      name: "Como funciona o Radar Vértice?",
      acceptedAnswer: {
        "@type": "Answer",
        text: "O Radar Vértice é uma autoavaliação gratuita com 28 perguntas em 6 dimensões que identifica seu nível de maturidade em CX, Dados e IA, e recomenda o programa ideal para você. Leva menos de 5 minutos.",
      },
    },
    {
      "@type": "Question",
      name: "Quanto custa o Playbook Vértice?",
      acceptedAnswer: {
        "@type": "Answer",
        text: "O Playbook Vértice custa R$ 377 e inclui acesso a 24 módulos das trilhas de Introdução e CX, com playbooks práticos, templates e certificado de conclusão.",
      },
    },
    {
      "@type": "Question",
      name: "Quais formas de pagamento são aceitas?",
      acceptedAnswer: {
        "@type": "Answer",
        text: "Aceitamos cartão de crédito (todas as bandeiras) e PIX. O pagamento é processado de forma segura pelo Stripe.",
      },
    },
    {
      "@type": "Question",
      name: "Recebo certificado ao concluir?",
      acceptedAnswer: {
        "@type": "Answer",
        text: "Sim! Ao completar todos os módulos de uma trilha, você recebe um certificado digital verificável. Ao completar as 4 trilhas, recebe o certificado especial 'Protocolo Vértice Completo'.",
      },
    },
  ],
};

// Breadcrumb helper
export function createBreadcrumbLD(items: { name: string; url: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: item.url,
    })),
  };
}
