import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Share2,
  Linkedin,
  Twitter,
  Facebook,
  MessageCircle,
  Link2,
  CheckCircle2,
  Trophy,
  Target,
  Flame,
  Crown,
  Medal,
  Download,
} from "lucide-react";
import { toast } from "sonner";

interface BadgeData {
  id: number;
  slug: string;
  name: string;
  description: string | null;
  category: string;
  pointsReward: number;
  earnedAt?: string;
}

interface ShareBadgeModalProps {
  badge: BadgeData | null;
  userName: string;
  isOpen: boolean;
  onClose: () => void;
}

// Badge Preview Card Component
function BadgePreviewCard({ badge, userName }: { badge: BadgeData; userName: string }) {
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "progress": return <Target className="w-8 h-8" />;
      case "engagement": return <Flame className="w-8 h-8" />;
      case "achievement": return <Trophy className="w-8 h-8" />;
      case "special": return <Crown className="w-8 h-8" />;
      default: return <Medal className="w-8 h-8" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "progress": return "from-blue-500 to-cyan-500";
      case "engagement": return "from-orange-500 to-red-500";
      case "achievement": return "from-purple-500 to-pink-500";
      case "special": return "from-yellow-500 to-amber-500";
      default: return "from-gray-500 to-slate-500";
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "progress": return "Progresso";
      case "engagement": return "Engajamento";
      case "achievement": return "Conquista";
      case "special": return "Especial";
      default: return "Medalha";
    }
  };

  return (
    <div 
      id="badge-share-card"
      className="relative w-full max-w-md mx-auto bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 rounded-2xl overflow-hidden shadow-2xl"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-32 h-32 bg-primary rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-32 h-32 bg-purple-500 rounded-full blur-3xl" />
      </div>

      {/* Content */}
      <div className="relative p-6 text-center">
        {/* Header */}
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center">
            <span className="text-white font-bold text-sm">DCX</span>
          </div>
          <span className="text-sm font-medium text-muted-foreground">Data CX • Protocolo Vértice</span>
        </div>

        {/* Badge Icon */}
        <div className="flex justify-center mb-4">
          <div className={`w-24 h-24 rounded-full bg-gradient-to-br ${getCategoryColor(badge.category)} flex items-center justify-center text-white shadow-2xl ring-4 ring-white/20`}>
            {getCategoryIcon(badge.category)}
          </div>
        </div>

        {/* Badge Info */}
        <Badge variant="secondary" className="mb-3">
          {getCategoryLabel(badge.category)}
        </Badge>
        
        <h3 className="text-2xl font-bold text-white mb-2">{badge.name}</h3>
        <p className="text-sm text-muted-foreground mb-4 px-4">{badge.description}</p>

        {/* Points */}
        {badge.pointsReward > 0 && (
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-yellow-500/20 text-yellow-400 mb-4">
            <Trophy className="w-4 h-4" />
            <span className="font-semibold">+{badge.pointsReward} pontos</span>
          </div>
        )}

        {/* Divider */}
        <div className="border-t border-white/10 my-4" />

        {/* User Info */}
        <div className="flex items-center justify-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center text-white font-bold">
            {userName.charAt(0).toUpperCase()}
          </div>
          <div className="text-left">
            <p className="font-semibold text-white">{userName}</p>
            <p className="text-xs text-muted-foreground">
              Conquistou em {badge.earnedAt ? new Date(badge.earnedAt).toLocaleDateString("pt-BR") : new Date().toLocaleDateString("pt-BR")}
            </p>
          </div>
        </div>

        {/* Checkmark */}
        <div className="absolute top-4 right-4">
          <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
            <CheckCircle2 className="w-5 h-5 text-white" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ShareBadgeModal({ badge, userName, isOpen, onClose }: ShareBadgeModalProps) {
  const [copied, setCopied] = useState(false);

  if (!badge) return null;

  const shareUrl = `${window.location.origin}/perfil?badge=${badge.slug}`;
  const shareText = `🏆 Acabei de conquistar a medalha "${badge.name}" no Data CX - Protocolo Vértice! ${badge.pointsReward > 0 ? `+${badge.pointsReward} pontos` : ""}`;
  const shareHashtags = "DataCX,ProtocoloVertice,CX,Dados,IA";

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      toast.success("Link copiado para a área de transferência!");
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error("Erro ao copiar link");
    }
  };

  const handleShareLinkedIn = () => {
    const url = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`;
    window.open(url, "_blank", "width=600,height=400");
  };

  const handleShareTwitter = () => {
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}&hashtags=${shareHashtags}`;
    window.open(url, "_blank", "width=600,height=400");
  };

  const handleShareFacebook = () => {
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`;
    window.open(url, "_blank", "width=600,height=400");
  };

  const handleShareWhatsApp = () => {
    const url = `https://wa.me/?text=${encodeURIComponent(`${shareText}\n\n${shareUrl}`)}`;
    window.open(url, "_blank");
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Medalha: ${badge.name}`,
          text: shareText,
          url: shareUrl,
        });
      } catch (err) {
        // User cancelled
      }
    } else {
      handleCopyLink();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            Compartilhar Medalha
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Badge Preview */}
          <BadgePreviewCard badge={badge} userName={userName} />

          {/* Share Buttons */}
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground text-center">
              Compartilhe sua conquista nas redes sociais
            </p>

            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                className="flex items-center gap-2 h-12 bg-[#0077B5]/10 hover:bg-[#0077B5]/20 border-[#0077B5]/30 text-[#0077B5]"
                onClick={handleShareLinkedIn}
              >
                <Linkedin className="w-5 h-5" />
                LinkedIn
              </Button>

              <Button
                variant="outline"
                className="flex items-center gap-2 h-12 bg-[#1DA1F2]/10 hover:bg-[#1DA1F2]/20 border-[#1DA1F2]/30 text-[#1DA1F2]"
                onClick={handleShareTwitter}
              >
                <Twitter className="w-5 h-5" />
                Twitter/X
              </Button>

              <Button
                variant="outline"
                className="flex items-center gap-2 h-12 bg-[#25D366]/10 hover:bg-[#25D366]/20 border-[#25D366]/30 text-[#25D366]"
                onClick={handleShareWhatsApp}
              >
                <MessageCircle className="w-5 h-5" />
                WhatsApp
              </Button>

              <Button
                variant="outline"
                className="flex items-center gap-2 h-12 bg-[#1877F2]/10 hover:bg-[#1877F2]/20 border-[#1877F2]/30 text-[#1877F2]"
                onClick={handleShareFacebook}
              >
                <Facebook className="w-5 h-5" />
                Facebook
              </Button>
            </div>

            {/* Copy Link */}
            <Button
              variant="secondary"
              className="w-full flex items-center gap-2 h-12"
              onClick={handleCopyLink}
            >
              {copied ? (
                <>
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                  Link Copiado!
                </>
              ) : (
                <>
                  <Link2 className="w-5 h-5" />
                  Copiar Link
                </>
              )}
            </Button>

            {/* Native Share (Mobile) */}
            {typeof navigator !== 'undefined' && 'share' in navigator && (
              <Button
                className="w-full flex items-center gap-2 h-12"
                onClick={handleNativeShare}
              >
                <Share2 className="w-5 h-5" />
                Mais Opções de Compartilhamento
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
