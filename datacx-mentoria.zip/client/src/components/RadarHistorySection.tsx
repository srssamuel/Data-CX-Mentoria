import { useState, useMemo } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Radar, History, TrendingUp, Download, Eye, ChevronDown, ChevronUp,
  Calendar, Target, BarChart3, Brain, Shield, ArrowRight, Sparkles, FileDown
} from "lucide-react";

// Dimension config for display
const DIMENSION_CONFIG = {
  CX: { label: "CX - Cliente & Jornada", color: "#2563eb", icon: <Target className="w-4 h-4" /> },
  Dados: { label: "Dados & Analytics", color: "#16a34a", icon: <BarChart3 className="w-4 h-4" /> },
  IA: { label: "Inteligência Artificial", color: "#9333ea", icon: <Brain className="w-4 h-4" /> },
  Governança: { label: "Governança & Execução", color: "#d97706", icon: <Shield className="w-4 h-4" /> },
};

const LEVEL_LABELS: Record<string, string> = {
  fundamentos: "Fundamentos",
  aplicacao: "Aplicação",
  escala: "Escala",
  estrategia: "Estratégia",
};

const PERSONA_LABELS: Record<string, string> = {
  jovem: "Jovem Profissional",
  gestor: "Gestor",
  executivo: "Executivo",
  empresario: "Empresário",
};

interface RadarHistoryItem {
  id: number;
  name: string;
  email: string;
  persona: string | null;
  sector: string | null;
  scoreCX: string | null;
  scoreData: string | null;
  scoreIA: string | null;
  scoreGovernance: string | null;
  scoreTotal: string | null;
  recommendedLevel: string | null;
  recommendedProduct: string | null;
  aiAnalysis: string | null;
  answers: Record<string, number | string> | null;
  challenges: string | null;
  createdAt: Date | string;
}

interface RadarHistorySectionProps {
  history: RadarHistoryItem[];
}

function scoreColor(s: number): string {
  if (s <= 2) return "#ef4444";
  if (s <= 3) return "#f59e0b";
  return "#22c55e";
}

function scoreBadge(s: number): string {
  if (s <= 2) return "bg-red-500/20 text-red-400 border-red-500/30";
  if (s <= 3) return "bg-amber-500/20 text-amber-400 border-amber-500/30";
  return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30";
}

// Mini radar chart SVG component
function MiniRadarChart({ scoreCX, scoreData, scoreIA, scoreGovernance, size = 120 }: {
  scoreCX: number; scoreData: number; scoreIA: number; scoreGovernance: number; size?: number;
}) {
  const center = size / 2;
  const maxR = (size / 2) - 10;
  
  const getPoint = (score: number, index: number) => {
    const angle = (Math.PI * 2 * index / 4) - Math.PI / 2;
    const r = (score / 5) * maxR;
    return {
      x: center + r * Math.cos(angle),
      y: center + r * Math.sin(angle),
    };
  };

  const scores = [scoreCX, scoreData, scoreIA, scoreGovernance];
  const colors = ["#2563eb", "#16a34a", "#9333ea", "#d97706"];
  const labels = ["CX", "Dados", "IA", "Gov"];
  
  const dataPoints = scores.map((s, i) => getPoint(s, i));
  const polygonPoints = dataPoints.map(p => `${p.x},${p.y}`).join(" ");

  // Grid lines
  const gridLevels = [1, 2, 3, 4, 5];

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="flex-shrink-0">
      {/* Grid */}
      {gridLevels.map(level => {
        const pts = [0, 1, 2, 3].map(i => getPoint(level, i));
        return (
          <polygon
            key={level}
            points={pts.map(p => `${p.x},${p.y}`).join(" ")}
            fill="none"
            stroke="currentColor"
            strokeOpacity={0.1}
            strokeWidth={0.5}
          />
        );
      })}
      
      {/* Axes */}
      {[0, 1, 2, 3].map(i => {
        const end = getPoint(5, i);
        return (
          <line
            key={i}
            x1={center}
            y1={center}
            x2={end.x}
            y2={end.y}
            stroke="currentColor"
            strokeOpacity={0.1}
            strokeWidth={0.5}
          />
        );
      })}

      {/* Data polygon */}
      <polygon
        points={polygonPoints}
        fill="url(#radarGrad)"
        fillOpacity={0.25}
        stroke="url(#radarGrad)"
        strokeWidth={1.5}
      />
      
      {/* Data points */}
      {dataPoints.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r={3} fill={colors[i]} />
      ))}

      {/* Labels */}
      {[0, 1, 2, 3].map(i => {
        const labelPt = getPoint(5.8, i);
        return (
          <text
            key={i}
            x={labelPt.x}
            y={labelPt.y}
            textAnchor="middle"
            dominantBaseline="middle"
            className="fill-muted-foreground"
            fontSize={9}
            fontWeight={500}
          >
            {labels[i]}
          </text>
        );
      })}

      <defs>
        <linearGradient id="radarGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#06b6d4" />
          <stop offset="100%" stopColor="#8b5cf6" />
        </linearGradient>
      </defs>
    </svg>
  );
}

// Evolution line chart SVG
function EvolutionChart({ history }: { history: RadarHistoryItem[] }) {
  const sorted = useMemo(() => 
    [...history].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()),
    [history]
  );

  if (sorted.length < 2) return null;

  const width = 600;
  const height = 200;
  const padding = { top: 20, right: 20, bottom: 40, left: 40 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  const xStep = chartW / (sorted.length - 1);
  
  const dimensions = [
    { key: "scoreCX", color: "#2563eb", label: "CX" },
    { key: "scoreData", color: "#16a34a", label: "Dados" },
    { key: "scoreIA", color: "#9333ea", label: "IA" },
    { key: "scoreGovernance", color: "#d97706", label: "Gov" },
  ];

  const getY = (score: number) => padding.top + chartH - (score / 5) * chartH;
  const getX = (index: number) => padding.left + index * xStep;

  return (
    <div className="w-full overflow-x-auto">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full min-w-[400px]" preserveAspectRatio="xMidYMid meet">
        {/* Grid lines */}
        {[1, 2, 3, 4, 5].map(v => (
          <g key={v}>
            <line
              x1={padding.left}
              y1={getY(v)}
              x2={width - padding.right}
              y2={getY(v)}
              stroke="currentColor"
              strokeOpacity={0.08}
              strokeWidth={0.5}
            />
            <text
              x={padding.left - 8}
              y={getY(v)}
              textAnchor="end"
              dominantBaseline="middle"
              className="fill-muted-foreground"
              fontSize={10}
            >
              {v}
            </text>
          </g>
        ))}

        {/* X axis labels */}
        {sorted.map((item, i) => (
          <text
            key={i}
            x={getX(i)}
            y={height - 8}
            textAnchor="middle"
            className="fill-muted-foreground"
            fontSize={9}
          >
            {new Date(item.createdAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "short" })}
          </text>
        ))}

        {/* Lines for each dimension */}
        {dimensions.map(dim => {
          const points = sorted.map((item, i) => {
            const score = parseFloat((item as any)[dim.key] || "0");
            return `${getX(i)},${getY(score)}`;
          });
          return (
            <g key={dim.key}>
              <polyline
                points={points.join(" ")}
                fill="none"
                stroke={dim.color}
                strokeWidth={2}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {sorted.map((item, i) => {
                const score = parseFloat((item as any)[dim.key] || "0");
                return (
                  <circle
                    key={i}
                    cx={getX(i)}
                    cy={getY(score)}
                    r={3.5}
                    fill={dim.color}
                    stroke="var(--background)"
                    strokeWidth={1.5}
                  />
                );
              })}
            </g>
          );
        })}

        {/* Legend */}
        {dimensions.map((dim, i) => (
          <g key={dim.key} transform={`translate(${padding.left + i * 90}, ${padding.top - 10})`}>
            <circle cx={0} cy={0} r={4} fill={dim.color} />
            <text x={8} y={0} dominantBaseline="middle" className="fill-foreground" fontSize={10} fontWeight={500}>
              {dim.label}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

// Comparison between two diagnostics
function ComparisonView({ current, previous }: { current: RadarHistoryItem; previous: RadarHistoryItem }) {
  const dims = [
    { key: "scoreCX", label: "CX", color: "#2563eb" },
    { key: "scoreData", label: "Dados", color: "#16a34a" },
    { key: "scoreIA", label: "IA", color: "#9333ea" },
    { key: "scoreGovernance", label: "Governança", color: "#d97706" },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      {dims.map(dim => {
        const curr = parseFloat((current as any)[dim.key] || "0");
        const prev = parseFloat((previous as any)[dim.key] || "0");
        const diff = curr - prev;
        const diffStr = diff > 0 ? `+${diff.toFixed(1)}` : diff.toFixed(1);
        const diffColor = diff > 0 ? "text-emerald-400" : diff < 0 ? "text-red-400" : "text-muted-foreground";
        
        return (
          <div key={dim.key} className="bg-card/30 border border-border/30 rounded-lg p-3 text-center">
            <div className="text-[10px] text-muted-foreground mb-1 font-medium">{dim.label}</div>
            <div className="text-lg font-bold" style={{ color: dim.color }}>{curr.toFixed(1)}</div>
            <div className={`text-xs font-semibold ${diffColor}`}>
              {diff !== 0 ? diffStr : "="}
            </div>
            <div className="text-[9px] text-muted-foreground mt-0.5">
              ant: {prev.toFixed(1)}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ===== PDF GENERATION HELPERS =====

function generateRadarSVGForPDF(
  scores1: number[], scores2: number[] | null,
  labels: string[], colors: string[],
  size: number = 300
): string {
  const center = size / 2;
  const maxR = (size / 2) - 30;
  
  const getPoint = (score: number, index: number) => {
    const angle = (Math.PI * 2 * index / 4) - Math.PI / 2;
    const r = (score / 5) * maxR;
    return { x: center + r * Math.cos(angle), y: center + r * Math.sin(angle) };
  };

  let svg = `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg">`;
  
  // Grid
  for (let level = 1; level <= 5; level++) {
    const pts = [0,1,2,3].map(i => getPoint(level, i));
    svg += `<polygon points="${pts.map(p => `${p.x},${p.y}`).join(' ')}" fill="none" stroke="#e5e7eb" stroke-width="0.8"/>`;
  }
  
  // Axes
  for (let i = 0; i < 4; i++) {
    const end = getPoint(5, i);
    svg += `<line x1="${center}" y1="${center}" x2="${end.x}" y2="${end.y}" stroke="#e5e7eb" stroke-width="0.8"/>`;
  }

  // Grid level labels
  for (let level = 1; level <= 5; level++) {
    const pt = getPoint(level, 0);
    svg += `<text x="${pt.x + 6}" y="${pt.y - 4}" font-size="9" fill="#9ca3af" font-family="Inter, sans-serif">${level}</text>`;
  }

  // Polygon 2 (previous - if comparison)
  if (scores2) {
    const pts2 = scores2.map((s, i) => getPoint(s, i));
    svg += `<polygon points="${pts2.map(p => `${p.x},${p.y}`).join(' ')}" fill="rgba(156,163,175,0.15)" stroke="#9ca3af" stroke-width="1.5" stroke-dasharray="6,3"/>`;
    pts2.forEach((p, i) => {
      svg += `<circle cx="${p.x}" cy="${p.y}" r="4" fill="#9ca3af" stroke="white" stroke-width="1.5"/>`;
    });
  }

  // Polygon 1 (current)
  const pts1 = scores1.map((s, i) => getPoint(s, i));
  svg += `<polygon points="${pts1.map(p => `${p.x},${p.y}`).join(' ')}" fill="rgba(6,182,212,0.2)" stroke="#06b6d4" stroke-width="2"/>`;
  pts1.forEach((p, i) => {
    svg += `<circle cx="${p.x}" cy="${p.y}" r="5" fill="${colors[i]}" stroke="white" stroke-width="2"/>`;
  });

  // Labels
  const labelPositions = [0,1,2,3].map(i => getPoint(6.2, i));
  labelPositions.forEach((p, i) => {
    svg += `<text x="${p.x}" y="${p.y}" text-anchor="middle" dominant-baseline="middle" font-size="12" font-weight="600" fill="${colors[i]}" font-family="Inter, sans-serif">${labels[i]}</text>`;
  });

  svg += `</svg>`;
  return svg;
}

function generateComparisonPDF(current: RadarHistoryItem, previous: RadarHistoryItem): void {
  const dims = [
    { key: "scoreCX", label: "CX - Cliente & Jornada", shortLabel: "CX", color: "#2563eb" },
    { key: "scoreData", label: "Dados & Analytics", shortLabel: "Dados", color: "#16a34a" },
    { key: "scoreIA", label: "Inteligência Artificial", shortLabel: "IA", color: "#9333ea" },
    { key: "scoreGovernance", label: "Governança & Execução", shortLabel: "Gov", color: "#d97706" },
  ];

  const currScores = dims.map(d => parseFloat((current as any)[d.key] || "0"));
  const prevScores = dims.map(d => parseFloat((previous as any)[d.key] || "0"));
  const currTotal = parseFloat(current.scoreTotal || "0");
  const prevTotal = parseFloat(previous.scoreTotal || "0");
  const totalDiff = currTotal - prevTotal;

  const currDate = new Date(current.createdAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });
  const prevDate = new Date(previous.createdAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });
  const today = new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });

  const radarSVG = generateRadarSVGForPDF(
    currScores, prevScores,
    dims.map(d => d.shortLabel),
    dims.map(d => d.color),
    300
  );

  const scColor = (s: number) => s <= 2 ? '#ef4444' : s <= 3 ? '#f59e0b' : '#22c55e';
  const diffArrow = (d: number) => d > 0 ? '↑' : d < 0 ? '↓' : '=';
  const diffColor = (d: number) => d > 0 ? '#22c55e' : d < 0 ? '#ef4444' : '#9ca3af';

  const comparisonRows = dims.map((dim, i) => {
    const curr = currScores[i];
    const prev = prevScores[i];
    const diff = curr - prev;
    const pctCurr = (curr / 5) * 100;
    const pctPrev = (prev / 5) * 100;
    return `
      <tr>
        <td style="padding: 12px 16px; font-weight: 500; color: ${dim.color}; border-bottom: 1px solid #f3f4f6;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 10px; height: 10px; border-radius: 50%; background: ${dim.color};"></div>
            ${dim.label}
          </div>
        </td>
        <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #f3f4f6;">
          <div style="font-size: 18px; font-weight: 700; color: #6b7280;">${prev.toFixed(1)}</div>
          <div style="background: #e5e7eb; border-radius: 4px; height: 6px; margin-top: 4px; overflow: hidden;">
            <div style="background: #9ca3af; height: 100%; width: ${pctPrev}%; border-radius: 4px;"></div>
          </div>
        </td>
        <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #f3f4f6;">
          <div style="font-size: 18px; font-weight: 700; color: ${dim.color};">${curr.toFixed(1)}</div>
          <div style="background: #e5e7eb; border-radius: 4px; height: 6px; margin-top: 4px; overflow: hidden;">
            <div style="background: ${dim.color}; height: 100%; width: ${pctCurr}%; border-radius: 4px;"></div>
          </div>
        </td>
        <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #f3f4f6;">
          <span style="font-size: 16px; font-weight: 700; color: ${diffColor(diff)};">
            ${diffArrow(diff)} ${diff !== 0 ? (diff > 0 ? '+' : '') + diff.toFixed(1) : '—'}
          </span>
        </td>
      </tr>
    `;
  }).join('');

  // Total row
  const totalRow = `
    <tr style="background: #f9fafb;">
      <td style="padding: 14px 16px; font-weight: 700; color: #111827; border-top: 2px solid #e5e7eb;">
        Média Geral
      </td>
      <td style="padding: 14px 16px; text-align: center; border-top: 2px solid #e5e7eb;">
        <div style="font-size: 20px; font-weight: 800; color: ${scColor(prevTotal)};">${prevTotal.toFixed(1)}</div>
      </td>
      <td style="padding: 14px 16px; text-align: center; border-top: 2px solid #e5e7eb;">
        <div style="font-size: 20px; font-weight: 800; color: ${scColor(currTotal)};">${currTotal.toFixed(1)}</div>
      </td>
      <td style="padding: 14px 16px; text-align: center; border-top: 2px solid #e5e7eb;">
        <span style="font-size: 18px; font-weight: 800; color: ${diffColor(totalDiff)};">
          ${diffArrow(totalDiff)} ${totalDiff !== 0 ? (totalDiff > 0 ? '+' : '') + totalDiff.toFixed(1) : '—'}
        </span>
      </td>
    </tr>
  `;

  // Insights section
  const improvements = dims.filter((_, i) => currScores[i] > prevScores[i]);
  const declines = dims.filter((_, i) => currScores[i] < prevScores[i]);
  const stable = dims.filter((_, i) => currScores[i] === prevScores[i]);

  let insightsHtml = '';
  if (improvements.length > 0) {
    insightsHtml += `
      <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 16px; margin-bottom: 12px;">
        <div style="font-weight: 600; color: #166534; margin-bottom: 6px;">✅ Dimensões em Evolução</div>
        <p style="color: #15803d; font-size: 13px; margin: 0;">
          ${improvements.map((d, i) => {
            const idx = dims.indexOf(d);
            const diff = currScores[idx] - prevScores[idx];
            return `<strong>${d.shortLabel}</strong> (+${diff.toFixed(1)})`;
          }).join(', ')}
        </p>
      </div>
    `;
  }
  if (declines.length > 0) {
    insightsHtml += `
      <div style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; padding: 16px; margin-bottom: 12px;">
        <div style="font-weight: 600; color: #991b1b; margin-bottom: 6px;">⚠️ Dimensões que Precisam de Atenção</div>
        <p style="color: #b91c1c; font-size: 13px; margin: 0;">
          ${declines.map((d) => {
            const idx = dims.indexOf(d);
            const diff = currScores[idx] - prevScores[idx];
            return `<strong>${d.shortLabel}</strong> (${diff.toFixed(1)})`;
          }).join(', ')}
        </p>
      </div>
    `;
  }
  if (stable.length > 0) {
    insightsHtml += `
      <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-bottom: 12px;">
        <div style="font-weight: 600; color: #475569; margin-bottom: 6px;">➡️ Dimensões Estáveis</div>
        <p style="color: #64748b; font-size: 13px; margin: 0;">
          ${stable.map(d => `<strong>${d.shortLabel}</strong>`).join(', ')}
        </p>
      </div>
    `;
  }

  // Level info
  const currLevel = LEVEL_LABELS[current.recommendedLevel || ""] || current.recommendedLevel || "—";
  const prevLevel = LEVEL_LABELS[previous.recommendedLevel || ""] || previous.recommendedLevel || "—";
  const currPersona = PERSONA_LABELS[current.persona || ""] || current.persona || "—";

  const htmlContent = `
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
      <meta charset="UTF-8">
      <title>Comparativo Radar Vértice - ${current.name}</title>
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; color: #1f2937; background: white; }
        @page { size: A4; margin: 0; }
        .page { width: 210mm; min-height: 297mm; padding: 0; page-break-after: always; }
        @media print {
          body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .no-print { display: none !important; }
        }
      </style>
    </head>
    <body>
      <!-- PAGE 1 -->
      <div class="page">
        <!-- Header -->
        <div style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%); padding: 32px 40px; color: white;">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
                <div style="background: linear-gradient(135deg, #06b6d4, #8b5cf6); padding: 8px 14px; border-radius: 8px; font-weight: 800; font-size: 16px; letter-spacing: 1px;">DCX</div>
                <div>
                  <div style="font-size: 18px; font-weight: 700;">Data CX</div>
                  <div style="font-size: 10px; color: #94a3b8; letter-spacing: 2px; text-transform: uppercase;">Protocolo Vértice</div>
                </div>
              </div>
            </div>
            <div style="text-align: right;">
              <div style="font-size: 20px; font-weight: 800; background: linear-gradient(135deg, #06b6d4, #8b5cf6); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                RELATÓRIO COMPARATIVO
              </div>
              <div style="font-size: 11px; color: #94a3b8; margin-top: 4px;">Radar Vértice — Evolução de Maturidade</div>
            </div>
          </div>
        </div>

        <!-- Info Bar -->
        <div style="background: #f8fafc; border-bottom: 1px solid #e2e8f0; padding: 16px 40px; display: flex; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
          <div>
            <span style="font-size: 11px; color: #64748b;">Profissional:</span>
            <span style="font-size: 13px; font-weight: 600; margin-left: 6px;">${current.name}</span>
          </div>
          <div>
            <span style="font-size: 11px; color: #64748b;">Perfil:</span>
            <span style="font-size: 13px; font-weight: 500; margin-left: 6px;">${currPersona}</span>
          </div>
          ${current.sector ? `<div>
            <span style="font-size: 11px; color: #64748b;">Setor:</span>
            <span style="font-size: 13px; font-weight: 500; margin-left: 6px;">${current.sector}</span>
          </div>` : ''}
          <div>
            <span style="font-size: 11px; color: #64748b;">Gerado em:</span>
            <span style="font-size: 13px; font-weight: 500; margin-left: 6px;">${today}</span>
          </div>
        </div>

        <!-- Period comparison header -->
        <div style="padding: 24px 40px 0;">
          <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 20px;">
            <div style="flex: 1; background: #f1f5f9; border-radius: 10px; padding: 14px 18px; text-align: center; border: 1px solid #e2e8f0;">
              <div style="font-size: 10px; color: #64748b; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px;">Diagnóstico Anterior</div>
              <div style="font-size: 14px; font-weight: 600; color: #374151;">${prevDate}</div>
              <div style="font-size: 24px; font-weight: 800; color: ${scColor(prevTotal)}; margin-top: 4px;">${prevTotal.toFixed(1)}<span style="font-size: 14px; color: #9ca3af;">/5.0</span></div>
              <div style="font-size: 11px; color: #6b7280; margin-top: 2px;">Nível: ${prevLevel}</div>
            </div>
            <div style="display: flex; flex-direction: column; align-items: center; gap: 4px;">
              <div style="font-size: 28px; font-weight: 800; color: ${diffColor(totalDiff)};">
                ${diffArrow(totalDiff)}
              </div>
              <div style="font-size: 16px; font-weight: 700; color: ${diffColor(totalDiff)};">
                ${totalDiff !== 0 ? (totalDiff > 0 ? '+' : '') + totalDiff.toFixed(1) : '—'}
              </div>
            </div>
            <div style="flex: 1; background: linear-gradient(135deg, #f0f9ff, #eff6ff); border-radius: 10px; padding: 14px 18px; text-align: center; border: 1px solid #bfdbfe;">
              <div style="font-size: 10px; color: #2563eb; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px;">Diagnóstico Atual</div>
              <div style="font-size: 14px; font-weight: 600; color: #1e40af;">${currDate}</div>
              <div style="font-size: 24px; font-weight: 800; color: ${scColor(currTotal)}; margin-top: 4px;">${currTotal.toFixed(1)}<span style="font-size: 14px; color: #9ca3af;">/5.0</span></div>
              <div style="font-size: 11px; color: #1e40af; margin-top: 2px;">Nível: ${currLevel}</div>
            </div>
          </div>
        </div>

        <!-- Radar Chart -->
        <div style="padding: 0 40px; text-align: center; margin-bottom: 20px;">
          <div style="font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 12px;">Gráfico Radar Comparativo</div>
          <div style="display: flex; justify-content: center; align-items: center; gap: 24px;">
            <div>${radarSVG}</div>
            <div style="text-align: left;">
              <div style="margin-bottom: 12px;">
                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
                  <div style="width: 24px; height: 3px; background: #06b6d4; border-radius: 2px;"></div>
                  <span style="font-size: 11px; color: #374151; font-weight: 500;">Atual (${currDate.split(' de ')[0]} ${currDate.split(' de ')[1]?.substring(0, 3) || ''})</span>
                </div>
                <div style="display: flex; align-items: center; gap: 8px;">
                  <div style="width: 24px; height: 3px; background: #9ca3af; border-radius: 2px; border: none; background-image: repeating-linear-gradient(90deg, #9ca3af 0, #9ca3af 6px, transparent 6px, transparent 9px);"></div>
                  <span style="font-size: 11px; color: #6b7280; font-weight: 500;">Anterior (${prevDate.split(' de ')[0]} ${prevDate.split(' de ')[1]?.substring(0, 3) || ''})</span>
                </div>
              </div>
              ${dims.map((d, i) => `
                <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 6px;">
                  <div style="width: 10px; height: 10px; border-radius: 50%; background: ${d.color};"></div>
                  <span style="font-size: 11px; color: #374151;">${d.shortLabel}</span>
                </div>
              `).join('')}
            </div>
          </div>
        </div>

        <!-- Comparison Table -->
        <div style="padding: 0 40px 24px;">
          <div style="font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 12px;">Comparação por Dimensão</div>
          <table style="width: 100%; border-collapse: collapse; border-radius: 10px; overflow: hidden; border: 1px solid #e5e7eb;">
            <thead>
              <tr style="background: #f8fafc;">
                <th style="padding: 10px 16px; text-align: left; font-size: 11px; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #e5e7eb;">Dimensão</th>
                <th style="padding: 10px 16px; text-align: center; font-size: 11px; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #e5e7eb;">Anterior</th>
                <th style="padding: 10px 16px; text-align: center; font-size: 11px; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #e5e7eb;">Atual</th>
                <th style="padding: 10px 16px; text-align: center; font-size: 11px; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #e5e7eb;">Variação</th>
              </tr>
            </thead>
            <tbody>
              ${comparisonRows}
              ${totalRow}
            </tbody>
          </table>
        </div>

        <!-- Insights -->
        <div style="padding: 0 40px 24px;">
          <div style="font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 12px;">Análise da Evolução</div>
          ${insightsHtml}
          ${totalDiff > 0 ? `
            <div style="background: linear-gradient(135deg, #f0fdf4, #ecfdf5); border: 1px solid #86efac; border-radius: 8px; padding: 16px; margin-top: 8px;">
              <p style="color: #166534; font-size: 13px; margin: 0; line-height: 1.6;">
                <strong>Parabéns!</strong> Sua média geral evoluiu de <strong>${prevTotal.toFixed(1)}</strong> para <strong>${currTotal.toFixed(1)}</strong> 
                (${totalDiff > 0 ? '+' : ''}${totalDiff.toFixed(1)} pontos). Continue investindo no seu desenvolvimento em CX, Dados, IA e Governança.
              </p>
            </div>
          ` : totalDiff < 0 ? `
            <div style="background: #fffbeb; border: 1px solid #fde68a; border-radius: 8px; padding: 16px; margin-top: 8px;">
              <p style="color: #92400e; font-size: 13px; margin: 0; line-height: 1.6;">
                Sua média geral variou de <strong>${prevTotal.toFixed(1)}</strong> para <strong>${currTotal.toFixed(1)}</strong> 
                (${totalDiff.toFixed(1)} pontos). Isso pode indicar uma autoavaliação mais crítica ou mudanças no contexto profissional. 
                Revise as dimensões em queda e trace um plano de ação.
              </p>
            </div>
          ` : `
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-top: 8px;">
              <p style="color: #475569; font-size: 13px; margin: 0; line-height: 1.6;">
                Sua média geral se manteve em <strong>${currTotal.toFixed(1)}</strong>. 
                Analise as dimensões individualmente para identificar oportunidades de evolução.
              </p>
            </div>
          `}
        </div>

        <!-- Recommendations -->
        <div style="padding: 0 40px 24px;">
          <div style="display: flex; gap: 16px;">
            <div style="flex: 1; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 16px;">
              <div style="font-size: 10px; color: #64748b; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px;">Recomendação Anterior</div>
              <div style="font-size: 13px; font-weight: 600; color: #374151;">${previous.recommendedProduct || '—'}</div>
            </div>
            <div style="flex: 1; background: linear-gradient(135deg, #eff6ff, #f0f9ff); border: 1px solid #bfdbfe; border-radius: 10px; padding: 16px;">
              <div style="font-size: 10px; color: #2563eb; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px;">Recomendação Atual</div>
              <div style="font-size: 13px; font-weight: 600; color: #1e40af;">${current.recommendedProduct || '—'}</div>
            </div>
          </div>
        </div>

        <!-- Footer -->
        <div style="position: absolute; bottom: 0; left: 0; right: 0; background: #0f172a; padding: 16px 40px; display: flex; justify-content: space-between; align-items: center;">
          <div style="color: #94a3b8; font-size: 10px;">
            Data CX — Protocolo Vértice | Relatório Comparativo de Maturidade
          </div>
          <div style="color: #64748b; font-size: 9px;">
            datacx.com.br | Gerado automaticamente em ${today}
          </div>
        </div>
      </div>

    </body>
    </html>
  `;

  const printWindow = window.open('', '_blank');
  if (printWindow) {
    printWindow.document.write(htmlContent);
    printWindow.document.close();
    setTimeout(() => {
      printWindow.print();
    }, 800);
  }
}

function generateSingleDiagnosticPDF(item: RadarHistoryItem): void {
  const dims = [
    { key: "scoreCX", label: "CX - Cliente & Jornada", shortLabel: "CX", color: "#2563eb" },
    { key: "scoreData", label: "Dados & Analytics", shortLabel: "Dados", color: "#16a34a" },
    { key: "scoreIA", label: "Inteligência Artificial", shortLabel: "IA", color: "#9333ea" },
    { key: "scoreGovernance", label: "Governança & Execução", shortLabel: "Gov", color: "#d97706" },
  ];

  const scores = dims.map(d => parseFloat((item as any)[d.key] || "0"));
  const total = parseFloat(item.scoreTotal || "0");
  const date = new Date(item.createdAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });
  const today = new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });
  const level = LEVEL_LABELS[item.recommendedLevel || ""] || item.recommendedLevel || "—";
  const persona = PERSONA_LABELS[item.persona || ""] || item.persona || "—";

  const radarSVG = generateRadarSVGForPDF(
    scores, null,
    dims.map(d => d.shortLabel),
    dims.map(d => d.color),
    280
  );

  const scColor = (s: number) => s <= 2 ? '#ef4444' : s <= 3 ? '#f59e0b' : '#22c55e';

  const scoreRows = dims.map((d, i) => {
    const pct = (scores[i] / 5) * 100;
    return `
      <tr>
        <td style="padding: 12px 16px; border-bottom: 1px solid #f3f4f6;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 10px; height: 10px; border-radius: 50%; background: ${d.color};"></div>
            <span style="font-weight: 500; color: ${d.color};">${d.label}</span>
          </div>
        </td>
        <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #f3f4f6;">
          <span style="font-size: 20px; font-weight: 700; color: ${scColor(scores[i])};">${scores[i].toFixed(1)}</span>
          <span style="font-size: 12px; color: #9ca3af;">/5.0</span>
        </td>
        <td style="padding: 12px 16px; border-bottom: 1px solid #f3f4f6; width: 200px;">
          <div style="background: #e5e7eb; border-radius: 4px; height: 8px; overflow: hidden;">
            <div style="background: ${d.color}; height: 100%; width: ${pct}%; border-radius: 4px;"></div>
          </div>
        </td>
      </tr>
    `;
  }).join('');

  const htmlContent = `
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
      <meta charset="UTF-8">
      <title>Diagnóstico Radar Vértice - ${item.name}</title>
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; color: #1f2937; background: white; }
        @page { size: A4; margin: 0; }
        .page { width: 210mm; min-height: 297mm; padding: 0; position: relative; }
        @media print {
          body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
      </style>
    </head>
    <body>
      <div class="page">
        <!-- Header -->
        <div style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%); padding: 32px 40px; color: white;">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <div style="background: linear-gradient(135deg, #06b6d4, #8b5cf6); padding: 8px 14px; border-radius: 8px; font-weight: 800; font-size: 16px; letter-spacing: 1px;">DCX</div>
              <div>
                <div style="font-size: 18px; font-weight: 700;">Data CX</div>
                <div style="font-size: 10px; color: #94a3b8; letter-spacing: 2px; text-transform: uppercase;">Protocolo Vértice</div>
              </div>
            </div>
            <div style="text-align: right;">
              <div style="font-size: 18px; font-weight: 800; color: #06b6d4;">DIAGNÓSTICO INDIVIDUAL</div>
              <div style="font-size: 11px; color: #94a3b8; margin-top: 4px;">Radar Vértice — ${date}</div>
            </div>
          </div>
        </div>

        <!-- Info -->
        <div style="background: #f8fafc; border-bottom: 1px solid #e2e8f0; padding: 16px 40px; display: flex; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
          <div><span style="font-size: 11px; color: #64748b;">Profissional:</span> <strong style="font-size: 13px;">${item.name}</strong></div>
          <div><span style="font-size: 11px; color: #64748b;">Perfil:</span> <span style="font-size: 13px;">${persona}</span></div>
          ${item.sector ? `<div><span style="font-size: 11px; color: #64748b;">Setor:</span> <span style="font-size: 13px;">${item.sector}</span></div>` : ''}
          <div><span style="font-size: 11px; color: #64748b;">Nível:</span> <strong style="font-size: 13px; color: ${scColor(total)};">${level}</strong></div>
        </div>

        <!-- Score + Radar -->
        <div style="padding: 24px 40px; display: flex; align-items: center; gap: 32px;">
          <div style="text-align: center;">
            <div style="font-size: 48px; font-weight: 800; color: ${scColor(total)};">${total.toFixed(1)}</div>
            <div style="font-size: 14px; color: #9ca3af;">/5.0 — Média Geral</div>
          </div>
          <div>${radarSVG}</div>
        </div>

        <!-- Scores Table -->
        <div style="padding: 0 40px 24px;">
          <table style="width: 100%; border-collapse: collapse; border: 1px solid #e5e7eb; border-radius: 10px; overflow: hidden;">
            <thead>
              <tr style="background: #f8fafc;">
                <th style="padding: 10px 16px; text-align: left; font-size: 11px; color: #64748b; font-weight: 600; text-transform: uppercase; border-bottom: 2px solid #e5e7eb;">Dimensão</th>
                <th style="padding: 10px 16px; text-align: center; font-size: 11px; color: #64748b; font-weight: 600; text-transform: uppercase; border-bottom: 2px solid #e5e7eb;">Score</th>
                <th style="padding: 10px 16px; text-align: left; font-size: 11px; color: #64748b; font-weight: 600; text-transform: uppercase; border-bottom: 2px solid #e5e7eb;">Progresso</th>
              </tr>
            </thead>
            <tbody>${scoreRows}</tbody>
          </table>
        </div>

        <!-- Recommendation -->
        <div style="padding: 0 40px 24px;">
          <div style="background: linear-gradient(135deg, #eff6ff, #f0f9ff); border: 1px solid #bfdbfe; border-radius: 10px; padding: 20px;">
            <div style="font-size: 11px; color: #2563eb; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px;">Produto Recomendado</div>
            <div style="font-size: 15px; font-weight: 700; color: #1e40af;">${item.recommendedProduct || '—'}</div>
          </div>
        </div>

        ${item.challenges ? `
        <!-- Challenges -->
        <div style="padding: 0 40px 24px;">
          <div style="background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 10px; padding: 20px;">
            <div style="font-size: 11px; color: #0284c7; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;">💬 Desafios e Contexto Relatados</div>
            <div style="font-size: 13px; color: #374151; line-height: 1.7; white-space: pre-wrap;">${item.challenges}</div>
          </div>
        </div>
        ` : ''}

        <!-- Footer -->
        <div style="position: absolute; bottom: 0; left: 0; right: 0; background: #0f172a; padding: 16px 40px; display: flex; justify-content: space-between; align-items: center;">
          <div style="color: #94a3b8; font-size: 10px;">Data CX — Protocolo Vértice | Diagnóstico Individual</div>
          <div style="color: #64748b; font-size: 9px;">datacx.com.br | Gerado em ${today}</div>
        </div>
      </div>
    </body>
    </html>
  `;

  const printWindow = window.open('', '_blank');
  if (printWindow) {
    printWindow.document.write(htmlContent);
    printWindow.document.close();
    setTimeout(() => { printWindow.print(); }, 800);
  }
}

// ===== MAIN COMPONENT =====

export default function RadarHistorySection({ history }: RadarHistorySectionProps) {
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [compareMode, setCompareMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);

  const sorted = useMemo(() =>
    [...history].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
    [history]
  );

  const toggleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const toggleSelect = (id: number) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(x => x !== id));
    } else if (selectedIds.length < 2) {
      setSelectedIds([...selectedIds, id]);
    } else {
      toast.info("Selecione no máximo 2 diagnósticos para comparar");
    }
  };

  const comparisonPair = useMemo(() => {
    if (selectedIds.length === 2) {
      const a = history.find(h => h.id === selectedIds[0]);
      const b = history.find(h => h.id === selectedIds[1]);
      if (a && b) {
        const dateA = new Date(a.createdAt).getTime();
        const dateB = new Date(b.createdAt).getTime();
        return dateA > dateB ? { current: a, previous: b } : { current: b, previous: a };
      }
    }
    return null;
  }, [selectedIds, history]);

  const handleExportComparisonPDF = () => {
    if (!comparisonPair) return;
    generateComparisonPDF(comparisonPair.current, comparisonPair.previous);
    toast.success("Relatório comparativo aberto para impressão/download!");
  };

  const handleExportSinglePDF = (item: RadarHistoryItem) => {
    generateSingleDiagnosticPDF(item);
    toast.success("Relatório aberto para impressão/download!");
  };

  if (history.length === 0) {
    return (
      <div className="text-center py-20">
        <Radar className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
        <h2 className="text-xl font-bold mb-2">Nenhum Diagnóstico Realizado</h2>
        <p className="text-muted-foreground text-sm max-w-md mx-auto mb-6">
          Faça seu primeiro diagnóstico no Radar Vértice para avaliar sua maturidade em CX, Dados, IA e Governança.
        </p>
        <Link href="/radar">
          <Button className="gap-2">
            <Radar className="w-4 h-4" />
            Fazer Diagnóstico
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Radar className="w-6 h-6 text-cyan-400" />
            <h1 className="text-2xl font-bold">Histórico Radar Vértice</h1>
          </div>
          <p className="text-sm text-muted-foreground">
            {history.length} diagnóstico{history.length !== 1 ? "s" : ""} realizado{history.length !== 1 ? "s" : ""}
          </p>
        </div>
        <div className="flex gap-2">
          {history.length >= 2 && (
            <Button
              variant={compareMode ? "default" : "outline"}
              size="sm"
              className="text-xs gap-1.5"
              onClick={() => {
                setCompareMode(!compareMode);
                setSelectedIds([]);
              }}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              {compareMode ? "Sair da Comparação" : "Comparar"}
            </Button>
          )}
          <Link href="/radar">
            <Button size="sm" className="text-xs gap-1.5">
              <Radar className="w-3.5 h-3.5" />
              Novo Diagnóstico
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-card/50 border border-border/50 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-cyan-400">{history.length}</p>
          <p className="text-[10px] text-muted-foreground mt-0.5">Diagnósticos</p>
        </div>
        {(() => {
          const latest = sorted[0];
          const dims = [
            { key: "scoreCX", label: "CX", color: "text-blue-400" },
            { key: "scoreData", label: "Dados", color: "text-emerald-400" },
            { key: "scoreIA", label: "IA", color: "text-purple-400" },
            { key: "scoreGovernance", label: "Governança", color: "text-amber-400" },
          ];
          return dims.map(dim => {
            const val = parseFloat((latest as any)[dim.key] || "0");
            return (
              <div key={dim.key} className="bg-card/50 border border-border/50 rounded-xl p-4 text-center">
                <p className={`text-2xl font-bold ${dim.color}`}>{val.toFixed(1)}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">{dim.label} (último)</p>
              </div>
            );
          });
        })()}
      </div>

      {/* Evolution Chart */}
      {history.length >= 2 && (
        <Card className="bg-card/50 border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              Evolução ao Longo do Tempo
            </CardTitle>
          </CardHeader>
          <CardContent>
            <EvolutionChart history={history} />
          </CardContent>
        </Card>
      )}

      {/* Comparison Mode */}
      {compareMode && (
        <Card className="bg-cyan-500/5 border-cyan-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-cyan-400 font-medium">
                Selecione 2 diagnósticos abaixo para comparar
              </p>
              {comparisonPair && (
                <Button
                  size="sm"
                  variant="outline"
                  className="text-xs gap-1.5 border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
                  onClick={handleExportComparisonPDF}
                >
                  <FileDown className="w-3.5 h-3.5" />
                  Exportar PDF Comparativo
                </Button>
              )}
            </div>
            {comparisonPair && (
              <div className="mt-4">
                <p className="text-xs text-muted-foreground mb-3">
                  Comparando: {new Date(comparisonPair.previous.createdAt).toLocaleDateString("pt-BR")} → {new Date(comparisonPair.current.createdAt).toLocaleDateString("pt-BR")}
                </p>
                <ComparisonView current={comparisonPair.current} previous={comparisonPair.previous} />
              </div>
            )}
            {!comparisonPair && selectedIds.length < 2 && (
              <p className="text-xs text-muted-foreground">
                {selectedIds.length === 0 ? "Clique nos cards abaixo para selecionar" : "Selecione mais 1 diagnóstico"}
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Diagnostic Cards */}
      <div className="space-y-4">
        {sorted.map((item, index) => {
          const scoreCX = parseFloat(item.scoreCX || "0");
          const scoreData = parseFloat(item.scoreData || "0");
          const scoreIA = parseFloat(item.scoreIA || "0");
          const scoreGov = parseFloat(item.scoreGovernance || "0");
          const scoreTotal = parseFloat(item.scoreTotal || "0");
          const isExpanded = expandedId === item.id;
          const isSelected = selectedIds.includes(item.id);
          const isLatest = index === 0;
          const date = new Date(item.createdAt);

          // Calculate diff with previous
          const prevItem = index < sorted.length - 1 ? sorted[index + 1] : null;
          const prevTotal = prevItem ? parseFloat(prevItem.scoreTotal || "0") : null;
          const totalDiff = prevTotal !== null ? scoreTotal - prevTotal : null;

          return (
            <Card
              key={item.id}
              className={`bg-card/50 border-border/50 transition-all duration-300 ${
                isSelected ? "border-cyan-500/50 bg-cyan-500/5" : ""
              } ${isLatest ? "border-primary/30" : ""}`}
            >
              <CardContent className="p-0">
                {/* Card Header */}
                <div
                  className="flex items-center gap-4 p-4 cursor-pointer hover:bg-muted/20 transition-colors"
                  onClick={() => compareMode ? toggleSelect(item.id) : toggleExpand(item.id)}
                >
                  {/* Checkbox for compare mode */}
                  {compareMode && (
                    <div className={`w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
                      isSelected ? "bg-cyan-500 border-cyan-500" : "border-muted-foreground/30"
                    }`}>
                      {isSelected && <span className="text-white text-xs font-bold">✓</span>}
                    </div>
                  )}

                  {/* Mini Radar */}
                  <div className="hidden sm:block">
                    <MiniRadarChart
                      scoreCX={scoreCX}
                      scoreData={scoreData}
                      scoreIA={scoreIA}
                      scoreGovernance={scoreGov}
                      size={80}
                    />
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      {isLatest && (
                        <Badge className="bg-primary/20 text-primary border-primary/30 text-[9px] px-1.5 py-0">
                          Mais recente
                        </Badge>
                      )}
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {date.toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" })}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 flex-wrap">
                      <span className="text-lg font-bold" style={{ color: scoreColor(scoreTotal) }}>
                        {scoreTotal.toFixed(1)}/5.0
                      </span>
                      {totalDiff !== null && totalDiff !== 0 && (
                        <span className={`text-xs font-semibold ${totalDiff > 0 ? "text-emerald-400" : "text-red-400"}`}>
                          {totalDiff > 0 ? "↑" : "↓"} {Math.abs(totalDiff).toFixed(1)}
                        </span>
                      )}
                      <Badge variant="outline" className={`text-[9px] ${scoreBadge(scoreTotal)}`}>
                        {LEVEL_LABELS[item.recommendedLevel || ""] || item.recommendedLevel}
                      </Badge>
                      {item.persona && (
                        <span className="text-[10px] text-muted-foreground">
                          {PERSONA_LABELS[item.persona] || item.persona}
                        </span>
                      )}
                    </div>
                    {/* Score bars inline */}
                    <div className="flex items-center gap-3 mt-2">
                      {[
                        { label: "CX", score: scoreCX, color: "#2563eb" },
                        { label: "Dados", score: scoreData, color: "#16a34a" },
                        { label: "IA", score: scoreIA, color: "#9333ea" },
                        { label: "Gov", score: scoreGov, color: "#d97706" },
                      ].map(d => (
                        <div key={d.label} className="flex items-center gap-1.5">
                          <span className="text-[9px] text-muted-foreground w-8">{d.label}</span>
                          <div className="w-16 bg-muted/30 rounded-full h-1.5">
                            <div
                              className="h-1.5 rounded-full transition-all duration-500"
                              style={{ width: `${(d.score / 5) * 100}%`, backgroundColor: d.color }}
                            />
                          </div>
                          <span className="text-[9px] font-medium" style={{ color: d.color }}>
                            {d.score.toFixed(1)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Expand toggle */}
                  {!compareMode && (
                    <div className="flex-shrink-0">
                      {isExpanded ? (
                        <ChevronUp className="w-5 h-5 text-muted-foreground" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-muted-foreground" />
                      )}
                    </div>
                  )}
                </div>

                {/* Expanded Content */}
                {isExpanded && !compareMode && (
                  <div className="border-t border-border/30 p-4 space-y-4">
                    {/* Detailed scores */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {[
                        { label: "CX - Cliente & Jornada", score: scoreCX, color: "#2563eb" },
                        { label: "Dados & Analytics", score: scoreData, color: "#16a34a" },
                        { label: "Inteligência Artificial", score: scoreIA, color: "#9333ea" },
                        { label: "Governança & Execução", score: scoreGov, color: "#d97706" },
                      ].map(d => (
                        <div key={d.label} className="bg-background/50 rounded-lg p-3 text-center">
                          <div className="text-2xl font-bold" style={{ color: d.color }}>
                            {d.score.toFixed(1)}
                          </div>
                          <div className="text-[10px] text-muted-foreground mt-0.5">{d.label}</div>
                          <div className="w-full bg-muted/30 rounded-full h-1.5 mt-2">
                            <div
                              className="h-1.5 rounded-full"
                              style={{ width: `${(d.score / 5) * 100}%`, backgroundColor: d.color }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Recommendation */}
                    <div className="bg-primary/5 border border-primary/20 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Sparkles className="w-4 h-4 text-primary" />
                        <span className="text-sm font-medium">Recomendação</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        <strong className="text-foreground">{item.recommendedProduct}</strong>
                        {item.sector && <> — Setor: {item.sector}</>}
                      </p>
                    </div>

                    {/* Challenges / Context */}
                    {item.challenges && (
                      <div className="bg-card/30 border border-border/30 rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <Target className="w-4 h-4 text-cyan-400" />
                          <span className="text-sm font-medium">Desafios e Contexto</span>
                        </div>
                        <p className="text-xs text-muted-foreground whitespace-pre-wrap">
                          {item.challenges}
                        </p>
                      </div>
                    )}

                    {/* AI Analysis preview */}
                    {item.aiAnalysis && (
                      <div className="bg-card/30 border border-border/30 rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <Brain className="w-4 h-4 text-purple-400" />
                          <span className="text-sm font-medium">Análise IA</span>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-4 whitespace-pre-wrap">
                          {item.aiAnalysis.replace(/[#*]/g, "").substring(0, 300)}...
                        </p>
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex items-center gap-2 pt-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-xs gap-1.5"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleExportSinglePDF(item);
                        }}
                      >
                        <Download className="w-3.5 h-3.5" />
                        Baixar PDF
                      </Button>
                      <Link href="/radar">
                        <Button size="sm" variant="outline" className="text-xs gap-1.5">
                          <Radar className="w-3.5 h-3.5" />
                          Refazer Diagnóstico
                        </Button>
                      </Link>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* CTA for new diagnostic */}
      <Card className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border-cyan-500/20">
        <CardContent className="p-6 text-center">
          <Radar className="w-10 h-10 text-cyan-400 mx-auto mb-3" />
          <h3 className="text-lg font-bold mb-1">Acompanhe sua Evolução</h3>
          <p className="text-sm text-muted-foreground mb-4 max-w-md mx-auto">
            Refaça o Radar Vértice periodicamente para medir seu progresso em CX, Dados, IA e Governança.
          </p>
          <Link href="/radar">
            <Button className="gap-2">
              Fazer Novo Diagnóstico
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </CardContent>
      </Card>
    </>
  );
}
