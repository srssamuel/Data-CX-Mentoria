# Configuração do Cenário Make.com para WhatsApp

## Visão Geral

O portal Data CX Mentoria envia dados enriquecidos ao Make.com via webhook sempre que:
1. **Novo lead completa o Radar Vértice** (automático)
2. **Admin dispara follow-up por segmento** (manual, via painel Admin)
3. **Admin dispara follow-up individual** (manual, via detalhe do lead)

O webhook envia um payload JSON com todas as informações necessárias para personalizar a mensagem de WhatsApp.

---

## Passo 1: Criar o Cenário no Make.com

1. Acesse [make.com](https://www.make.com) e crie um novo cenário
2. Adicione o módulo **Webhooks > Custom Webhook**
3. Copie a URL do webhook gerada
4. Cole a URL no portal: **Settings > Secrets > MAKE_WEBHOOK_URL**

---

## Passo 2: Payload Recebido

### Novo Lead (automático)
```json
{
  "type": "new_radar_lead",
  "name": "João Silva",
  "email": "joao@empresa.com",
  "phone": "+5584991278513",
  "persona": "gestor",
  "company": "Empresa XYZ",
  "sector": "Financeiro",
  "scoreTotal": 72,
  "recommendedLevel": "Mentoria Sprint",
  "recommendedProduct": "mentoria_sprint",
  "challengeSegment": "dados",
  "challengeSegmentLabel": "Dados & Analytics",
  "challenges": "[Falta de dados estruturados] [Dificuldade em medir ROI de CX] Temos dados dispersos em vários sistemas...",
  "consentWhatsapp": true,
  "timestamp": "2026-02-26T10:30:00.000Z"
}
```

### Follow-up por Segmento (manual)
```json
{
  "type": "whatsapp_nurture",
  "phone": "+5584991278513",
  "name": "João Silva",
  "email": "joao@empresa.com",
  "persona": "gestor",
  "segment": "dados",
  "segmentLabel": "Dados & Analytics",
  "score": 72,
  "level": "Mentoria Sprint",
  "product": "mentoria_sprint",
  "challenges": "[Falta de dados estruturados] ...",
  "customMessage": "",
  "timestamp": "2026-02-26T10:30:00.000Z"
}
```

---

## Passo 3: Configurar Filtro por Tipo

Adicione um **Router** após o webhook com filtros:

| Rota | Filtro | Ação |
|------|--------|------|
| Novo Lead | `type` = `new_radar_lead` | Mensagem de boas-vindas |
| Nurture | `type` = `whatsapp_nurture` | Mensagem de follow-up |

---

## Passo 4: Conectar WhatsApp Business API

### Opção A: WhatsApp Business API (via 360dialog, Twilio, etc.)
1. Adicione o módulo **HTTP > Make a Request**
2. Configure a URL da API do seu provedor
3. Monte o body com os dados do webhook

### Opção B: WhatsApp Cloud API (Meta)
1. Adicione o módulo **WhatsApp Business Cloud > Send a Message**
2. Configure o token de acesso da Meta
3. Use templates aprovados pela Meta

---

## Passo 5: Templates de Mensagem por Segmento

### Boas-vindas (Novo Lead)
```
Olá {{name}}! 👋

Obrigado por completar o Radar Vértice da Data CX.

Seu diagnóstico identificou que seu principal desafio está em *{{challengeSegmentLabel}}*.

Sua pontuação foi {{scoreTotal}}/100, e recomendamos o programa *{{recommendedLevel}}* para acelerar seus resultados.

Quer agendar uma sessão gratuita de 15 min para discutir seu diagnóstico? 📊

Acesse: https://datacx.manus.space/ofertas
```

### Follow-up por Segmento

#### Dados & Analytics
```
{{name}}, vi que seu principal desafio é com dados e analytics.

Muitos profissionais enfrentam o mesmo: dados dispersos, falta de estrutura e dificuldade em extrair insights.

Na nossa mentoria, trabalhamos exatamente isso — desde a organização dos dados até a criação de dashboards que geram decisões.

Posso te mostrar como funciona? 📊
```

#### Experiência do Cliente (CX)
```
{{name}}, percebi que seu foco está em melhorar a experiência do cliente.

Mapear jornadas, criar métricas de CX e implementar uma cultura centrada no cliente são passos fundamentais.

Já ajudamos +50 profissionais a transformar a experiência dos seus clientes.

Quer conhecer nosso método? 🎯
```

#### IA & Automação
```
{{name}}, seu diagnóstico mostrou interesse em IA e automação.

A inteligência artificial está revolucionando o CX — desde chatbots inteligentes até análise preditiva de churn.

Na mentoria, ensinamos como implementar IA de forma prática, sem precisar ser desenvolvedor.

Vamos conversar sobre isso? 🤖
```

#### Governança & Compliance
```
{{name}}, vi que governança de dados é um desafio importante para você.

LGPD, qualidade de dados e processos de governança são fundamentais para qualquer estratégia de CX.

Temos um módulo específico sobre isso na mentoria.

Posso te contar mais? 🏛️
```

#### Cultura & Pessoas
```
{{name}}, transformar a cultura organizacional é um dos maiores desafios em CX.

Engajar equipes, desenvolver lideranças e criar uma mentalidade data-driven exige método e persistência.

Já ajudamos empresas a fazer essa transição com sucesso.

Quer saber como? 👥
```

---

## Passo 6: Testar

1. No portal, acesse **Admin > Radar > Segmentos**
2. Clique no botão **WhatsApp** de qualquer segmento
3. Verifique no Make.com se o webhook foi recebido
4. Confirme se a mensagem chegou no WhatsApp

---

## Dicas

- **Horário de envio**: Configure no Make.com um filtro de horário para enviar apenas em horário comercial (8h-18h)
- **Rate limiting**: Adicione um delay de 2-3 segundos entre mensagens para evitar bloqueio
- **Opt-out**: Monitore respostas com "cancelar" ou "sair" para remover o consentimento
- **Métricas**: Use o módulo Google Sheets do Make.com para registrar envios e respostas
