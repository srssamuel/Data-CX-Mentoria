/**
 * Challenge Segments - Shared constants for lead segmentation by challenges
 * 
 * Each challenge maps to a segment category with specific nurture content.
 * Segments group related challenges for targeted email campaigns.
 */

export interface ChallengeDefinition {
  id: string;
  label: string;
  icon: string;
  segment: SegmentCategory;
}

export type SegmentCategory = "dados" | "cx" | "ia" | "governanca" | "cultura";

export interface SegmentDefinition {
  id: SegmentCategory;
  label: string;
  icon: string;
  color: string;
  description: string;
  /** Nurture email subject line template */
  nurtureSubject: string;
  /** Nurture email content template (use {{name}} for personalization) */
  nurtureContent: string;
  /** Related challenges IDs */
  challengeIds: string[];
}

/** The 10 common challenges with their segment mapping */
export const COMMON_CHALLENGES: ChallengeDefinition[] = [
  { id: "dados", label: "Falta de dados estruturados", icon: "📊", segment: "dados" },
  { id: "cx", label: "Equipe sem capacitação em CX", icon: "🎯", segment: "cx" },
  { id: "roi", label: "Dificuldade em medir ROI de CX", icon: "💰", segment: "cx" },
  { id: "ia", label: "Não sei como usar IA na operação", icon: "🤖", segment: "ia" },
  { id: "jornada", label: "Jornada do cliente não mapeada", icon: "🗝️", segment: "cx" },
  { id: "silos", label: "Silos entre áreas/departamentos", icon: "🏢", segment: "governanca" },
  { id: "governanca", label: "Falta de governança de dados", icon: "🛡️", segment: "governanca" },
  { id: "cultura", label: "Cultura não orientada ao cliente", icon: "🧠", segment: "cultura" },
  { id: "ferramentas", label: "Ferramentas desconectadas", icon: "🔧", segment: "dados" },
  { id: "lideranca", label: "Falta de apoio da liderança", icon: "👥", segment: "cultura" },
];

/** Segment definitions with nurture email templates */
export const SEGMENTS: SegmentDefinition[] = [
  {
    id: "dados",
    label: "Dados & Integração",
    icon: "📊",
    color: "#3B82F6",
    description: "Leads com desafios em estruturação, integração e qualidade de dados",
    challengeIds: ["dados", "ferramentas"],
    nurtureSubject: "{{name}}, como estruturar seus dados para decisões mais inteligentes",
    nurtureContent: `Olá {{name}},

Sabemos que um dos maiores desafios que você enfrenta é a falta de dados estruturados e ferramentas desconectadas. Essa é uma realidade comum — e a boa notícia é que existe um caminho prático para resolver isso.

No Protocolo Vértice, ensinamos um framework de 3 etapas para organizar seus dados:

1. **Mapeamento de fontes**: Identificar todos os pontos de coleta (CRM, planilhas, sistemas legados)
2. **Unificação progressiva**: Começar com os dados mais críticos e expandir gradualmente
3. **Governança básica**: Definir donos, frequência de atualização e padrões de qualidade

Profissionais que aplicaram esse método reduziram em média 60% o tempo gasto buscando informações dispersas.

Quer saber como aplicar isso na sua realidade? Agende uma sessão diagnóstica gratuita de 30 minutos.`,
  },
  {
    id: "cx",
    label: "CX & Jornada do Cliente",
    icon: "🎯",
    color: "#8B5CF6",
    description: "Leads com desafios em experiência do cliente, jornada e ROI de CX",
    challengeIds: ["cx", "roi", "jornada"],
    nurtureSubject: "{{name}}, transforme a experiência do seu cliente com método",
    nurtureContent: `Olá {{name}},

Você mencionou desafios relacionados à experiência do cliente — seja mapear a jornada, capacitar a equipe ou medir o ROI das iniciativas de CX. Esses são os pilares que separam empresas que "fazem CX" das que realmente geram resultado com CX.

No Protocolo Vértice, trabalhamos com o conceito de CX Baseado em Evidências:

1. **Jornada mapeada com métricas**: Cada etapa da jornada vinculada a indicadores mensuráveis
2. **Equipe capacitada com método**: Não basta treinar — é preciso criar rituais e processos
3. **ROI tangível**: Conectar cada ação de CX a impacto financeiro real

Empresas que aplicaram esse método viram um aumento médio de 35% na retenção de clientes em 6 meses.

Quer entender como adaptar isso para o seu contexto? Agende uma sessão diagnóstica gratuita.`,
  },
  {
    id: "ia",
    label: "IA & Automação",
    icon: "🤖",
    color: "#10B981",
    description: "Leads com desafios em adoção e uso prático de IA na operação",
    challengeIds: ["ia"],
    nurtureSubject: "{{name}}, como começar a usar IA na sua operação (sem complicação)",
    nurtureContent: `Olá {{name}},

Você indicou que não sabe como usar IA na operação — e isso é mais comum do que imagina. A maioria dos profissionais sabe que IA é importante, mas não sabe por onde começar de forma prática.

No Protocolo Vértice, ensinamos IA Aplicada com foco em resultados rápidos:

1. **Quick wins com IA**: Automações simples que economizam horas por semana (análise de feedback, classificação de tickets, geração de relatórios)
2. **Prompts estratégicos**: Como escrever prompts que geram insights acionáveis para o negócio
3. **Integração gradual**: Começar com ferramentas acessíveis e escalar conforme a maturidade

Profissionais que passaram pelo programa conseguiram automatizar em média 40% das tarefas repetitivas em 30 dias.

Quer descobrir os quick wins de IA para o seu setor? Agende uma sessão diagnóstica gratuita.`,
  },
  {
    id: "governanca",
    label: "Governança & Processos",
    icon: "🛡️",
    color: "#F59E0B",
    description: "Leads com desafios em governança, silos organizacionais e processos",
    challengeIds: ["silos", "governanca"],
    nurtureSubject: "{{name}}, como quebrar silos e criar governança que funciona",
    nurtureContent: `Olá {{name}},

Silos entre áreas e falta de governança são dois dos maiores obstáculos para a transformação digital. Quando cada departamento opera isoladamente e não há processos padronizados, as melhores iniciativas morrem na execução.

No Protocolo Vértice, trabalhamos Governança Pragmática:

1. **Rituais de alinhamento**: Reuniões curtas e objetivas que conectam áreas sem burocracia
2. **Donos e métricas claras**: Cada processo com responsável definido e indicadores de sucesso
3. **Cadência de execução**: Ciclos curtos de revisão que mantêm o foco e a accountability

Empresas que implementaram esse modelo reduziram em 50% o retrabalho entre áreas e aceleraram a entrega de projetos.

Quer saber como implementar governança sem burocratizar? Agende uma sessão diagnóstica gratuita.`,
  },
  {
    id: "cultura",
    label: "Cultura & Liderança",
    icon: "🧠",
    color: "#EF4444",
    description: "Leads com desafios em cultura organizacional e engajamento da liderança",
    challengeIds: ["cultura", "lideranca"],
    nurtureSubject: "{{name}}, como engajar a liderança e criar cultura centrada no cliente",
    nurtureContent: `Olá {{name}},

Cultura não orientada ao cliente e falta de apoio da liderança são desafios que exigem uma abordagem estratégica. Não adianta ter as melhores ferramentas se as pessoas não estão alinhadas.

No Protocolo Vértice, trabalhamos Transformação Cultural com Evidências:

1. **Business case para a liderança**: Traduzir CX e dados em linguagem de resultado financeiro
2. **Quick wins visíveis**: Gerar resultados rápidos que criam momentum e credibilidade
3. **Embaixadores internos**: Identificar e capacitar aliados em cada área para multiplicar a mudança

Líderes que aplicaram essa abordagem conseguiram aprovação de budget para projetos de CX em menos de 60 dias.

Quer uma estratégia personalizada para engajar sua liderança? Agende uma sessão diagnóstica gratuita.`,
  },
];

/** Persona types */
export type Persona = "jovem" | "gestor" | "executivo" | "empresario";

/** Challenges prioritized per persona (ordered by relevance) */
export const CHALLENGES_BY_PERSONA: Record<Persona, string[]> = {
  jovem: ["cx", "dados", "ia", "jornada", "ferramentas", "cultura"],
  gestor: ["dados", "roi", "jornada", "silos", "ferramentas", "governanca", "ia", "cx"],
  executivo: ["roi", "governanca", "silos", "lideranca", "cultura", "dados", "ia"],
  empresario: ["dados", "roi", "ia", "ferramentas", "silos", "governanca", "cultura", "lideranca", "cx", "jornada"],
};

/** Get challenges filtered and ordered by persona */
export function getChallengesForPersona(persona: string): ChallengeDefinition[] {
  const personaKey = persona as Persona;
  const order = CHALLENGES_BY_PERSONA[personaKey] || CHALLENGES_BY_PERSONA.gestor;
  return order
    .map(id => COMMON_CHALLENGES.find(c => c.id === id))
    .filter((c): c is ChallengeDefinition => !!c);
}

/**
 * Extract challenge IDs from the challenges text field
 * The text contains [tag] patterns from checkboxes
 */
export function extractChallengeIds(challengesText: string): string[] {
  if (!challengesText) return [];
  
  const ids: string[] = [];
  for (const challenge of COMMON_CHALLENGES) {
    if (challengesText.toLowerCase().includes(challenge.label.toLowerCase())) {
      ids.push(challenge.id);
    }
  }
  return ids;
}

/**
 * Determine the primary segment for a lead based on their challenges
 * Returns the segment with the most matching challenges
 */
export function determinePrimarySegment(challengesText: string): SegmentCategory | null {
  if (!challengesText) return null;
  
  const challengeIds = extractChallengeIds(challengesText);
  if (challengeIds.length === 0) return null;
  
  // Count challenges per segment
  const segmentCounts: Record<SegmentCategory, number> = {
    dados: 0,
    cx: 0,
    ia: 0,
    governanca: 0,
    cultura: 0,
  };
  
  for (const cId of challengeIds) {
    const challenge = COMMON_CHALLENGES.find(c => c.id === cId);
    if (challenge) {
      segmentCounts[challenge.segment]++;
    }
  }
  
  // Find segment with highest count
  let maxCount = 0;
  let primarySegment: SegmentCategory | null = null;
  
  for (const [seg, count] of Object.entries(segmentCounts)) {
    if (count > maxCount) {
      maxCount = count;
      primarySegment = seg as SegmentCategory;
    }
  }
  
  return primarySegment;
}

/**
 * Get all matching segments for a lead (sorted by relevance)
 */
export function getMatchingSegments(challengesText: string): SegmentCategory[] {
  if (!challengesText) return [];
  
  const challengeIds = extractChallengeIds(challengesText);
  if (challengeIds.length === 0) return [];
  
  const segmentCounts: Record<SegmentCategory, number> = {
    dados: 0,
    cx: 0,
    ia: 0,
    governanca: 0,
    cultura: 0,
  };
  
  for (const cId of challengeIds) {
    const challenge = COMMON_CHALLENGES.find(c => c.id === cId);
    if (challenge) {
      segmentCounts[challenge.segment]++;
    }
  }
  
  return (Object.entries(segmentCounts) as [SegmentCategory, number][])
    .filter(([_, count]) => count > 0)
    .sort((a, b) => b[1] - a[1])
    .map(([seg]) => seg);
}

/**
 * Get the segment definition by ID
 */
export function getSegmentById(id: SegmentCategory): SegmentDefinition | undefined {
  return SEGMENTS.find(s => s.id === id);
}
