# Data CX Mentoria - TODO

## Landing Page
- [x] Hero section com dados McKinsey ($2.6-4.4 trilhões IA)
- [x] Estatísticas de CX e urgência da transformação digital
- [x] Seção de benefícios da mentoria
- [x] CTAs estratégicos
- [x] Seção do Protocolo Vértice com os 5 passos
- [x] Manifesto do Samuel Rosa

## Autenticação e Controle de Acesso
- [x] Sistema de login/logout com Manus OAuth
- [x] Perfis de usuário
- [x] Controle de acesso por roles (admin/user)
- [x] Proteção de rotas

## Área de Membros
- [x] Acesso aos playbooks (Mentoria Grupo, Individual, Diagnóstico)
- [x] Visualização de materiais em PDF/markdown
- [x] Progresso do aluno
- [x] Filtros por tipo de conteúdo

## Ofertas de Mentoria
- [x] Página de ofertas detalhada
- [x] Mentoria em Grupo (8 semanas)
- [x] Mentoria Individual (Sprint/90 dias/Executive)
- [x] Diagnóstico 360º
- [x] Tabela comparativa de modalidades

## Integração Stripe
- [x] Checkout de planos de mentoria (implementado na Fase 7/41 - Stripe checkout funcional)
- [x] Gestão de assinaturas (implementado via Stripe webhooks)
- [x] Webhooks de pagamento (implementado na Fase 7/41)

## Painel Administrativo
- [x] Dashboard de métricas (alunos, receita, conversões)
- [x] Lista de membros ativos
- [x] Relatórios de engajamento
- [x] Restrição apenas para admin
- [x] Gestão de contatos
- [x] Gestão de depoimentos
- [x] Gestão de conteúdos

## Gestão de Conteúdo
- [x] Upload de materiais (playbooks, templates)
- [x] Organização por módulos
- [x] Gestão de vídeos
- [x] CRUD completo de conteúdos

## Página Sobre
- [x] Perfil profissional Samuel Rosa
- [x] Experiência +70 clientes
- [x] Posicionamento CX, Dados e IA
- [x] Pilares de atuação
- [x] Frases assinatura

## Depoimentos e Cases
- [x] Seção de depoimentos na home
- [x] Cases de sucesso
- [x] Prova social

## Contato
- [x] Formulário de contato
- [x] Agendamento sessão diagnóstica gratuita
- [x] Notificações ao owner
- [x] Informações de contato (email, WhatsApp, redes)

## Design e UX
- [x] Navbar responsiva com menu mobile
- [x] Footer com links e redes sociais
- [x] Tema dark elegante com gradientes
- [x] Animações suaves (framer-motion)
- [x] Design responsivo (mobile-first)

## Backend
- [x] Schema do banco de dados completo
- [x] Routers tRPC para todas as entidades
- [x] Helpers de banco de dados
- [x] Testes automatizados


## Fase 2 - Personas e Radar Vértice

### Radar Vértice (Autoavaliação)
- [x] Página do Radar Vértice com formulário de captura (nome, email, WhatsApp, perfil)
- [x] Quiz com 28 perguntas em 6 blocos (Contexto, CX, Dados, IA, Governança, Intenção)
- [x] Sistema de pontuação por dimensão (escala 1-5)
- [x] Lógica de recomendação automática baseada na média
- [x] Resultado visual com gráfico radar
- [x] Geração de relatório PDF personalizado (implementado na Fase 55/57)
- [x] Envio de resultado por email (implementado via emailService + nurture)
- [x] CTA de agendamento após resultado

### Páginas Segmentadas por Persona
- [x] Página Mentoria para Jovens (18-26)
- [x] Página Mentoria para Gestores
- [x] Página Mentoria para Executivos
- [x] Página Empresas & Empresários (Diagnóstico + Assessoria)

### Escada de Ofertas
- [x] Masterclass Vértice (90 min) - produto de entrada (plano masterclass criado na Fase 29)
- [x] Mentoria Vértice (8 semanas) com variações por persona
- [x] Diagnóstico Vértice (2-4 semanas) para empresas
- [x] Assessoria Vértice (6 ou 12 meses)

### Storytelling e Conversão
- [x] Atualizar Home com narrativa em degraus (Reconhecimento → Tensão → Virada → Prova → CTA)
- [x] Seção de identificação de persona na Home
- [x] CTAs direcionados para o Radar Vértice
- [x] Seção de cases e provas sociais

### Sistema de Leads
- [x] Captura de leads com consentimento LGPD
- [x] Armazenamento de resultados do Radar no banco
- [x] Segmentação automática por recomendação


## Fase 3 - Redesign inspirado em G4 Educação

### Paleta de Cores e Tipografia
- [x] Atualizar paleta para azul marinho escuro + teal + coral
- [x] Implementar tipografia mais impactante nos títulos
- [x] Adicionar gradientes sutis no background

### Layout da Home
- [x] Hero section com foto do mentor + headline forte
- [x] Seção de prova social com números grandes
- [x] Cards de programas em grid estilo G4
- [x] Depoimentos em carousel
- [x] Badges de "Vagas limitadas" / "Próxima turma"

### Elementos de UX
- [x] CTAs em coral que se destacam
- [x] Countdown para próxima turma (implementado nas Ofertas nesta sessão)
- [x] Avaliações e NPS visíveis
- [x] Navegação sticky aprimorada
- [x] Animações sutis de entrada

### Páginas Internas
- [x] Redesign da página de Ofertas
- [x] Redesign da página Sobre
- [x] Redesign do Radar Vértice


## Fase 4 - Melhorias Solicitadas

### Correções de Navegação e UX
- [x] Scroll to top ao trocar de página
- [x] Remover botão "Fazer Radar Vértice" da página do Radar (já tem "Começar Avaliação")
- [x] Corrigir navegação do botão "Fazer Radar Vértice" em outras páginas

### Novo Plano e Revisão de Preços
- [x] Adicionar plano introdutório R$ 377 (Playbook CX, Dados e IA)
- [x] Revisar preços dos planos existentes para valores mais acessíveis

### Painel Admin Completo
- [x] Visualização de todos os resultados do Radar Vértice
- [x] Visualização de todos os formulários preenchidos
- [x] Métricas de leads (total, novos, contatados, convertidos)
- [x] Detalhes de cada lead (scores, persona, produto recomendado)

### Integração Make/WhatsApp
- [x] Webhook para Make.com (/api/webhook/make)
- [x] Alertas de cadastros no WhatsApp +55 84 99127-8513
- [x] Alertas de dúvidas/contatos no WhatsApp
- [x] Configurar MAKE_WEBHOOK_URL nas secrets

### Assistente IA
- [x] Assistente IA para usuários (chat geral)
- [x] Assistente IA dentro dos cursos (mentor virtual)
- [x] Simulação de professor/mentor online
- [x] Botão flutuante de chat em todas as páginas

### Integração de Pagamentos
- [x] Integração Stripe para PIX e Cartão
- [x] Checkout funcional em todos os planos
- [x] Webhook para processar pagamentos
- [ ] Configurar conta Stripe em produção (Settings → Payment)
- [ ] Vincular conta Itaú (Ag: 9056, Cc: 06562-7) no Stripe
- [ ] Configurar Chave PIX: 33a47e94-22f8-4dba-b44f-3f79ab2f2889
- [x] Checkout para cada plano de mentoria (createCheckout aceita qualquer productId via Stripe)


## Fase 5 - Formulário de Contato Detalhado

### Campos do Formulário
- [x] Nome completo
- [x] Email profissional
- [x] WhatsApp com máscara
- [x] Empresa/Organização
- [x] Cargo/Função
- [x] Segmento de atuação (dropdown)
- [x] Tamanho da empresa (dropdown)
- [x] Interesse principal (dropdown: Mentoria, Diagnóstico, Assessoria, Playbook)
- [x] Desafio atual (textarea)
- [x] Como conheceu a Data CX (dropdown)
- [x] Melhor horário para contato
- [x] Consentimento LGPD

### Funcionalidades
- [x] Validação de campos obrigatórios
- [x] Máscara de telefone brasileiro
- [x] Notificação ao owner via webhook
- [x] Mensagem de confirmação após envio
- [x] Armazenamento no banco de dados


## Fase 6 - Webhook Make.com e Mensagem de Confirmação

### Webhook Make.com
- [x] Criar endpoint de webhook para Make.com
- [x] Enviar dados do formulário para Make.com
- [x] Configurar MAKE_WEBHOOK_URL: https://hook.us2.make.com/8ohg2b9jvvtchqqa91dee0m14sqtyd0l

### Mensagem de Confirmação
- [x] Adicionar modal/toast de sucesso após envio do formulário
- [x] Mensagem personalizada com próximos passos (3 etapas)
- [x] Animação de confirmação (pulse animado)
- [x] Resumo do contato enviado


## Fase 7 - Stripe PIX/Cartão e Área de Login

### Integração Stripe PIX/Cartão
- [x] Configurar Stripe Checkout com payment_method_types: ['card', 'pix']
- [x] Adicionar suporte a PIX no Brasil (BRL)
- [x] Página de sucesso após pagamento (/pagamento-sucesso)
- [x] Página de cancelamento de pagamento (/ofertas?cancelled=true)
- [x] Webhook para processar pagamentos confirmados
- [x] Atualizar status do usuário após pagamento

### Área de Login e Conteúdos Exclusivos
- [x] Página de login dedicada (/login) com Manus OAuth
- [x] Área de membros protegida por autenticação (/membros)
- [x] Dashboard do aluno com progresso
- [x] Listagem de conteúdos exclusivos (playbooks, templates, vídeos)
- [x] Sistema de acesso baseado em plano adquirido
- [x] Página de perfil do usuário (/perfil)
- [x] Histórico de compras/assinaturas


## Fase 8 - Sistema de Cupons de Desconto

### Schema e Backend
- [x] Tabela de cupons no banco de dados (código, tipo desconto, valor, validade, limite uso)
- [x] Router tRPC para CRUD de cupons (criar, listar, editar, excluir)
- [x] Validação de cupom (ativo, não expirado, limite não atingido)
- [x] Aplicação de desconto no checkout

### Interface Admin
- [x] Aba de Cupons no painel Admin
- [x] Formulário para criar novo cupom
- [x] Lista de cupons com status (ativo/inativo/expirado)
- [x] Métricas de uso de cada cupom
- [x] Opção de ativar/desativar cupom

### Integração Stripe
- [x] Criar cupom no Stripe automaticamente
- [x] Aplicar desconto via Stripe Checkout (allow_promotion_codes: true)
- [x] Sincronizar uso de cupons com Stripe



## Fase 9 - Jornada Inicial e LGPD

### Jornada Inicial Interativa (Typeform-style)
- [x] Página de entrada com quiz interativo estilo Viver de IA
- [x] Perguntas de qualificação em tela cheia
- [x] Transições suaves entre perguntas
- [x] Captura de dados (nome, email, WhatsApp)
- [x] Direcionamento para oferta personalizada
- [x] Integração com webhook Make.com

### Página de Política de Privacidade (LGPD)
- [x] Informações sobre coleta de dados
- [x] Finalidade do tratamento de dados
- [x] Direitos do titular
- [x] Contato do encarregado de dados
- [x] Link no footer e formulários


## Fase 10 - Melhorias Identidade Visual e Funcionalidades

### Identidade Visual DCX
- [x] Atualizar paleta de cores para azul royal/índigo DCX
- [x] Substituir logo atual pelo logo oficial DCX
- [x] Ajustar CSS global com novas cores da marca

### Jornada Inicial
- [x] Adicionar botão de compartilhamento no final da jornada
- [x] Permitir compartilhar via WhatsApp, LinkedIn, email

### Correções de Bugs
- [x] Corrigir botão de download PDF do diagnóstico
- [x] Verificar sistema de notificação (usa notificações internas Manus, não email)

### Área de Conteúdos Estilo Netflix
- [x] Redesenhar layout com vídeos laterais e textos
- [x] Implementar duração de acesso baseada no plano
- [x] Adicionar gestão manual de datas no Admin
- [x] Espaço para áudios narrados

### Conteúdo Data Storytelling
- [x] Criar conteúdo autêntico baseado no PDF enviado (17 conteúdos)
- [x] Criar conteúdo CX Academy baseado nos materiais (18 conteúdos)
- [x] Garantir informações atualizadas sobre o tema
- [x] Design e layout profissional


## Fase 11 - Redes Sociais do Mentor

### Links de Redes Sociais
- [x] Atualizar LinkedIn para linkedin.com/in/samuel-rosa-5a1447b7
- [x] Atualizar Instagram para @srssamuelrosa
- [x] Atualizar links no Footer
- [x] Atualizar links na página Contato
- [x] Verificar outros locais com links de redes sociais


## Fase 12 - Benchmark Membox e Melhorias Visuais

### Benchmark e Funcionalidades
- [x] Analisar funcionalidades do portal Membox
- [x] Identificar funcionalidades faltantes no portal Data CX
- [x] Implementar gamificação (pontos, badges, níveis)
- [x] Implementar comunidade/fórum de membros
- [ ] Melhorar hospedagem de vídeos
- [x] Adicionar aplicativo white label (PWA) (manifest.json + sw.js já configurados)
- [x] Aprimorar IA do assistente virtual (avatar Daniel)

### Fotos Profissionais Samuel Rosa
- [x] Extrair fotos enviadas pelo usuário
- [x] Gerar fotos profissionais em cenários corporativos
- [x] Atualizar fotos no portal (Home, Sobre, etc.)

### Avatar Daniel - Assistente Virtual
- [x] Criar avatar hiperrealista masculino "Daniel"
- [x] Atualizar assistente virtual com novo avatar e nome


## Fase 13 - Correções e Melhorias Visuais

### Correções de Bugs
- [x] Corrigir erro ao comprar planos (PIX desativado - requer ativação no Stripe Dashboard)
- [x] Validar todos os links e jornadas
- [x] Adicionar rota /radar-vertice como alias

### Banner Impactante
- [x] Criar banner hero com foto de palestra
- [x] Texto: "Vai ficar parado? Qual seu próximo nível?"
- [x] Usar foto real do CONGREPARH 2024

### Seção Sobre Mim
- [x] Usar fotos reais do CONGREPARH 2024
- [x] Adicionar seção "Quem é Samuel Rosa" com fotos de palestras
- [x] Links para LinkedIn e Instagram na seção


## Fase 14 - Correções Críticas de Rotas e Performance

### Correções de Rotas (Cache miss)
- [x] Diagnosticar problema de Cache miss no ambiente publicado
- [x] Verificar configuração de rotas SPA no servidor
- [x] Garantir que todas as rotas retornem index.html para SPA
- [x] Adicionar headers de cache otimizados para assets

### Otimização de Performance
- [x] Otimizar página /ofertas para evitar timeout (lazy loading + CDN images, sem assets locais pesados)
- [x] Otimizar página /contato para evitar timeout (lazy loading + formulário simplificado)
- [x] Reduzir tamanho de assets e imagens (todas as imagens em CDN, zero assets locais)
- [x] Implementar lazy loading onde necessário (React.lazy no App.tsx)

### Consistência de Login
- [x] Garantir fluxo de login consistente (OAuth Manus funcional com window.location.origin)
- [x] Verificar redirecionamentos OAuth (parseState extrai origin do state corretamente)
- [x] Testar sessão/cookies em diferentes cenários (JWT session cookie implementado)


## Fase 15 - Funcionalidades Completas do Portal

### Chat por Módulo
- [x] Chat dentro de cada módulo com histórico por usuário
- [x] Contexto do módulo/aula no chat
- [x] Admin pode injetar materiais (PDF, links, templates) como base do chat
- [x] Versão do material (controle de atualizações) (campo contentVersion + versionNotes no schema e Admin)

### Workspace de Consultoria (Cliente Empresa)
- [x] Status do projeto (etapas do Protocolo Vértice)
- [x] Backlog de ações (tarefas, donos, prazos)
- [x] Repositório de documentos por cliente
- [x] Registro de decisões (atas por reunião)
- [x] Linha do tempo / marcos
- [x] Chat do projeto (cliente + consultor)
- [x] Planos: Diagnóstico, Consultoria, Assessoria 6/12 meses (diagnostico_360, assessoria_semestral, assessoria_anual no products.ts)

### Melhorias na Comunidade
- [x] Eventos (office hours, AMA, plantões)
- [x] DM (mensagens diretas entre membros)
- [x] Notificações de retenção
- [x] Spaces por coorte/turma (Jovens, Gestores, Executivos, Empresas) (implementado na Fase 62)
- [x] Papel de Moderador (implementado nesta sessão - admin delete/pin posts)

### Régua de Relacionamento (Radar Vértice)
- [x] Régua automática com 5 mensagens após diagnóstico (implementado nesta sessão - nurtureProcessor)
- [x] Entrega do diagnóstico (email 1 da régua)
- [x] Conteúdo recomendado por lacuna (email 2 da régua)
- [x] Convite para sessão (email 3 da régua)
- [x] Prova social/case (email 4 da régua)
- [x] Oferta final (email 5 da régua)
- [x] Geração de relatório PDF personalizado (implementado na Fase 55/57)
- [x] Envio de resultado por email (implementado via emailService + nurture)

### Logs de Auditoria e Saúde
- [x] Logs de auditoria (quem mexeu em quê)
- [x] Saúde do portal (aba Saúde no Admin com status de serviços, páginas e integrações)
- [x] Dashboard de monitoramento (implementado com checklist de produção)

### Otimização de Performance
- [x] Otimizar página /ofertas (lazy loading no App.tsx + CDN images)
- [x] Otimizar página /contato (lazy loading no App.tsx + formulário simplificado)
- [x] Implementar lazy loading em componentes pesados (React.lazy em todas as 20+ páginas)

### PWA (Progressive Web App)
- [x] Manifest.json configurado
- [x] Service Worker para cache offline
- [x] Ícones para instalação
- [x] Prompt de instalação no celular


## Fase 16 - Fotos Reais e Case FCO

### Fotos Reais na Página Sobre Mim
- [x] Fazer upload das fotos reais de palestra para o S3
- [x] Substituir foto gerada por IA pela foto real na seção Sobre Mim
- [x] Usar fotos do evento CONGREPARH e outros eventos

### Case FCO
- [x] Criar página dedicada ao case de sucesso FCO (/cases/fco)
- [x] Destacar resultado: 120 matrículas através de CX, Dados e IA
- [x] Incluir métricas e timeline do projeto
- [x] Adicionar link no Footer para o case
- [ ] Adicionar depoimentos e evidências do resultado (aguardando materiais)


## Fase 17 - Correções de Performance e Acesso

### Configurar Acesso do Usuário
- [x] Liberar acesso a todos os cursos para o usuário de teste (2 programas com status active e pagamento paid)

### Correções de Cache miss
- [x] Diagnosticar problema de Cache miss nas rotas (Radar, Membros, Programas, Login)
- [x] Verificar configuração de rotas SPA no servidor - TODAS FUNCIONANDO no dev
- [x] Todas as rotas retornam index.html corretamente (fallback SPA configurado)
- [x] Testado: /radar, /membros, /ofertas, /contato, /login, /mentoria-jovens - TODAS OK

### Correções de Timeout
- [x] Testada página /ofertas - carrega normalmente (sem timeout)
- [x] Testada página /contato - carrega normalmente (sem timeout)
- [x] Lazy loading já implementado via React.lazy no App.tsx

### Nota sobre Produção
- [x] Se problemas persistirem em produção, republicar o projeto (orientação: clicar Publish na UI)


## Fase 18 - Sistema de Cupons de Desconto

### Backend
- [x] Criar tabela de cupons no schema (implementado na Fase 8)
- [x] Implementar rotas tRPC para CRUD de cupons (implementado na Fase 8)
- [x] Implementar rota para validar cupom (implementado na Fase 8)
- [x] Integrar cupom com Stripe checkout (implementado na Fase 8)

### Admin
- [x] Criar página de gerenciamento de cupons no painel Admin (implementado na Fase 8)
- [x] Listar cupons existentes com status (implementado na Fase 8)
- [x] Formulário para criar novo cupom (implementado na Fase 8)
- [x] Opções: desconto percentual ou valor fixo (implementado na Fase 8)
- [x] Definir validade e limite de uso (implementado na Fase 8)

### Checkout
- [x] Adicionar campo para inserir código do cupom (implementado na Fase 52)
- [x] Validar cupom em tempo real (implementado na Fase 52)
- [x] Mostrar desconto aplicado no preço (implementado na Fase 52)
- [x] Passar cupom para sessão do Stripe (implementado na Fase 52)


## Fase 19 - Correções na Área de Membros

### Problemas Reportados
- [x] Conteúdos marcados como "Em breve" precisam ser liberados (corrigido na Fase 41 - releaseDate)
- [x] Usuário não consegue acessar consultorias (corrigido na Fase 47 - controle de acesso)
- [x] Usuário não consegue acessar conteúdos (corrigido na Fase 20/47)
- [x] Conteúdos enviados pelo usuário não estão aparecendo (corrigido na Fase 20)

### Correções Necessárias
- [x] Organizar conteúdos por módulos e temas (CX, Dados, IA) (implementado na Fase 29 - 4 trilhas)
- [x] Vincular liberação de conteúdos ao pacote comprado pelo usuário (implementado na Fase 47)
- [x] Atualizar status dos conteúdos de "Em breve" para "Disponível" (implementado na Fase 41)
- [x] Verificar e corrigir a lógica de exibição de conteúdos na área de membros (implementado na Fase 29)


## Fase 20 - AUDITORIA COMPLETA E CORREÇÕES CRÍTICAS

### PENDÊNCIAS CRÍTICAS IDENTIFICADAS

#### Admin - Gestão de Usuários
- [x] Adicionar funcionalidade de EDITAR usuário no Admin
- [x] Adicionar funcionalidade de EXCLUIR usuário no Admin
- [x] Visualizar detalhes completos do usuário

#### Conteúdos - Criação Autoral
- [x] CRIAR conteúdos NOVOS e autorais (10 conteúdos com linguagem Protocolo Vértice)
- [x] Módulo 1: Introdução ao Data Storytelling - CONTEÚDO AUTORAL CRIADO
- [x] Módulo 2: Métodos de Coleta de Dados - CONTEÚDO AUTORAL CRIADO
- [x] Módulo 3: Transformando Dados em Narrativas - CONTEÚDO AUTORAL CRIADO
- [x] Módulo 4: Escolhendo o Visual Eficaz - CONTEÚDO AUTORAL CRIADO
- [x] Módulo 5: Pitch - Sua Ideia Cronometrada - CONTEÚDO AUTORAL CRIADO
- [x] História de Florence Nightingale - CONTEÚDO AUTORAL CRIADO
- [x] Pirâmide do Conhecimento - CONTEÚDO AUTORAL CRIADO
- [x] Fundamentos de CX - CONTEÚDO AUTORAL CRIADO
- [x] Jornada do Cliente - CONTEÚDO AUTORAL CRIADO
- [x] Métricas de CX - CONTEÚDO AUTORAL CRIADO
- [x] Criar conteúdos autorais para os demais módulos (35 conteúdos autorais criados no total)

#### Área de Membros
- [x] Corrigir acesso aos conteúdos (35 conteúdos disponíveis)
- [x] Foto do Samuel Rosa atualizada para foto real do evento
- [x] Organizar conteúdos por módulos e temas (CX, Dados, IA) - implementado na Fase 29 (4 trilhas)
- [x] Liberar conteúdos de acordo com o pacote comprado - implementado na Fase 47

#### Melhorias Pendentes no Admin
- [x] Melhorias visuais no painel Admin (tooltips, tendências, badges implementados)
- [x] Dashboard mais completo com métricas (10 métricas com tooltips)



## Fase 21 - Melhorias Solicitadas (Fev 2026)

### Correção Visual
- [x] Corrigir foto cortada na Home (ajustado object-position para center 20%)

### Sistema de Quiz
- [x] Criar tabela de quizzes no banco de dados (já existia)
- [x] Criar tabela de perguntas e respostas (quiz_questions)
- [x] Criar tabela de resultados do aluno (quiz_attempts)
- [x] Implementar rotas tRPC para quiz (create, list, submit, etc.)
- [x] Criar interface de quiz ao final de cada módulo (/quiz/:id)
- [x] Criar interface Admin para gerenciar quizzes (aba Quizzes)

### Certificado de Conclusão
- [x] Criar tabela de certificados no banco de dados (já existia)
- [x] Implementar geração automática de certificado
- [x] Criar página de visualização do certificado (/certificados)
- [x] Emitir certificado quando aluno completar programa (rota certificates.generate)

### Funcionalidade de Vídeos
- [x] Adicionar campo de videoUrl na tabela contents
- [x] Criar interface Admin para vincular vídeos aos módulos (botão Editar)
- [x] Implementar player de vídeo na área de membros (YouTube embed funcional na Fase 23)


## Fase 22 - Correções na Página do Case

### Remover Identificação FCO
- [x] Substituir "FCO" por nome genérico ("Instituição de Ensino")
- [x] Remover qualquer referência que identifique o cliente

### Menu de Navegação
- [x] Adicionar link "Case" no menu principal (nova rota /cases/120-matriculas)

### Scroll to Top
- [x] Scroll automático para o topo ao trocar de página (já implementado no App.tsx)


## Fase 23 - Melhorias na Área de Membros

### Visualização de Conteúdos na Web
- [x] Criar página de leitura de conteúdo (texto/markdown) - /membros/conteudo/:id
- [x] Implementar player de vídeo integrado (YouTube embed) - iframe responsivo
- [x] Implementar player de áudio para arquivos hospedados - HTML5 audio player
- [x] Adicionar botão de compartilhamento ao final do conteúdo - Web Share API

### Geração de PDF com ABNT
- [x] Criar template PDF com normas ABNT - /api/contents/:id/pdf
- [x] Adicionar cabeçalho com logo e nome do usuário
- [x] Formatar título e corpo do texto conforme ABNT (Times New Roman 12pt, margens 3/2/3/2cm, recuo 1.25cm)
- [x] Implementar rota de exportação de PDF - abre HTML formatado para impressão

### Organização por Temas
- [x] Adicionar campo de categoria/tema na tabela contents (category: introducao, cx, dados, ia)
- [x] Categorizar conteúdos: Introdução (1-17), CX (24-29), Dados (18-23, 30-35)
- [x] Criar filtros por tema na área de membros - badges coloridas por categoria
- [x] Atualizar interface com navegação por categoria

### Vinculação de Conteúdos aos Cursos
- [x] Definir quais conteúdos pertencem a cada programa (implementado na Fase 47 - plan_module_access)
- [x] Implementar lógica de liberação por plano adquirido (implementado na Fase 47)
- [x] Mostrar conteúdos bloqueados com CTA de upgrade (implementado na Fase 47)

### Pendências Anteriores (a implementar depois)
- [x] Checkout de planos de mentoria (implementado na Fase 7/41 - Stripe checkout funcional)
- [x] Gestão de assinaturas (implementado via Stripe webhooks)
- [x] Webhooks de pagamento (implementado na Fase 7/41)
- [x] Masterclass Vértice (90 min) (plano criado na Fase 29)
- [x] Countdown para próxima turma (implementado nas Ofertas nesta sessão)
- [x] PWA (aplicativo white label) (manifest.json + sw.js já configurados)
- [x] Spaces por coorte/turma (implementado na Fase 62)
- [x] Régua automática pós-diagnóstico (implementado nesta sessão)


## Fase 24 - Barra de Progresso de Conteúdos

### Sistema de Progresso
- [x] Verificar estrutura de progresso existente no banco de dados (tabela user_progress já existia)
- [x] Implementar marcação de conteúdo como concluído (botão "Concluir" na página de conteúdo)
- [x] Adicionar barra de progresso visual na área de membros (ProgressRing circular + barras por categoria)
- [x] Mostrar indicador de conteúdos concluídos vs total (cards com Mentorias Ativas, Concluídos, Restantes)
- [x] Persistir progresso no banco de dados (via tRPC progress.markComplete)
- [x] Testar funcionalidade completa (progresso atualiza em tempo real)


## Fase 25 - Perfil do Aluno com Estatísticas e Medalhas

### Sistema de Medalhas
- [x] Criar tabela de medalhas no banco de dados (tabelas badges, userBadges já existiam)
- [x] Definir tipos de medalhas (14 medalhas: progresso, categorias, engajamento, especiais)
- [x] Implementar lógica de conquista automática de medalhas (awardBadge com pontos de recompensa)
- [x] Criar procedure tRPC para listar medalhas do usuário (gamification.myStats, gamification.allBadges)

### Página de Perfil
- [x] Criar página de perfil com dashboard de estatísticas (ProgressRing, cards de estatísticas)
- [x] Exibir progresso geral e por categoria (Introdução, CX, Dados, IA com barras de progresso)
- [x] Mostrar medalhas conquistadas com visual atrativo (BadgeCard com gradientes e ícones)
- [x] Adicionar histórico de atividades recentes (transações de pontos com tipo e data)
- [x] Implementar compartilhamento de conquistas (Web Share API com botão Compartilhar)


## Fase 26 - Conquista Automática de Medalhas

### Lógica de Verificação
- [x] Criar função checkAndAwardBadges no backend (server/db.ts)
- [x] Verificar medalhas de progresso (content_count: 1, 5, 10, 25, all_content)
- [x] Verificar medalhas por categoria completa (category_complete: introducao, cx, dados, ia)
- [x] Verificar medalha do Radar Vértice completo (radar_complete)

### Integração com Fluxo
- [x] Chamar verificação após cada conteúdo concluído (progress.markComplete)
- [x] Retornar medalhas conquistadas na resposta (awardedBadges array)
- [x] Atualizar pontos do usuário automaticamente (+10 por conteúdo + pontos da medalha)

### Notificação Visual
- [x] Criar componente de notificação de medalha conquistada (toast com ícone troféu)
- [x] Exibir modal/toast quando medalha for ganha (toast.success com JSX)
- [x] Animação de celebração (notificações em sequência com delay de 1.5s)


## Fase 27 - Compartilhamento de Medalhas nas Redes Sociais

### Card Visual de Medalha
- [x] Criar componente ShareBadgeCard com design atrativo (gradiente escuro, ícones coloridos)
- [x] Incluir nome do aluno, medalha e data de conquista (BadgePreviewCard)
- [x] Adicionar branding do Data CX Protocolo Vértice (logo DCX + checkmark verde)

### Integração com Redes Sociais
- [x] Implementar compartilhamento no LinkedIn (botão azul #0077B5)
- [x] Implementar compartilhamento no Twitter/X (botão azul #1DA1F2)
- [x] Implementar compartilhamento no WhatsApp (botão verde #25D366)
- [x] Implementar compartilhamento no Facebook (botão azul #1877F2)
- [x] Adicionar opção de copiar link (com feedback visual)

### Modal de Compartilhamento
- [x] Criar modal com preview do card (ShareBadgeModal com Dialog)
- [x] Adicionar botões das redes sociais (grid 2x2 + copiar link)
- [x] Implementar mensagem personalizada por rede (texto + hashtags + URL)


## Fase 28 - Certificados Automáticos por Categoria

### Estrutura de Dados
- [x] Criar tabela de certificados no schema (userId, category, type, certificateNumber, verificationCode)
- [x] Adicionar funções de CRUD para certificados no db.ts (create, get, list, checkCompletion)
- [x] Criar procedures tRPC para certificados (myCertificates, categoryProgress, generate)

### Geração de Certificados
- [x] Implementar verificação de conclusão de categoria (checkCategoryCompletion)
- [x] Criar template HTML do certificado com design profissional (bordas douradas, selos, branding DCX)
- [x] Implementar endpoint de geração de PDF (/api/certificates/:id/pdf)
- [x] Adicionar código de verificação único ao certificado (DCX-CAT-{CATEGORY}-{CODE}-{ID})

### Página de Certificados
- [x] Criar página /certificados para listar certificados do aluno (dashboard com progress)
- [x] Adicionar botão de download do PDF (abre em nova aba)
- [x] Implementar visualização do certificado (cards por categoria com progresso)
- [x] Adicionar compartilhamento nas redes sociais (botão compartilhar)

### Integração Automática
- [x] Chamar verificação após cada conteúdo concluído (progress.markComplete chama checkAndAwardCertificates)
- [x] Gerar certificado automaticamente ao completar categoria (+100 pontos)
- [x] Exibir notificação de certificado conquistado (toast com ícone 🎓 e duração 8s)


## Fase 29 - Reconstrução Total V2 (60 Módulos + Netflix + Quizzes + Acesso por Plano)

### Limpeza e Importação
- [x] Apagar 100% do conteúdo antigo (módulos, aulas, quizzes, trilhas)
- [x] Extrair e analisar 5 ZIPs (INTRO, CX, DADOS, IA, QUIZZES)
- [x] Importar 60 módulos markdown (6 INTRO + 18 CX + 18 DADOS + 18 IA)
- [x] Importar 60 quizzes JSON com 600 questões (10 por quiz)
- [x] Importar mapa de planos (5 planos, 139 entradas de acesso)

### Schema e Backend
- [x] Atualizar tabela contents com campos V2 (moduleCode, pilar, nivel, duracao, tags, prerequisites, personas)
- [x] Criar tabela planModuleAccess para controle de acesso por plano
- [x] Adicionar funções de trilhas e módulos por pilar ao db.ts
- [x] Adicionar funções de acesso por plano (getUserActivePlanSlugs, getUserAccessibleModuleCodes, checkModuleAccess)
- [x] Atualizar routers.ts com procedures de trilhas, busca, acesso por plano e módulos V2

### Área de Membros Netflix
- [x] Layout estilo Netflix com scroll horizontal por trilha
- [x] 4 trilhas: Introdução (6), CX (18), Dados (18), IA (18)
- [x] Barra de progresso geral (0/60 módulos) com breakdown por pilar
- [x] Busca por módulos (campo de texto)
- [x] Filtros por pilar (Todos, Intro, CX, Dados, IA)
- [x] Filtro por nível (Todos, Fundamento, Intermediário, Avançado)
- [x] Botão "Ver Todos" por trilha
- [x] Cards com código do módulo, título, nível e duração

### Página de Módulo V2
- [x] Conteúdo Web renderizado com índice lateral por capítulos (16 capítulos)
- [x] Player de vídeo placeholder (YouTube embed pronto)
- [x] Player de áudio placeholder (HTML5 audio pronto)
- [x] Aba Chat IA contextual por módulo
- [x] Aba Prova integrada (10 questões, 4 alternativas, 3 tentativas, mínimo 70%)
- [x] Navegação por questão na prova
- [x] Botão Concluir com conquista automática de medalhas

### Controle de Acesso por Plano
- [x] 5 planos V2 criados (diagnostico, masterclass, mentoria-grupo, mentoria-individual, assessoria)
- [x] Verificação de acesso no frontend (módulos bloqueados com overlay e CTA de upgrade)
- [x] Verificação de acesso no ContentView (tela de bloqueio se módulo não acessível)
- [x] Suporte a múltiplos planos ativos por usuário

### Testes
- [x] 51 testes passando (14 novos testes V2)
- [x] 5 módulos aleatórios testados: INT-01, CX-F01, D-F01, AI-F01, AI-S06
- [x] Verificação de conteúdo web + chat + prova em todos os módulos testados
- [x] Substituir fotos na seção "Sobre Mim" e foto do especialista em CX pelas novas fotos enviadas
- [x] Corrigir foto circular do card do especialista em CX - Samuel Rosa cortado, precisa ficar visível


## Fase 27 - Atualização Global: Mini Apostilas + Áudios Automáticos

### Schema e Backend
- [x] Adicionar campos no DB: mini apostila por persona (jovem/gestor/executivo/empresario), áudio URL por persona, roteiro admin
- [x] Criar rotas tRPC para geração de mini apostila via LLM
- [x] Criar rota tRPC para geração de áudio narrado via TTS
- [x] Criar rota admin para gerar conteúdo em massa

### Mini Apostila (Conteúdo do Aluno)
- [x] Estrutura completa: capa, resumo executivo, aula principal, frameworks, mini-case, exercícios 3 níveis, checklist, glossário, referências
- [x] Texto pronto e fluido (sem rótulos vazios ou instruções de implementação)
- [x] Conteúdo adaptado por persona (linguagem, exemplos, exercícios)

### Toggle de Persona (Frontend)
- [x] Toggle no topo do módulo para selecionar persona (Jovem/Gestor/Executivo/Empresário)
- [x] Se persona vier do Radar/onboarding: renderizar automaticamente a versão correta
- [x] Trocar texto + exemplos + exercícios + linguagem ao mudar persona

### Áudio Narrado
- [x] Gerar áudio via TTS para cada módulo/persona (8-12 min padrão)
- [x] Player de áudio funcional no módulo (não placeholder)
- [x] Estrutura do áudio: abertura 20s, 3 pontos principais, mini-case, próximo passo
- [x] Roteiro do áudio visível apenas no Admin (invisível ao aluno)

### Limpeza do Frontend do Aluno
- [x] Placeholder limpo de vídeo ("Vídeo em breve" sem roteiros/instruções)
- [x] Chat contextual: interface limpa, regras/prompts só no back
- [x] Prova: 10 questões / 3 tentativas / feedback, sem instruções internas
- [x] Zero texto de admin/back-end aparecendo no conteúdo do aluno

### Geração em Massa
- [x] Gerar mini apostilas para 4 módulos de teste (16 versões: INT-01, CX-F01, D-F01, AI-F01 x 4 personas)
- [x] Gerar áudios para 4 módulos de teste (16 versões com player funcional)

### Validação
- [x] Validar 4 módulos com mini apostila completa (INT-01, CX-F01, D-F01, AI-F01)
- [x] Validar persona correta (toggle funcional, auto-detect do radar)
- [x] Validar áudio gerado e anexado (player funcionando - 16/16 ready)
- [x] Validar chat e prova ok
- [x] Validar zero texto admin no conteúdo do aluno


## Fase 28 - Personalização Completa: Identidade Data CX + Geração em Massa

### Prompt de Apostilas
- [x] Atualizar prompt LLM com tom Samuel Rosa (frases assinatura, estilo mentor em sala de guerra)
- [x] Incluir cases híbridos (70% fictícios realistas, 30% inspirados em projetos reais)
- [x] Adicionar referências fortes (Reichheld, Deming, Don Norman, Christensen, Teresa Torres, COPC, Lean Six Sigma, NIST AI RMF)
- [x] Incluir glossário Protocolo Vértice (Radar Vértice, Cockpit Executivo, Esteira de Impacto, etc.)
- [x] Exercícios com ferramentas (Excel, Power BI, ChatGPT, NotebookLM) e artefatos (1-pager, backlog, blueprint)

### Configuração TTS
- [x] Voz configurada como pt-BR-AntonioNeural (única masculina pt-BR disponível) com ajustes de tom executivo
- [x] Ajustar velocidade para 0.95x (levemente mais lenta)
- [x] Adicionar pausas médias entre seções
- [x] Tom conversacional-executivo (mentor em sala de guerra)

### Regenerar 4 Módulos de Teste
- [x] Regenerar apostilas INT-01, CX-F01, D-F01, AI-F01 (16 versões) com novo prompt
- [x] Regenerar áudios INT-01, CX-F01, D-F01, AI-F01 (16 versões) com nova voz

### Gerar 56 Módulos Restantes
- [x] Gerar apostilas: 240/240 ready (60 módulos x 4 personas) via OpenAI GPT-4o com identidade Data CX
- [x] Gerar áudios: 240/240 ready via edge-tts (pt-BR-AntonioNeural, 0.95x) com upload CDN

### Validação
- [x] Validar qualidade das apostilas personalizadas no browser (identidade Data CX confirmada)
- [x] Validar áudio com voz AntonioNeural (executiva, 0.95x, pausas)
- [x] Verificar contagem final: 240 versões, 240 apostilas ready, 240 áudios ready, 0 pendentes


## Fase 29 - Validação Final e Próximos Passos

### Spot-check de Qualidade
- [x] Testar 10-15 módulos aleatórios (testados na Fase 30: INT-01, CX-F03, D-S02, AI-P01, CX-P05)
- [x] Verificar zero texto admin/backend visível ao aluno (validado na Fase 30)
- [x] Validar chat IA contextual e quiz funcional (validado na Fase 32)

### Stripe Checkout V2
- [x] Configurar checkout para 5 planos V2 (implementado na Fase 41 - 5 planos Stripe)
- [x] Testar fluxo de pagamento completo (testado na Fase 41 com cartão 4242)

### Vídeos Reais
- [ ] Adicionar URLs do YouTube quando vídeos estiverem gravados
- [ ] Substituir placeholders "Vídeo em breve"


## Fase 30 - Teste Completo da Jornada do Aluno

### Área de Membros
- [x] Verificar layout Netflix com scroll horizontal por trilha
- [x] Verificar 4 trilhas visíveis (Introdução, CX, Dados, IA)
- [x] Verificar barra de progresso geral
- [x] Verificar busca e filtros funcionais

### Módulo INT-01 (Introdução)
- [x] Apostila completa sem texto admin/backend
- [x] Toggle de persona funcional (4 opções)
- [x] Conteúdo muda ao trocar persona
- [x] Player de áudio funcional
- [x] Quiz funcional (10 questões com conteúdo real)
- [x] Chat IA contextual (corrigido na Fase 32 - migrado para OpenAI)

### Módulo CX-F03 (CX Fundamento)
- [x] Apostila completa com identidade Data CX
- [x] Toggle de persona funcional
- [x] Player de áudio funcional

### Módulo D-S02 (Dados Intermediário)
- [x] Apostila completa
- [x] Toggle de persona funcional
- [x] Player de áudio funcional

### Módulo AI-P01 (IA Avançado)
- [x] Apostila completa
- [x] Toggle de persona funcional
- [x] Player de áudio funcional
- [x] Quiz funcional (10 questões com conteúdo real)

### Módulo CX-P05 (CX Avançado)
- [x] Apostila completa
- [x] Chat IA contextual funcional (corrigido na Fase 32 - migrado para OpenAI)


## Fase 31 - Geração de Quizzes Reais

- [x] Gerar 600 questões reais (60 módulos × 10 questões) via OpenAI gpt-4.1-mini ($0.19 ~R$1.16)
- [x] Substituir placeholders genéricos no banco de dados (600 questões atualizadas)
- [x] Validar quizzes no browser (CX-F01 testado: 10 questões específicas confirmadas)


## Fase 32 - Substituir LLM do Chatbot pela API OpenAI do Usuário

- [x] Identificar todos os pontos de chamada do LLM integrado (chat global Daniel + chat por módulo)
- [x] Configurar OPENAI_API_KEY como secret do projeto
- [x] Criar helper de chamada OpenAI (gpt-4.1-mini) em server/openaiChat.ts
- [x] Substituir invokeLLM por invokeOpenAI nos 2 chatbots (routers.ts)
- [x] Testar chatbot Daniel (resposta sobre Protocolo Vértice OK)
- [x] Testar chat por módulo CX-P05 (exemplo prático de rechamadas OK)


## Fase 33 - Feedback com Estrelas para Tutor IA

- [x] Criar tabela chat_feedback no schema (rating 1-5, comment, messageId, userId)
- [x] Migrar banco de dados (pnpm db:push)
- [x] Criar helpers de banco para feedback (submitChatFeedback, getChatFeedback)
- [x] Criar procedures tRPC para feedback (submitFeedback, getFeedback)
- [x] Implementar componente de estrelas interativo no frontend (ChatFeedbackWidget)
- [x] Integrar campo de comentário opcional (botão Comentar/Editar)
- [x] Exibir feedback abaixo de cada resposta do Tutor IA
- [x] Testar no browser (4 estrelas + comentário salvo no banco OK)
- [x] Escrever testes vitest para as procedures de feedback (9 testes passando)


## Fase 34 - Melhorias do Painel Administrativo

### Backend - Novas Métricas e Procedures
- [x] Métricas de engajamento por módulo (views, completions, chat messages)
- [x] Dashboard de feedbacks do Tutor IA (média por módulo, comentários recentes, distribuição)
- [x] Métricas de progresso dos alunos (% conclusão por trilha, alunos ativos vs inativos)
- [x] Métricas de quiz (taxa de aprovação, nota média por módulo)
- [x] Lista de alunos com progresso detalhado

### Frontend - Novas Abas e Melhorias Visuais
- [x] Dashboard com 8 cards de tendência (usuários, matrículas, receita, chat, avaliações IA, conclusões, quizzes, leads, contatos)
- [x] Aba "Feedbacks IA" com tabela de avaliações por módulo, feedbacks recentes, busca e filtro por trilha
- [x] Aba "Progresso" com visão por aluno (módulos, chat, quizzes, nota média, última atividade)
- [x] Aba "Engajamento" com performance de quizzes e engajamento por módulo
- [x] Indicadores de tendência (setas up/down com % de mudança semanal)
- [x] Badges coloridos por trilha (Introdução, CX, Dados, IA)
- [x] Busca e filtros em todas as tabelas

### Testes
- [x] Testes vitest para novas procedures admin (9 testes, 80 total passando)


## Fase 36 - Bug: Apostilas exibindo markdown bruto

- [x] Investigar componente de renderização de apostilas no ContentView.tsx (Streamdown na linha 912)
- [x] Causa raiz: 2 de 240 apostilas tinham prefixo ```markdown no banco de dados
- [x] Corrigido: removido prefixo ```markdown e sufixo ``` das 2 apostilas (IDs 30194, 30207)
- [x] Verificado: 238 apostilas já estavam corretas, 0 restantes com problema
- [x] Testado no browser: INT-02 executivo e AI-S04 gestor renderizando corretamente


## Fase 37 - Capas Profissionais para os 60 Módulos

- [x] Criar exemplo de capa para aprovação (INT-01) com imagem hiperrealista
- [x] Padrão visual: quadrado, dark, gradientes azul/roxo, nome do módulo, código, badge trilha
- [x] Gerar imagem hiperrealista temática via IA para cada módulo (60 imagens geradas em paralelo)
- [x] Compor capa final com overlay de texto (nome, código, badge) - design aprovado pelo usuário
- [x] Gerar as 60 capas em lote após aprovação (60/60 sucesso)
- [x] Upload para S3 e atualizar banco de dados (campo thumbnailUrl) - 60/60 atualizados
- [x] Integrar capas nos cards da área de membros (estilo Netflix) - implementado na Fase 37b
- [x] Testar no browser e salvar checkpoint (Fase 37b)


## Fase 37b - Bug: Capas não exibidas nos cards da área de membros

- [x] Investigar componente de cards da área de membros (thumbnailUrl não renderizado)
- [x] Corrigir para exibir as capas geradas nos cards estilo Netflix
- [x] Testar no browser e salvar checkpoint

## Fase 37c - Remover texto duplicado nos cards com capa

- [x] Remover título, código, descrição e footer dos cards que têm thumbnailUrl (manter apenas imagem)

## Fase 38 - Scrollbar moderna + Banners dos pilares

- [x] Estilizar scrollbar horizontal dos carrosséis (moderna, discreta, tema dark)
- [x] Gerar 4 imagens de fundo para banners dos pilares (Introdução, CX, Dados, IA)
- [x] Compor banners finais com overlay de texto e integrar no Members.tsx
- [x] Testar e salvar checkpoint

## Fase 39 - Sistema de Login com E-mail e Senha

- [x] Adicionar campos email, passwordHash, emailVerified, resetToken, resetTokenExpiry ao schema de users
- [x] Implementar backend: rota de registro (signup) com hash bcrypt
- [x] Implementar backend: rota de login com e-mail/senha e geração de JWT
- [x] Implementar backend: rota de recuperação de senha (envio de token por e-mail)
- [x] Implementar backend: rota de reset de senha com token
- [x] Implementar frontend: página de Login com e-mail/senha
- [x] Implementar frontend: página de Cadastro (signup)
- [x] Implementar frontend: página de Recuperação de Senha
- [x] Integrar novo auth com área de membros e sistema de planos existente
- [x] Manter login OAuth do Manus apenas para admin/owner (OAuth continua funcional para admin)
- [x] Escrever testes vitest para os fluxos de auth (10 testes, todos passando)
- [x] Criar conta de teste para o usuário compartilhar com sócios (sistema de cadastro implementado)

## Fase 40 - Revisão de preços, controle de acesso por plano e gestão admin

- [x] Pesquisar benchmarks de mercado para mentorias CX/Dados/IA
- [ ] Revisar valores dos planos (exceto Playbook)
- [x] Implementar modelo de controle de acesso por plano (schema + backend) - tabela user_module_overrides + plan_module_access populada
- [x] Vincular conteúdo ao plano contratado pelo usuário (overrides grant/revoke implementados)
- [x] Implementar UX de conteúdo bloqueado/liberado na área de membros (implementado na Fase 47)
- [x] Implementar painel Admin para editar acessos de usuários (implementado na Fase 47 - aba Acessos)
- [ ] Atualizar valores dos planos no código
- [x] Escrever testes vitest para controle de acesso (17 testes na Fase 47)
- [x] Testar fluxos completos e salvar checkpoint (Fase 47 - 152 testes)


## Fase 41 - Melhorias Finais (Fev 2026)

### Hero Full-Width Cinematográfico
- [x] Remover container do hero, fazer imagem e texto ocuparem 100% da largura
- [x] Melhorar overlay e gradientes para efeito cinematográfico (vignette, multi-layer gradients)
- [x] Garantir responsividade em todas as telas (px responsivo de 6 a 40)

### Página de Upgrade
- [x] Criar página /upgrade com comparação de planos (5 planos lado a lado)
- [x] Quando aluno clica em módulo bloqueado, redirecionar para /upgrade
- [x] Mostrar plano atual vs planos superiores com CTA de compra
- [x] Destacar módulos que serão desbloqueados com cada upgrade (tabela comparativa)

### Integração Resend para E-mails Transacionais
- [x] Instalar SDK Resend (resend 6.9.2)
- [x] Criar serviço de e-mail (emailService.ts) com templates HTML profissionais
- [x] E-mail de boas-vindas ao cadastrar (sendWelcomeEmail)
- [x] E-mail de recuperação de senha com link (sendPasswordResetEmail)
- [x] E-mail de confirmação de compra (sendPurchaseConfirmationEmail)
- [x] Testes vitest para o serviço de e-mail (7 testes passando)

### Liberação Progressiva por Data
- [x] Adicionar campo releaseDate na tabela contents (migração aplicada)
- [x] Implementar lógica de verificação de data no backend (isReleased no getAllModulesWithProgress)
- [x] Módulos com releaseDate futuro aparecem como "Em breve" na área de membros (overlay amber)
- [x] Admin pode definir datas de liberação por módulo (ContentEditDialog + coluna na tabela)
- [x] Procedure bulkSetReleaseDates para agendamento em massa

### Cards Expandidos na Área de Membros
- [x] Expandir grid para 4-5 cards visíveis em telas wide (xl:grid-cols-4 2xl:grid-cols-5)

### Teste do Fluxo de Compra
- [x] Verificar fluxo completo: cadastro -> compra -> redirecionamento para sucesso
- [x] Testar com cartão de teste Stripe (4242) - pagamento processado com sucesso
- [x] Corrigir mapeamento product_id -> programId no webhook (era fixo 1, agora mapeia corretamente)
- [x] Confirmar liberação automática de módulos após pagamento (webhook Stripe implementado)


## Fase 42 - Melhorias Fev 2026 (Parte 2)

### Régua de E-mails Pós-Compra (Onboarding)
- [x] Criar tabela scheduled_emails no schema para rastrear e-mails agendados
- [x] Implementar templates de e-mail para dia 1 (boas-vindas), dia 3 (dicas), dia 7 (engajamento)
- [x] Criar procedure para agendar e-mails após compra (scheduleOnboardingEmails)
- [x] Implementar job/cron para enviar e-mails agendados (processPendingEmails a cada 15min)
- [x] Testes vitest para a régua de e-mails (8 testes passando)

### Indicador de Progresso nos Cards de Módulo
- [x] Indicador visual de status (não iniciado, em andamento, concluído) nos cards
- [x] Barra de progresso por trilha (pilar) no banner de cada seção
- [x] Badges de status com cores diferenciadas (cinza, amber, green)

### Seção de Depoimentos na Página de Upgrade
- [x] Criar seção de depoimentos/prova social na página /upgrade (TestimonialsSection)
- [x] 5 depoimentos estáticos como fallback + integração com DB para depoimentos reais
- [x] Design com cards, estrelas, iniciais do nome, e barra de estatísticas (200+ mentorados, 98% satisfação)

### Agendamento de Liberação Progressiva
- [x] Tab "Cronograma" no admin com UI de agendamento em massa
- [x] Gerador automático de cronograma semanal (data inicial + intervalo em dias)
- [x] Filtro por trilha e edição individual de datas por módulo
- [x] Procedure bulkSetReleaseDates para salvar cronograma

### Publicação
- [x] Orientar usuário a clicar em Publish para testar em produção (checklist na aba Saúde do Admin)


## Fase 44 - Sistema de Certificados por Programa

### Certificados Automáticos por Programa
- [x] Schema de certificados já existia (certificates table com pdfUrl, verificationCode)
- [x] Geração de PDF profissional com jsPDF (certificateGenerator.ts) - design com bordas, selo, QR code
- [x] Upload automático do PDF para S3 via storagePut
- [x] Detecção automática ao completar todos os módulos (checkAndAwardCertificates integrado no markComplete)
- [x] Envio de e-mail com link do certificado (sendCertificateEmail)
- [x] Endpoint /api/certificates/:id/pdf gera PDF on-demand se não existir no S3
- [x] Página de verificação pública (/verificar-certificado?code=xxx)
- [x] UI de certificados na área de membros (Certificates.tsx já existia)
- [x] Testes vitest para o sistema de certificados (7 testes passando, 126 total)


## Fase 45 - Certificado Especial de Conclusão Geral

### Certificado "Protocolo Vértice Completo"
- [x] Detectar quando aluno possui certificados das 4 trilhas (introducao, cx, dados, ia)
- [x] Gerar certificado especial tipo "general" automaticamente
- [x] Design diferenciado do PDF (dourado, premium, selo especial)
- [x] Exibir certificado geral com destaque na UI de certificados
- [x] E-mail especial de parabéns ao conquistar o certificado geral
- [x] Testes vitest para a lógica de conclusão geral (18 testes, 135 total passando)


## Fase 46 - Correções de Layout e UX

### Layout Full-Width
- [x] Expandir layout de todas as páginas para ocupar 100% da largura em telas grandes (container max-width 1600px/1800px/100%)
- [x] Corrigir Home, Programas, Case, Sobre, Contato, Área de Membros

### Scroll dos Índices na Área de Membros
- [x] Corrigir sidebar/índice de conteúdo que não rola quando o conteúdo é longo (max-h calc(100vh-180px))
- [x] Garantir que o índice tenha scroll independente do conteúdo principal

### Chat IA - Remover Histórico
- [x] Cada abertura do chat IA em módulos deve iniciar conversa nova (sem histórico)
- [x] Remover persistência de mensagens anteriores no chat do tutor IA
- [x] Botão "Nova conversa" para limpar sessão manualmente

## Fase 47 - Controle de Acesso por Plano (Playbook vs Mentoria)

### Backend - Lógica de Acesso
- [x] Analisar schema atual de planos e permissões
- [x] Tabela plan_module_access já existia com 180 registros mapeando planos a módulos
- [x] Planos definidos: playbook-vertice (24 módulos), mentoria-grupo (60), mentoria-individual (60), mentoria-executiva (60), diagnostico-360 (60)
- [x] Procedure tRPC accessibleModules retorna isAdmin, hasActivePlan, moduleCodes
- [x] Webhook Stripe já ativa plano após pagamento (checkout.session.completed)

### Frontend - UI de Conteúdo Bloqueado/Liberado
- [x] Sem plano = tudo bloqueado exceto INT-01 (preview gratuito)
- [x] Com plano = mostra bloqueado/liberado conforme mapeamento
- [x] Admin = tudo liberado
- [x] Mensagem diferenciada: "Plano necessário" vs "Fora do seu plano"
- [x] Redireciona para /ofertas (sem plano) ou /upgrade (plano insuficiente)
- [x] ContentView também bloqueia acesso direto via URL

### Admin - Gerenciamento de Acessos
- [x] Aba "Acessos" no painel admin com seletor de usuário
- [x] Visualizar planos ativos e módulos acessíveis de cada usuário
- [x] Liberar/bloquear módulos individuais (overrides manuais)
- [x] Botão "Liberar Tudo" e "Revogar Overrides"
- [x] Visualizar mapeamento completo de planos
- [x] Datas de liberação já gerenciáveis na aba Cronograma

### Testes
- [x] Testes vitest para lógica de verificação de acesso (17 testes)
- [x] Testes para frontend lock logic (sem plano, com plano, admin, loading)
- [x] 152 testes totais passando

## Fase 48 - Remover Filtro de Nível

- [x] Remover dropdown de filtro de nível (Fundamento/Intermediário/Avançado) da área de membros
- [x] Manter apenas filtros por trilha (Todos, Intro, CX, Dados, IA)

## Fase 49 - Índice Sincronizado e Export PDF

- [x] Sincronizar scroll do índice com o conteúdo (IntersectionObserver + highlight automático)
- [x] Índice acompanha a rolagem do conteúdo principal (auto-scroll do TOC para item ativo)
- [x] Export PDF personalizado com logo DCX - Protocolo Vértice e nome do aluno (capa, header/footer, cores por trilha)

## Fase 50 - Redesenho Profissional dos Certificados

- [x] Certificado de trilha: layout limpo, sem sobreposições, textos centralizados, espaçamento profissional
- [x] Certificado geral Gold: layout limpo, bordas duplas gold, 4 badges centralizados, sem sobreposições
- [x] Hierarquia visual clara com breathing room entre elementos
- [x] Validar visualmente ambos os certificados (152 testes passando)

## Fase 51 - Melhorias da Análise GPT (Alta Prioridade)

### SEO & Meta Tags
- [x] Meta descriptions dinâmicas por página (SEO component com PAGE_SEO em todas as páginas)
- [x] Títulos únicos por página (document.title dinâmico via SEO component)
- [x] Dados estruturados JSON-LD (Organization, Course, FAQ, BreadcrumbList)
- [x] Open Graph e Twitter Cards completos em todas as páginas
- [x] Canonical URLs dinâmicas
- [x] Meta tags no index.html (author, keywords, robots)

### Erros 404 e URLs
- [x] Redirecionar /programas → /ofertas (já configurado no App.tsx)
- [x] Redirecionar /case → /cases/120-matriculas (já configurado no App.tsx)
- [x] Consistência nomenclatura menu "Programas" vs URL /ofertas (menu usa label "Programas" apontando para /ofertas)

### Prova Social
- [x] Seção de depoimentos com nome, cargo e foto na Home (já existia)
- [x] Selos/logotipos de segmentos atendidos (badges com ícones e nomes)
- [x] Contador de profissionais formados mais visível (+70 Profissionais nos trust badges)
- [x] Trust badges: Pagamento Seguro, Certificado Verificável, Acesso Imediato, +70 Profissionais

### Acessibilidade
- [x] Alt text em todas as imagens (verificado e melhorado)
- [x] Focus indicators visíveis para navegação por teclado
- [x] Skip-to-content link para acessibilidade
- [x] ARIA labels no menu mobile (aria-label, aria-expanded)
- [x] Reduced motion preference respeitada
- [x] Minimum touch target size (44x44px) no mobile
- [x] Formulários com labels acessíveis (já existiam)
- [x] Selection colors com contraste adequado

### Performance
- [x] Lazy loading via React.lazy no App.tsx (já implementado)
- [x] Otimizar carregamento de cards na área de membros (lazy loading + thumbnails otimizadas)

### UX - Formulário de Contato
- [x] Simplificar campos obrigatórios (reorganizado formulário de contato nesta sessão)

### UX - Navegação Admin
- [x] Agrupar abas do admin em categorias (separadores visuais: Aprendizado | Comercial | Gestão)
- [x] Tooltips de ajuda contextual em cada aba (implementado nesta sessão)

### CTAs e Conversão
- [x] Refinar textos dos CTAs com verbos de ação claros (implementado nas Ofertas e Members)
- [x] Elementos de urgência/escassez nas ofertas (countdown + badges implementados nesta sessão)
- [x] Transparência de preços nas mentorias individuais (preço por sessão adicionado)

### Política de Privacidade/LGPD
- [x] Link de política de privacidade no rodapé (já existe no Footer, seção Recursos)

### Área de Membros
- [x] Onboarding/tour guiado para novos alunos (OnboardingWelcome component implementado)
- [x] Corrigir bug de progresso 0/0 módulos (não reproduzível - progresso funciona corretamente)


## Fase 52 - Diagnóstico Cirúrgico: Jornada Cupom 100%

### P0 - Cupom e Checkout
- [x] Criar cupom espelho sem "%" (SOCIODATACX100 / SOCIODATACX100OFF) - nomes de cupom configuráveis no admin
- [x] Feedback ultra claro ao aplicar cupom (sucesso/erro com motivo específico)
- [x] Mostrar elegibilidade: quais produtos o cupom cobre (badge "Cupom aplicável")
- [x] Efeito imediato no preço: exibir R$ 0,00 com badge GRATUITO no produto elegível
- [x] CTA contextual após aplicar: "Confirmar inscrição gratuita" com ícone PartyPopper
- [x] Microtexto de confiança: "Você não será cobrado" + selo ShieldCheck

### P0 - Checkout 100% OFF
- [x] Total destacado R$ 0,00 no checkout (badge verde GRATUITO)
- [x] Copy explícita: "Você não será cobrado. Cupom 100% aplicado."
- [x] Botão: "Confirmar inscrição gratuita" (não "Pagar" ou "Comprar")
- [x] Bloco "o que você recebe" no resumo da página de sucesso
- [x] Não pedir cartão em checkout 100% (bypass Stripe, inscrição direta no backend)

### P0 - Página de Sucesso / Pós-compra
- [x] Página de sucesso com CTA principal: "Acessar Área de Membros" (contextual por produto)
- [x] Resumo do que recebe: módulos, certificados, comunidade, suporte
- [x] Mini-onboarding "comece em 30 segundos" (3-4 passos com auto-avanço animado)
- [x] Confetti animado + mensagem de boas-vindas personalizada

### P0 - Central de Ajuda
- [x] Criar Central de Ajuda (/ajuda) com FAQ completo
- [x] 6 categorias: Acesso, Pagamento, Conteúdo, Certificados, Mentoria + busca
- [x] SLA declarado: "Respondemos em até 24 horas úteis"
- [x] Separação clara: Chat IA para conteúdo, suporte humano para conta/certificado/pagamento
- [x] Guias rápidos: Primeiro acesso, Como usar cupom, Gerar certificado

### P0 - Certificados
- [x] Regras cristalinas visíveis: seção "Como funcionam os certificados?" com 4 regras numeradas
- [x] Barra de progresso: "X/Y conteúdos" por trilha + progress bar
- [x] Botão "Compartilhar no LinkedIn" com texto pronto em todos os certificados
- [x] Botão LinkedIn no certificado geral de excelência

### P0 - Instrumentação de Eventos
- [x] Sistema de analytics com buffer e flush automático (client/src/lib/analytics.ts)
- [x] Eventos: coupon_applied/coupon_failed com código e motivo
- [x] Eventos: checkout_started (com productId, amount, isFree)
- [x] Eventos: payment_success_viewed, onboarding_step_viewed
- [x] Eventos: certificate_generated/downloaded/shared_linkedin
- [x] Eventos: help_search (com query e resultados), help_faq_opened
- [x] Propriedades: url, referrer, timestamp em todos os eventos
- [x] Eventos: first_login, first_module_start/complete (implementado nesta sessão via analytics)

### P1 - Melhorias de Escala
- [x] Próxima ação recomendada após concluir módulo (NextActionCard implementado nesta sessão)
- [x] Downloads com "quando usar + exemplo + erros comuns" (implementado nos cards de Soluções na Fase 53)
- [x] Tour/checklist de primeiro acesso (3 passos: Radar, Trilhas, Comunidade)


## Fase 53 - Área de Membros "Cara de Produto" (inspirado Viver de IA)

### Sidebar Fixa com Grupos e Contadores
- [x] Sidebar fixa com navegação agrupada por intenção (APRENDIZADO, CONQUISTAS, COMUNIDADE, TRILHAS)
- [x] Contadores dinâmicos (Trilhas 60, Soluções 12, contadores por trilha)
- [x] Badges "Novo" para conteúdos recém-liberados (Soluções)
- [x] Sidebar colapsável no desktop + overlay mobile

### Hub de Soluções
- [x] Seção "Soluções" com 12 recursos (templates, checklists, prompts, documentos)
- [x] Cards com tags de categoria (CX, Dados, IA, Gestão) com cores distintas
- [x] Filtro rápido por categoria (Todas, CX, Dados, IA, Gestão)
- [x] Tabs: Todas | Mais usadas | Novas | Recomendadas

### Cards Melhorados
- [x] Cards de soluções com descrição + ação clara (Baixar, Aplicar, Abrir)
- [x] Badge de nível (Fundamentos, Aplicação, Escala) e tempo estimado nos cards
- [x] Ação clara nos cards: "Abrir", "Baixar", "Aplicar" com ícones
- [x] Tags visuais por trilha (badges coloridos por pilar) nos module cards

### Topo e Navegação
- [x] "Continuar de Onde Parei" com cards dos módulos em andamento no dashboard
- [x] Busca global no topo (busca módulos, soluções, quizzes)
- [x] Atalhos rápidos no topo: Certificados e Perfil

### Suporte Integrado
- [x] "Ajuda & Suporte" na sidebar (grupo COMUNIDADE) → redireciona para /ajuda
- [x] "Comunidade" na sidebar → redireciona para /comunidade
- [x] Card de Suporte no Acesso Rápido do dashboard
- [x] Seção "Meu Progresso" com stats gerais e progresso por trilha


## Fase 54 - Integração LLM no Radar Vértice

### Análise IA Personalizada
- [x] Criar procedure tRPC radar.generateAnalysis que envia respostas ao GPT (invokeOpenAI)
- [x] Gerar análise personalizada com base no perfil (persona, setor, scores, respostas detalhadas)
- [x] Gerar observações textuais por pilar (CX, Dados, IA, Governança)
- [x] Gerar 3 ações prioritárias para os próximos 30 dias
- [x] Exibir análise IA na página de resultado (card dedicado com ícone Bot)
- [x] Renderizar markdown com Streamdown e prose styles dark mode
- [x] Loading state animado (spinner + texto "Analisando seu perfil...")
- [x] Fallback com botão "Tentar Novamente" caso a IA não responda
- [x] Análise disparada em paralelo (não bloqueia exibição do resultado)


## Fase 55 - Correção do PDF do Radar Vértice

### PDF com Análise IA e Formatação
- [x] Incluir análise IA (diagnóstico personalizado) no PDF exportado (seção dedicada com fundo amarelo)
- [x] Corrigir formatação do PDF (layout profissional A4, Inter font, gradientes, barras de progresso)
- [x] Converter markdown da análise IA para HTML formatado no PDF (via marked.js)
- [x] Manter identidade visual Data CX no PDF (header gradiente, logo DCX, footer com tagline)
- [x] Adicionar respostas detalhadas por pilar com barras de progresso coloridas
- [x] Adicionar scores coloridos (vermelho/amarelo/verde) por dimensão
- [x] Page breaks automáticos para impressão limpa
- [x] Aguardar fontes carregarem antes de acionar print dialog


## Fase 56 - Histórico de Diagnósticos Radar na Área de Membros

### Seção Histórico Radar
- [x] Componente RadarHistorySection com listagem de diagnósticos anteriores
- [x] Cards detalhados com mini radar chart SVG, scores por dimensão e badges de nível
- [x] Gráfico de evolução dos 4 pilares ao longo do tempo (SVG line chart)
- [x] Modo de comparação entre 2 diagnósticos (seleção e diff por dimensão)
- [x] Indicadores de variação (↑/↓) entre diagnósticos consecutivos
- [x] Expansão de card com scores detalhados, recomendação e preview da análise IA
- [x] Estado vazio com CTA para fazer primeiro diagnóstico
- [x] CTA para refazer diagnóstico no final da página

### Integração na Área de Membros
- [x] Item "Histórico Radar" na sidebar (seção CONQUISTAS) com contador de diagnósticos
- [x] Card de atalho "Histórico Radar" no dashboard de Acesso Rápido
- [x] Query trpc.radar.getHistory integrada na página Members
- [x] radarCount passado como stat para a sidebar

### Testes
- [x] 18 testes para RadarHistory (data structure, score colors, comparison, sidebar, labels, evolution chart)
- [x] 188 testes totais passando (22 arquivos)


## Fase 57 - Exportar Comparação de Diagnósticos Radar em PDF

### Relatório PDF Comparativo
- [x] Botão "Exportar PDF" no modo de comparação quando 2 diagnósticos estão selecionados
- [x] Geração de HTML formatado com identidade visual Data CX para impressão/PDF
- [x] Gráfico radar SVG comparativo (sobreposição dos 2 diagnósticos) no PDF
- [x] Tabela de comparação por dimensão com variação (↑/↓) e cores
- [x] Resumo com dados do aluno, datas, níveis recomendados e scores totais
- [x] Seção de evolução com indicadores visuais de melhoria/piora
- [x] Botão de exportar PDF também disponível nos cards expandidos individuais
- [x] Testes unitários para a lógica de geração do PDF comparativo


## Bug Fix - Títulos dos Cards de Módulos Conflitando

- [x] Corrigir sobreposição dos títulos com as imagens de capa nos cards de módulos na Área de Membros
- [x] Garantir que título, código, duração e badge sejam legíveis sobre a imagem

- [x] Remover badge de pilar (Intro, CX, etc.) sobre a thumbnail dos cards de módulos (já está na imagem de capa)


## Fase 58 - Campo de Desafios no Radar Vértice
- [x] Adicionar campo de texto aberto ao final do Radar para descrever desafios
- [x] Salvar o texto no banco de dados (coluna challenges na tabela radarLeads)
- [x] Exibir os desafios no resultado do diagnóstico, histórico, PDF e painel Admin
- [x] Incluir desafios no prompt da análise IA para personalizar recomendações
- [x] Incluir desafios na notificação ao owner (novo lead)
- [x] Testes unitários para o novo campo (211 testes passando)

## Fase 59 - Melhorias no Campo de Desafios do Radar

### Checkboxes de Desafios Comuns
- [x] Adicionar checkboxes com desafios pré-definidos antes do textarea
- [x] Opções: Falta de dados estruturados, Equipe sem capacitação em CX, Dificuldade em medir ROI, etc. (10 opções)
- [x] Checkboxes preenchem/complementam o textarea automaticamente
- [x] Manter textarea livre para complemento

### Filtro por Desafios no Admin
- [x] Campo de busca por palavras-chave nos desafios na aba Leads
- [x] Exibir texto completo dos desafios ao expandir/clicar no lead (Dialog de detalhes)
- [x] Filtro funcional com busca em tempo real

### Teste de Fluxo Completo
- [x] Testar diagnóstico completo no browser com campo de desafios preenchido
- [x] Verificar se análise IA menciona os desafios descritos (confirmado: IA referencia dados dispersos, CRM, sistemas legados)

## Fase 60 - Segmentação Automática de Leads e Nurture por Desafio

### Schema e Categorização
- [x] Definir categorias de segmento baseadas nos 10 desafios (5 categorias: dados, cx, ia, governanca, cultura)
- [x] Criar lógica de categorização automática ao submeter o Radar (shared/challengeSegments.ts)
- [x] Salvar segmentos/tags no lead ao criar (challengeSegment + challengeSegments)

### Nurture Emails por Desafio
- [x] Criar templates de email específicos por categoria de desafio (nurtureSubject + nurtureContent por segmento)
- [x] Implementar disparo automático de nurture email após submissão do Radar (createNurtureSequence personalizado)
- [x] Email personalizado com conteúdo relevante ao desafio do lead (steps 2 e 3 segmentados)

### UI Admin para Segmentos
- [x] Visualizar distribuição de leads por segmento/desafio no Admin (cards com barras de progresso)
- [x] Filtrar leads por segmento (clique no card filtra a tabela)
- [x] Permitir disparo manual de nurture por segmento (botão Nurture em cada card)

### Testes
- [x] Testes unitários para categorização e disparo de nurture (215 testes passando)

## Fase 61 - Dashboard Temporal, Checkboxes por Persona e WhatsApp Follow-up

###### Dashboard de Evolução Temporal de Segmentos
- [x] Criar query getSegmentTrends com GROUP BY mês/segmento (últimos 6 meses)
- [x] Gráfico de linhas Recharts com cores por segmento no Admin
- [x] Indicadores visuais de tendência por segmento
### Checkboxes de Desafios por Persona
- [x] Definir desafios específicos para cada persona (Jovem, Gestor, Executivo, Empresário)
- [x] getChallengesForPersona() em shared/challengeSegments.ts
- [x] RadarVertice renderiza checkboxes dinâmicos baseados na persona selecionada
- [x] Compatibilidade total com segmentação existente
### Automação de Follow-up por WhatsApp
- [x] Webhook Make.com enriquecido com segmento, desafios e consentWhatsapp
- [x] Procedure sendWhatsappFollowup para disparo por segmento ou leads individuais
- [x] Botão WhatsApp nos cards de segmento e no Dialog de detalhes do lead
- [x] Checkbox de consentimento WhatsApp no formulário + campo consentWhatsapp no banco
### Testes
- [x] Testes unitários para todas as funcionalidades (221 testes passando)

## Fase 62 - Jornada de Acompanhamento, Spaces, Relatório Semanal e Make.com

### Spaces por Coorte na Comunidade
- [x] Adicionar campo space ao schema communityPosts
- [x] Criar tabs de Spaces na Comunidade: Geral, Jovens, Gestores, Executivos, Empresas
- [x] Filtrar posts por space selecionado (query parametrizada)
- [x] Posts criados dentro de um space ficam associados ao space

### Painel de Jornada (Mentoria/Consultoria) na Área de Membros
- [x] Criar tabelas projectStages e stageDeliverables no schema
- [x] CRUD completo de stages e deliverables (db.ts + routers.ts)
- [x] Tab "Jornada" como tab padrão no Workspace de Consultoria
- [x] Timeline visual com etapas, barra de progresso e status
- [x] Cada etapa mostra: status, descrição, documentos/deliverables
- [x] Upload de deliverables pelo admin com download pelo aluno
- [x] Próximos passos visíveis (próxima etapa pendente destacada)
- [x] Integração com Workspace existente (milestones, tasks, docs nas outras tabs)

### Relatório Semanal Automático ao Owner
- [x] Criar weeklyReport.ts com getWeeklyMetrics() e sendWeeklyReport()
- [x] Cron job a cada hora verifica se é segunda-feira 9h para enviar
- [x] Enviar via notifyOwner com métricas resumidas
- [x] Inclui: novos leads, usuários, projetos ativos, posts, segmentos, top desafios
- [x] Procedure sendWeeklyReport no Admin para disparo manual

### Documentação Cenário Make.com para WhatsApp
- [x] Guia passo a passo em docs/make-whatsapp-setup.md
- [x] Payload documentado para new_radar_lead e whatsapp_nurture
- [x] Templates de mensagem WhatsApp por segmento (5 segmentos)
- [x] Instruções para WhatsApp Business API e Cloud API

### Testes
- [x] 221 testes passando (22 arquivos de teste)

## Fase 63 - Dashboard de Progresso do Aluno na Área de Membros
- [x] Query getStudentJourneyDashboard com métricas consolidadas (projetos, stages, deliverables, milestones, tasks)
- [x] Procedure consulting.journeyDashboard protegida no tRPC
- [x] Componente JornadaDashboard integrado na seção "jornada-consultoria" do Members.tsx
- [x] Anel de progresso geral + 6 cards de métricas (projetos, etapas, tarefas, marcos, entregas, concluídos)
- [x] Cards de projeto expansíveis com barra de progresso e timeline de etapas
- [x] Seção "Próximos Prazos" com deadlines dos próximos 30 dias (urgente/alerta/normal)
- [x] Seção "Atividade Recente" com histórico de ações
- [x] Próxima etapa destacada com tarefas pendentes
- [x] Marcos do projeto em grid visual
- [x] Item "Minha Jornada" no MembersSidebar com badge "Novo"
- [x] Estado vazio amigável com CTA para Ver Programas
- [x] Link para Workspace completo em cada projeto
- [x] 221 testes passando (22 arquivos)

## Fase 64 - Gestão Completa da Jornada (Admin/Membro)

### Schema e Backend
- [x] Tabela stage_contents (conteúdos por etapa: documentos, vídeos, links, textos, áudio)
- [x] Tabela stage_checklist_items (itens de checklist por etapa)
- [x] Tabela stage_checklist_progress (progresso do membro nos checklists)
- [x] Tabela stage_comments (comentários/dúvidas por etapa)
- [x] Tabela stage_member_progress (progresso do membro por etapa: not_started, in_progress, completed)
- [x] Procedures CRUD para conteúdos de etapa (admin)
- [x] Procedures CRUD para checklist items (admin)
- [x] Procedures para interações do membro (toggle checklist, comentar, atualizar progresso)
- [x] Procedure getFullStageDetail com conteúdos, checklist, comentários e progresso
- [x] Procedure allProjectsWithStages (admin)
- [x] Procedure uploadStageFile para upload de documentos via base64/S3

### UI Admin
- [x] Criar/editar/excluir etapas com formulário completo (título, descrição, conteúdo markdown, vídeo, status, prazo)
- [x] Adicionar conteúdos por etapa (documentos para download, vídeos, links, textos, áudio)
- [x] Adicionar checklist items por etapa
- [x] Toggle "Ver como Membro" para simular experiência do aluno
- [x] Visualizar comentários/dúvidas dos membros por etapa
- [x] Upload de documentos/arquivos via S3

### UI Membro
- [x] Visualizar jornada com etapas e conteúdos interativos
- [x] Download de documentos/arquivos por etapa
- [x] Checklist interativo que o membro marca como concluído
- [x] Campo de comentários/dúvidas por etapa
- [x] Status de conclusão por etapa com progresso visual
- [x] Botões Iniciar/Concluir/Reabrir etapa

### Testes
- [x] Testes unitários para Jornada (243 testes passando, 23 arquivos)

## Fase 65 - Melhorias na Jornada: Notificações, Drag-and-Drop e Desbloqueio Automático

### Notificações ao Admin
- [x] Disparar notifyOwner quando membro posta comentário/dúvida em etapa da Jornada
- [x] Incluir nome do membro, nome do projeto, nome da etapa e trecho do comentário na notificação

### Reordenação de Etapas por Drag-and-Drop
- [x] Instalar biblioteca de drag-and-drop (@dnd-kit/core, @dnd-kit/sortable, @dnd-kit/utilities)
- [x] Implementar drag-and-drop visual na lista de etapas (visão Admin)
- [x] Criar procedure reorderStages para atualizar sortOrder das etapas no backend
- [x] Persistir nova ordem no banco de dados

### Desbloqueio Automático de Etapas
- [x] Ao concluir uma etapa, desbloquear automaticamente a próxima (locked → available)
- [x] Lógica no backend (procedure updateMemberProgress) para detectar conclusão e desbloquear
- [x] Feedback visual no frontend quando etapa é desbloqueada (toast com ícone Unlock)

### Testes
- [x] Testes unitários para notificação, reordenação e desbloqueio automático (248 testes passando, 23 arquivos)
