#!/usr/bin/env python3
"""
Fix 3 short audio versions by regenerating their audio scripts and audio files.
"""
import asyncio
import os
import sys
import tempfile
import time
import json
import requests

sys.path.append('/opt/.manus/.sandbox-runtime')
import edge_tts
import mysql.connector
from urllib.parse import urlparse, parse_qs

VOICE_CONFIG = {
    "jovem": {"voice": "pt-BR-AntonioNeural", "rate": "-3%", "pitch": "+0Hz"},
    "gestor": {"voice": "pt-BR-AntonioNeural", "rate": "-5%", "pitch": "-1Hz"},
    "executivo": {"voice": "pt-BR-AntonioNeural", "rate": "-7%", "pitch": "-2Hz"},
    "empresario": {"voice": "pt-BR-AntonioNeural", "rate": "-5%", "pitch": "-1Hz"},
}

PERSONA_LABELS = {
    "jovem": "Jovem Profissional (18-26 anos)",
    "gestor": "Gestor de Área (coordenador, gerente, supervisor)",
    "executivo": "Executivo C-Level (diretor, VP, C-suite)",
    "empresario": "Empresário/Dono de Negócio (PME ou scale-up)",
}

PERSONA_TONES = {
    "jovem": "Leve, direto, com gírias profissionais e referências pop. Motivacional.",
    "gestor": "Prático, orientado a resultados, com frameworks aplicáveis. Direto ao ponto.",
    "executivo": "Estratégico, conciso, com visão de board. Dados e ROI.",
    "empresario": "Pragmático, focado em crescimento e rentabilidade. Cases de PME.",
}

# Versions to fix
VERSIONS_TO_FIX = [
    {"id": 30176, "contentId": 30053, "moduleCode": "AI-P05", "persona": "empresario"},
    {"id": 30111, "contentId": 30036, "moduleCode": "D-P06", "persona": "executivo"},
    {"id": 30058, "contentId": 30022, "moduleCode": "CX-S04", "persona": "gestor"},
]

def get_db_connection():
    url = os.environ.get("DATABASE_URL", "")
    parsed = urlparse(url)
    ssl_config = {}
    qs = parse_qs(parsed.query)
    if 'ssl-mode' in qs or 'sslaccept' in qs:
        ssl_config = {"ssl_disabled": False}
    return mysql.connector.connect(
        host=parsed.hostname,
        port=parsed.port or 3306,
        user=parsed.username,
        password=parsed.password,
        database=parsed.path.lstrip('/'),
        **ssl_config
    )

def upload_to_s3(file_path, s3_key):
    forge_url = os.environ.get("BUILT_IN_FORGE_API_URL", "").rstrip("/")
    forge_key = os.environ.get("BUILT_IN_FORGE_API_KEY", "")
    upload_url = f"{forge_url}/v1/storage/upload?path={s3_key}"
    with open(file_path, "rb") as f:
        files = {"file": (os.path.basename(file_path), f, "audio/mpeg")}
        headers = {"Authorization": f"Bearer {forge_key}"}
        resp = requests.post(upload_url, files=files, headers=headers)
    if resp.status_code != 200:
        raise Exception(f"Upload failed: {resp.status_code} {resp.text}")
    return resp.json().get("url", "")

def generate_audio_script_via_llm(module_title, apostila_markdown, persona, pilar):
    """Generate audio script using the built-in LLM API"""
    forge_url = os.environ.get("BUILT_IN_FORGE_API_URL", "").rstrip("/")
    forge_key = os.environ.get("BUILT_IN_FORGE_API_KEY", "")
    
    label = PERSONA_LABELS[persona]
    tone = PERSONA_TONES[persona]
    
    duration_guide = {
        "executivo": "6 a 9 minutos (aproximadamente 900-1350 palavras)",
        "jovem": "9 a 13 minutos (aproximadamente 1350-1950 palavras)",
    }.get(persona, "8 a 12 minutos (aproximadamente 1200-1800 palavras)")
    
    system_prompt = f"""Você é Daniel, narrador oficial da plataforma Data CX Mentoria. Seu estilo é de "mentor em sala de guerra" — conversacional, executivo, firme e prático. Crie um roteiro de narração para ser convertido em áudio TTS.

IDENTIDADE DO NARRADOR DANIEL:
- Tom: conversacional-executivo. Direto, claro, sem formalidade excessiva.
- Estilo: como se estivesse em uma sala de guerra com o aluno, compartilhando conhecimento de forma prática.
- Pode usar expressões naturais do Samuel Rosa: "Vamos ao que interessa", "Na prática funciona assim", "Sem achismo".
- Humanizado e leve, mas com autoridade. Nunca robótico.

REGRAS DO ROTEIRO:
- Duração alvo: {duration_guide}
- Escreva como se estivesse FALANDO diretamente com o aluno. Use linguagem oral natural.
- Use pausas naturais com vírgulas e pontos. Frases de transição suaves.
- Evite referências visuais ("como você pode ver", "no gráfico abaixo").
- NÃO inclua marcações de roteiro ([PAUSA], [MÚSICA], etc.). Apenas o texto a ser narrado.
- Inclua respirações naturais entre seções.
- O roteiro DEVE ter no mínimo 1200 palavras para garantir duração adequada.

ESTRUTURA OBRIGATÓRIA:
1. Abertura (20 segundos): "Fala, [persona]! Aqui é o Daniel, da Data CX..." + promessa do módulo
2. Ponto 1: Conceito principal com exemplo prático e contextualizado
3. Ponto 2: Framework ou método aplicável (explicado de forma conversacional)
4. Ponto 3: Insight avançado ou dica de implementação
5. Mini-case narrado (versão curta, envolvente, com números)
6. Fechamento: Próximo passo, exercício recomendado e motivação

PERSONA: {label}
TOM: {tone}

Retorne APENAS o texto do roteiro, sem meta-instruções. Comece direto com a abertura."""

    user_prompt = f"""Crie o roteiro de áudio narrado por Daniel para o módulo "{module_title}" (pilar: {pilar}) baseado nesta apostila:

{apostila_markdown[:8000]}"""

    url = f"{forge_url}/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {forge_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "max_tokens": 8000,
    }
    
    resp = requests.post(url, json=payload, headers=headers, timeout=120)
    if resp.status_code != 200:
        raise Exception(f"LLM API error: {resp.status_code} {resp.text}")
    
    data = resp.json()
    return data["choices"][0]["message"]["content"]

async def generate_audio(text, voice_cfg, output_path):
    communicate = edge_tts.Communicate(
        text=text,
        voice=voice_cfg["voice"],
        rate=voice_cfg["rate"],
        pitch=voice_cfg["pitch"],
    )
    await communicate.save(output_path)
    file_size = os.path.getsize(output_path)
    estimated_duration = file_size / 6000
    return estimated_duration

async def main():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    for v in VERSIONS_TO_FIX:
        print(f"\n{'='*60}")
        print(f"Fixing {v['moduleCode']} - {v['persona']} (ID={v['id']})")
        print(f"{'='*60}")
        
        # Get apostila and module info
        cursor.execute("""
            SELECT cpv.apostilaMarkdown, c.title, c.pilar
            FROM content_persona_versions cpv
            JOIN contents c ON c.id = cpv.contentId
            WHERE cpv.id = %s
        """, (v["id"],))
        row = cursor.fetchone()
        
        if not row:
            print(f"  ERROR: Version not found!")
            continue
        
        # Step 1: Regenerate audio script via LLM
        print(f"  1. Generating audio script via LLM...")
        try:
            new_script = generate_audio_script_via_llm(
                row["title"], row["apostilaMarkdown"], v["persona"], row["pilar"]
            )
            print(f"     Script generated: {len(new_script)} chars ({len(new_script.split())} words)")
        except Exception as e:
            print(f"     ERROR generating script: {e}")
            continue
        
        # Step 2: Generate audio via edge-tts
        print(f"  2. Generating audio via edge-tts...")
        voice_cfg = VOICE_CONFIG[v["persona"]]
        
        with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp:
            tmp_path = tmp.name
        
        try:
            duration = await generate_audio(new_script, voice_cfg, tmp_path)
            file_size = os.path.getsize(tmp_path)
            print(f"     Audio: {file_size/1024:.0f}KB, ~{duration:.0f}s")
        except Exception as e:
            print(f"     ERROR generating audio: {e}")
            os.unlink(tmp_path)
            continue
        
        # Step 3: Upload to S3
        print(f"  3. Uploading to S3...")
        try:
            s3_key = f"audio/modules/{v['moduleCode']}-{v['persona']}-{int(time.time())}.mp3"
            audio_url = upload_to_s3(tmp_path, s3_key)
            print(f"     URL: {audio_url[:80]}...")
        except Exception as e:
            print(f"     ERROR uploading: {e}")
            os.unlink(tmp_path)
            continue
        
        # Step 4: Update DB
        print(f"  4. Updating database...")
        cursor.execute("""
            UPDATE content_persona_versions 
            SET audioScriptAdmin = %s, audioUrl = %s, audioDurationSeconds = %s, audioStatus = 'ready'
            WHERE id = %s
        """, (new_script, audio_url, int(duration), v["id"]))
        conn.commit()
        
        os.unlink(tmp_path)
        print(f"  DONE! New duration: ~{duration:.0f}s")
    
    conn.close()
    print(f"\n{'='*60}")
    print("All fixes complete!")

asyncio.run(main())
