import mysql from 'mysql2/promise';

// URLs dos PDFs
const dataStorytelling = 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/zbvdNIjwlmVcgfJG.pdf';
const cxCap1 = 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/zDdVQbmaKqdZYMld.pdf';
const cxCap2 = 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/MCZlPZkZOVugCiVp.pdf';
const cxCap3 = 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/UNeaYFwvunuVLwju.pdf';
const cxCap4 = 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/gVNofKSDWZioEZFT.pdf';
const cxCap5 = 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/MxrVBevjaUrIcwtP.pdf';

async function main() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  
  console.log('Atualizando TODOS os conteúdos com URLs dos PDFs...');
  
  // Atualizar todos os conteúdos que ainda não têm URL
  // Data Storytelling para conteúdos de Dados
  await connection.execute(
    `UPDATE contents SET fileUrl = ? WHERE fileUrl IS NULL OR fileUrl = ''`,
    [dataStorytelling]
  );
  
  // Agora atualizar específicos por tema
  // Metodologias Ágeis, Scrum, Kanban, OKRs - usar Data Storytelling
  await connection.execute(
    `UPDATE contents SET fileUrl = ? WHERE title LIKE '%Metodologias%' OR title LIKE '%Scrum%' OR title LIKE '%Kanban%' OR title LIKE '%OKR%'`,
    [dataStorytelling]
  );
  
  // CX - Fundamentos
  await connection.execute(
    `UPDATE contents SET fileUrl = ? WHERE title LIKE '%Customer Experience%' OR title LIKE '%Fundamentos de CX%'`,
    [cxCap1]
  );
  
  // Jornada do Cliente
  await connection.execute(
    `UPDATE contents SET fileUrl = ? WHERE title LIKE '%Jornada%'`,
    [cxCap2]
  );
  
  // Neuromarketing
  await connection.execute(
    `UPDATE contents SET fileUrl = ? WHERE title LIKE '%Neuromarketing%' OR title LIKE '%Processo de Decisão%'`,
    [cxCap3]
  );
  
  // CRM
  await connection.execute(
    `UPDATE contents SET fileUrl = ? WHERE title LIKE '%CRM%'`,
    [cxCap4]
  );
  
  // Métricas
  await connection.execute(
    `UPDATE contents SET fileUrl = ? WHERE title LIKE '%Métricas%' OR title LIKE '%NPS%' OR title LIKE '%CSAT%'`,
    [cxCap5]
  );
  
  // Verificar resultado
  const [rows] = await connection.execute('SELECT COUNT(*) as total FROM contents WHERE fileUrl IS NOT NULL AND fileUrl != ""');
  console.log('Total de conteúdos com URLs:', rows[0].total);
  
  const [empty] = await connection.execute('SELECT COUNT(*) as total FROM contents WHERE fileUrl IS NULL OR fileUrl = ""');
  console.log('Conteúdos sem URL:', empty[0].total);
  
  await connection.end();
  console.log('Atualização concluída!');
}

main().catch(console.error);
