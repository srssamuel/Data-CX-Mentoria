#!/usr/bin/env python3
"""
Gera 600 questões de quiz reais (60 módulos × 10 questões) usando OpenAI gpt-4.1-mini.
Usa a apostila executivo de cada módulo como contexto.
"""

import os
import sys
import json
import time
import mysql.connector
from openai import OpenAI

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
DATABASE_URL = os.environ.get("DATABASE_URL")
MODEL = "gpt-4.1-mini"

client = OpenAI(api_key=OPENAI_API_KEY)

def get_db_connection():
    url = DATABASE_URL.replace("mysql://", "")
    if "?" in url:
        url = url.split("?")[0]
    userpass, hostdb = url.split("@")
    user, password = userpass.split(":")
    hostport, db = hostdb.split("/")
    host, port = hostport.split(":")
    return mysql.connector.connect(
        host=host, port=int(port), user=user, password=password,
        database=db, ssl_disabled=False, ssl_verify_cert=False
    )

def get_all_modules(conn):
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT q.id as quizId, q.moduleCode, q.title as quizTitle, q.contentId,
               c.title as moduleTitle
        FROM quizzes q
        JOIN contents c ON c.id = q.contentId
        ORDER BY q.moduleCode
    """)
    quizzes = cursor.fetchall()
    
    for quiz in quizzes:
        cursor.execute("""
            SELECT SUBSTRING(apostilaMarkdown, 1, 3000) as apostila
            FROM content_persona_versions
            WHERE contentId = %s AND persona = 'executivo'
            LIMIT 1
        """, (quiz['contentId'],))
        row = cursor.fetchone()
        quiz['apostila'] = row['apostila'] if row else ''
    
    cursor.close()
    return quizzes

def generate_quiz_questions(module_code, module_title, apostila_preview):
    prompt = f"""Você é um especialista em educação corporativa da Data CX Mentoria.
Gere exatamente 10 questões de múltipla escolha para o módulo "{module_code}: {module_title}".

CONTEXTO DO MÓDULO:
{apostila_preview}

Retorne um JSON com chave "questions" contendo array de 10 objetos com:
- question: texto da pergunta
- options: array de 4 objetos {{"id": "A"/"B"/"C"/"D", "text": texto, "isCorrect": true/false}}
- explanation: explicação da resposta correta

Regras: alternativas específicas ao módulo, 1 correta por questão, dificuldade progressiva."""

    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role": "system", "content": "Gere questões de quiz educacional em JSON."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=8000,
            response_format={"type": "json_object"}
        )
        
        content = response.choices[0].message.content.strip()
        data = json.loads(content)
        
        # Extract questions array
        questions = []
        if isinstance(data, dict):
            for key, val in data.items():
                if isinstance(val, list) and len(val) > 0:
                    questions = val
                    break
        elif isinstance(data, list):
            questions = data
        
        # Validate each question
        valid_questions = []
        for q in questions[:10]:
            if not isinstance(q, dict):
                continue
            if "question" not in q or "options" not in q:
                continue
            opts = q["options"]
            if not isinstance(opts, list) or len(opts) != 4:
                continue
            # Ensure exactly one correct
            correct_count = sum(1 for o in opts if o.get("isCorrect", False))
            if correct_count == 0:
                opts[0]["isCorrect"] = True
            elif correct_count > 1:
                first_found = False
                for o in opts:
                    if o.get("isCorrect", False):
                        if first_found:
                            o["isCorrect"] = False
                        else:
                            first_found = True
            valid_questions.append(q)
        
        usage = response.usage
        cost = (usage.prompt_tokens * 0.40 + usage.completion_tokens * 1.60) / 1_000_000
        
        return valid_questions, cost, usage.prompt_tokens, usage.completion_tokens
        
    except Exception as e:
        print(f"  ERRO: {e}")
        return [], 0, 0, 0

def update_quiz_in_db(conn, quiz_id, questions):
    cursor = conn.cursor()
    cursor.execute("DELETE FROM quiz_questions WHERE quizId = %s", (quiz_id,))
    
    for i, q in enumerate(questions):
        cursor.execute("""
            INSERT INTO quiz_questions (quizId, question, type, options, explanation, points, sortOrder, createdAt)
            VALUES (%s, %s, 'multiple_choice', %s, %s, 10, %s, NOW())
        """, (
            quiz_id,
            q["question"],
            json.dumps(q["options"], ensure_ascii=False),
            q.get("explanation", ""),
            i + 1
        ))
    
    conn.commit()
    cursor.close()

def main():
    print("=" * 60)
    print("GERAÇÃO DE QUIZZES REAIS - Data CX Mentoria")
    print(f"Modelo: {MODEL}")
    print("=" * 60)
    
    conn = get_db_connection()
    modules = get_all_modules(conn)
    print(f"Total de módulos: {len(modules)}")
    
    total_cost = 0
    total_input = 0
    total_output = 0
    success_count = 0
    error_count = 0
    
    for i, mod in enumerate(modules):
        module_code = mod['moduleCode']
        quiz_id = mod['quizId']
        title = mod['moduleTitle']
        apostila = mod.get('apostila', '')
        
        if not apostila:
            print(f"\n[{i+1}/60] {module_code} - SEM APOSTILA, pulando...")
            error_count += 1
            continue
        
        print(f"\n[{i+1}/60] {module_code}: {title[:50]}")
        
        questions, cost, inp, out = generate_quiz_questions(module_code, title, apostila)
        
        if len(questions) >= 5:
            update_quiz_in_db(conn, quiz_id, questions)
            total_cost += cost
            total_input += inp
            total_output += out
            success_count += 1
            print(f"  ✓ {len(questions)} questões | ${cost:.4f}")
        else:
            print(f"  ✗ Apenas {len(questions)} questões, retry...")
            time.sleep(2)
            questions, cost, inp, out = generate_quiz_questions(module_code, title, apostila)
            if len(questions) >= 5:
                update_quiz_in_db(conn, quiz_id, questions)
                total_cost += cost
                total_input += inp
                total_output += out
                success_count += 1
                print(f"  ✓ Retry OK: {len(questions)} questões | ${cost:.4f}")
            else:
                error_count += 1
                print(f"  ✗ Retry falhou ({len(questions)} questões)")
        
        if (i + 1) % 10 == 0:
            print(f"\n--- {i+1}/60 | ${total_cost:.4f} | OK:{success_count} ERR:{error_count} ---")
            time.sleep(1)
        else:
            time.sleep(0.3)
    
    conn.close()
    
    print("\n" + "=" * 60)
    print(f"RESULTADO: {success_count}/60 OK | {error_count} erros")
    print(f"Tokens: {total_input:,} in + {total_output:,} out")
    print(f"Custo: ${total_cost:.4f} (~R${total_cost * 6:.2f})")
    print("=" * 60)

if __name__ == "__main__":
    main()
