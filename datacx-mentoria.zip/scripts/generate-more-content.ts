import { drizzle } from "drizzle-orm/mysql2";
import { contents } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { storagePut } from "../server/storage";

const db = drizzle(process.env.DATABASE_URL!);

const moreContents = [
  {
    id: 3,
    title: "Dados, Informação e Insight: A Pirâmide do Conhecimento",
    content: `# Dados, Informação e Insight: A Pirâmide do Conhecimento

## Transformando Ruído em Decisões Estratégicas

No mundo corporativo, somos bombardeados por dados o tempo todo. Mas poucos profissionais sabem transformar esse oceano de números em decisões que movem o negócio.

### A Pirâmide DIKI

A Pirâmide do Conhecimento (DIKI - Data, Information, Knowledge, Insight) é o framework fundamental para qualquer profissional que trabalha com dados:

**Nível 1: DADOS (Data)**
- Fatos brutos, sem processamento
- Números isolados, sem contexto
- Exemplo: "1.247 chamados no call center ontem"

**Nível 2: INFORMAÇÃO (Information)**
- Dados organizados e contextualizados
- Responde: Quem? O quê? Quando? Onde?
- Exemplo: "1.247 chamados, 40% acima da média, concentrados entre 14h-16h"

**Nível 3: CONHECIMENTO (Knowledge)**
- Informação processada e compreendida
- Responde: Por quê?
- Exemplo: "O pico de chamados coincide com o horário de entrega de pedidos da nova campanha"

**Nível 4: INSIGHT**
- Conhecimento que gera ação específica
- Responde: E agora?
- Exemplo: "Precisamos reforçar o time de atendimento entre 14h-16h durante campanhas promocionais"

### O Erro Comum

A maioria das empresas para no nível 2 (Informação). Criam dashboards cheios de números, relatórios extensos, mas nunca chegam ao insight que gera ação.

**Sintomas de que você está preso no nível 2:**
- Reuniões onde todos olham números mas ninguém decide nada
- Relatórios que são enviados mas nunca lidos
- KPIs que são medidos mas nunca melhoram
- Dados que impressionam mas não transformam

### Como Escalar a Pirâmide

**De Dados para Informação:**
- Organize cronologicamente
- Compare com benchmarks
- Segmente por categorias relevantes

**De Informação para Conhecimento:**
- Pergunte "Por quê?" repetidamente
- Cruze com outras fontes de dados
- Busque padrões e correlações

**De Conhecimento para Insight:**
- Defina a ação específica
- Quantifique o impacto esperado
- Estabeleça responsáveis e prazos

### Exercício Protocolo Vértice

Pegue um KPI da sua área e escale a pirâmide:

1. Qual é o dado bruto?
2. Que contexto transforma em informação?
3. Qual análise gera conhecimento?
4. Que ação específica é o insight?

> "Não seja um colecionador de dados. Seja um gerador de insights."
> — Protocolo Vértice
`
  },
  {
    id: 4,
    title: "Módulo 2: Métodos de Coleta de Dados",
    content: `# Módulo 2: Métodos de Coleta de Dados

## Coletando os Dados Certos da Forma Certa

A qualidade do seu Data Storytelling depende diretamente da qualidade dos dados coletados. Dados ruins geram histórias ruins — e decisões piores ainda.

### Os 3 Tipos de Coleta de Dados

**1. Coleta Contínua**
- Dados coletados automaticamente, em tempo real
- Exemplos: analytics de site, logs de sistema, sensores IoT
- Vantagem: Visão completa do comportamento
- Desafio: Volume massivo de dados

**2. Coleta Periódica**
- Dados coletados em intervalos regulares
- Exemplos: pesquisas mensais de NPS, relatórios trimestrais
- Vantagem: Comparabilidade ao longo do tempo
- Desafio: Pode perder eventos importantes entre coletas

**3. Coleta Ocasional**
- Dados coletados para projetos específicos
- Exemplos: pesquisas de mercado, focus groups, entrevistas
- Vantagem: Profundidade e contexto
- Desafio: Custo e tempo elevados

### Pesquisa Quantitativa vs Qualitativa

**Quantitativa (O QUÊ e QUANTO)**
- Números, estatísticas, métricas
- Amostra grande
- Análise estatística
- Responde: "Quantos clientes estão insatisfeitos?"

**Qualitativa (POR QUÊ e COMO)**
- Opiniões, percepções, motivações
- Amostra pequena, profunda
- Análise de conteúdo
- Responde: "Por que os clientes estão insatisfeitos?"

**A Combinação Ideal:**
Use quantitativo para identificar ONDE está o problema.
Use qualitativo para entender POR QUÊ existe o problema.

### Framework de Coleta Protocolo Vértice

**Passo 1: Defina o Objetivo**
- Que decisão você quer tomar?
- Que pergunta precisa responder?

**Passo 2: Escolha o Método**
- Contínuo para monitoramento
- Periódico para tendências
- Ocasional para profundidade

**Passo 3: Desenhe a Coleta**
- Amostra representativa
- Perguntas claras e objetivas
- Evite vieses

**Passo 4: Execute e Valide**
- Teste piloto
- Verifique qualidade dos dados
- Documente metodologia

### Erros Comuns na Coleta

1. **Viés de confirmação** — Coletar apenas dados que confirmam sua hipótese
2. **Amostra enviesada** — Ouvir apenas clientes satisfeitos (ou insatisfeitos)
3. **Perguntas direcionadas** — "Você concorda que nosso produto é excelente?"
4. **Ignorar contexto** — Números sem entender o cenário

> "Dados de qualidade são como ingredientes frescos: fazem toda a diferença no resultado final."
> — Protocolo Vértice
`
  },
  {
    id: 7,
    title: "Módulo 3: Transformando Dados em Narrativas",
    content: `# Módulo 3: Transformando Dados em Narrativas

## A Arte de Contar Histórias com Números

Ter dados é fácil. Transformá-los em uma narrativa que move pessoas e decisões é uma arte que poucos dominam.

### O Princípio "Show, Don't Tell"

Em vez de DIZER que algo é importante, MOSTRE com dados.

**Ruim:** "Nosso NPS caiu muito"
**Bom:** "Nosso NPS caiu de 45 para 32 em 3 meses — perdemos 13 pontos, o equivalente a 2.300 clientes promotores"

**Ruim:** "Precisamos investir em CX"
**Bom:** "Cada ponto de NPS representa R$ 47.000 em receita anual. Recuperar 13 pontos significa R$ 611.000"

### A Estrutura da Narrativa com Dados

**1. GANCHO (Hook)**
- Capture atenção imediatamente
- Use um dado surpreendente ou provocativo
- "Estamos perdendo R$ 2 milhões por mês sem perceber"

**2. CONTEXTO (Context)**
- Situe a audiência
- Explique de onde vêm os dados
- Estabeleça a linha de base

**3. TENSÃO (Tension)**
- Apresente o problema ou oportunidade
- Mostre a urgência
- Crie necessidade de ação

**4. SOLUÇÃO (Solution)**
- Apresente sua recomendação
- Suporte com dados
- Mostre cenários

**5. CHAMADA À AÇÃO (Call to Action)**
- Seja específico
- Defina próximos passos
- Estabeleça responsáveis e prazos

### Técnicas de Narrativa

**Comparação Temporal**
- "Antes vs Depois"
- "Este ano vs Ano passado"
- Mostra evolução e tendência

**Comparação Espacial**
- "Nós vs Concorrência"
- "Brasil vs Mundo"
- Contextualiza performance

**Analogia**
- Traduz números abstratos em algo tangível
- "R$ 2 milhões é o equivalente a 40 funcionários por ano"

**Personalização**
- Traz o macro para o individual
- "Cada cliente insatisfeito custa R$ 3.200 em lifetime value perdido"

### O Framework 3-2-1

Para qualquer apresentação de dados:

**3 Insights principais** — Não mais que isso
**2 Visualizações de suporte** — Gráficos que comprovam
**1 Ação clara** — O que você quer que façam

> "Dados contam o que aconteceu. Narrativas explicam por que importa."
> — Protocolo Vértice
`
  },
  {
    id: 10,
    title: "Módulo 4: Escolhendo o Visual Eficaz",
    content: `# Módulo 4: Escolhendo o Visual Eficaz

## O Gráfico Certo para Cada Mensagem

Escolher o visual errado pode destruir sua mensagem. O gráfico certo amplifica; o errado confunde.

### Guia Rápido de Visualizações

**COMPARAÇÃO**
- Gráfico de Barras: Comparar categorias
- Gráfico de Barras Empilhadas: Comparar partes do todo
- Bullet Chart: Comparar com meta

**TENDÊNCIA**
- Gráfico de Linha: Evolução ao longo do tempo
- Área: Evolução com ênfase em volume
- Sparklines: Tendência compacta

**COMPOSIÇÃO**
- Pizza: Partes do todo (máximo 5 fatias)
- Treemap: Hierarquia de composição
- Waterfall: Contribuição para resultado

**DISTRIBUIÇÃO**
- Histograma: Frequência de valores
- Box Plot: Distribuição estatística
- Scatter Plot: Correlação entre variáveis

**GEOGRÁFICO**
- Mapa de Calor: Intensidade por região
- Mapa de Bolhas: Volume por localização

### Regras de Ouro

**1. Menos é Mais**
- Remova tudo que não adiciona informação
- Elimine gridlines desnecessárias
- Use cores com propósito

**2. Comece em Zero**
- Gráficos de barra SEMPRE começam em zero
- Gráficos de linha podem ter base ajustada (com aviso)

**3. Cores com Significado**
- Verde = positivo, Vermelho = negativo
- Destaque apenas o que importa
- Máximo 5-7 cores distintas

**4. Títulos que Contam a História**
- Ruim: "NPS por Trimestre"
- Bom: "NPS Caiu 13 Pontos no Q3 — Pior Resultado em 2 Anos"

**5. Anotações Estratégicas**
- Destaque pontos importantes
- Explique anomalias
- Guie o olhar do leitor

### Erros Fatais

1. **Pizza 3D** — Distorce proporções
2. **Muitas séries** — Confunde em vez de esclarecer
3. **Eixo truncado** — Engana o leitor
4. **Cores aleatórias** — Sem significado
5. **Excesso de decoração** — Distrai da mensagem

### Checklist Antes de Apresentar

- [ ] O gráfico responde à pergunta principal?
- [ ] Alguém de fora entenderia em 5 segundos?
- [ ] As cores têm significado consistente?
- [ ] O título conta a história?
- [ ] Removi tudo que não é essencial?

> "Um bom gráfico é como uma boa piada: se você precisa explicar, não funcionou."
> — Protocolo Vértice
`
  },
  {
    id: 14,
    title: "Módulo 5: Pitch - Sua Ideia Cronometrada",
    content: `# Módulo 5: Pitch - Sua Ideia Cronometrada

## Convencendo em Minutos (ou Segundos)

Você tem 3 minutos com o CEO. Ou 30 segundos no elevador. Como transmitir uma ideia complexa de forma que gere ação?

### O Que é um Pitch?

Pitch é a arte de apresentar uma ideia de forma concisa, convincente e acionável. Não é um resumo — é uma versão otimizada para persuasão.

### Os 4 Passos do Pitch Perfeito

**1. GANCHO (10% do tempo)**
- Capture atenção imediatamente
- Use um dado surpreendente ou pergunta provocativa
- "Estamos deixando R$ 2 milhões na mesa todo mês"

**2. PROBLEMA (30% do tempo)**
- Descreva a dor claramente
- Quantifique o impacto
- Crie urgência
- "Nosso churn aumentou 40% porque clientes não conseguem resolver problemas no primeiro contato"

**3. SOLUÇÃO (40% do tempo)**
- Apresente sua proposta
- Mostre evidências de que funciona
- Seja específico sobre implementação
- "Implementando um sistema de triagem inteligente, podemos aumentar FCR de 45% para 75%"

**4. CHAMADA À AÇÃO (20% do tempo)**
- Peça algo específico
- Defina próximo passo concreto
- "Preciso de aprovação para um piloto de 30 dias com a equipe de São Paulo"

### Adaptando o Pitch ao Tempo

**Pitch de 30 segundos (Elevador)**
- 1 frase de gancho
- 1 frase de problema
- 1 frase de solução
- 1 frase de pedido

**Pitch de 3 minutos**
- 20 segundos de gancho
- 50 segundos de problema
- 70 segundos de solução
- 40 segundos de chamada à ação

**Pitch de 10 minutos**
- Estrutura completa com dados de suporte
- Espaço para perguntas
- Backup slides para objeções

### O Case do Airbnb

O pitch original do Airbnb é um exemplo clássico:

**Gancho:** "Hotéis custam caro e são impessoais"
**Problema:** "Viajantes querem experiências autênticas a preços acessíveis"
**Solução:** "Conectamos viajantes a anfitriões locais"
**Prova:** "Já temos X reservas e Y% de crescimento"
**Pedido:** "Precisamos de $X para escalar"

### Erros Comuns

1. **Começar com contexto** — Perde a audiência antes de chegar ao ponto
2. **Muitos dados** — Confunde em vez de convencer
3. **Sem pedido claro** — Deixa a audiência sem saber o que fazer
4. **Jargão técnico** — Aliena quem decide
5. **Falta de prática** — Parece inseguro

### Exercício Protocolo Vértice

Prepare 3 versões do mesmo pitch:
1. 30 segundos (elevador)
2. 3 minutos (reunião rápida)
3. 10 minutos (apresentação formal)

> "Se você não consegue explicar em 30 segundos, provavelmente não entendeu bem o suficiente."
> — Protocolo Vértice
`
  },
  {
    id: 25,
    title: "Jornada do Cliente: Mapeamento Completo",
    content: `# Jornada do Cliente: Mapeamento Completo

## Visualizando a Experiência de Ponta a Ponta

O mapa de jornada do cliente é uma das ferramentas mais poderosas de CX. Ele transforma a experiência abstrata em algo visual, mensurável e acionável.

### O Que é um Mapa de Jornada?

É uma representação visual de todas as interações que um cliente tem com sua marca, desde o primeiro contato até o pós-venda (e além). Inclui:

- **Etapas** da jornada
- **Pontos de contato** em cada etapa
- **Emoções** do cliente
- **Pontos de dor** e fricção
- **Oportunidades** de melhoria

### As 5 Etapas Universais

**1. CONSCIÊNCIA (Awareness)**
- Cliente descobre que tem um problema/necessidade
- Primeiro contato com sua marca
- Canais: redes sociais, propaganda, indicação

**2. CONSIDERAÇÃO (Consideration)**
- Cliente pesquisa soluções
- Compara alternativas
- Canais: site, reviews, conteúdo

**3. DECISÃO (Decision)**
- Cliente escolhe sua solução
- Processo de compra
- Canais: e-commerce, vendas, checkout

**4. EXPERIÊNCIA (Experience)**
- Cliente usa o produto/serviço
- Onboarding e suporte
- Canais: produto, atendimento, app

**5. FIDELIZAÇÃO (Loyalty)**
- Cliente decide se volta
- Recomendação e advocacy
- Canais: programa de fidelidade, comunidade

### Momentos de Verdade

Em cada jornada, existem "momentos de verdade" — pontos críticos onde a experiência pode ser excepcional ou desastrosa:

**Momento Zero da Verdade (ZMOT)**
- Quando o cliente pesquisa online antes de comprar
- Crítico: reviews, conteúdo, presença digital

**Primeiro Momento da Verdade (FMOT)**
- Primeiro contato com o produto/serviço
- Crítico: embalagem, primeira impressão, onboarding

**Segundo Momento da Verdade (SMOT)**
- Uso contínuo do produto/serviço
- Crítico: qualidade, suporte, consistência

### Como Criar Seu Mapa

**Passo 1: Defina a Persona**
- Quem é o cliente que você está mapeando?
- Quais são suas características, necessidades, comportamentos?

**Passo 2: Liste os Pontos de Contato**
- Todos os canais e interações
- Online e offline
- Diretos e indiretos

**Passo 3: Mapeie as Emoções**
- Como o cliente se sente em cada ponto?
- Use escala: muito insatisfeito → muito satisfeito

**Passo 4: Identifique Pontos de Dor**
- Onde há fricção?
- O que frustra o cliente?

**Passo 5: Priorize Oportunidades**
- Impacto vs Esforço
- Quick wins vs projetos estratégicos

> "Você não pode melhorar o que não consegue ver. O mapa de jornada torna o invisível visível."
> — Protocolo Vértice
`
  }
];

async function generateAndSaveContent(contentData: { id: number; title: string; content: string }) {
  try {
    const fileName = "content_" + contentData.id + "_" + Date.now() + ".md";
    const buffer = Buffer.from(contentData.content, 'utf-8');
    
    const { url } = await storagePut(fileName, buffer, 'text/markdown');
    
    await db.update(contents)
      .set({ 
        fileUrl: url,
        mimeType: 'text/markdown',
        updatedAt: new Date()
      })
      .where(eq(contents.id, contentData.id));
    
    console.log("✅ Conteúdo " + contentData.id + " atualizado: " + contentData.title);
    return true;
  } catch (error) {
    console.error("❌ Erro ao atualizar conteúdo " + contentData.id + ":", error);
    return false;
  }
}

async function main() {
  console.log("🚀 Gerando mais conteúdos autorais...");
  
  for (const content of moreContents) {
    await generateAndSaveContent(content);
  }
  
  console.log("\\n✅ Geração de conteúdos concluída!");
  process.exit(0);
}

main().catch(console.error);
