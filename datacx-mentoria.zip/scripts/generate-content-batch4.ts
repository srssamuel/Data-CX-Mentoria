import { drizzle } from "drizzle-orm/mysql2";
import { contents } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { storagePut } from "../server/storage";

const db = drizzle(process.env.DATABASE_URL!);

const contentsBatch4 = [
  {
    id: 7,
    title: "Fontes de Dados: Primárias vs Secundárias",
    content: `# Fontes de Dados: Primárias vs Secundárias

## Escolhendo a Fonte Certa para Cada Análise

Nem todo dado é igual. Entender a diferença entre fontes primárias e secundárias é fundamental para construir análises confiáveis e tomar decisões acertadas.

### Dados Primários

São dados coletados diretamente por você, para responder sua pergunta específica.

**Características:**
- Coletados em primeira mão
- Específicos para seu objetivo
- Controle total sobre metodologia
- Geralmente mais caros e demorados

**Exemplos em CX:**
- Pesquisa de NPS que você aplica
- Entrevistas com clientes
- Grupos focais
- Testes de usabilidade
- Observação de comportamento

**Vantagens:**
- Relevância garantida para sua pergunta
- Dados atualizados
- Metodologia conhecida e controlada
- Exclusividade (concorrentes não têm)

**Desvantagens:**
- Custo de coleta
- Tempo necessário
- Possível viés na coleta
- Amostra limitada

### Dados Secundários

São dados coletados por outros, para outros propósitos, que você reutiliza.

**Características:**
- Já existem, prontos para uso
- Coletados com outro objetivo
- Metodologia definida por terceiros
- Geralmente mais baratos e rápidos

**Exemplos em CX:**
- Relatórios de mercado (Gartner, Forrester)
- Dados públicos (IBGE, Banco Central)
- Benchmarks setoriais
- Reviews em sites públicos
- Dados de redes sociais

**Vantagens:**
- Rapidez de acesso
- Custo reduzido
- Amostras maiores
- Comparabilidade com mercado

**Desvantagens:**
- Pode não responder sua pergunta exata
- Metodologia pode ser desconhecida
- Dados podem estar desatualizados
- Qualidade variável

### Quando Usar Cada Tipo

**Use Dados Primários quando:**
- Precisa de informação específica que não existe
- Quer entender o "porquê" profundo
- Precisa de dados atualizados e contextualizados
- A decisão é crítica e exige precisão

**Use Dados Secundários quando:**
- Precisa de contexto de mercado
- Orçamento ou tempo são limitados
- Quer validar achados primários
- Precisa de benchmarks externos

**Combine os Dois quando:**
- Quer triangular informações
- Precisa de visão completa
- Quer validar hipóteses

### Avaliando Qualidade de Dados Secundários

Antes de usar dados de terceiros, pergunte:

**Quem coletou?**
Fonte confiável? Possível viés?

**Quando foi coletado?**
Dados de 5 anos atrás podem estar obsoletos.

**Como foi coletado?**
Metodologia é transparente? Amostra é representativa?

**Para que foi coletado?**
O objetivo original pode ter influenciado os resultados.

**É consistente?**
Cruze com outras fontes. Dados muito diferentes são suspeitos.

### Fontes Úteis de Dados Secundários para CX

**Benchmarks de Mercado:**
- Relatórios Gartner, Forrester, McKinsey
- Pesquisas setoriais (ABEMD, ABT, etc.)
- Índices de satisfação públicos

**Dados Públicos:**
- IBGE (dados demográficos)
- Banco Central (dados econômicos)
- Reclame Aqui (reclamações públicas)

**Dados Digitais:**
- Google Trends (interesse de busca)
- SimilarWeb (tráfego de sites)
- Reviews em app stores

### Aplicação Prática

**Cenário:** Você quer entender por que o NPS caiu.

**Dados Primários:**
- Entrevistas com detratores recentes
- Análise de verbatims da pesquisa
- Shadowing de atendimentos

**Dados Secundários:**
- Benchmark de NPS do setor
- Reclamações no Reclame Aqui
- Tendências de mercado

**Combinação:**
Dados secundários mostram que o setor todo caiu (contexto). Dados primários revelam que seu problema específico é tempo de espera (causa raiz).

### Checklist de Seleção de Fonte

- [ ] A fonte responde minha pergunta?
- [ ] Os dados são recentes o suficiente?
- [ ] A metodologia é confiável?
- [ ] O tamanho da amostra é adequado?
- [ ] Há viés evidente?
- [ ] Posso verificar com outra fonte?

> "Dados primários te dão profundidade. Dados secundários te dão contexto. Os melhores insights vêm da combinação dos dois."
> — Protocolo Vértice
`
  },
  {
    id: 10,
    title: "Gráficos de Pizza: Quando Usar (e Quando Evitar)",
    content: `# Gráficos de Pizza: Quando Usar (e Quando Evitar)

## O Visual Mais Mal Utilizado do Mundo Corporativo

O gráfico de pizza é provavelmente o tipo de visualização mais popular — e também o mais mal utilizado. Vamos entender quando ele funciona e quando você deveria escolher outra opção.

### O Que o Gráfico de Pizza Faz Bem

O gráfico de pizza mostra **partes de um todo**. Ele responde à pergunta: "Como o total se divide entre as categorias?"

**Funciona quando:**
- Você quer mostrar proporções de um total
- Tem poucas categorias (máximo 5-6)
- Uma ou duas fatias dominam claramente
- O público é não-técnico

### O Problema Fundamental

O cérebro humano é péssimo em comparar ângulos e áreas. Olhe para duas fatias de 23% e 27% — é muito difícil perceber qual é maior sem os números.

Já em um gráfico de barras, a diferença é óbvia: uma barra é visivelmente maior que a outra.

### Quando Evitar

**Muitas categorias**
Pizza com 10 fatias é ilegível. Use barras.

**Valores próximos**
Se as fatias são parecidas (25%, 24%, 26%, 25%), pizza não mostra diferença. Use barras.

**Comparação entre períodos**
Duas pizzas lado a lado são difíceis de comparar. Use barras agrupadas ou linhas.

**Valores negativos**
Pizza não representa números negativos. Use barras.

**Precisão necessária**
Se a diferença de 2% importa, pizza não é precisa o suficiente.

### Alternativas Melhores

**Gráfico de Barras Horizontais**
Para comparar categorias. Mais preciso, mais fácil de ler.

**Gráfico de Barras Empilhadas**
Para mostrar composição ao longo do tempo. Mostra partes do todo E evolução.

**Treemap**
Para muitas categorias com hierarquia. Usa área de forma mais eficiente.

**Waffle Chart**
Para porcentagens simples. 100 quadradinhos, fácil de contar.

### Se For Usar Pizza, Faça Direito

**Limite a 5-6 fatias**
Agrupe categorias menores em "Outros".

**Ordene as fatias**
Do maior para o menor, começando às 12h no sentido horário.

**Destaque o que importa**
Use cor diferente para a fatia principal.

**Inclua os valores**
Porcentagens visíveis em cada fatia.

**Evite 3D**
Distorce a percepção. Sempre use 2D.

**Evite "explodir" fatias**
Separar uma fatia do centro dificulta comparação.

### Exemplo Prático

**Ruim:** Pizza com 12 fatias mostrando motivos de reclamação, todas entre 5% e 12%.

**Bom:** Barras horizontais ordenadas do maior para menor, com os top 5 destacados.

**Aceitável:** Pizza com 4 fatias mostrando que "Tempo de espera" representa 45% das reclamações (fatia dominante clara).

### O Teste da Pizza

Antes de criar um gráfico de pizza, pergunte:

1. Estou mostrando partes de um todo? (Se não, pizza é errado)
2. Tenho 5 ou menos categorias? (Se não, use barras)
3. Há uma fatia claramente dominante? (Se não, use barras)
4. Preciso de precisão? (Se sim, use barras)
5. Vou comparar com outro período? (Se sim, use barras ou linhas)

Se respondeu "não" a qualquer pergunta, provavelmente barras são melhores.

### A Regra de Ouro

Na dúvida, use barras. Você raramente vai errar com um gráfico de barras bem feito. Pizza é para situações específicas onde a mensagem é "olha como essa fatia domina o todo".

> "Gráfico de pizza é como sal na comida: um pouco realça, muito estraga. Na dúvida, use menos."
> — Protocolo Vértice
`
  },
  {
    id: 14,
    title: "Mapas de Calor e Visualizações Avançadas",
    content: `# Mapas de Calor e Visualizações Avançadas

## Além dos Gráficos Básicos

Quando gráficos de linha e barra não são suficientes, visualizações avançadas podem revelar padrões que ficariam invisíveis. Vamos explorar quando e como usar cada uma.

### Mapa de Calor (Heatmap)

**O que é:** Matriz onde cores representam intensidade de valores.

**Quando usar:**
- Comparar muitas categorias em duas dimensões
- Identificar padrões em grandes volumes de dados
- Mostrar correlações entre variáveis

**Exemplo em CX:**
Mapa de calor de satisfação por canal (linhas) e tipo de problema (colunas). Vermelho = baixa satisfação, verde = alta.

| | Dúvida | Reclamação | Cancelamento |
|---|--------|------------|--------------|
| Telefone | 🟢 4.2 | 🟡 3.1 | 🔴 2.3 |
| Chat | 🟢 4.5 | 🟢 3.8 | 🟡 3.0 |
| Email | 🟡 3.5 | 🔴 2.5 | 🔴 2.1 |

**Insight imediato:** Cancelamentos por email são o ponto crítico.

**Dicas:**
- Use escala de cor intuitiva (vermelho = ruim, verde = bom)
- Inclua valores numéricos nas células
- Ordene linhas/colunas por padrão (não alfabeticamente)

### Gráfico de Dispersão (Scatter Plot)

**O que é:** Pontos em dois eixos mostrando relação entre variáveis.

**Quando usar:**
- Explorar correlação entre duas métricas
- Identificar outliers
- Segmentar visualmente

**Exemplo em CX:**
Eixo X = Tempo de relacionamento. Eixo Y = NPS. Cada ponto = um cliente.

**Insights possíveis:**
- Clientes antigos têm NPS maior? (correlação positiva)
- Há um grupo de clientes antigos insatisfeitos? (cluster de outliers)
- A relação é linear ou há um "platô"?

**Dicas:**
- Adicione linha de tendência para mostrar correlação
- Use cores para terceira dimensão (ex: segmento)
- Use tamanho do ponto para quarta dimensão (ex: valor do cliente)

### Gráfico de Bolhas

**O que é:** Scatter plot onde o tamanho do ponto representa uma terceira variável.

**Quando usar:**
- Comparar três variáveis simultaneamente
- Destacar importância relativa

**Exemplo em CX:**
X = CSAT, Y = Volume de tickets, Tamanho = Receita do cliente.

**Insight:** Clientes grandes (bolhas grandes) com baixo CSAT e alto volume de tickets são prioridade.

### Gráfico de Sankey

**O que é:** Fluxo visual mostrando como valores se movem entre categorias.

**Quando usar:**
- Mostrar jornadas e conversões
- Visualizar fluxo de clientes entre estados
- Entender "de onde vem, para onde vai"

**Exemplo em CX:**
Fluxo de clientes: Prospect → Trial → Ativo → Churned. Largura da faixa = volume.

**Insight:** Visualiza onde está o maior "vazamento" na jornada.

### Treemap

**O que é:** Retângulos aninhados onde área representa proporção.

**Quando usar:**
- Mostrar hierarquias com muitas categorias
- Substituir pizza com muitas fatias
- Visualizar composição com detalhes

**Exemplo em CX:**
Motivos de reclamação hierárquicos. Área = volume. Cor = tendência (crescendo/diminuindo).

### Gráfico de Radar (Spider Chart)

**O que é:** Múltiplos eixos radiais partindo do centro.

**Quando usar:**
- Comparar perfis em múltiplas dimensões
- Mostrar pontos fortes e fracos
- Comparar poucos itens (máximo 3-4)

**Exemplo em CX:**
Comparar 3 canais em 6 dimensões: Velocidade, Qualidade, Custo, Satisfação, Volume, Resolução.

**Cuidado:** Com muitos itens ou dimensões, fica confuso.

### Gráfico de Funil

**O que é:** Barras decrescentes mostrando conversão em etapas.

**Quando usar:**
- Visualizar processo de conversão
- Identificar onde há maior perda
- Mostrar eficiência de pipeline

**Exemplo em CX:**
Funil de onboarding: Cadastro (100%) → Ativação (60%) → Primeiro uso (40%) → Uso recorrente (25%).

### Quando Usar Cada Visualização

| Objetivo | Visualização |
|----------|--------------|
| Comparar categorias | Barras |
| Mostrar tendência | Linhas |
| Mostrar composição | Pizza (poucas) ou Treemap (muitas) |
| Mostrar correlação | Scatter plot |
| Mostrar padrões em matriz | Heatmap |
| Mostrar fluxo/jornada | Sankey ou Funil |
| Comparar perfis | Radar |
| Mostrar 3+ variáveis | Bolhas |

### Princípios para Visualizações Avançadas

**1. Complexidade Justificada**
Use visualização avançada só quando a simples não resolve.

**2. Explique o Visual**
Público pode não conhecer o formato. Adicione legenda ou explicação.

**3. Teste a Compreensão**
Mostre para alguém e pergunte: "O que você entende deste gráfico?"

**4. Interatividade Ajuda**
Tooltips, filtros e drill-down facilitam exploração.

**5. Menos é Mais**
Mesmo em visualizações avançadas, remova o desnecessário.

> "Visualização avançada não é para impressionar. É para revelar o que visualização simples esconde."
> — Protocolo Vértice
`
  },
  {
    id: 24,
    title: "Voz do Cliente (VoC): Captura e Análise",
    content: `# Voz do Cliente (VoC): Captura e Análise

## Ouvindo o Cliente em Escala

Voice of Customer (VoC) é o processo sistemático de capturar, analisar e agir sobre o feedback dos clientes. Não é apenas "ouvir reclamações" — é construir um sistema que transforma a voz do cliente em melhoria contínua.

### O Que é VoC

**Definição:** Processo estruturado para coletar, analisar e distribuir feedback do cliente para toda a organização, gerando ações de melhoria.

**Não é:**
- Apenas pesquisa de satisfação
- Só ouvir reclamações
- Responsabilidade apenas de CX

**É:**
- Sistema integrado de escuta
- Múltiplas fontes de feedback
- Análise contínua e acionável
- Cultura organizacional

### Fontes de VoC

**Diretas (cliente fala para você):**
- Pesquisas (NPS, CSAT, CES)
- Entrevistas e grupos focais
- Feedback em atendimento
- Sugestões e reclamações formais

**Indiretas (cliente fala sobre você):**
- Redes sociais
- Sites de review (Google, Reclame Aqui)
- Fóruns e comunidades
- Menções em mídia

**Inferidas (comportamento do cliente):**
- Dados de uso do produto
- Padrões de navegação
- Taxas de conversão e abandono
- Churn e retenção

### Estrutura de um Programa de VoC

**1. Coleta**
Múltiplos canais, múltiplos momentos. Pesquisas transacionais (após interação) e relacionais (periódicas).

**2. Integração**
Dados de todas as fontes em um lugar. Visão unificada do cliente.

**3. Análise**
Quantitativa (métricas, tendências) e qualitativa (temas, sentimentos).

**4. Distribuição**
Insights chegam a quem pode agir. Dashboards, alertas, relatórios.

**5. Ação**
Fechamento de loop. Problemas resolvidos, melhorias implementadas.

**6. Medição**
Impacto das ações medido. Ciclo de melhoria contínua.

### Análise de Texto (Text Analytics)

Com milhares de comentários, análise manual é impossível. Text analytics automatiza:

**Categorização**
Agrupa comentários por tema automaticamente. "Preço", "Atendimento", "Produto", etc.

**Análise de Sentimento**
Classifica como positivo, negativo ou neutro. Identifica emoções (frustração, satisfação, raiva).

**Extração de Entidades**
Identifica produtos, pessoas, locais mencionados.

**Tendências**
Detecta temas emergentes ou em declínio.

### Fechamento de Loop (Closed Loop)

O VoC só gera valor se houver ação. Closed loop significa:

**Inner Loop (Curto prazo)**
Responder ao cliente individual. Detrator recebe ligação em 24h. Problema específico resolvido.

**Outer Loop (Longo prazo)**
Mudanças sistêmicas baseadas em padrões. Se 30% reclamam de X, mude X.

### Métricas de VoC

**Cobertura**
% de clientes que dão feedback. Meta: representatividade.

**Tempo de Resposta**
Quanto tempo até agir no feedback. Meta: 24-48h para críticos.

**Taxa de Fechamento**
% de feedbacks que resultam em ação documentada.

**Impacto**
Melhoria nas métricas após ações de VoC.

### Implementação Prática

**Fase 1: Fundação (Mês 1-2)**
- Mapear fontes existentes de feedback
- Consolidar em uma visão única
- Definir processo de análise

**Fase 2: Escala (Mês 3-4)**
- Implementar text analytics
- Criar dashboards de VoC
- Treinar times para usar insights

**Fase 3: Ação (Mês 5-6)**
- Implementar closed loop
- Conectar VoC a processos de melhoria
- Medir impacto das ações

### Erros Comuns

**1. Coletar sem Analisar**
Montanha de dados que ninguém olha.

**2. Analisar sem Agir**
Insights bonitos que não viram melhoria.

**3. Agir sem Medir**
Mudanças sem saber se funcionaram.

**4. Focar só em Detratores**
Promotores também têm insights valiosos.

**5. Ignorar Feedback Indireto**
Redes sociais e reviews são minas de ouro.

### O Futuro do VoC

**IA Generativa:** Resumos automáticos de milhares de comentários.
**Real-time:** Análise e ação em tempo real durante a interação.
**Preditivo:** Antecipar problemas antes do cliente reclamar.
**Omnichannel:** Visão unificada de todas as interações.

> "VoC não é sobre coletar feedback. É sobre criar uma organização que ouve, aprende e melhora continuamente."
> — Protocolo Vértice
`
  },
  {
    id: 25,
    title: "Cultura Centrada no Cliente",
    content: `# Cultura Centrada no Cliente

## Transformando CX em DNA Organizacional

Ferramentas e processos são importantes, mas cultura é o que determina se CX será prioridade ou discurso vazio. Cultura centrada no cliente significa que toda decisão, em toda área, considera o impacto no cliente.

### O Que é Cultura Centrada no Cliente

**Não é:**
- Ter um departamento de CX
- Medir NPS
- Dizer "o cliente é nossa prioridade"

**É:**
- Cliente presente em toda decisão
- Incentivos alinhados com satisfação
- Liderança que exemplifica
- Processos que facilitam fazer o certo

### Os 4 Pilares

**1. Liderança pelo Exemplo**
Executivos que vivem o cliente. CEO que liga para detratores. Diretores que visitam operação.

**2. Empoderamento da Linha de Frente**
Autonomia para resolver problemas. Confiança para tomar decisões. Sem scripts rígidos.

**3. Métricas e Incentivos Alinhados**
Bônus conectado a satisfação. Metas de qualidade, não só quantidade. Reconhecimento por CX.

**4. Processos que Facilitam**
Sistemas que ajudam, não atrapalham. Informação acessível. Burocracia mínima.

### Diagnóstico: Sua Cultura é Centrada no Cliente?

**Perguntas reveladoras:**

Quando há conflito entre meta de vendas e satisfação do cliente, o que prevalece?

Atendentes podem resolver problemas sem escalar para supervisor?

Executivos passam tempo com clientes regularmente?

Feedback negativo de cliente chega rápido à liderança?

Funcionários são reconhecidos por ir além pelo cliente?

### Barreiras Comuns

**Silos Organizacionais**
Cada área otimiza seu indicador, ninguém olha a jornada completa.

**Incentivos Desalinhados**
Vendas ganha por vender, mesmo que cliente cancele em 3 meses.

**Falta de Autonomia**
Atendente sabe o que fazer, mas precisa de 5 aprovações.

**Liderança Distante**
Executivos não têm contato com realidade do cliente.

**Foco em Curto Prazo**
Pressão por resultado trimestral sacrifica relacionamento.

### Práticas de Empresas Centradas no Cliente

**Amazon: Cadeira Vazia**
Em reuniões, uma cadeira vazia representa o cliente. Decisões consideram "o que o cliente acharia?"

**Zappos: Empoderamento Total**
Atendentes podem fazer o que for necessário para encantar. Sem scripts, sem limites de tempo.

**Ritz-Carlton: US$ 2.000**
Cada funcionário pode gastar até US$ 2.000 para resolver problema de hóspede, sem aprovação.

**Netflix: Contexto, não Controle**
Funcionários entendem o objetivo e têm liberdade para decidir como alcançar.

### Transformação Cultural: Por Onde Começar

**1. Diagnóstico Honesto**
Pesquisa interna: funcionários acreditam que somos centrados no cliente? Onde falhamos?

**2. Compromisso da Liderança**
CEO precisa ser o maior defensor. Sem isso, não funciona.

**3. Quick Wins**
Mudanças visíveis que mostram que é sério. Remover uma burocracia absurda.

**4. Rituais de Cliente**
Reuniões começam com história de cliente. Executivos em atendimento mensalmente.

**5. Métricas Visíveis**
NPS no dashboard de toda área. Celebrar melhorias.

**6. Reconhecimento**
Premiar comportamentos centrados no cliente. Histórias de sucesso compartilhadas.

**7. Contratação e Onboarding**
Contratar por valores, não só habilidades. Onboarding inclui vivência com cliente.

### Medindo Cultura

**Pesquisa de Engajamento**
"Minha empresa realmente se importa com clientes" (concordância).

**Comportamentos Observáveis**
Quantas decisões citam impacto no cliente? Quantos executivos falam com clientes?

**Métricas de Resultado**
NPS, retenção, CLV. Cultura boa gera resultados.

**Turnover**
Empresas centradas no cliente têm menor rotatividade.

### O Papel de Cada Área

**RH:** Contratar por valores, treinar em CX, alinhar incentivos.
**Financeiro:** Investir em experiência, medir ROI de CX.
**Produto:** Desenvolver com cliente, não para cliente.
**Marketing:** Prometer o que entrega, comunicar com verdade.
**Operações:** Processos que facilitam, não burocratizam.
**TI:** Sistemas que empoderam, dados acessíveis.

### Sinais de Progresso

**Curto prazo (3-6 meses):**
- Liderança fala de cliente regularmente
- Primeiras barreiras removidas
- Quick wins celebrados

**Médio prazo (6-12 meses):**
- Métricas de CX em todas as áreas
- Funcionários empoderados para resolver
- Histórias de cliente em reuniões

**Longo prazo (12-24 meses):**
- Decisões naturalmente consideram cliente
- Cultura atrai talentos alinhados
- Resultados de negócio melhoram

> "Cultura não é o que você diz. É o que você faz quando ninguém está olhando. E os clientes sempre percebem."
> — Protocolo Vértice
`
  },
  {
    id: 28,
    title: "Experiência do Funcionário e CX",
    content: `# Experiência do Funcionário e CX

## O Elo Invisível que Determina a Experiência do Cliente

Existe uma verdade incômoda em CX: funcionários infelizes não criam clientes felizes. A experiência do funcionário (EX) é o alicerce sobre o qual a experiência do cliente é construída.

### A Conexão EX-CX

**O Ciclo Virtuoso:**
Funcionário engajado → Atendimento melhor → Cliente satisfeito → Resultados melhores → Empresa investe em funcionário → Funcionário mais engajado

**O Ciclo Vicioso:**
Funcionário desengajado → Atendimento ruim → Cliente insatisfeito → Resultados piores → Empresa corta custos → Funcionário mais desengajado

**Dados que Comprovam:**
Empresas com alto engajamento de funcionários têm NPS 2x maior. Redução de 1 ponto em turnover = aumento de 0.5 ponto em CSAT.

### O Que é Employee Experience (EX)

**Definição:** A soma de todas as interações que um funcionário tem com a empresa, desde o recrutamento até o desligamento.

**Dimensões:**
- Ambiente físico (espaço, ferramentas)
- Ambiente tecnológico (sistemas, acesso)
- Ambiente cultural (valores, liderança)

### Jornada do Funcionário

**1. Atração**
Como a empresa é percebida no mercado? Employer branding.

**2. Recrutamento**
Processo de seleção é respeitoso? Comunicação clara?

**3. Onboarding**
Primeiros dias são acolhedores? Treinamento adequado?

**4. Desenvolvimento**
Há oportunidades de crescimento? Feedback constante?

**5. Retenção**
Reconhecimento justo? Equilíbrio vida-trabalho?

**6. Offboarding**
Saída é tratada com dignidade? Aprendizado capturado?

### Métricas de EX

**eNPS (Employee NPS)**
"De 0 a 10, quanto você recomendaria trabalhar aqui?"

**Engajamento**
Pesquisas de clima com múltiplas dimensões.

**Turnover**
Taxa de rotatividade, especialmente voluntária.

**Absenteísmo**
Faltas não programadas.

**Tempo de Ramp-up**
Quanto tempo até novo funcionário ser produtivo.

### Impacto Direto em CX

**Conhecimento**
Funcionário que fica mais tempo conhece mais. Resolve melhor.

**Motivação**
Funcionário engajado vai além do script. Encanta.

**Consistência**
Baixo turnover = experiência consistente para cliente.

**Inovação**
Funcionário que se sente ouvido sugere melhorias.

### Práticas que Conectam EX e CX

**1. Mesmas Métricas**
NPS de cliente E de funcionário no mesmo dashboard.

**2. Feedback Bidirecional**
Funcionário ouve feedback do cliente. Cliente ouve que funcionário foi reconhecido.

**3. Empoderamento Real**
Autonomia para resolver, não só para seguir script.

**4. Ferramentas Adequadas**
Sistemas que ajudam, não atrapalham. Informação acessível.

**5. Reconhecimento por CX**
Premiar quem encanta cliente, não só quem bate meta.

**6. Carreira em CX**
Caminho de crescimento para quem trabalha com cliente.

### O Papel da Liderança

**Líderes de Linha de Frente:**
- Coaching diário
- Remoção de barreiras
- Reconhecimento frequente
- Escuta ativa

**Liderança Executiva:**
- Definir tom e prioridades
- Investir em EX
- Visitar operação
- Celebrar sucessos

### Diagnóstico: EX está Sabotando seu CX?

**Sinais de alerta:**
- Turnover alto em áreas de atendimento
- Reclamações de clientes sobre "funcionário mal-humorado"
- Funcionários não conhecem produtos/processos
- Sugestões de melhoria não são implementadas
- Liderança distante da operação

### Quick Wins para Melhorar EX

**Semana 1:**
- Pergunte aos funcionários: "O que te impede de atender bem?"
- Remova uma burocracia desnecessária

**Mês 1:**
- Implemente reconhecimento por CX
- Crie canal de sugestões com resposta garantida

**Trimestre 1:**
- Revise ferramentas e sistemas
- Treine liderança em coaching

### Medindo o ROI de EX

**Custos de Turnover:**
Recrutamento + treinamento + produtividade perdida = 50-200% do salário anual.

**Impacto em CX:**
Correlacione eNPS com NPS. Calcule quanto vale 1 ponto de NPS.

**Produtividade:**
Funcionários engajados são 17% mais produtivos (Gallup).

### O Futuro de EX

**Personalização:** Experiência adaptada ao perfil do funcionário.
**Bem-estar Integral:** Saúde mental, financeira, física.
**Flexibilidade:** Trabalho híbrido, horários flexíveis.
**Propósito:** Conexão com impacto do trabalho.
**Tecnologia:** IA para remover tarefas repetitivas.

> "Cuide dos seus funcionários e eles cuidarão dos seus clientes. Não existe atalho."
> — Protocolo Vértice
`
  }
];

async function generateAndSaveContent(contentData: { id: number; title: string; content: string }) {
  try {
    const fileName = "content_" + contentData.id + "_" + Date.now() + ".md";
    const buffer = Buffer.from(contentData.content, 'utf-8');
    
    const { url } = await storagePut(fileName, buffer, 'text/markdown');
    
    await db.update(contents)
      .set({ 
        fileUrl: url,
        mimeType: 'text/markdown',
        updatedAt: new Date()
      })
      .where(eq(contents.id, contentData.id));
    
    console.log("✅ Conteúdo " + contentData.id + " atualizado: " + contentData.title);
    return true;
  } catch (error) {
    console.error("❌ Erro ao atualizar conteúdo " + contentData.id + ":", error);
    return false;
  }
}

async function main() {
  console.log("🚀 Gerando conteúdos autorais - Batch 4 (Últimos conteúdos)...");
  
  for (const content of contentsBatch4) {
    await generateAndSaveContent(content);
  }
  
  console.log("\n✅ Batch 4 concluído! Todos os 35 conteúdos agora têm material autoral.");
  process.exit(0);
}

main().catch(console.error);
