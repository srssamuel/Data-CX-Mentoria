import { drizzle } from "drizzle-orm/mysql2";
import { contents } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { storagePut } from "../server/storage";

const db = drizzle(process.env.DATABASE_URL!);

const contentsBatch2 = [
  {
    id: 18,
    title: "Pilar 1: Introdução às Metodologias Ágeis",
    content: `# Pilar 1: Introdução às Metodologias Ágeis

## Por Que Agilidade é Fundamental para CX

No mundo de Customer Experience, velocidade de resposta e capacidade de adaptação são diferenciais competitivos. Metodologias ágeis não são apenas para times de tecnologia — são ferramentas essenciais para qualquer operação que precisa evoluir continuamente.

### O Que São Metodologias Ágeis

Metodologias ágeis são frameworks de trabalho que priorizam:
- **Entregas incrementais** em vez de grandes projetos
- **Feedback contínuo** em vez de planejamento rígido
- **Colaboração** em vez de silos
- **Adaptação** em vez de seguir plano cegamente

### Por Que Importa para CX

**1. Clientes Mudam Rápido**
- Expectativas evoluem constantemente
- Concorrência lança novidades toda semana
- Quem demora a adaptar, perde

**2. Problemas São Complexos**
- Não dá para prever tudo no início
- Descobrimos causas raiz durante a execução
- Precisamos ajustar o rumo constantemente

**3. Recursos São Limitados**
- Não podemos fazer tudo ao mesmo tempo
- Precisamos priorizar o que gera mais valor
- Entregas pequenas mostram resultado mais rápido

### Os 4 Valores do Manifesto Ágil

**1. Indivíduos e interações** mais que processos e ferramentas
- Times de CX precisam conversar, não só trocar emails
- Reuniões curtas e frequentes > Reuniões longas e raras

**2. Software funcionando** mais que documentação abrangente
- No contexto de CX: Melhoria implementada > Relatório bonito
- Teste rápido > Planejamento perfeito

**3. Colaboração com o cliente** mais que negociação de contratos
- Ouvir o cliente continuamente
- Co-criar soluções

**4. Responder a mudanças** mais que seguir um plano
- Flexibilidade para ajustar prioridades
- Aprender com dados reais

### Frameworks Principais

**Scrum**
- Sprints de 2-4 semanas
- Papéis definidos (PO, SM, Time)
- Cerimônias estruturadas
- Ideal para projetos de melhoria

**Kanban**
- Fluxo contínuo
- Visualização do trabalho
- Limites de WIP
- Ideal para operações do dia a dia

**OKRs**
- Objetivos ambiciosos
- Resultados-chave mensuráveis
- Ciclos trimestrais
- Ideal para alinhar estratégia

### Aplicação Prática em CX

**Cenário:** Reduzir tempo de resposta do SAC

**Abordagem Tradicional:**
1. Análise de 3 meses
2. Projeto de 6 meses
3. Implementação de 3 meses
4. Resultado: 12 meses depois

**Abordagem Ágil:**
1. Sprint 1: Identificar top 3 causas (2 semanas)
2. Sprint 2: Testar solução para causa #1 (2 semanas)
3. Sprint 3: Escalar se funcionou, pivotar se não (2 semanas)
4. Resultado: Melhorias visíveis em 6 semanas

### Primeiros Passos

1. **Comece pequeno** — Um time, um projeto
2. **Defina ciclos** — Sprints de 2 semanas são um bom início
3. **Visualize o trabalho** — Quadro Kanban físico ou digital
4. **Faça retrospectivas** — O que funcionou? O que melhorar?
5. **Meça resultados** — Dados, não opiniões

> "Agilidade não é fazer mais rápido. É aprender mais rápido."
> — Protocolo Vértice
`
  },
  {
    id: 19,
    title: "Scrum: Framework para Times de Alta Performance",
    content: `# Scrum: Framework para Times de Alta Performance

## O Framework Mais Popular do Mundo Ágil

Scrum é um framework leve que ajuda times a entregar valor de forma incremental e iterativa. Originalmente criado para desenvolvimento de software, hoje é aplicado em marketing, RH, operações e, claro, Customer Experience.

### Os 3 Pilares do Scrum

**1. Transparência**
- Todo mundo vê o mesmo quadro
- Progresso é visível
- Problemas aparecem cedo

**2. Inspeção**
- Verificamos frequentemente o trabalho
- Comparamos com o objetivo
- Identificamos desvios

**3. Adaptação**
- Ajustamos o rumo quando necessário
- Não esperamos o fim para corrigir
- Aprendemos com cada ciclo

### Os 3 Papéis

**Product Owner (PO)**
- Dono do "o quê"
- Define prioridades
- Representa o cliente/negócio
- Decide o que entra no backlog

**Scrum Master (SM)**
- Guardião do processo
- Remove impedimentos
- Facilita cerimônias
- Protege o time

**Time de Desenvolvimento**
- Executa o trabalho
- Auto-organizado
- Multidisciplinar
- 3-9 pessoas

### Os 5 Eventos

**1. Sprint**
- Ciclo de trabalho (2-4 semanas)
- Objetivo fixo durante o sprint
- Entrega incremento ao final

**2. Sprint Planning**
- Início do sprint
- Define o que será feito
- Time se compromete com o objetivo

**3. Daily Scrum**
- 15 minutos, todo dia
- O que fiz ontem?
- O que farei hoje?
- Algum impedimento?

**4. Sprint Review**
- Final do sprint
- Demonstra o que foi feito
- Coleta feedback

**5. Sprint Retrospective**
- Final do sprint
- O que funcionou?
- O que melhorar?
- Ações para próximo sprint

### Os 3 Artefatos

**Product Backlog**
- Lista priorizada de tudo que precisa ser feito
- Gerenciado pelo PO
- Sempre evoluindo

**Sprint Backlog**
- Itens selecionados para o sprint
- Compromisso do time
- Não muda durante o sprint

**Incremento**
- O que foi entregue no sprint
- Potencialmente utilizável
- Soma dos sprints anteriores

### Aplicação em CX

**Exemplo: Projeto de Melhoria do NPS**

**Sprint 1 - Diagnóstico**
- Analisar dados de NPS por segmento
- Identificar top 3 detratores
- Entrevistar 10 clientes insatisfeitos

**Sprint 2 - Prototipação**
- Desenhar solução para detrator #1
- Testar com grupo piloto
- Coletar feedback

**Sprint 3 - Implementação**
- Escalar solução validada
- Treinar equipe
- Medir impacto inicial

**Sprint 4 - Otimização**
- Ajustar baseado em dados
- Atacar detrator #2
- Documentar aprendizados

### Métricas de Scrum

**Velocidade**
- Quantidade de trabalho entregue por sprint
- Ajuda a prever capacidade futura

**Burndown**
- Trabalho restante ao longo do sprint
- Mostra se está no ritmo

**Lead Time**
- Tempo do pedido até a entrega
- Quanto menor, melhor

### Erros Comuns

1. **Sprints que mudam** — O objetivo do sprint é fixo
2. **Daily de 1 hora** — São 15 minutos, ponto
3. **PO ausente** — Precisa estar disponível
4. **Sem retrospectiva** — É onde a melhoria acontece
5. **Time muito grande** — Máximo 9 pessoas

> "Scrum não resolve problemas. Scrum expõe problemas para que você possa resolvê-los."
> — Protocolo Vértice
`
  },
  {
    id: 20,
    title: "Kanban e Gestão Visual",
    content: `# Kanban e Gestão Visual

## O Poder de Ver o Trabalho

Kanban é um método de gestão visual que transforma trabalho invisível em trabalho visível. Quando você vê o fluxo, você pode melhorá-lo.

### Origem e Filosofia

Kanban nasceu na Toyota nos anos 1940. A palavra significa "cartão visual" em japonês. A ideia central é simples: **limite o trabalho em progresso para aumentar a vazão**.

### Os 4 Princípios

**1. Comece com o que você faz hoje**
- Não precisa mudar tudo de uma vez
- Mapeie o processo atual
- Melhore incrementalmente

**2. Busque mudanças incrementais e evolutivas**
- Pequenos ajustes frequentes
- Menos resistência
- Resultados sustentáveis

**3. Respeite os papéis e responsabilidades atuais**
- Não precisa reorganizar o time
- Funciona com estrutura existente

**4. Encoraje liderança em todos os níveis**
- Qualquer um pode sugerir melhorias
- Decisões descentralizadas

### As 6 Práticas

**1. Visualize o Fluxo de Trabalho**
- Quadro com colunas (A Fazer → Fazendo → Feito)
- Cartões representam tarefas
- Todo mundo vê o mesmo quadro

**2. Limite o Trabalho em Progresso (WIP)**
- Defina máximo de itens por coluna
- Força foco e conclusão
- Evita multitarefa excessiva

**3. Gerencie o Fluxo**
- Observe gargalos
- Meça tempo de ciclo
- Otimize continuamente

**4. Torne as Políticas Explícitas**
- Critérios para mover cartões
- Definição de "pronto"
- Regras claras para todos

**5. Implemente Loops de Feedback**
- Reuniões de revisão do quadro
- Métricas de fluxo
- Retrospectivas

**6. Melhore Colaborativamente**
- Experimente mudanças
- Meça impacto
- Ajuste baseado em dados

### Anatomia de um Quadro Kanban

**Colunas Básicas:**
- Backlog (a fazer)
- Em Análise
- Em Execução
- Em Revisão
- Concluído

**Informações no Cartão:**
- Título da tarefa
- Responsável
- Data de entrada
- Prioridade (cor)
- Prazo (se houver)

**Limites de WIP:**
- Backlog: Sem limite
- Em Análise: 3
- Em Execução: 5
- Em Revisão: 2

### Aplicação em Operações de CX

**Quadro de Atendimento de Reclamações:**

| Novas | Triagem (3) | Análise (5) | Resolução (3) | Aguardando Cliente | Fechadas |
|-------|-------------|-------------|---------------|-------------------|----------|
| 15    | 3           | 4           | 2             | 8                 | 127      |

**Benefícios:**
- Visibilidade do volume
- Identificação de gargalos
- Priorização clara
- Métricas de tempo

### Métricas Kanban

**Lead Time**
- Tempo total do início ao fim
- Meta: Reduzir progressivamente

**Cycle Time**
- Tempo em cada etapa
- Identifica gargalos

**Throughput**
- Quantidade entregue por período
- Mede capacidade real

**WIP**
- Trabalho em progresso
- Quanto menor, mais foco

### Kanban vs Scrum

| Aspecto | Kanban | Scrum |
|---------|--------|-------|
| Cadência | Fluxo contínuo | Sprints fixos |
| Papéis | Flexíveis | Definidos (PO, SM) |
| Mudanças | A qualquer momento | Entre sprints |
| Planejamento | Contínuo | Por sprint |
| Melhor para | Operações, suporte | Projetos, desenvolvimento |

### Primeiros Passos

1. **Mapeie seu processo atual** — Quais são as etapas?
2. **Crie um quadro** — Físico ou digital
3. **Defina WIP inicial** — Comece conservador
4. **Revise semanalmente** — O que está travando?
5. **Ajuste limites** — Baseado em dados reais

> "Você não pode melhorar o que não pode ver. Kanban torna o invisível visível."
> — Protocolo Vértice
`
  },
  {
    id: 21,
    title: "OKRs: Objetivos e Resultados-Chave",
    content: `# OKRs: Objetivos e Resultados-Chave

## O Framework que Alinha Estratégia e Execução

OKR (Objectives and Key Results) é um framework de definição de metas usado por Google, Intel, LinkedIn e milhares de empresas. Ele conecta a visão estratégica com ações mensuráveis.

### A Estrutura

**Objetivo (O)**
- O QUE você quer alcançar
- Qualitativo e inspirador
- Ambicioso mas alcançável
- Claro e memorável

**Resultados-Chave (KR)**
- COMO você vai medir o progresso
- Quantitativos e específicos
- 2-5 por objetivo
- Mensuráveis objetivamente

### Exemplo Prático

**Objetivo:** Transformar a experiência do cliente no atendimento

**Resultados-Chave:**
1. Aumentar NPS de 32 para 50
2. Reduzir tempo médio de espera de 12 para 4 minutos
3. Atingir 90% de resolução no primeiro contato
4. Reduzir reclamações recorrentes em 40%

### Características de Bons OKRs

**Objetivos:**
- ✅ "Ser referência em atendimento no setor"
- ❌ "Melhorar o atendimento" (vago)
- ❌ "Aumentar NPS em 10 pontos" (isso é KR, não O)

**Resultados-Chave:**
- ✅ "Reduzir churn de 5% para 3%"
- ❌ "Melhorar retenção" (não mensurável)
- ❌ "Implementar sistema X" (isso é tarefa, não KR)

### O Ciclo de OKRs

**Trimestral (mais comum):**
1. **Semana 1:** Definição de OKRs
2. **Semanas 2-12:** Execução e check-ins semanais
3. **Semana 13:** Avaliação e aprendizados

**Check-in Semanal:**
- Progresso de cada KR (0-100%)
- Confiança de atingir (verde/amarelo/vermelho)
- Impedimentos e ações

### Pontuação

**Escala 0.0 a 1.0:**
- 0.0-0.3: Falha significativa
- 0.4-0.6: Progresso, mas não atingiu
- 0.7-1.0: Sucesso

**Meta ideal:** 0.7 (70%)
- Se sempre atinge 1.0, os OKRs estão fáceis demais
- Se sempre fica abaixo de 0.3, estão impossíveis

### Cascateamento

**OKRs da Empresa:**
- Objetivo: Ser líder em satisfação do cliente no Brasil

**OKRs do Time de CX:**
- Objetivo: Revolucionar a jornada de atendimento
- KR1: NPS de 32 → 50
- KR2: Tempo de espera de 12 → 4 min

**OKRs Individuais:**
- Objetivo: Dominar análise de causa raiz
- KR1: Conduzir 20 análises de detratores
- KR2: Implementar 5 melhorias baseadas em dados

### Erros Comuns

**1. Confundir KR com Tarefa**
- ❌ "Implementar chatbot"
- ✅ "Reduzir volume de ligações em 30% via autoatendimento"

**2. Muitos OKRs**
- ❌ 10 objetivos com 5 KRs cada
- ✅ 3-5 objetivos com 2-4 KRs cada

**3. OKRs Fáceis Demais**
- Se sempre atinge 100%, não está se desafiando
- OKRs devem ser desconfortáveis

**4. Não Fazer Check-ins**
- OKRs sem acompanhamento viram decoração
- Check-in semanal é essencial

**5. Usar como Ferramenta de Punição**
- OKRs são para aprendizado, não para demitir
- Falhar em OKR ambicioso é esperado

### Template de OKR para CX

**Objetivo 1: Eliminar fricção na jornada do cliente**
- KR1: Reduzir pontos de atrito mapeados de 12 para 4
- KR2: Aumentar CSAT de jornada de 3.2 para 4.5
- KR3: Reduzir reclamações sobre processo em 50%

**Objetivo 2: Criar cultura de dados no time**
- KR1: 100% do time usando dashboard diariamente
- KR2: 80% das decisões documentadas com dados
- KR3: Conduzir 10 análises de causa raiz por mês

**Objetivo 3: Antecipar problemas antes do cliente reclamar**
- KR1: Implementar 3 alertas preditivos
- KR2: Resolver 40% dos problemas proativamente
- KR3: Reduzir reclamações reativas em 25%

> "OKRs não são sobre atingir 100%. São sobre mirar alto e aprender rápido."
> — Protocolo Vértice
`
  },
  {
    id: 22,
    title: "Design Thinking para CX",
    content: `# Design Thinking para CX

## Resolvendo Problemas com Empatia

Design Thinking é uma abordagem centrada no ser humano para resolver problemas complexos. Em CX, é a ferramenta perfeita para criar soluções que realmente atendem às necessidades dos clientes.

### As 5 Etapas

**1. EMPATIZAR**
Entender profundamente o cliente.

**Ferramentas:**
- Entrevistas em profundidade
- Observação etnográfica
- Shadowing (acompanhar o cliente)
- Mapa de empatia

**Perguntas-chave:**
- O que o cliente pensa e sente?
- O que ele vê no ambiente?
- O que ele ouve de outros?
- O que ele fala e faz?
- Quais suas dores?
- Quais seus ganhos desejados?

**2. DEFINIR**
Sintetizar os insights em um problema claro.

**Ferramentas:**
- Personas
- Jornada do cliente
- Point of View (POV)
- How Might We (HMW)

**Template POV:**
"[Usuário] precisa de [necessidade] porque [insight]"

**Exemplo:**
"Maria, mãe de 2 filhos, precisa resolver problemas de forma rápida porque seu tempo é escasso e cada minuto de espera gera frustração."

**3. IDEAR**
Gerar muitas ideias sem julgamento.

**Ferramentas:**
- Brainstorming
- Crazy 8s
- SCAMPER
- Analogias

**Regras do Brainstorming:**
- Quantidade > Qualidade (nesta fase)
- Sem julgamento
- Construa sobre ideias dos outros
- Encoraje ideias malucas
- Seja visual

**4. PROTOTIPAR**
Criar versões rápidas e baratas para testar.

**Tipos de Protótipo:**
- Papel e caneta (fluxos, telas)
- Storyboard (narrativa visual)
- Role-play (simular interação)
- MVP digital (versão mínima)

**Princípios:**
- Rápido e barato
- Suficiente para testar a hipótese
- Descartável (não se apegue)

**5. TESTAR**
Validar com usuários reais.

**Métodos:**
- Teste de usabilidade
- Entrevistas com protótipo
- A/B testing
- Piloto controlado

**O que observar:**
- Comportamento (não só opinião)
- Onde travam
- O que surpreende
- O que frustra

### Aplicação em CX

**Caso: Reduzir Abandono no Call Center**

**Empatizar:**
- Entrevistar 20 clientes que abandonaram
- Ouvir gravações de chamadas longas
- Acompanhar atendentes por 1 dia

**Definir:**
"Clientes que ligam para resolver problemas simples precisam de uma solução rápida porque cada minuto de espera aumenta a frustração e a probabilidade de desistir."

**Idear:**
- Callback automático
- Autoatendimento por WhatsApp
- Triagem inteligente por URA
- Atendimento por vídeo
- Agendamento de horário

**Prototipar:**
- Fluxo de callback em papel
- Simulação de WhatsApp com Wizard of Oz
- Script de nova URA

**Testar:**
- Piloto com 100 clientes
- Medir tempo e satisfação
- Coletar feedback qualitativo

### Ferramentas Essenciais

**Mapa de Empatia**
| Pensa/Sente | Vê |
|-------------|-----|
| Ouve | Fala/Faz |
| Dores | Ganhos |

**How Might We (HMW)**
Transforme problemas em perguntas de oportunidade:
- Problema: "Clientes esperam muito"
- HMW: "Como podemos fazer o tempo de espera parecer menor?"
- HMW: "Como podemos eliminar a necessidade de esperar?"
- HMW: "Como podemos transformar espera em valor?"

**Crazy 8s**
- Dobre papel em 8 partes
- 1 minuto por quadrante
- 8 ideias em 8 minutos
- Força criatividade rápida

### Mindset de Design Thinking

1. **Centrado no humano** — Comece pelo cliente, não pela solução
2. **Colaborativo** — Times diversos geram melhores ideias
3. **Experimental** — Teste cedo, falhe barato
4. **Otimista** — Todo problema tem solução
5. **Iterativo** — Volte atrás quantas vezes precisar

> "Design Thinking não é sobre ter a ideia certa. É sobre ter muitas ideias e testar até encontrar a certa."
> — Protocolo Vértice
`
  },
  {
    id: 23,
    title: "Playbook: Implementação de Metodologias Ágeis",
    content: `# Playbook: Implementação de Metodologias Ágeis

## Guia Prático para Transformar sua Operação

Este playbook é um roteiro passo a passo para implementar metodologias ágeis em times de CX. Não tente fazer tudo de uma vez — comece pequeno e evolua.

### Fase 1: Preparação (Semanas 1-2)

**Objetivo:** Criar as condições para começar

**Ações:**
1. **Escolha um time piloto**
   - 5-9 pessoas
   - Problema claro para resolver
   - Liderança engajada

2. **Defina o escopo inicial**
   - Um processo ou projeto específico
   - Métricas de sucesso claras
   - Prazo de 3 meses para avaliar

3. **Prepare o ambiente**
   - Quadro Kanban (físico ou digital)
   - Sala/horário para reuniões
   - Ferramentas básicas (Trello, Jira, ou post-its)

4. **Alinhe expectativas**
   - Comunique o "porquê"
   - Explique que é experimento
   - Peça paciência e abertura

### Fase 2: Kickoff (Semana 3)

**Objetivo:** Começar com o pé direito

**Workshop de Kickoff (4 horas):**

**Parte 1: Contexto (1h)**
- Por que estamos fazendo isso?
- O que são metodologias ágeis?
- O que vamos experimentar?

**Parte 2: Mapeamento (1h)**
- Qual nosso processo atual?
- Onde estão os gargalos?
- O que queremos melhorar?

**Parte 3: Setup (1h)**
- Montar o quadro Kanban
- Definir colunas e limites de WIP
- Criar primeiros cartões

**Parte 4: Acordos (1h)**
- Quando são as reuniões?
- Quem faz o quê?
- Como vamos medir sucesso?

### Fase 3: Execução (Semanas 4-12)

**Objetivo:** Rodar o processo e aprender

**Rotina Semanal:**

| Dia | Atividade | Duração |
|-----|-----------|---------|
| Segunda | Planning (se Scrum) | 1-2h |
| Diário | Daily standup | 15min |
| Sexta | Review + Retro | 1-2h |

**Daily Standup:**
- Mesmo horário todo dia
- Em pé (para ser rápido)
- 3 perguntas por pessoa:
  1. O que fiz ontem?
  2. O que farei hoje?
  3. Algum impedimento?

**Review (semanal ou quinzenal):**
- O que entregamos?
- Demonstração para stakeholders
- Feedback coletado

**Retrospectiva:**
- O que funcionou bem?
- O que podemos melhorar?
- Ações concretas para próximo ciclo

### Fase 4: Otimização (Semanas 13+)

**Objetivo:** Refinar e escalar

**Análise de Métricas:**
- Lead time está diminuindo?
- Throughput está aumentando?
- Qualidade está melhorando?

**Ajustes Comuns:**
- Limites de WIP muito altos/baixos
- Colunas que não fazem sentido
- Reuniões muito longas/curtas

**Decisão de Escala:**
- Funcionou? Expanda para outros times
- Não funcionou? Analise o porquê antes de desistir

### Checklist de Implementação

**Preparação:**
- [ ] Time piloto definido
- [ ] Sponsor executivo confirmado
- [ ] Escopo e métricas claros
- [ ] Ferramentas disponíveis

**Kickoff:**
- [ ] Workshop realizado
- [ ] Quadro montado
- [ ] Acordos documentados
- [ ] Primeiro backlog criado

**Execução:**
- [ ] Dailies acontecendo
- [ ] Reviews com stakeholders
- [ ] Retrospectivas gerando ações
- [ ] Métricas sendo coletadas

**Otimização:**
- [ ] Dados analisados mensalmente
- [ ] Ajustes implementados
- [ ] Aprendizados documentados
- [ ] Plano de escala definido

### Armadilhas a Evitar

**1. "Ágil de Fachada"**
- Fazer cerimônias sem propósito
- Quadro existe mas ninguém usa
- Solução: Foque no valor, não no ritual

**2. "Tudo ao Mesmo Tempo"**
- Implementar Scrum + Kanban + OKRs de uma vez
- Solução: Comece com uma coisa, domine, depois adicione

**3. "Sem Apoio da Liderança"**
- Time quer, mas chefe não libera tempo
- Solução: Envolva liderança desde o início

**4. "Desistir Cedo Demais"**
- "Tentamos por 2 semanas e não funcionou"
- Solução: Mínimo 3 meses para avaliar

**5. "Copiar sem Adaptar"**
- "O Google faz assim, vamos fazer igual"
- Solução: Adapte ao seu contexto

### Métricas de Sucesso

**Curto Prazo (1-3 meses):**
- Time usando o quadro diariamente
- Reuniões acontecendo no ritmo
- Primeiras melhorias implementadas

**Médio Prazo (3-6 meses):**
- Lead time reduzido em 20%+
- Satisfação do time aumentando
- Stakeholders vendo valor

**Longo Prazo (6-12 meses):**
- Cultura de melhoria contínua
- Outros times querendo adotar
- Resultados de negócio impactados

> "Implementar ágil não é um projeto com fim. É uma jornada de melhoria contínua."
> — Protocolo Vértice
`
  }
];

async function generateAndSaveContent(contentData: { id: number; title: string; content: string }) {
  try {
    const fileName = "content_" + contentData.id + "_" + Date.now() + ".md";
    const buffer = Buffer.from(contentData.content, 'utf-8');
    
    const { url } = await storagePut(fileName, buffer, 'text/markdown');
    
    await db.update(contents)
      .set({ 
        fileUrl: url,
        mimeType: 'text/markdown',
        updatedAt: new Date()
      })
      .where(eq(contents.id, contentData.id));
    
    console.log("✅ Conteúdo " + contentData.id + " atualizado: " + contentData.title);
    return true;
  } catch (error) {
    console.error("❌ Erro ao atualizar conteúdo " + contentData.id + ":", error);
    return false;
  }
}

async function main() {
  console.log("🚀 Gerando conteúdos autorais - Batch 2 (Metodologias Ágeis)...");
  
  for (const content of contentsBatch2) {
    await generateAndSaveContent(content);
  }
  
  console.log("\n✅ Batch 2 concluído!");
  process.exit(0);
}

main().catch(console.error);
