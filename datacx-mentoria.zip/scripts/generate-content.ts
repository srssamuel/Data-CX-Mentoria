import { drizzle } from "drizzle-orm/mysql2";
import { contents } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { storagePut } from "../server/storage";

const db = drizzle(process.env.DATABASE_URL!);

// Conteúdos autorais para Data Storytelling
const dataStorytellingContents = [
  {
    id: 1,
    title: "Módulo 1: Introdução ao Data Storytelling",
    content: `# Introdução ao Data Storytelling

## Por que Data Storytelling é o Diferencial Competitivo do Século XXI

Segundo a Gartner, até 2025, **80% de todas as inovações de negócios serão baseadas em dados visualizados**. Mas ter dados não é suficiente — o verdadeiro poder está em transformá-los em narrativas que movem pessoas e decisões.

### O Que é Data Storytelling?

Data Storytelling é a arte de transformar números em histórias que conectam, convencem e convertem. Não se trata apenas de criar gráficos bonitos, mas de construir uma narrativa que:

- **Contextualiza** os dados dentro de uma realidade de negócio
- **Conecta** emocionalmente com a audiência
- **Conduz** a uma ação específica

### O Caso Florence Nightingale

A primeira grande contribuição de dados na história veio de uma enfermeira durante a Guerra da Crimeia. Florence Nightingale não apenas coletou dados — ela os transformou em uma história visual tão poderosa que convenceu as autoridades britânicas a reformar completamente o sistema hospitalar militar.

Ela provou que mais soldados morriam por condições de higiene do que por ferimentos de guerra. Seu "diagrama de rosa" foi revolucionário: transformou estatísticas frias em uma narrativa visual impossível de ignorar.

### A Pirâmide do Conhecimento

Para dominar Data Storytelling, você precisa entender a progressão:

1. **Dados** → Fatos brutos, números sem contexto
2. **Informação** → Dados organizados e contextualizados
3. **Conhecimento** → Informação processada e compreendida
4. **Insight** → Conhecimento que gera ação

**Seu objetivo como profissional de CX e Dados é sempre chegar ao insight** — aquele momento "aha!" que transforma a forma como sua empresa opera.

### Aplicação Prática no Protocolo Vértice

No contexto do Protocolo Vértice, Data Storytelling é uma das competências fundamentais para:

- Apresentar resultados de projetos de CX para stakeholders
- Justificar investimentos em experiência do cliente
- Demonstrar ROI de iniciativas de transformação digital
- Influenciar decisões estratégicas com evidências

> "Tenha opiniões baseadas em dados, mas apresente-as como histórias que movem pessoas."
> — Protocolo Vértice

### Próximos Passos

Nos próximos módulos, você aprenderá:
- Métodos de coleta de dados eficazes
- Técnicas de transformação de dados em narrativas
- Escolha do visual certo para cada situação
- Como estruturar um pitch baseado em dados

**Exercício:** Identifique uma decisão recente na sua empresa que foi tomada sem dados. Como você poderia ter usado Data Storytelling para influenciar essa decisão?
`
  },
  {
    id: 2,
    title: "A História de Florence Nightingale",
    content: `# A História de Florence Nightingale: A Mãe do Data Storytelling

## Como Uma Enfermeira Mudou o Mundo com Dados

Florence Nightingale não era apenas uma enfermeira dedicada — ela era uma estatística brilhante que entendeu, há mais de 150 anos, o poder de transformar dados em histórias visuais.

### O Contexto

Durante a Guerra da Crimeia (1853-1856), Florence foi enviada para cuidar de soldados britânicos feridos. O que ela encontrou foi devastador: hospitais superlotados, condições sanitárias deploráveis e uma taxa de mortalidade assustadora.

### A Descoberta

Enquanto outros viam apenas caos, Florence viu padrões. Ela começou a coletar dados meticulosamente:

- Número de mortes por mês
- Causas das mortes
- Condições do hospital
- Procedimentos de higiene

### O Insight Revolucionário

Os dados revelaram uma verdade chocante: **mais soldados morriam de doenças evitáveis do que de ferimentos de guerra**. A falta de higiene, ventilação e cuidados básicos estava matando mais que as balas inimigas.

### O Diagrama de Rosa

Florence sabia que números em uma tabela não convenceriam ninguém. Ela precisava de algo visual, impactante, impossível de ignorar.

Criou então o famoso "Diagrama de Rosa" (ou Diagrama de Área Polar) — uma visualização inovadora que mostrava claramente:

- Mortes por doenças evitáveis (em azul)
- Mortes por ferimentos (em vermelho)
- Mortes por outras causas (em preto)

O impacto visual era devastador: a área azul dominava completamente o gráfico.

### O Resultado

Armada com seus dados e visualizações, Florence apresentou suas descobertas ao Parlamento Britânico. O resultado:

- Reforma completa do sistema hospitalar militar
- Criação de padrões de higiene hospitalar
- Redução drástica na taxa de mortalidade
- Fundação da enfermagem moderna como profissão

### Lições para o Profissional de CX

1. **Dados sem contexto são inúteis** — Florence não apresentou apenas números, mas uma história de vida e morte

2. **Visualização é persuasão** — O diagrama de rosa comunicou em segundos o que páginas de relatórios não conseguiriam

3. **Dados devem gerar ação** — O objetivo não era informar, mas transformar

4. **Persistência com evidências vence** — Florence enfrentou resistência, mas os dados eram irrefutáveis

### Aplicação no Protocolo Vértice

Quando você apresentar dados de CX para sua liderança, pergunte-se:

- Qual é a "história de Florence" dos meus dados?
- Qual visualização tornará meu ponto impossível de ignorar?
- Que ação específica quero que tomem após ver isso?

> "Os dados são a munição. A visualização é a arma. A narrativa é a estratégia."
> — Protocolo Vértice
`
  },
  {
    id: 24,
    title: "Pilar 2: Fundamentos de Customer Experience",
    content: `# Fundamentos de Customer Experience

## A Experiência do Cliente Como Vantagem Competitiva Definitiva

Segundo pesquisa da American Express, **60% dos clientes estão dispostos a pagar mais por produtos ou serviços que ofereçam uma boa experiência**. Em um mundo onde produtos e preços são facilmente copiados, a experiência do cliente se tornou o único diferencial sustentável.

### O Que é Customer Experience?

Customer Experience (CX) é a **percepção total** que o cliente tem da sua marca, construída em cada ponto de contato:

- Propaganda e marketing
- Navegação no site
- Processo de compra
- Atendimento ao cliente
- Uso do produto/serviço
- Pós-venda e suporte

### O Caso Uber vs Táxi

Antes do Uber, clientes de táxi provavelmente tinham uma percepção "ok" do serviço — simplesmente porque não havia comparação. Quando o Uber chegou oferecendo:

- Preços transparentes
- Carros mais confortáveis
- App intuitivo
- Avaliação de motoristas

A percepção sobre "o que é um bom serviço de transporte" mudou completamente. Táxis que antes eram "aceitáveis" passaram a ser "ruins" — não porque pioraram, mas porque a régua subiu.

**Lição:** Seus concorrentes estão constantemente redefinindo as expectativas dos seus clientes.

### Os 7 Pilares de uma Experiência Excepcional

**1. Conheça Profundamente Seu Cliente**
- Pesquisas qualitativas e quantitativas
- Análise de comportamento
- Personas detalhadas

**2. Mapeie a Jornada Completa**
- Todos os pontos de contato
- Momentos de verdade
- Pontos de fricção

**3. Crie Momentos WOW**
- Supere expectativas em pontos-chave
- Personalize quando possível
- Surpreenda positivamente

**4. Empodere Sua Equipe**
- Treinamento contínuo
- Autonomia para resolver problemas
- Cultura customer-centric

**5. Meça e Monitore**
- NPS, CSAT, CES
- Feedback em tempo real
- Análise de tendências

**6. Aja Sobre o Feedback**
- Feche o loop com clientes
- Implemente melhorias
- Comunique mudanças

**7. Inove Continuamente**
- Antecipe necessidades
- Teste novas abordagens
- Aprenda com erros

### O Protocolo Vértice em CX

No Protocolo Vértice, CX não é um departamento — é uma mentalidade que permeia toda a organização. Nosso framework integra:

- **Dados** para entender comportamentos
- **IA** para personalizar experiências
- **Governança** para garantir consistência

> "Experiência do cliente não é o que você faz PARA o cliente. É o que o cliente SENTE sobre você."
> — Protocolo Vértice
`
  },
  {
    id: 28,
    title: "Métricas de CX: NPS, CSAT, CES e Mais",
    content: `# Métricas de CX: NPS, CSAT, CES e Mais

## Medindo o Que Realmente Importa

"O que não é medido não é gerenciado." Em CX, as métricas certas são a diferença entre achismo e decisão baseada em evidências.

### As 3 Métricas Fundamentais

**1. NPS (Net Promoter Score)**

A métrica mais popular de CX, mede a probabilidade de recomendação.

*Pergunta:* "Em uma escala de 0 a 10, qual a probabilidade de você recomendar nossa empresa a um amigo?"

*Cálculo:*
- Promotores (9-10): % de promotores
- Neutros (7-8): ignorados no cálculo
- Detratores (0-6): % de detratores
- **NPS = % Promotores - % Detratores**

*Benchmarks:*
- Abaixo de 0: Crítico
- 0-30: Bom
- 30-50: Muito bom
- 50-70: Excelente
- Acima de 70: Classe mundial

**2. CSAT (Customer Satisfaction Score)**

Mede a satisfação com uma interação específica.

*Pergunta:* "Quão satisfeito você está com [interação específica]?"

*Escala:* 1-5 ou 1-7

*Cálculo:* % de respostas positivas (4-5 em escala de 5)

**3. CES (Customer Effort Score)**

Mede o esforço que o cliente precisou fazer.

*Pergunta:* "Quão fácil foi [realizar ação específica]?"

*Escala:* 1-7 (muito difícil → muito fácil)

*Por que importa:*
- 96% dos clientes que têm experiências de alto esforço se tornam desleais
- Reduzir esforço é mais impactante que encantar

### Framework de Métricas Protocolo Vértice

**Nível Estratégico (Mensal/Trimestral)**
- NPS Relacional
- CLV
- Churn Rate

**Nível Tático (Semanal)**
- CSAT por canal
- CES por jornada
- FCR

**Nível Operacional (Diário)**
- Volume de contatos
- Tempo de resposta
- Taxa de resolução

### Erros Comuns

1. **Medir demais** — Foco em poucas métricas que importam
2. **Não agir** — Métricas sem ação são desperdício
3. **Ignorar contexto** — Números precisam de qualitativo
4. **Comparar errado** — Benchmarks devem ser do seu setor
5. **Manipular** — Métricas devem refletir realidade

> "Métricas são o espelho da experiência. Mas o espelho não muda a realidade — suas ações sim."
> — Protocolo Vértice
`
  }
];

async function generateAndSaveContent(contentData: { id: number; title: string; content: string }) {
  try {
    const pdfContent = contentData.content;
    const fileName = "content_" + contentData.id + "_" + Date.now() + ".md";
    const buffer = Buffer.from(pdfContent, 'utf-8');
    
    const { url } = await storagePut(fileName, buffer, 'text/markdown');
    
    await db.update(contents)
      .set({ 
        fileUrl: url,
        mimeType: 'text/markdown',
        updatedAt: new Date()
      })
      .where(eq(contents.id, contentData.id));
    
    console.log("✅ Conteúdo " + contentData.id + " atualizado: " + contentData.title);
    return true;
  } catch (error) {
    console.error("❌ Erro ao atualizar conteúdo " + contentData.id + ":", error);
    return false;
  }
}

async function main() {
  console.log("🚀 Iniciando geração de conteúdos autorais...");
  
  for (const content of dataStorytellingContents) {
    await generateAndSaveContent(content);
  }
  
  console.log("\\n✅ Geração de conteúdos concluída!");
  process.exit(0);
}

main().catch(console.error);
