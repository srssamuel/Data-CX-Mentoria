import { db } from "../server/db";
import { contents } from "../drizzle/schema";
import { eq, sql } from "drizzle-orm";
import * as fs from "fs";

async function main() {
  const rows = await db.select({
    id: contents.id,
    moduleCode: contents.moduleCode,
    title: contents.title,
    category: contents.category,
  }).from(contents).where(eq(contents.type, "module")).orderBy(sql`FIELD(category, 'introducao', 'cx', 'dados', 'ia')`, contents.sortOrder, contents.id);
  
  fs.writeFileSync("/home/ubuntu/modules-list.json", JSON.stringify(rows, null, 2));
  console.log("Exported " + rows.length + " modules");
  rows.forEach((r: any) => console.log(r.moduleCode + " | " + r.category + " | " + r.title));
  process.exit(0);
}
main().catch(e => { console.error(e); process.exit(1); });
