#!/usr/bin/env python3
"""
Generate audio narration for module persona versions using edge-tts (Microsoft Edge TTS).
Uses pt-BR-FranciscoNeural voice (Daniel) for professional Brazilian Portuguese narration.
Voice: conversacional-executivo, velocidade 0.95x, tom de 'mentor em sala de guerra'.

Usage: python3 scripts/generate-audio.py [--content-id ID] [--persona PERSONA] [--all]
"""
import asyncio
import argparse
import os
import sys
import json
import tempfile
import time

# Add Manus API client path
sys.path.append('/opt/.manus/.sandbox-runtime')

import edge_tts
import mysql.connector

# Voice config per persona
# Daniel (narrador) = pt-BR-AntonioNeural (voz masculina brasileira, natural e profissional)
# Velocidade base: -5% (0.95x) para ser didático sem arrastar
# Pitch levemente mais grave para autoridade executiva
VOICE_CONFIG = {
    "jovem": {"voice": "pt-BR-AntonioNeural", "rate": "-3%", "pitch": "+0Hz"},
    "gestor": {"voice": "pt-BR-AntonioNeural", "rate": "-5%", "pitch": "-1Hz"},
    "executivo": {"voice": "pt-BR-AntonioNeural", "rate": "-7%", "pitch": "-2Hz"},
    "empresario": {"voice": "pt-BR-AntonioNeural", "rate": "-5%", "pitch": "-1Hz"},
}

def get_db_connection():
    url = os.environ.get("DATABASE_URL", "")
    # Parse mysql://user:pass@host:port/db?ssl=...
    from urllib.parse import urlparse, parse_qs
    parsed = urlparse(url)
    ssl_config = {}
    qs = parse_qs(parsed.query)
    if 'ssl-mode' in qs or 'sslaccept' in qs:
        ssl_config = {"ssl_disabled": False}
    
    return mysql.connector.connect(
        host=parsed.hostname,
        port=parsed.port or 3306,
        user=parsed.username,
        password=parsed.password,
        database=parsed.path.lstrip('/'),
        **ssl_config
    )

def upload_to_s3(file_path, s3_key):
    """Upload file to S3 via Forge storage API"""
    import requests
    
    forge_url = os.environ.get("BUILT_IN_FORGE_API_URL", "").rstrip("/")
    forge_key = os.environ.get("BUILT_IN_FORGE_API_KEY", "")
    
    upload_url = f"{forge_url}/v1/storage/upload?path={s3_key}"
    
    with open(file_path, "rb") as f:
        files = {"file": (os.path.basename(file_path), f, "audio/mpeg")}
        headers = {"Authorization": f"Bearer {forge_key}"}
        resp = requests.post(upload_url, files=files, headers=headers)
    
    if resp.status_code != 200:
        raise Exception(f"Upload failed: {resp.status_code} {resp.text}")
    
    return resp.json().get("url", "")

async def generate_audio(text, voice_cfg, output_path):
    """Generate audio using edge-tts"""
    communicate = edge_tts.Communicate(
        text=text,
        voice=voice_cfg["voice"],
        rate=voice_cfg["rate"],
        pitch=voice_cfg["pitch"],
    )
    await communicate.save(output_path)
    
    # Get file size and estimate duration
    file_size = os.path.getsize(output_path)
    # MP3 at ~48kbps (edge-tts default) = ~6KB/s
    estimated_duration = file_size / 6000
    return estimated_duration

async def process_version(conn, content_id, persona, force=False):
    """Process a single content+persona version"""
    cursor = conn.cursor(dictionary=True)
    
    # Get the version
    cursor.execute(
        "SELECT id, audioScriptAdmin, audioStatus, audioUrl FROM content_persona_versions WHERE contentId = %s AND persona = %s",
        (content_id, persona)
    )
    version = cursor.fetchone()
    
    if not version:
        print(f"  ⚠️  No version found for content {content_id} persona {persona}")
        return False
    
    if version["audioStatus"] == "ready" and version["audioUrl"] and not force:
        print(f"  ⏭️  Audio already ready - skipping")
        return True
    
    script = version["audioScriptAdmin"]
    if not script:
        print(f"  ⚠️  No audio script available")
        return False
    
    voice_cfg = VOICE_CONFIG.get(persona, VOICE_CONFIG["gestor"])
    
    # Update status
    cursor.execute(
        "UPDATE content_persona_versions SET audioStatus = 'generating' WHERE id = %s",
        (version["id"],)
    )
    conn.commit()
    
    try:
        # Generate audio
        with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp:
            tmp_path = tmp.name
        
        start_time = time.time()
        duration = await generate_audio(script, voice_cfg, tmp_path)
        gen_time = time.time() - start_time
        
        file_size = os.path.getsize(tmp_path)
        print(f"    🎙️ Audio generated ({gen_time:.1f}s, {file_size/1024:.0f}KB, ~{duration:.0f}s)")
        
        # Upload to S3
        # Get moduleCode
        cursor.execute("SELECT moduleCode FROM contents WHERE id = %s", (content_id,))
        content = cursor.fetchone()
        module_code = content["moduleCode"] if content else f"mod-{content_id}"
        
        s3_key = f"audio/modules/{module_code}-{persona}-{int(time.time())}.mp3"
        audio_url = upload_to_s3(tmp_path, s3_key)
        
        print(f"    ☁️ Uploaded: {audio_url[:80]}...")
        
        # Update DB
        cursor.execute(
            "UPDATE content_persona_versions SET audioUrl = %s, audioDurationSeconds = %s, audioStatus = 'ready' WHERE id = %s",
            (audio_url, int(duration), version["id"])
        )
        conn.commit()
        
        # Cleanup
        os.unlink(tmp_path)
        
        return True
        
    except Exception as e:
        print(f"    ❌ Error: {e}")
        cursor.execute(
            "UPDATE content_persona_versions SET audioStatus = 'error' WHERE id = %s",
            (version["id"],)
        )
        conn.commit()
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)
        return False

async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--content-id", type=int, help="Specific content ID")
    parser.add_argument("--persona", type=str, help="Specific persona")
    parser.add_argument("--all", action="store_true", help="Process all pending versions")
    parser.add_argument("--force", action="store_true", help="Regenerate even if already ready")
    args = parser.parse_args()
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    if args.content_id and args.persona:
        print(f"Processing content {args.content_id} persona {args.persona}")
        await process_version(conn, args.content_id, args.persona, args.force)
    elif args.all:
        # Get all versions that need audio
        if args.force:
            cursor.execute("SELECT DISTINCT contentId, persona FROM content_persona_versions WHERE apostilaStatus = 'ready'")
        else:
            cursor.execute("SELECT DISTINCT contentId, persona FROM content_persona_versions WHERE apostilaStatus = 'ready' AND (audioStatus != 'ready' OR audioUrl IS NULL)")
        
        rows = cursor.fetchall()
        print(f"Found {len(rows)} versions to process")
        
        success = 0
        errors = 0
        for row in rows:
            print(f"\n📚 Content {row['contentId']} - {row['persona']}")
            if await process_version(conn, row["contentId"], row["persona"], args.force):
                success += 1
            else:
                errors += 1
        
        print(f"\n=== Results ===")
        print(f"✅ Success: {success}")
        print(f"❌ Errors: {errors}")
    else:
        print("Usage: python3 scripts/generate-audio.py --content-id ID --persona PERSONA")
        print("       python3 scripts/generate-audio.py --all")
    
    conn.close()

if __name__ == "__main__":
    asyncio.run(main())
