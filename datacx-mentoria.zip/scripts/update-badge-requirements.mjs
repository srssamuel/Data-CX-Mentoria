import mysql from 'mysql2/promise';

const DATABASE_URL = process.env.DATABASE_URL;

async function updateBadgeRequirements() {
  const connection = await mysql.createConnection(DATABASE_URL);
  
  const badgeUpdates = [
    // Progress badges
    { slug: 'primeiro-passo', requirement: JSON.stringify({ type: 'content_count', value: 1 }) },
    { slug: 'iniciante', requirement: JSON.stringify({ type: 'content_count', value: 5 }) },
    { slug: 'dedicado', requirement: JSON.stringify({ type: 'content_count', value: 10 }) },
    { slug: 'persistente', requirement: JSON.stringify({ type: 'content_count', value: 25 }) },
    { slug: 'mestre-conteudo', requirement: JSON.stringify({ type: 'all_content', value: 1 }) },
    
    // Category badges
    { slug: 'explorador', requirement: JSON.stringify({ type: 'category_complete', value: 1, target: 'introducao' }) },
    { slug: 'especialista-cx', requirement: JSON.stringify({ type: 'category_complete', value: 1, target: 'cx' }) },
    { slug: 'analista-dados', requirement: JSON.stringify({ type: 'category_complete', value: 1, target: 'dados' }) },
    { slug: 'pioneiro-ia', requirement: JSON.stringify({ type: 'category_complete', value: 1, target: 'ia' }) },
    
    // Engagement badges
    { slug: 'radar-completo', requirement: JSON.stringify({ type: 'radar_complete', value: 1 }) },
    { slug: 'testado', requirement: JSON.stringify({ type: 'quiz_complete', value: 1 }) },
    { slug: 'nota-maxima', requirement: JSON.stringify({ type: 'quiz_perfect', value: 1 }) },
    
    // Special badges
    { slug: 'early-adopter', requirement: JSON.stringify({ type: 'early_adopter', value: 100 }) },
    { slug: 'vertice', requirement: JSON.stringify({ type: 'points_total', value: 1000 }) },
  ];
  
  console.log('Updating badge requirements...');
  
  for (const badge of badgeUpdates) {
    try {
      await connection.execute(
        'UPDATE badges SET requirement = ? WHERE slug = ?',
        [badge.requirement, badge.slug]
      );
      console.log(`✓ Updated ${badge.slug}`);
    } catch (error) {
      console.log(`✗ Error updating ${badge.slug}:`, error.message);
    }
  }
  
  await connection.end();
  console.log('Done!');
}

updateBadgeRequirements().catch(console.error);
