import mysql from 'mysql2/promise';

const badges = [
  // Progress badges
  {
    slug: 'primeiro-passo',
    name: 'Primeiro Passo',
    description: 'Complete seu primeiro conteúdo',
    category: 'progress',
    requirement: JSON.stringify({ type: 'contents_completed', value: 1 }),
    pointsReward: 10,
    sortOrder: 1,
  },
  {
    slug: 'iniciante',
    name: 'Iniciante',
    description: 'Complete 5 conteúdos',
    category: 'progress',
    requirement: JSON.stringify({ type: 'contents_completed', value: 5 }),
    pointsReward: 25,
    sortOrder: 2,
  },
  {
    slug: 'dedicado',
    name: 'Dedicado',
    description: 'Complete 10 conteúdos',
    category: 'progress',
    requirement: JSON.stringify({ type: 'contents_completed', value: 10 }),
    pointsReward: 50,
    sortOrder: 3,
  },
  {
    slug: 'persistente',
    name: 'Persistente',
    description: 'Complete 20 conteúdos',
    category: 'progress',
    requirement: JSON.stringify({ type: 'contents_completed', value: 20 }),
    pointsReward: 100,
    sortOrder: 4,
  },
  {
    slug: 'mestre-conteudo',
    name: 'Mestre do Conteúdo',
    description: 'Complete todos os conteúdos disponíveis',
    category: 'progress',
    requirement: JSON.stringify({ type: 'contents_completed', value: 35 }),
    pointsReward: 500,
    sortOrder: 5,
  },
  
  // Category badges
  {
    slug: 'explorador-intro',
    name: 'Explorador',
    description: 'Complete todos os conteúdos de Introdução',
    category: 'achievement',
    requirement: JSON.stringify({ type: 'category_completed', value: 100, target: 'introducao' }),
    pointsReward: 100,
    sortOrder: 10,
  },
  {
    slug: 'especialista-cx',
    name: 'Especialista CX',
    description: 'Complete todos os conteúdos de Customer Experience',
    category: 'achievement',
    requirement: JSON.stringify({ type: 'category_completed', value: 100, target: 'cx' }),
    pointsReward: 100,
    sortOrder: 11,
  },
  {
    slug: 'analista-dados',
    name: 'Analista de Dados',
    description: 'Complete todos os conteúdos de Dados',
    category: 'achievement',
    requirement: JSON.stringify({ type: 'category_completed', value: 100, target: 'dados' }),
    pointsReward: 100,
    sortOrder: 12,
  },
  {
    slug: 'pioneiro-ia',
    name: 'Pioneiro IA',
    description: 'Complete todos os conteúdos de Inteligência Artificial',
    category: 'achievement',
    requirement: JSON.stringify({ type: 'category_completed', value: 100, target: 'ia' }),
    pointsReward: 100,
    sortOrder: 13,
  },
  
  // Engagement badges
  {
    slug: 'radar-completo',
    name: 'Radar Completo',
    description: 'Complete o diagnóstico Radar Vértice',
    category: 'engagement',
    requirement: JSON.stringify({ type: 'radar_completed', value: 1 }),
    pointsReward: 50,
    sortOrder: 20,
  },
  {
    slug: 'primeiro-quiz',
    name: 'Testado',
    description: 'Complete seu primeiro quiz',
    category: 'engagement',
    requirement: JSON.stringify({ type: 'quiz_completed', value: 1 }),
    pointsReward: 25,
    sortOrder: 21,
  },
  {
    slug: 'quiz-perfeito',
    name: 'Nota Máxima',
    description: 'Obtenha 100% em um quiz',
    category: 'engagement',
    requirement: JSON.stringify({ type: 'quiz_perfect', value: 1 }),
    pointsReward: 75,
    sortOrder: 22,
  },
  
  // Special badges
  {
    slug: 'early-adopter',
    name: 'Early Adopter',
    description: 'Um dos primeiros membros da plataforma',
    category: 'special',
    requirement: JSON.stringify({ type: 'manual', value: 1 }),
    pointsReward: 200,
    sortOrder: 30,
  },
  {
    slug: 'vertice',
    name: 'Vértice',
    description: 'Alcance o nível máximo de pontuação',
    category: 'special',
    requirement: JSON.stringify({ type: 'level_reached', value: 6 }),
    pointsReward: 1000,
    sortOrder: 31,
  },
];

async function seedBadges() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  
  console.log('Seeding badges...');
  
  for (const badge of badges) {
    try {
      await connection.execute(
        `INSERT INTO badges (slug, name, description, category, requirement, pointsReward, sortOrder, isActive, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, true, NOW())
         ON DUPLICATE KEY UPDATE 
           name = VALUES(name),
           description = VALUES(description),
           category = VALUES(category),
           requirement = VALUES(requirement),
           pointsReward = VALUES(pointsReward),
           sortOrder = VALUES(sortOrder)`,
        [badge.slug, badge.name, badge.description, badge.category, badge.requirement, badge.pointsReward, badge.sortOrder]
      );
      console.log(`✓ Badge "${badge.name}" created/updated`);
    } catch (error) {
      console.error(`✗ Error with badge "${badge.name}":`, error.message);
    }
  }
  
  await connection.end();
  console.log('Done!');
}

seedBadges().catch(console.error);
