/**
 * Script para gerar mini apostilas para módulos
 * Executa via: node --import tsx scripts/generate-apostilas.mjs
 * 
 * Args: --content-ids 30001,30007,30025,30043
 *       --personas jovem,gestor,executivo,empresario
 *       --skip-existing (pula se já existe com status ready)
 *       --retries 3 (número de tentativas por versão)
 *       --delay 5 (segundos entre chamadas LLM)
 */
import mysql from 'mysql2/promise';

const ALL_PERSONAS = ["jovem", "gestor", "executivo", "empresario"];

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function generateWithRetry(generateApostila, title, description, content, persona, pilar, maxRetries, delayMs) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      if (attempt > 1) {
        const backoff = delayMs * attempt;
        console.log(`    ⏳ Retry ${attempt}/${maxRetries} after ${backoff/1000}s...`);
        await sleep(backoff);
      }
      const result = await generateApostila(title, description, content, persona, pilar);
      return result;
    } catch (error) {
      if (attempt === maxRetries) throw error;
      console.log(`    ⚠️  Attempt ${attempt} failed: ${error.message.substring(0, 80)}`);
    }
  }
}

async function main() {
  const args = process.argv.slice(2);
  
  // Parse args
  let contentIds = null;
  let personas = ALL_PERSONAS;
  let skipExisting = false;
  let maxRetries = 3;
  let delayMs = 5000;
  
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--content-ids' && args[i+1]) {
      contentIds = args[i+1].split(',').map(Number);
      i++;
    } else if (args[i] === '--personas' && args[i+1]) {
      personas = args[i+1].split(',');
      i++;
    } else if (args[i] === '--skip-existing') {
      skipExisting = true;
    } else if (args[i] === '--retries' && args[i+1]) {
      maxRetries = parseInt(args[i+1]);
      i++;
    } else if (args[i] === '--delay' && args[i+1]) {
      delayMs = parseInt(args[i+1]) * 1000;
      i++;
    }
  }
  
  const { generateApostila } = await import("../server/apostilaGenerator.ts");
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  
  // Get target modules
  let query = "SELECT id, title, description, markdownContent, pilar, moduleCode FROM contents";
  let params = [];
  
  if (contentIds) {
    query += ` WHERE id IN (${contentIds.map(() => '?').join(',')})`;
    params = contentIds;
  }
  
  query += " ORDER BY pilar, id";
  const [modules] = await conn.execute(query, params);
  
  console.log(`=== Geração de Mini Apostilas ===`);
  console.log(`Módulos: ${modules.length}`);
  console.log(`Personas: ${personas.join(', ')}`);
  console.log(`Total: ${modules.length * personas.length}`);
  console.log(`Skip existing: ${skipExisting}`);
  console.log(`Max retries: ${maxRetries}`);
  console.log(`Delay between calls: ${delayMs/1000}s`);
  console.log('');
  
  let success = 0, skipped = 0, errors = 0;
  
  for (const mod of modules) {
    console.log(`\n📚 ${mod.moduleCode} - ${mod.title}`);
    
    for (const persona of personas) {
      const startTime = Date.now();
      
      // Check existing
      if (skipExisting) {
        const [existing] = await conn.execute(
          "SELECT apostilaStatus FROM content_persona_versions WHERE contentId = ? AND persona = ?",
          [mod.id, persona]
        );
        if (existing.length > 0 && existing[0].apostilaStatus === 'ready') {
          console.log(`  ⏭️  ${persona}: já existe`);
          skipped++;
          continue;
        }
      }
      
      console.log(`  🎯 ${persona}: gerando...`);
      
      // Add delay between calls to reduce upstream pressure
      await sleep(delayMs);
      
      try {
        // Upsert generating status
        const [existing] = await conn.execute(
          "SELECT id FROM content_persona_versions WHERE contentId = ? AND persona = ?",
          [mod.id, persona]
        );
        
        if (existing.length > 0) {
          await conn.execute(
            "UPDATE content_persona_versions SET apostilaStatus = 'generating', audioStatus = 'pending' WHERE contentId = ? AND persona = ?",
            [mod.id, persona]
          );
        } else {
          await conn.execute(
            "INSERT INTO content_persona_versions (contentId, persona, apostilaStatus, audioStatus) VALUES (?, ?, 'generating', 'pending')",
            [mod.id, persona]
          );
        }
        
        // Generate with retry
        const { markdown, audioScript } = await generateWithRetry(
          generateApostila,
          mod.title,
          mod.description || "",
          mod.markdownContent || "",
          persona,
          mod.pilar || "CX",
          maxRetries,
          delayMs
        );
        
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        
        // Save
        await conn.execute(
          "UPDATE content_persona_versions SET apostilaMarkdown = ?, audioScriptAdmin = ?, apostilaStatus = 'ready', generatedAt = NOW() WHERE contentId = ? AND persona = ?",
          [markdown, audioScript, mod.id, persona]
        );
        
        console.log(`  ✅ ${persona}: ${markdown.length} chars, ${elapsed}s`);
        success++;
        
      } catch (error) {
        console.error(`  ❌ ${persona}: ${error.message}`);
        await conn.execute(
          "UPDATE content_persona_versions SET apostilaStatus = 'error' WHERE contentId = ? AND persona = ?",
          [mod.id, persona]
        ).catch(() => {});
        errors++;
      }
    }
  }
  
  await conn.end();
  
  console.log(`\n=== Resultado ===`);
  console.log(`✅ Sucesso: ${success}`);
  console.log(`⏭️  Pulados: ${skipped}`);
  console.log(`❌ Erros: ${errors}`);
}

main().catch(console.error);
