import mysql from 'mysql2/promise';

const contentUpdates = [
  // Data Storytelling PDF
  { id: 1, fileUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/zbvdNIjwlmVcgfJG.pdf' },
  { id: 5, fileUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/zbvdNIjwlmVcgfJG.pdf' },
  { id: 7, fileUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/zbvdNIjwlmVcgfJG.pdf' },
  { id: 14, fileUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/zbvdNIjwlmVcgfJG.pdf' },
  { id: 19, fileUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/zbvdNIjwlmVcgfJG.pdf' },
  { id: 28, fileUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/zbvdNIjwlmVcgfJG.pdf' },
  
  // CX Cap 1 - Estratégias de CX
  { id: 13, fileUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/zDdVQbmaKqdZYMld.pdf' },
  
  // CX Cap 2 - Jornada do Cliente
  { id: 15, fileUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/MCZlPZkZOVugCiVp.pdf' },
  
  // CX Cap 3 - Neuromarketing
  { id: 18, fileUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/UNeaYFwvunuVLwju.pdf' },
  
  // CX Cap 4 - CRM
  { id: 20, fileUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/gVNofKSDWZioEZFT.pdf' },
  
  // CX Cap 5 - Métricas
  { id: 21, fileUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/MxrVBevjaUrIcwtP.pdf' },
  
  // Estatística
  { id: 27, fileUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/zbvdNIjwlmVcgfJG.pdf' },
];

async function main() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  
  console.log('Atualizando conteúdos com URLs dos PDFs...');
  
  for (const update of contentUpdates) {
    try {
      await connection.execute(
        'UPDATE contents SET fileUrl = ? WHERE id = ?',
        [update.fileUrl, update.id]
      );
      console.log(`✓ Conteúdo ${update.id} atualizado`);
    } catch (error) {
      console.error(`✗ Erro ao atualizar conteúdo ${update.id}:`, error.message);
    }
  }
  
  // Verificar resultado
  const [rows] = await connection.execute('SELECT id, title, fileUrl FROM contents WHERE fileUrl IS NOT NULL AND fileUrl != "" LIMIT 20');
  console.log('\\nConteúdos com URLs:', rows.length);
  
  await connection.end();
  console.log('\\nAtualização concluída!');
}

main().catch(console.error);
