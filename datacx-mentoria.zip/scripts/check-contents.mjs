import { drizzle } from "drizzle-orm/mysql2";
import { contents } from "../drizzle/schema.ts";

const db = drizzle(process.env.DATABASE_URL);
const allContents = await db.select().from(contents).orderBy(contents.programId, contents.sortOrder);
console.log("Total de conteúdos:", allContents.length);
allContents.forEach(c => {
  console.log(`ID: ${c.id} | ${c.title} | Type: ${c.type} | FileUrl: ${c.fileUrl ? 'SIM' : 'NÃO'}`);
});
process.exit(0);
