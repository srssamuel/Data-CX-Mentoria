/**
 * Script para gerar mini apostilas + áudios para módulos de teste
 * Executa via: node scripts/generate-test-batch.mjs
 */
import mysql from 'mysql2/promise';

const TEST_MODULES = [
  { id: 30001, code: "INT-01", pilar: "INTRO" },
  { id: 30007, code: "CX-F01", pilar: "CX" },
  { id: 30025, code: "D-F01", pilar: "DADOS" },
  { id: 30043, code: "AI-F01", pilar: "IA" },
];

const PERSONAS = ["jovem", "gestor", "executivo", "empresario"];

// We'll call the tRPC endpoint directly via HTTP
const BASE_URL = "http://localhost:3000";

async function callGenerateApostila(contentId, persona) {
  // Use tRPC batch endpoint
  const input = JSON.stringify({ "0": { json: { contentId, persona } } });
  const url = `${BASE_URL}/api/trpc/personaVersions.generateApostila?batch=1&input=${encodeURIComponent(input)}`;
  
  // We need admin auth - let's use a different approach
  // Call the generation functions directly
  return null;
}

async function main() {
  console.log("=== Geração de Mini Apostilas + Áudios ===");
  console.log(`Módulos: ${TEST_MODULES.length}`);
  console.log(`Personas: ${PERSONAS.length}`);
  console.log(`Total de gerações: ${TEST_MODULES.length * PERSONAS.length}`);
  console.log("");

  // Import the generation functions directly
  const { generateApostila } = await import("../server/apostilaGenerator.ts");
  const { generateSpeech } = await import("../server/_core/tts.ts");
  const { storagePut } = await import("../server/storage.ts");

  const conn = await mysql.createConnection(process.env.DATABASE_URL);

  let successCount = 0;
  let errorCount = 0;

  for (const mod of TEST_MODULES) {
    // Get module content
    const [rows] = await conn.execute(
      "SELECT id, title, description, markdownContent, pilar, moduleCode FROM contents WHERE id = ?",
      [mod.id]
    );
    
    if (rows.length === 0) {
      console.error(`❌ Módulo ${mod.code} (ID ${mod.id}) não encontrado`);
      errorCount++;
      continue;
    }

    const content = rows[0];
    console.log(`\n📚 Módulo: ${content.title} (${content.moduleCode})`);

    for (const persona of PERSONAS) {
      const startTime = Date.now();
      console.log(`  🎯 Persona: ${persona}...`);

      try {
        // Check if already exists
        const [existing] = await conn.execute(
          "SELECT id, apostilaStatus FROM content_persona_versions WHERE contentId = ? AND persona = ?",
          [mod.id, persona]
        );

        if (existing.length > 0 && existing[0].apostilaStatus === "ready") {
          console.log(`  ⏭️  Já existe (status: ready) - pulando`);
          continue;
        }

        // Mark as generating
        if (existing.length > 0) {
          await conn.execute(
            "UPDATE content_persona_versions SET apostilaStatus = 'generating', audioStatus = 'pending' WHERE contentId = ? AND persona = ?",
            [mod.id, persona]
          );
        } else {
          await conn.execute(
            "INSERT INTO content_persona_versions (contentId, persona, apostilaStatus, audioStatus) VALUES (?, ?, 'generating', 'pending')",
            [mod.id, persona]
          );
        }

        // Generate apostila + audio script
        console.log(`    📝 Gerando apostila...`);
        const { markdown, audioScript } = await generateApostila(
          content.title,
          content.description || "",
          content.markdownContent || "",
          persona,
          content.pilar || "CX"
        );

        const apostilaTime = Date.now() - startTime;
        console.log(`    ✅ Apostila gerada (${(apostilaTime / 1000).toFixed(1)}s, ${markdown.length} chars)`);

        // Save apostila
        await conn.execute(
          "UPDATE content_persona_versions SET apostilaMarkdown = ?, audioScriptAdmin = ?, apostilaStatus = 'ready', audioStatus = 'generating', generatedAt = NOW() WHERE contentId = ? AND persona = ?",
          [markdown, audioScript, mod.id, persona]
        );

        // Generate audio
        console.log(`    🎙️ Gerando áudio...`);
        const ttsResult = await generateSpeech({
          text: audioScript,
          voice: "nova",
          speed: 1.0,
        });

        if ("error" in ttsResult) {
          console.error(`    ❌ Erro TTS: ${ttsResult.error}`);
          await conn.execute(
            "UPDATE content_persona_versions SET audioStatus = 'error' WHERE contentId = ? AND persona = ?",
            [mod.id, persona]
          );
          errorCount++;
        } else {
          // Upload to S3
          const audioKey = `audio/modules/${content.moduleCode}-${persona}-${Date.now()}.mp3`;
          const { url: audioUrl } = await storagePut(audioKey, ttsResult.audioBuffer, "audio/mpeg");
          const estimatedDuration = Math.round(ttsResult.audioBuffer.length / 16000);

          await conn.execute(
            "UPDATE content_persona_versions SET audioUrl = ?, audioDurationSeconds = ?, audioStatus = 'ready' WHERE contentId = ? AND persona = ?",
            [audioUrl, estimatedDuration, mod.id, persona]
          );

          const totalTime = Date.now() - startTime;
          console.log(`    ✅ Áudio gerado (${(totalTime / 1000).toFixed(1)}s, ~${estimatedDuration}s duração, URL: ${audioUrl.substring(0, 60)}...)`);
          successCount++;
        }
      } catch (error) {
        console.error(`    ❌ Erro: ${error.message}`);
        await conn.execute(
          "UPDATE content_persona_versions SET apostilaStatus = 'error', audioStatus = 'error' WHERE contentId = ? AND persona = ?",
          [mod.id, persona]
        ).catch(() => {});
        errorCount++;
      }
    }
  }

  await conn.end();

  console.log(`\n=== Resultado ===`);
  console.log(`✅ Sucesso: ${successCount}`);
  console.log(`❌ Erros: ${errorCount}`);
  console.log(`Total: ${successCount + errorCount}`);
}

main().catch(console.error);
