#!/usr/bin/env node
/**
 * Script para popular conteúdos de Data Storytelling e CX Academy
 * Execute com: node scripts/seed-contents.mjs
 */

import mysql from 'mysql2/promise';

const DATABASE_URL = process.env.DATABASE_URL;

const dataStorytellingContents = [
  // Módulo 1 - Fundamentos de Data Storytelling
  {
    title: "Módulo 1: Introdução ao Data Storytelling",
    description: "Entenda o que é Data Storytelling e por que 80% das inovações de negócios até 2025 serão baseadas em dados visualizados. Aprenda a transformar dados em narrativas poderosas para comunicação eficaz.",
    type: "video",
    sortOrder: 1,
  },
  {
    title: "A História de Florence Nightingale",
    description: "Como uma enfermeira revolucionou a estatística médica durante a guerra da Crimeia, provando através de dados que as más condições de higiene causavam mais mortes que os ferimentos de guerra.",
    type: "document",
    sortOrder: 2,
  },
  {
    title: "Dados, Informação e Insight: A Pirâmide do Conhecimento",
    description: "Diferencie dados brutos de informação processada e insights acionáveis. Aprenda a subir na pirâmide do conhecimento para gerar valor real para o negócio.",
    type: "video",
    sortOrder: 3,
  },
  
  // Módulo 2 - Coleta e Pesquisa
  {
    title: "Módulo 2: Métodos de Coleta de Dados",
    description: "Explore os três tipos de coleta: contínua, periódica e ocasional. Aprenda quando usar cada método e como escolher o mais adequado para sua necessidade.",
    type: "video",
    sortOrder: 4,
  },
  {
    title: "Pesquisa Quantitativa vs Qualitativa",
    description: "Entenda as diferenças fundamentais entre pesquisas que medem números e métricas versus aquelas que exploram experiências e percepções. Saiba quando usar cada abordagem.",
    type: "document",
    sortOrder: 5,
  },
  {
    title: "Template: Questionário de Pesquisa Eficaz",
    description: "Modelo prático para criar questionários com perguntas claras, opções equilibradas e imparciais. Inclui exemplos de perguntas quantitativas e qualitativas.",
    type: "template",
    sortOrder: 6,
  },
  
  // Módulo 3 - Narrativa com Dados
  {
    title: "Módulo 3: Transformando Dados em Narrativas",
    description: "Aprenda o framework 'Quem? O quê? Como?' para criar histórias envolventes com dados. Descubra como gerar conexão emocional com seu público através de informações.",
    type: "video",
    sortOrder: 7,
  },
  {
    title: "Show, Don't Tell: A Arte de Mostrar com Dados",
    description: "Técnica cinematográfica aplicada a apresentações de dados. Aprenda a mostrar evidências em vez de apenas contar, criando impacto visual e emocional.",
    type: "video",
    sortOrder: 8,
  },
  {
    title: "Framework: Estrutura de Narrativa com Dados",
    description: "Template completo para estruturar sua apresentação: contexto, conflito, dados de suporte, insight principal e chamada para ação.",
    type: "template",
    sortOrder: 9,
  },
  
  // Módulo 4 - Visualização de Dados
  {
    title: "Módulo 4: Escolhendo o Visual Eficaz",
    description: "Guia completo para selecionar o tipo de gráfico ideal: texto simples, tabelas, mapas de calor, gráficos de pontos, linhas, barras e pizza. Cada visualização tem seu propósito.",
    type: "video",
    sortOrder: 10,
  },
  {
    title: "Gráficos de Linha e Tendências Temporais",
    description: "Domine a arte de mostrar mudanças ao longo do tempo. Aprenda a comparar múltiplas séries e destacar pontos de inflexão importantes.",
    type: "video",
    sortOrder: 11,
  },
  {
    title: "Gráficos de Barra: Comparações Poderosas",
    description: "Quando e como usar gráficos de barras para comparações eficazes. Inclui técnicas para destacar diferenças e criar hierarquia visual.",
    type: "video",
    sortOrder: 12,
  },
  {
    title: "Playbook: Design de Visualizações",
    description: "Guia prático com princípios de design para visualização de dados: simplicidade, clareza, hierarquia visual e uso estratégico de cores.",
    type: "playbook",
    sortOrder: 13,
  },
  
  // Módulo 5 - Pitch e Apresentação
  {
    title: "Módulo 5: Pitch - Sua Ideia Cronometrada",
    description: "Aprenda a técnica do Elevator Pitch aplicada a apresentações de dados. Descubra como capturar atenção nos primeiros segundos e manter o engajamento.",
    type: "video",
    sortOrder: 14,
  },
  {
    title: "Os 4 Passos do Pitch Perfeito",
    description: "1) Mensagem principal, 2) Dor que você soluciona, 3) Solução matadora, 4) Benefícios claros. Estrutura comprovada para apresentações de impacto.",
    type: "video",
    sortOrder: 15,
  },
  {
    title: "Case Study: O Pitch do Airbnb",
    description: "Análise detalhada de como o Airbnb usou dados e storytelling para convencer investidores. Lições aplicáveis para qualquer apresentação de negócios.",
    type: "document",
    sortOrder: 16,
  },
  {
    title: "Template: Estrutura de Pitch 3 Minutos",
    description: "Modelo prático para criar seu pitch de dados em 3 minutos. Inclui cronometragem por seção e dicas para cada etapa.",
    type: "template",
    sortOrder: 17,
  },
];

const cxAcademyContents = [
  // Pilar 1 - Metodologias Ágeis
  {
    title: "Pilar 1: Introdução às Metodologias Ágeis",
    description: "Entenda por que precisamos de novas ferramentas de gestão no mundo VUCA. Visão geral das principais metodologias ágeis usadas no mercado.",
    type: "video",
    sortOrder: 1,
  },
  {
    title: "Scrum: Framework para Times de Alta Performance",
    description: "Aprenda os fundamentos do Scrum: sprints, daily meetings, retrospectivas e papéis. Como implementar em equipes de CX e atendimento.",
    type: "video",
    sortOrder: 2,
  },
  {
    title: "Kanban e Gestão Visual",
    description: "Sistema visual para gerenciar fluxo de trabalho. Aprenda a criar quadros Kanban eficientes para operações de Customer Experience.",
    type: "video",
    sortOrder: 3,
  },
  {
    title: "OKRs: Objetivos e Resultados-Chave",
    description: "Metodologia de definição de metas usada por Google e Intel. Como alinhar objetivos de CX com estratégia organizacional.",
    type: "video",
    sortOrder: 4,
  },
  {
    title: "Design Thinking para CX",
    description: "Metodologia centrada no usuário para resolver problemas complexos. Aplicações práticas em jornada do cliente e inovação em serviços.",
    type: "video",
    sortOrder: 5,
  },
  {
    title: "Playbook: Implementação de Metodologias Ágeis",
    description: "Guia prático para implementar Scrum, Kanban e OKRs em equipes de CX. Inclui templates e checklists.",
    type: "playbook",
    sortOrder: 6,
  },
  
  // Pilar 2 - Customer Experience
  {
    title: "Pilar 2: Fundamentos de Customer Experience",
    description: "Conceitos essenciais de CX: o que é, por que importa e como medir. Diferença entre Customer Experience, Customer Service e Customer Success.",
    type: "video",
    sortOrder: 7,
  },
  {
    title: "Jornada do Cliente: Mapeamento Completo",
    description: "Aprenda a mapear todos os pontos de contato do cliente com sua empresa. Identificação de momentos da verdade e oportunidades de melhoria.",
    type: "video",
    sortOrder: 8,
  },
  {
    title: "Processo de Decisão e Neuromarketing",
    description: "Como o cérebro do cliente toma decisões. Aplicações de neurociência para melhorar experiências e aumentar conversão.",
    type: "video",
    sortOrder: 9,
  },
  {
    title: "CRM e Gestão de Relacionamento",
    description: "Estratégias de CRM para personalização em escala. Como usar dados de clientes para criar experiências memoráveis.",
    type: "video",
    sortOrder: 10,
  },
  {
    title: "Métricas de CX: NPS, CSAT, CES e Mais",
    description: "Guia completo das principais métricas de Customer Experience. Como medir, interpretar e agir sobre os resultados.",
    type: "video",
    sortOrder: 11,
  },
  {
    title: "Template: Mapa de Jornada do Cliente",
    description: "Modelo editável para mapear a jornada completa do cliente. Inclui personas, touchpoints, emoções e oportunidades.",
    type: "template",
    sortOrder: 12,
  },
  
  // Pilar 3 - Ferramentas Técnicas
  {
    title: "Pilar 3: Noções de Estatística para CX",
    description: "Fundamentos estatísticos essenciais: tipos de dados, medidas de tendência central, dispersão e amostragem.",
    type: "video",
    sortOrder: 13,
  },
  {
    title: "Visualização de Dados com Excel e Power BI",
    description: "Técnicas intermediárias e avançadas para criar dashboards e relatórios visuais impactantes.",
    type: "video",
    sortOrder: 14,
  },
  {
    title: "Métodos de Resolução de Problemas",
    description: "Ferramentas práticas: Diagrama de Ishikawa, Pareto, Matriz GUT, SWOT e 5 Porquês aplicados a CX.",
    type: "video",
    sortOrder: 15,
  },
  {
    title: "Business Intelligence para CX",
    description: "Introdução a BI: conceitos, arquitetura de dados, ETL e entrega de informações para tomada de decisão.",
    type: "video",
    sortOrder: 16,
  },
  {
    title: "Big Data e Analytics em Customer Experience",
    description: "Como usar grandes volumes de dados para entender comportamento do cliente e prever tendências.",
    type: "video",
    sortOrder: 17,
  },
  {
    title: "Playbook: Análise de Dados para CX",
    description: "Guia completo para analisar dados de clientes: coleta, limpeza, análise e apresentação de insights acionáveis.",
    type: "playbook",
    sortOrder: 18,
  },
];

async function seedContents() {
  if (!DATABASE_URL) {
    console.error('DATABASE_URL não configurada');
    process.exit(1);
  }

  const connection = await mysql.createConnection(DATABASE_URL);
  
  try {
    console.log('Conectado ao banco de dados');
    
    // Buscar programas existentes
    const [programs] = await connection.execute('SELECT id, slug, name FROM mentorship_programs');
    console.log('Programas encontrados:', programs);
    
    // Encontrar ou criar programa de Data Storytelling
    let dataProgram = programs.find(p => p.slug === 'data-storytelling' || p.name.toLowerCase().includes('data'));
    let cxProgram = programs.find(p => p.slug === 'cx-academy' || p.name.toLowerCase().includes('cx'));
    
    if (!dataProgram) {
      console.log('Criando programa Data Storytelling...');
      await connection.execute(
        `INSERT INTO mentorship_programs (slug, name, description, type, duration, price, features, isActive)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          'data-storytelling',
          'Data Storytelling Masterclass',
          'Aprenda a transformar dados em narrativas poderosas. Curso completo com 5 módulos: fundamentos, coleta de dados, narrativa, visualização e pitch.',
          'group',
          '4 semanas',
          '497.00',
          JSON.stringify([
            '17 aulas em vídeo',
            'Templates e playbooks',
            'Exercícios práticos',
            'Certificado de conclusão',
            'Acesso por 6 meses'
          ]),
          true
        ]
      );
      const [newProgram] = await connection.execute('SELECT id FROM mentorship_programs WHERE slug = ?', ['data-storytelling']);
      dataProgram = { id: newProgram[0].id };
    }
    
    if (!cxProgram) {
      console.log('Criando programa CX Academy...');
      await connection.execute(
        `INSERT INTO mentorship_programs (slug, name, description, type, duration, price, features, isActive)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          'cx-academy',
          'CX Academy - Formação Completa',
          'Formação completa em Customer Experience com 3 pilares: Metodologias Ágeis, Customer Experience e Ferramentas Técnicas.',
          'group',
          '12 semanas',
          '1497.00',
          JSON.stringify([
            '18 módulos de conteúdo',
            'Certificação profissional',
            'Projetos práticos',
            'Mentoria em grupo',
            'Acesso por 12 meses'
          ]),
          true
        ]
      );
      const [newProgram] = await connection.execute('SELECT id FROM mentorship_programs WHERE slug = ?', ['cx-academy']);
      cxProgram = { id: newProgram[0].id };
    }
    
    console.log('Programa Data Storytelling ID:', dataProgram.id);
    console.log('Programa CX Academy ID:', cxProgram.id);
    
    // Inserir conteúdos de Data Storytelling
    console.log('Inserindo conteúdos de Data Storytelling...');
    for (const content of dataStorytellingContents) {
      await connection.execute(
        `INSERT INTO contents (programId, title, description, type, sortOrder, isPublic)
         VALUES (?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE description = VALUES(description)`,
        [dataProgram.id, content.title, content.description, content.type, content.sortOrder, false]
      );
    }
    
    // Inserir conteúdos de CX Academy
    console.log('Inserindo conteúdos de CX Academy...');
    for (const content of cxAcademyContents) {
      await connection.execute(
        `INSERT INTO contents (programId, title, description, type, sortOrder, isPublic)
         VALUES (?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE description = VALUES(description)`,
        [cxProgram.id, content.title, content.description, content.type, content.sortOrder, false]
      );
    }
    
    console.log('Conteúdos inseridos com sucesso!');
    console.log(`- ${dataStorytellingContents.length} conteúdos de Data Storytelling`);
    console.log(`- ${cxAcademyContents.length} conteúdos de CX Academy`);
    
  } catch (error) {
    console.error('Erro:', error);
  } finally {
    await connection.end();
  }
}

seedContents();
