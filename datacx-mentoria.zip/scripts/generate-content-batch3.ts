import { drizzle } from "drizzle-orm/mysql2";
import { contents } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { storagePut } from "../server/storage";

const db = drizzle(process.env.DATABASE_URL!);

const contentsBatch3 = [
  {
    id: 26,
    title: "Processo de Decisão e Neuromarketing",
    content: `# Processo de Decisão e Neuromarketing

## Como o Cérebro do Cliente Decide

Entender como o cérebro humano toma decisões é fundamental para criar experiências que convertem. Neuromarketing aplica neurociência ao comportamento do consumidor.

### O Cérebro Triuno

Paul MacLean propôs que temos três "cérebros" que evoluíram ao longo do tempo:

**Cérebro Reptiliano (Instintivo)**
O mais antigo, responsável por sobrevivência. Responde a: segurança, comida, reprodução. Em CX: Urgência, escassez, medo de perder.

**Cérebro Límbico (Emocional)**
Processa emoções e memórias. Responde a: prazer, dor, conexão social. Em CX: Histórias, pertencimento, recompensas.

**Neocórtex (Racional)**
O mais recente, responsável por lógica e linguagem. Responde a: dados, argumentos, análise. Em CX: Especificações, comparações, ROI.

### A Ordem da Decisão

Contraintuitivamente, decidimos assim: Reptiliano → Límbico → Neocórtex. Primeiro sentimos, depois racionalizamos. Por isso, argumentos lógicos sozinhos raramente convencem.

### Vieses Cognitivos em CX

**Ancoragem**
O primeiro número que vemos influencia nossa percepção. Aplicação: Mostre o preço original antes do desconto. "De R$ 997 por R$ 497" funciona melhor que apenas "R$ 497".

**Aversão à Perda**
Perdas doem mais que ganhos equivalentes alegram. Aplicação: "Não perca" é mais poderoso que "Ganhe". "Você está perdendo R$ 500/mês" > "Você pode economizar R$ 500/mês".

**Prova Social**
Seguimos o que outros fazem. Aplicação: "87% dos clientes recomendam" e depoimentos visíveis. Números específicos são mais críveis que redondos.

**Escassez**
Valorizamos mais o que é raro. Aplicação: "Últimas 3 vagas" e "Oferta válida até sexta". Escassez real é mais ética e eficaz que artificial.

**Efeito Halo**
Uma característica positiva influencia a percepção geral. Aplicação: Primeira impressão impecável no onboarding. Um momento "wow" eleva toda a experiência.

**Paradoxo da Escolha**
Muitas opções paralisam a decisão. Aplicação: Limite opções a 3-5 no máximo. Destaque a "recomendada" para facilitar.

### Gatilhos Emocionais

**Medo**
Funciona, mas use com responsabilidade. "Sua empresa pode estar perdendo clientes agora" é legítimo se verdadeiro.

**Pertencimento**
Humanos são sociais. "Junte-se a 5.000 profissionais" cria comunidade.

**Status**
Queremos ser reconhecidos. "Certificação exclusiva" e "Acesso VIP" apelam para isso.

**Curiosidade**
O cérebro odeia lacunas de informação. "O erro que 90% dos gestores cometem" gera cliques.

**Reciprocidade**
Quando recebemos, queremos retribuir. Conteúdo gratuito de valor gera boa vontade.

### Aplicação Prática em CX

**Na Página de Vendas:**
1. Comece com a dor (reptiliano)
2. Conte uma história de transformação (límbico)
3. Apresente dados e garantias (neocórtex)
4. Adicione prova social e escassez
5. CTA claro e urgente

**No Atendimento:**
1. Reconheça a emoção primeiro
2. Depois apresente a solução
3. Confirme que o problema foi resolvido
4. Surpreenda com algo extra

**No Onboarding:**
1. Reduza fricção ao mínimo
2. Celebre pequenas vitórias
3. Crie senso de progresso
4. Conecte com comunidade

### Ética no Neuromarketing

Conhecer esses princípios traz responsabilidade. Use para criar valor real, não para manipular. A diferença: Manipulação beneficia só você. Persuasão ética beneficia ambos.

> "Entender o cérebro do cliente não é para manipulá-lo. É para servi-lo melhor."
> — Protocolo Vértice
`
  },
  {
    id: 27,
    title: "CRM e Gestão de Relacionamento",
    content: `# CRM e Gestão de Relacionamento

## Transformando Dados em Relacionamentos

CRM (Customer Relationship Management) é mais que software. É uma filosofia de negócio centrada no cliente, suportada por tecnologia e processos.

### O Que é CRM de Verdade

**Não é apenas:**
- Um software de vendas
- Uma lista de contatos
- Um histórico de compras

**É:**
- Visão 360° do cliente
- Personalização em escala
- Relacionamento de longo prazo
- Decisões baseadas em dados

### Os 4 Pilares do CRM

**1. Dados Unificados**
Todas as interações em um lugar: vendas, suporte, marketing, produto. Sem silos, sem informação perdida.

**2. Processos Padronizados**
Fluxos claros para cada etapa do relacionamento. Onboarding, suporte, renovação, upsell.

**3. Automação Inteligente**
Tarefas repetitivas automatizadas. Humanos focam no que exige julgamento.

**4. Análise Contínua**
Métricas de relacionamento monitoradas. Ações baseadas em insights, não achismos.

### Métricas de CRM

**Aquisição:**
- CAC (Custo de Aquisição de Cliente)
- Taxa de conversão por canal
- Tempo médio de venda

**Retenção:**
- Churn rate (taxa de cancelamento)
- NRR (Net Revenue Retention)
- Tempo médio de vida do cliente

**Expansão:**
- Upsell rate
- Cross-sell rate
- Share of wallet

**Satisfação:**
- NPS (Net Promoter Score)
- CSAT (Customer Satisfaction)
- CES (Customer Effort Score)

### Segmentação de Clientes

**Por Valor:**
- Platinum: Top 5% em receita
- Gold: Top 20%
- Silver: Próximos 30%
- Bronze: Restante

**Por Comportamento:**
- Promotores: NPS 9-10
- Neutros: NPS 7-8
- Detratores: NPS 0-6

**Por Ciclo de Vida:**
- Prospect: Ainda não comprou
- Novo: Primeiros 90 dias
- Ativo: Engajado e comprando
- Em risco: Sinais de churn
- Churned: Cancelou

### Automações Essenciais

**Onboarding:**
- Email de boas-vindas (imediato)
- Guia de primeiros passos (dia 1)
- Check-in de sucesso (dia 7)
- Pesquisa de satisfação (dia 30)

**Engajamento:**
- Conteúdo relevante por segmento
- Alertas de inatividade
- Ofertas personalizadas
- Aniversário e datas especiais

**Retenção:**
- Alerta de risco de churn
- Campanha de win-back
- Pesquisa de motivo de saída
- Oferta de reativação

### Implementação de CRM

**Fase 1: Fundação (Mês 1-2)**
- Escolher ferramenta adequada
- Migrar dados existentes
- Configurar campos essenciais
- Treinar equipe básica

**Fase 2: Processos (Mês 3-4)**
- Mapear jornada do cliente
- Criar pipelines de vendas
- Definir automações básicas
- Estabelecer métricas

**Fase 3: Otimização (Mês 5+)**
- Analisar dados coletados
- Refinar segmentações
- Expandir automações
- Integrar com outros sistemas

### Erros Comuns

**1. CRM como Agenda Glorificada**
Só registra contatos, não relacionamentos. Solução: Capture interações, não só dados cadastrais.

**2. Dados Desatualizados**
Informações de 2 anos atrás. Solução: Processo de higienização regular.

**3. Silos de Informação**
Vendas não vê suporte, suporte não vê vendas. Solução: Integração real entre áreas.

**4. Automação Sem Personalização**
Emails genéricos para todos. Solução: Segmente e personalize.

**5. Foco em Ferramenta, Não em Processo**
"Compramos o Salesforce, agora somos customer-centric." Solução: Ferramenta é meio, não fim.

### O CRM do Futuro

**IA Preditiva:** Antecipa necessidades antes do cliente pedir.
**Omnichannel Real:** Mesma experiência em qualquer canal.
**Hiperpersonalização:** Cada cliente é um segmento de um.
**Proatividade:** Resolve problemas antes de virarem reclamações.

> "CRM não é sobre gerenciar clientes. É sobre cultivar relacionamentos que geram valor mútuo."
> — Protocolo Vértice
`
  },
  {
    id: 29,
    title: "Template: Mapa de Jornada do Cliente",
    content: `# Template: Mapa de Jornada do Cliente

## Guia Completo para Mapear a Experiência

O mapa de jornada é a ferramenta mais poderosa para visualizar a experiência do cliente. Este template te guia passo a passo na criação de um mapa acionável.

### Estrutura do Mapa

**Eixo Horizontal: Etapas da Jornada**

1. **Descoberta** — Cliente identifica uma necessidade
2. **Consideração** — Pesquisa opções disponíveis
3. **Decisão** — Escolhe e compra
4. **Onboarding** — Primeiros passos com o produto
5. **Uso** — Utilização regular
6. **Suporte** — Quando precisa de ajuda
7. **Renovação/Expansão** — Continua ou amplia
8. **Advocacy** — Recomenda para outros

**Eixo Vertical: Dimensões de Análise**

Para cada etapa, mapeie:

**Ações:** O que o cliente FAZ?
**Pensamentos:** O que ele PENSA?
**Emoções:** O que ele SENTE?
**Touchpoints:** Onde ele INTERAGE?
**Dores:** O que FRUSTRA?
**Oportunidades:** O que podemos MELHORAR?

### Template Visual

| Etapa | Descoberta | Consideração | Decisão | Onboarding | Uso | Suporte |
|-------|------------|--------------|---------|------------|-----|---------|
| **Ações** | Pesquisa no Google | Compara preços | Preenche cadastro | Assiste tutorial | Usa diariamente | Liga para SAC |
| **Pensamentos** | "Preciso resolver isso" | "Qual é melhor?" | "Será que vale?" | "Como funciona?" | "Está me ajudando?" | "Preciso de ajuda" |
| **Emoções** | 😐 Neutro | 🤔 Ansioso | 😰 Inseguro | 😊 Esperançoso | 😀 Satisfeito | 😤 Frustrado |
| **Touchpoints** | Site, Blog, Ads | Site, Reviews | Checkout | Email, App | App, Dashboard | Chat, Telefone |
| **Dores** | Muita informação | Preços confusos | Cadastro longo | Tutorial genérico | Bugs ocasionais | Espera longa |
| **Oportunidades** | Conteúdo educativo | Comparativo claro | Checkout simplificado | Onboarding personalizado | Proatividade | Autoatendimento |

### Passo a Passo para Criar

**Passo 1: Defina a Persona**
Quem é o cliente que você está mapeando? Seja específico. "Maria, 35 anos, gerente de marketing, primeira vez comprando software de automação."

**Passo 2: Liste as Etapas**
Quais são os momentos-chave da jornada? Adapte as etapas genéricas ao seu contexto.

**Passo 3: Colete Dados**
Fontes: Entrevistas com clientes, dados de analytics, gravações de atendimento, pesquisas de satisfação, feedback de vendas.

**Passo 4: Preencha o Mapa**
Para cada etapa, responda: O que faz? Pensa? Sente? Onde interage? O que frustra?

**Passo 5: Identifique Momentos Críticos**
Onde a emoção é mais negativa? Onde perdemos mais clientes? Onde há maior fricção?

**Passo 6: Priorize Oportunidades**
Quais melhorias teriam maior impacto? Quais são mais viáveis? Crie um roadmap.

### Dicas para um Bom Mapa

**Seja Específico**
Não: "Cliente pesquisa"
Sim: "Cliente digita 'melhor CRM para pequenas empresas' no Google"

**Use Dados Reais**
Não: "Achamos que o cliente sente..."
Sim: "Em 15 entrevistas, 12 mencionaram frustração com..."

**Inclua Emoções**
Números são importantes, mas emoções revelam oportunidades. Use emojis ou escala de sentimento.

**Atualize Regularmente**
A jornada muda. Revise trimestralmente ou após mudanças significativas.

**Envolva Múltiplas Áreas**
Vendas, suporte, produto, marketing — todos têm peças do quebra-cabeça.

### Métricas por Etapa

| Etapa | Métricas-Chave |
|-------|----------------|
| Descoberta | Tráfego, Impressões, CTR |
| Consideração | Tempo no site, Páginas vistas, Downloads |
| Decisão | Taxa de conversão, Abandono de carrinho |
| Onboarding | Ativação, Tempo para primeiro valor |
| Uso | DAU/MAU, Frequência, Depth of use |
| Suporte | CSAT, FCR, Tempo de resolução |
| Renovação | Churn, NRR, Upsell rate |
| Advocacy | NPS, Referrals, Reviews |

### Exemplo Completo: SaaS B2B

**Persona:** João, diretor de operações, empresa de 200 funcionários

**Descoberta:**
- Ação: Pesquisa "como reduzir tempo de atendimento"
- Pensamento: "Preciso resolver isso antes do fim do trimestre"
- Emoção: Pressão, urgência
- Touchpoint: Google, LinkedIn
- Dor: Muitos resultados genéricos
- Oportunidade: Conteúdo específico para seu problema

**Decisão:**
- Ação: Solicita demo, negocia preço
- Pensamento: "Será que meu time vai usar?"
- Emoção: Ansiedade, esperança
- Touchpoint: Vendedor, Proposta
- Dor: Processo de aprovação interno lento
- Oportunidade: Material para ele "vender" internamente

### Próximos Passos

1. Baixe este template
2. Escolha uma persona prioritária
3. Reúna dados existentes
4. Faça 5-10 entrevistas
5. Preencha o mapa em workshop colaborativo
6. Priorize 3 melhorias para os próximos 90 dias

> "O mapa de jornada não é um documento para arquivar. É uma ferramenta viva para transformar experiências."
> — Protocolo Vértice
`
  },
  {
    id: 30,
    title: "Pilar 3: Noções de Estatística para CX",
    content: `# Pilar 3: Noções de Estatística para CX

## Os Fundamentos que Todo Profissional de CX Precisa

Você não precisa ser estatístico para usar dados em CX. Mas precisa entender conceitos básicos para não cair em armadilhas e tomar decisões erradas.

### Medidas de Tendência Central

**Média**
Soma de todos os valores dividida pela quantidade. Útil para: Visão geral. Cuidado: Sensível a outliers.

Exemplo: Tempo médio de atendimento = (5+6+7+8+120) / 5 = 29,2 min. Mas 4 de 5 atendimentos foram abaixo de 10 min! O outlier de 120 distorceu.

**Mediana**
Valor do meio quando ordenados. Útil para: Dados com outliers. No exemplo acima: Mediana = 7 min (muito mais representativo).

**Moda**
Valor mais frequente. Útil para: Dados categóricos. Exemplo: Canal mais usado = WhatsApp (aparece 45% das vezes).

### Medidas de Dispersão

**Amplitude**
Diferença entre maior e menor valor. Simples, mas limitada.

**Desvio Padrão**
Quanto os valores se afastam da média. Baixo = dados concentrados. Alto = dados espalhados.

Exemplo: Duas equipes com NPS médio de 45. Equipe A: desvio padrão 5 (consistente). Equipe B: desvio padrão 25 (inconsistente). Qual você prefere?

**Coeficiente de Variação**
Desvio padrão / Média. Permite comparar dispersão entre métricas diferentes.

### Correlação vs Causalidade

**Correlação:** Duas variáveis se movem juntas.
**Causalidade:** Uma variável CAUSA mudança na outra.

Exemplo perigoso: "Clientes que usam o app têm NPS maior. Vamos forçar todos a usar o app!" Mas talvez clientes mais satisfeitos é que escolhem usar o app. Forçar insatisfeitos não vai melhorar NPS.

**Como testar causalidade:**
- Experimento controlado (A/B test)
- Análise temporal (X aconteceu antes de Y?)
- Eliminação de variáveis confundidoras

### Significância Estatística

Quando uma diferença é "real" vs "acaso"?

**Exemplo:** NPS subiu de 42 para 45 após mudança no processo. É melhoria real ou variação normal?

**Conceitos-chave:**

**Valor-p (p-value):** Probabilidade de ver esse resultado por acaso. p < 0.05 = estatisticamente significativo (convenção).

**Intervalo de Confiança:** Faixa onde o valor real provavelmente está. "NPS = 45 ± 3" significa que está entre 42 e 48 com 95% de confiança.

**Tamanho da Amostra:** Quanto maior, mais confiável. 30 respostas de NPS não são suficientes para conclusões.

### Vieses em Dados de CX

**Viés de Seleção**
Só clientes satisfeitos respondem pesquisa. Solução: Incentive respostas de todos, analise taxa de resposta por segmento.

**Viés de Recência**
Última experiência domina a avaliação. Solução: Pergunte sobre momentos específicos, não só "em geral".

**Viés de Confirmação**
Buscamos dados que confirmam o que já acreditamos. Solução: Defina hipótese ANTES de olhar os dados.

**Viés de Sobrevivência**
Analisamos só quem ficou, ignoramos quem saiu. Solução: Inclua análise de churn e motivos de saída.

### Aplicações Práticas

**Dimensionamento de Amostra para Pesquisa**
Para NPS com margem de erro de 5% e confiança de 95%, você precisa de aproximadamente 385 respostas. Menos que isso, suas conclusões são frágeis.

**Análise de A/B Test**
Teste A: 1000 clientes, 50 conversões (5%). Teste B: 1000 clientes, 60 conversões (6%). É significativo? Depende. Use calculadora de significância.

**Segmentação por Quartis**
Divida clientes em 4 grupos por valor. Q1: Top 25%. Q4: Bottom 25%. Compare comportamento e satisfação entre grupos.

### Ferramentas Simples

**Excel/Google Sheets:** MÉDIA, MEDIANA, DESVPAD, CORREL. Suficiente para 80% das análises.

**Calculadoras Online:** Tamanho de amostra, significância de A/B test, intervalo de confiança.

**Regra Prática:** Se a diferença não é óbvia visualmente em um gráfico, provavelmente não é significativa na prática.

### Checklist de Análise

Antes de apresentar qualquer conclusão baseada em dados:

- [ ] A amostra é grande o suficiente?
- [ ] Os dados são representativos?
- [ ] Considerei outliers?
- [ ] É correlação ou causalidade?
- [ ] A diferença é estatisticamente significativa?
- [ ] A diferença é praticamente relevante?

> "Estatística não é sobre ter certeza. É sobre quantificar a incerteza para tomar melhores decisões."
> — Protocolo Vértice
`
  },
  {
    id: 31,
    title: "Visualização de Dados com Excel e Power BI",
    content: `# Visualização de Dados com Excel e Power BI

## Ferramentas Práticas para o Dia a Dia

Você não precisa de ferramentas caras ou complexas para criar visualizações impactantes. Excel e Power BI cobrem 90% das necessidades de um profissional de CX.

### Excel: O Canivete Suíço

**Quando Usar:**
- Análises rápidas e ad-hoc
- Dados até 100.000 linhas
- Compartilhamento simples
- Prototipagem de dashboards

**Gráficos Essenciais no Excel:**

**Gráfico de Linhas**
Ideal para: Tendências temporais. Como criar: Selecione dados → Inserir → Gráfico de Linhas. Dica: Use marcadores para destacar pontos importantes.

**Gráfico de Barras**
Ideal para: Comparação entre categorias. Como criar: Selecione dados → Inserir → Gráfico de Barras. Dica: Ordene do maior para menor para facilitar leitura.

**Gráfico de Pizza**
Ideal para: Composição (máximo 5-6 fatias). Como criar: Selecione dados → Inserir → Gráfico de Pizza. Dica: Use com moderação, barras geralmente são melhores.

**Tabela Dinâmica**
Ideal para: Exploração de dados, agrupamentos. Como criar: Selecione dados → Inserir → Tabela Dinâmica. Dica: Arraste campos para linhas, colunas e valores.

**Formatação Condicional**
Ideal para: Destacar valores importantes. Como criar: Selecione células → Página Inicial → Formatação Condicional. Dica: Use escalas de cor para heatmaps.

### Power BI: O Próximo Nível

**Quando Usar:**
- Dashboards interativos
- Dados de múltiplas fontes
- Atualização automática
- Compartilhamento em escala

**Vantagens sobre Excel:**
- Conecta a dezenas de fontes de dados
- Atualização automática programada
- Filtros interativos (slicers)
- Compartilhamento via web
- Melhor performance com grandes volumes

**Componentes Principais:**

**Power Query:** Importa e transforma dados. Limpa, combina, formata antes de visualizar.

**Modelo de Dados:** Relaciona tabelas diferentes. Vendas + Clientes + Produtos em um modelo integrado.

**Visualizações:** Gráficos interativos e conectados. Clique em um, todos os outros filtram.

**DAX:** Linguagem de fórmulas avançadas. Cálculos complexos como YoY, Running Total, etc.

### Criando um Dashboard de CX

**Passo 1: Defina as Perguntas**
O que o dashboard precisa responder? Qual o NPS atual? Como está a tendência? Quais segmentos estão pior?

**Passo 2: Identifique os Dados**
De onde vêm? CRM, pesquisas, atendimento. Qual a frequência de atualização?

**Passo 3: Estruture o Layout**
Topo: KPIs principais (números grandes). Meio: Gráficos de tendência e comparação. Base: Detalhes e tabelas.

**Passo 4: Escolha os Visuais**
Cada visual responde uma pergunta. Não decore, comunique.

**Passo 5: Adicione Interatividade**
Filtros por período, segmento, canal. Drill-down para detalhes.

### Template de Dashboard de CX

**Linha 1: KPIs (Cards)**
- NPS Atual: 45
- CSAT Médio: 4.2/5
- Churn Rate: 3.2%
- Tickets Abertos: 127

**Linha 2: Tendências (Gráficos de Linha)**
- NPS últimos 12 meses
- Volume de atendimentos por semana

**Linha 3: Comparações (Gráficos de Barra)**
- NPS por segmento de cliente
- CSAT por canal de atendimento

**Linha 4: Detalhes (Tabela)**
- Top 10 motivos de reclamação
- Clientes em risco (lista)

### Dicas de Design

**Menos é Mais**
Remova gridlines, bordas, decorações. Foco no dado.

**Hierarquia Visual**
O mais importante, maior e mais visível. Detalhes menores e mais discretos.

**Cores com Propósito**
Verde = bom, Vermelho = ruim, Cinza = contexto. Consistência em todo o dashboard.

**Títulos que Contam**
Não: "Gráfico de NPS". Sim: "NPS Caiu 5 Pontos no Último Trimestre".

**Espaço em Branco**
Não preencha cada pixel. Respiro visual ajuda a processar.

### Erros Comuns

**1. Dashboard Frankenstein**
20 gráficos sem conexão. Solução: Máximo 6-8 visuais por página.

**2. Dados Desatualizados**
"Atualizado em janeiro" (estamos em março). Solução: Automatize atualização.

**3. Sem Contexto**
NPS = 45. É bom? Ruim? Solução: Adicione meta, benchmark, tendência.

**4. Muito Texto**
Parágrafos explicando cada gráfico. Solução: Visual deve ser autoexplicativo.

### Recursos para Aprender

**Excel:** Cursos gratuitos da Microsoft, YouTube (ExcelIsFun).
**Power BI:** Microsoft Learn (gratuito), comunidade Power BI.
**Prática:** Pegue dados reais e tente recriar dashboards que você admira.

> "A melhor ferramenta é a que você domina. Comece com Excel, evolua para Power BI quando precisar."
> — Protocolo Vértice
`
  },
  {
    id: 32,
    title: "Métodos de Resolução de Problemas",
    content: `# Métodos de Resolução de Problemas

## Frameworks para Atacar Qualquer Desafio

Problemas complexos de CX raramente têm soluções óbvias. Estes métodos estruturados te ajudam a ir da confusão à clareza.

### 1. Os 5 Porquês

**O que é:** Técnica simples para encontrar causa raiz perguntando "por quê?" repetidamente.

**Como usar:**

Problema: NPS caiu 10 pontos.

Por quê? Aumento de reclamações sobre tempo de espera.
Por quê? Fila do call center está maior.
Por quê? Volume de ligações aumentou 40%.
Por quê? Clientes não conseguem resolver pelo app.
Por quê? Nova funcionalidade tem bug que impede conclusão.

**Causa raiz:** Bug no app, não "problema de call center".

**Dicas:**
- Nem sempre são exatamente 5 perguntas
- Pode ter múltiplas ramificações
- Valide com dados, não só intuição

### 2. Diagrama de Ishikawa (Espinha de Peixe)

**O que é:** Mapa visual de possíveis causas organizadas por categoria.

**Categorias clássicas (6Ms):**
- Método (processos)
- Máquina (tecnologia)
- Mão de obra (pessoas)
- Material (insumos)
- Medição (métricas)
- Meio ambiente (contexto)

**Como usar:**

1. Coloque o problema na "cabeça do peixe"
2. Desenhe espinhas para cada categoria
3. Brainstorm de causas em cada categoria
4. Priorize as mais prováveis
5. Investigue com dados

**Exemplo: Alto tempo de atendimento**

Método: Processo de escalação confuso
Máquina: Sistema lento para carregar histórico
Mão de obra: Treinamento insuficiente
Material: Base de conhecimento desatualizada
Medição: Meta de TMA irreal
Meio ambiente: Ruído no ambiente de trabalho

### 3. Análise de Pareto (80/20)

**O que é:** Identificar os poucos fatores que causam a maioria dos problemas.

**Como usar:**

1. Liste todos os tipos de problema
2. Conte frequência de cada um
3. Ordene do mais frequente ao menos
4. Calcule porcentagem acumulada
5. Foque nos que somam 80%

**Exemplo:**

| Tipo de Reclamação | Qtd | % | % Acum |
|-------------------|-----|---|--------|
| Tempo de espera | 450 | 35% | 35% |
| Problema não resolvido | 320 | 25% | 60% |
| Atendente rude | 200 | 15% | 75% |
| Informação errada | 100 | 8% | 83% |
| Outros | 230 | 17% | 100% |

**Insight:** Resolver "tempo de espera" e "problema não resolvido" ataca 60% das reclamações.

### 4. PDCA (Plan-Do-Check-Act)

**O que é:** Ciclo de melhoria contínua em 4 etapas.

**Plan (Planejar):**
- Identifique o problema
- Analise causas
- Defina ações
- Estabeleça metas

**Do (Fazer):**
- Execute o plano
- Em escala pequena primeiro (piloto)
- Documente o que acontece

**Check (Verificar):**
- Compare resultados com metas
- O que funcionou?
- O que não funcionou?

**Act (Agir):**
- Se funcionou: padronize e escale
- Se não funcionou: ajuste e repita o ciclo

### 5. A3 (Toyota)

**O que é:** Método de resolução de problemas que cabe em uma folha A3.

**Estrutura:**

**Lado Esquerdo (Análise):**
1. Contexto: Por que isso importa?
2. Situação atual: Dados e fatos
3. Objetivo: Onde queremos chegar?
4. Análise de causa: Por que está assim?

**Lado Direito (Ação):**
5. Contramedidas: O que vamos fazer?
6. Plano: Quem, quando, como?
7. Acompanhamento: Como vamos medir?

**Benefícios:**
- Força síntese (tem que caber em 1 página)
- Estrutura o pensamento
- Facilita comunicação
- Documenta aprendizado

### Quando Usar Cada Método

| Situação | Método Recomendado |
|----------|-------------------|
| Problema simples, causa não óbvia | 5 Porquês |
| Problema complexo, muitas possíveis causas | Ishikawa |
| Muitos problemas, precisa priorizar | Pareto |
| Melhoria contínua, ciclos iterativos | PDCA |
| Problema importante, precisa documentar | A3 |

### Armadilhas a Evitar

**1. Pular para Solução**
Antes de resolver, entenda o problema. 5 minutos de análise economizam horas de retrabalho.

**2. Tratar Sintoma como Causa**
"Vamos contratar mais atendentes" trata o sintoma (fila), não a causa (por que ligam?).

**3. Análise Paralisia**
Analisar eternamente sem agir. Defina timebox para análise.

**4. Não Validar com Dados**
"Acho que o problema é X" não é análise. Prove com números.

**5. Não Fechar o Ciclo**
Implementou a solução? Mediu o resultado? Documentou o aprendizado?

> "Um problema bem definido é um problema meio resolvido."
> — Protocolo Vértice
`
  },
  {
    id: 33,
    title: "Business Intelligence para CX",
    content: `# Business Intelligence para CX

## Transformando Dados em Inteligência de Negócio

Business Intelligence (BI) é o conjunto de práticas, tecnologias e ferramentas que transformam dados brutos em informações acionáveis para tomada de decisão.

### O Que é BI

**Não é:**
- Apenas dashboards bonitos
- Só tecnologia
- Responsabilidade exclusiva de TI

**É:**
- Processo de coleta, organização e análise de dados
- Cultura de decisão baseada em evidências
- Combinação de pessoas, processos e tecnologia

### A Pirâmide de BI

**Base: Dados**
Registros brutos de transações, interações, eventos. Exemplo: Log de cada ligação no call center.

**Nível 2: Informação**
Dados organizados e contextualizados. Exemplo: Tempo médio de atendimento por dia.

**Nível 3: Conhecimento**
Padrões e insights extraídos da informação. Exemplo: TMA aumenta 30% às segundas-feiras.

**Topo: Sabedoria**
Aplicação do conhecimento para decisões. Exemplo: Escalar equipe às segundas reduz TMA e melhora NPS.

### Arquitetura de BI para CX

**Fontes de Dados:**
- CRM (dados de clientes)
- Sistema de atendimento (tickets, ligações)
- Pesquisas (NPS, CSAT)
- Web analytics (comportamento digital)
- ERP (transações, financeiro)

**Camada de Integração:**
- ETL (Extract, Transform, Load)
- Data Warehouse ou Data Lake
- Limpeza e padronização

**Camada de Análise:**
- Ferramentas de BI (Power BI, Tableau, Looker)
- Modelagem dimensional
- Cálculos e métricas

**Camada de Consumo:**
- Dashboards executivos
- Relatórios operacionais
- Alertas automáticos
- Self-service analytics

### KPIs Essenciais de CX

**Satisfação:**
- NPS (Net Promoter Score)
- CSAT (Customer Satisfaction)
- CES (Customer Effort Score)

**Atendimento:**
- TMA (Tempo Médio de Atendimento)
- TME (Tempo Médio de Espera)
- FCR (First Contact Resolution)
- Taxa de abandono

**Retenção:**
- Churn rate
- Retention rate
- Customer Lifetime Value (CLV)

**Eficiência:**
- Custo por atendimento
- Tickets por agente
- Utilização de autoatendimento

### Níveis de Maturidade em BI

**Nível 1: Reativo**
Relatórios manuais, Excel, dados em silos. "O que aconteceu no mês passado?"

**Nível 2: Descritivo**
Dashboards básicos, atualização periódica. "O que está acontecendo agora?"

**Nível 3: Diagnóstico**
Análise de causa raiz, drill-down. "Por que aconteceu?"

**Nível 4: Preditivo**
Modelos estatísticos, machine learning. "O que vai acontecer?"

**Nível 5: Prescritivo**
Recomendações automáticas, IA. "O que devemos fazer?"

### Implementando BI em CX

**Fase 1: Fundação (Mês 1-3)**
- Mapear fontes de dados existentes
- Definir KPIs prioritários
- Escolher ferramenta de BI
- Criar primeiros dashboards

**Fase 2: Expansão (Mês 4-6)**
- Integrar mais fontes de dados
- Automatizar atualização
- Treinar usuários
- Criar cultura de dados

**Fase 3: Otimização (Mês 7-12)**
- Análises avançadas
- Alertas proativos
- Self-service para áreas
- Governança de dados

### Governança de Dados

**Por que importa:**
Dados ruins = decisões ruins. "Garbage in, garbage out."

**Elementos:**
- Dono de cada dado (quem é responsável?)
- Definição de métricas (o que significa NPS?)
- Qualidade de dados (está correto? completo?)
- Segurança (quem pode ver o quê?)

**Práticas:**
- Dicionário de dados documentado
- Processo de validação de qualidade
- Revisão periódica de métricas
- Treinamento de usuários

### Erros Comuns

**1. Começar pela Ferramenta**
"Vamos comprar Tableau!" Antes: Quais perguntas precisamos responder?

**2. Dados sem Dono**
Ninguém é responsável pela qualidade. Resultado: Ninguém confia nos dados.

**3. Dashboards sem Ação**
Lindos gráficos que ninguém usa para decidir. Resultado: Desperdício de investimento.

**4. Métricas Demais**
50 KPIs no dashboard. Resultado: Nenhum é acompanhado de verdade.

**5. Falta de Contexto**
NPS = 45. É bom? Ruim? Comparado a quê? Resultado: Número sem significado.

### O Futuro do BI em CX

**IA Generativa:** Pergunte em linguagem natural, receba análises.
**Real-time:** Dashboards atualizados a cada segundo.
**Embedded:** BI dentro dos sistemas operacionais.
**Democratização:** Todo mundo analisa dados, não só especialistas.

> "BI não é sobre ter mais dados. É sobre ter os dados certos, no momento certo, para a decisão certa."
> — Protocolo Vértice
`
  },
  {
    id: 34,
    title: "Big Data e Analytics em Customer Experience",
    content: `# Big Data e Analytics em Customer Experience

## Escala, Velocidade e Variedade a Serviço do Cliente

Big Data não é apenas "muitos dados". É uma mudança de paradigma em como coletamos, processamos e extraímos valor de informações em escala sem precedentes.

### Os 5 Vs do Big Data

**Volume**
Quantidade massiva de dados. Terabytes, petabytes. Exemplo: Milhões de interações de clientes por dia.

**Velocidade**
Dados gerados e processados em tempo real. Exemplo: Análise de sentimento durante a ligação.

**Variedade**
Dados estruturados e não estruturados. Exemplo: Números + textos + áudios + vídeos + imagens.

**Veracidade**
Qualidade e confiabilidade dos dados. Exemplo: Dados duplicados, incompletos, incorretos.

**Valor**
O insight extraído que gera resultado. Exemplo: Prever churn antes que aconteça.

### Tipos de Analytics

**Descritivo: O que aconteceu?**
Relatórios históricos, dashboards. "NPS foi 45 no último mês."

**Diagnóstico: Por que aconteceu?**
Análise de causa raiz, correlações. "NPS caiu porque tempo de espera aumentou."

**Preditivo: O que vai acontecer?**
Modelos estatísticos, machine learning. "Este cliente tem 73% de chance de cancelar."

**Prescritivo: O que devemos fazer?**
Recomendações automáticas, otimização. "Ofereça desconto de 20% para reter este cliente."

### Aplicações em CX

**Análise de Sentimento**
Processar milhares de comentários, reviews, transcrições. Identificar temas, emoções, tendências automaticamente.

**Churn Prediction**
Modelo que identifica clientes em risco antes de cancelarem. Variáveis: frequência de uso, reclamações, pagamentos atrasados.

**Next Best Action**
Recomendar a melhor ação para cada cliente em cada momento. Oferta, conteúdo, canal, timing personalizados.

**Voice of Customer (VoC)**
Consolidar feedback de todas as fontes. Pesquisas, redes sociais, atendimento, reviews.

**Customer Journey Analytics**
Mapear e analisar jornadas reais em escala. Identificar pontos de fricção, abandono, conversão.

### Tecnologias Relevantes

**Armazenamento:**
- Data Warehouse (estruturado, SQL)
- Data Lake (estruturado + não estruturado)
- Cloud (AWS, Azure, GCP)

**Processamento:**
- Spark (processamento distribuído)
- Kafka (streaming em tempo real)
- Python/R (análise e modelagem)

**Visualização:**
- Power BI, Tableau, Looker
- Dashboards em tempo real

**Machine Learning:**
- Scikit-learn, TensorFlow, PyTorch
- AutoML (modelos automatizados)

### Caso Prático: Previsão de Churn

**Objetivo:** Identificar clientes com alta probabilidade de cancelar nos próximos 30 dias.

**Dados utilizados:**
- Histórico de uso (frequência, profundidade)
- Histórico de atendimento (tickets, reclamações)
- Dados de pagamento (atrasos, downgrades)
- Engajamento (emails abertos, logins)
- NPS e CSAT históricos

**Modelo:**
- Algoritmo: Random Forest ou XGBoost
- Variável alvo: Cancelou em 30 dias (sim/não)
- Métricas: AUC, Precision, Recall

**Resultado:**
- Score de 0-100 para cada cliente
- Top 10% de risco recebe ação proativa
- Redução de 25% no churn do segmento

### Desafios e Cuidados

**Qualidade de Dados**
Big Data amplifica problemas de qualidade. Lixo em escala ainda é lixo.

**Privacidade (LGPD)**
Dados pessoais exigem consentimento e proteção. Anonimização, minimização, finalidade.

**Viés Algorítmico**
Modelos podem perpetuar ou amplificar vieses. Auditoria e fairness são essenciais.

**Interpretabilidade**
Modelos complexos são "caixas pretas". Explainability é necessária para confiança.

**Custo**
Infraestrutura de Big Data não é barata. ROI precisa ser claro.

### Começando com Big Data em CX

**Passo 1: Defina o Problema**
Não comece pela tecnologia. Qual problema de negócio você quer resolver?

**Passo 2: Avalie seus Dados**
Você tem os dados necessários? Qual a qualidade? Onde estão os gaps?

**Passo 3: Comece Pequeno**
Piloto com escopo limitado. Prove valor antes de escalar.

**Passo 4: Construa Capacidade**
Pessoas > Tecnologia. Invista em skills de analytics.

**Passo 5: Escale com Governança**
Processos, políticas, responsabilidades claras.

### O Futuro

**IA Conversacional:** Chatbots que realmente entendem e resolvem.
**Hiperpersonalização:** Cada cliente é um segmento de um.
**Proatividade:** Resolver problemas antes do cliente perceber.
**Emotion AI:** Detectar e responder a emoções em tempo real.

> "Big Data sem estratégia é só big cost. O valor está na pergunta certa, não no volume de dados."
> — Protocolo Vértice
`
  },
  {
    id: 35,
    title: "Playbook: Análise de Dados para CX",
    content: `# Playbook: Análise de Dados para CX

## Guia Prático para Extrair Insights Acionáveis

Este playbook é um roteiro passo a passo para conduzir análises de dados em CX. Use como checklist em qualquer projeto de análise.

### Fase 1: Definição (Antes de Tocar nos Dados)

**1.1 Qual a Pergunta de Negócio?**
Não comece pela análise. Comece pela pergunta.

Ruim: "Vamos analisar os dados de NPS"
Bom: "Por que o NPS caiu 10 pontos no último trimestre?"

**1.2 Quem é o Público?**
A análise para o CEO é diferente da análise para o gerente de operações.

**1.3 Qual a Decisão a ser Tomada?**
Se a análise não vai mudar uma decisão, por que fazê-la?

**1.4 Qual o Prazo?**
Análise perfeita em 3 meses vs análise boa em 1 semana. O que é mais útil?

### Fase 2: Coleta de Dados

**2.1 Mapeie as Fontes**
Onde estão os dados relevantes? CRM, atendimento, pesquisas, web analytics.

**2.2 Extraia os Dados**
SQL, APIs, exports manuais. Documente a query/processo.

**2.3 Verifique a Qualidade**
Dados faltantes? Duplicados? Outliers? Inconsistências?

**2.4 Documente Limitações**
"Dados de janeiro incompletos" ou "Apenas canal telefone incluído".

### Fase 3: Análise Exploratória

**3.1 Estatísticas Descritivas**
Média, mediana, desvio padrão. Tenha uma visão geral.

**3.2 Visualizações Iniciais**
Gráficos simples para identificar padrões. Não se preocupe com estética ainda.

**3.3 Segmentações**
Corte os dados de diferentes formas. Por período, canal, segmento, produto.

**3.4 Anomalias**
O que se destaca? Picos, quedas, outliers. Investigue.

### Fase 4: Análise Profunda

**4.1 Teste Hipóteses**
"Acredito que o NPS caiu por causa de X." Prove ou refute com dados.

**4.2 Busque Causas**
Correlação não é causalidade. Use os 5 Porquês, Ishikawa.

**4.3 Quantifique Impacto**
Não apenas "caiu", mas "caiu X pontos, afetando Y clientes, custando R$ Z".

**4.4 Compare com Benchmarks**
Interno (período anterior) e externo (mercado).

### Fase 5: Síntese e Recomendação

**5.1 Destile os Insights**
De 100 descobertas, quais são as 3 mais importantes?

**5.2 Formule Recomendações**
Não apenas "o que descobrimos", mas "o que devemos fazer".

**5.3 Priorize Ações**
Matriz de impacto vs esforço. O que fazer primeiro?

**5.4 Defina Métricas de Sucesso**
Como vamos saber se a ação funcionou?

### Fase 6: Comunicação

**6.1 Adapte ao Público**
Executivo: 1 página, foco em decisão. Operacional: Detalhes e ações.

**6.2 Conte uma História**
Gancho → Contexto → Tensão → Solução → Pedido.

**6.3 Visualize com Propósito**
Cada gráfico responde uma pergunta. Remova o que não adiciona.

**6.4 Prepare para Perguntas**
Tenha análises de backup. "E se perguntarem sobre X?"

### Template de Análise

**1. Sumário Executivo (1 parágrafo)**
O que descobrimos e o que recomendamos.

**2. Contexto (1/2 página)**
Por que fizemos esta análise. Qual a pergunta.

**3. Metodologia (1/2 página)**
Dados usados, período, limitações.

**4. Descobertas (2-3 páginas)**
Insights principais com visualizações de suporte.

**5. Recomendações (1 página)**
Ações específicas, priorizadas, com responsáveis e prazos.

**6. Apêndice**
Detalhes técnicos, análises complementares.

### Checklist de Qualidade

**Antes de Apresentar:**

- [ ] A pergunta de negócio está clara?
- [ ] Os dados são confiáveis e documentados?
- [ ] As conclusões são suportadas por evidências?
- [ ] Considerei explicações alternativas?
- [ ] As recomendações são específicas e acionáveis?
- [ ] O formato está adequado ao público?
- [ ] Alguém revisou antes de apresentar?

### Erros Comuns

**1. Análise sem Pergunta**
"Vamos ver o que os dados dizem." Resultado: Relatório sem foco.

**2. Conclusão Precipitada**
Primeira hipótese vira verdade. Resultado: Viés de confirmação.

**3. Excesso de Detalhes**
50 slides com cada corte possível. Resultado: Ninguém lê.

**4. Falta de Recomendação**
"Aqui estão os dados." E daí? O que fazemos?

**5. Não Fechar o Ciclo**
Apresentou, esqueceu. A ação foi implementada? Funcionou?

### Ferramentas por Fase

| Fase | Ferramentas |
|------|-------------|
| Coleta | SQL, Python, APIs |
| Exploratória | Excel, Python (pandas) |
| Profunda | Python, R, ferramentas estatísticas |
| Visualização | Power BI, Tableau, Excel |
| Comunicação | PowerPoint, Google Slides |

> "Análise de dados não termina no insight. Termina na ação que gera resultado."
> — Protocolo Vértice
`
  }
];

async function generateAndSaveContent(contentData: { id: number; title: string; content: string }) {
  try {
    const fileName = "content_" + contentData.id + "_" + Date.now() + ".md";
    const buffer = Buffer.from(contentData.content, 'utf-8');
    
    const { url } = await storagePut(fileName, buffer, 'text/markdown');
    
    await db.update(contents)
      .set({ 
        fileUrl: url,
        mimeType: 'text/markdown',
        updatedAt: new Date()
      })
      .where(eq(contents.id, contentData.id));
    
    console.log("✅ Conteúdo " + contentData.id + " atualizado: " + contentData.title);
    return true;
  } catch (error) {
    console.error("❌ Erro ao atualizar conteúdo " + contentData.id + ":", error);
    return false;
  }
}

async function main() {
  console.log("🚀 Gerando conteúdos autorais - Batch 3 (CX e Dados)...");
  
  for (const content of contentsBatch3) {
    await generateAndSaveContent(content);
  }
  
  console.log("\n✅ Batch 3 concluído!");
  process.exit(0);
}

main().catch(console.error);
