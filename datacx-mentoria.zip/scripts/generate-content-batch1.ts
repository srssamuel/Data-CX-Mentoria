import { drizzle } from "drizzle-orm/mysql2";
import { contents } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { storagePut } from "../server/storage";

const db = drizzle(process.env.DATABASE_URL!);

const contentsBatch1 = [
  {
    id: 5,
    title: "Pesquisa Quantitativa vs Qualitativa",
    content: `# Pesquisa Quantitativa vs Qualitativa

## Duas Lentes para Entender Seu Cliente

No universo de CX e Dados, dominar os dois tipos de pesquisa é fundamental. Cada uma responde perguntas diferentes e, juntas, formam uma visão completa do seu cliente.

### Pesquisa Quantitativa: O QUÊ e QUANTO

A pesquisa quantitativa trabalha com números, estatísticas e métricas. É objetiva, mensurável e generalizável.

**Características:**
- Amostra grande (centenas ou milhares)
- Perguntas fechadas (escalas, múltipla escolha)
- Análise estatística
- Resultados numéricos

**Responde:**
- Quantos clientes estão insatisfeitos?
- Qual o NPS médio por segmento?
- Qual canal tem maior volume de reclamações?
- Quanto tempo médio de espera no atendimento?

**Métodos Comuns:**
- Surveys online (NPS, CSAT, CES)
- Formulários estruturados
- Análise de dados transacionais
- A/B testing

### Pesquisa Qualitativa: POR QUÊ e COMO

A pesquisa qualitativa explora motivações, percepções e sentimentos. É subjetiva, profunda e contextual.

**Características:**
- Amostra pequena (10-30 pessoas)
- Perguntas abertas
- Análise de conteúdo
- Resultados descritivos

**Responde:**
- Por que os clientes estão insatisfeitos?
- Como eles se sentem durante a jornada?
- O que os motiva a recomendar (ou não)?
- Quais são suas expectativas não atendidas?

**Métodos Comuns:**
- Entrevistas em profundidade
- Focus groups
- Observação etnográfica
- Análise de verbatins

### A Combinação Ideal

**Use Quantitativo para:**
- Identificar ONDE está o problema
- Medir a magnitude do impacto
- Priorizar por volume/frequência
- Acompanhar tendências ao longo do tempo

**Use Qualitativo para:**
- Entender POR QUÊ existe o problema
- Descobrir causas raiz
- Gerar hipóteses para testar
- Humanizar os números

### Framework Protocolo Vértice

**Passo 1: Quantitativo Exploratório**
- Identifique padrões nos dados existentes
- Encontre anomalias e outliers
- Priorize áreas de investigação

**Passo 2: Qualitativo Profundo**
- Investigue as causas dos padrões
- Entenda o contexto humano
- Gere hipóteses de melhoria

**Passo 3: Quantitativo Confirmatório**
- Valide as hipóteses em escala
- Meça o impacto das mudanças
- Estabeleça novos baselines

### Erros Comuns

1. **Usar apenas quantitativo** — Sabe que 30% estão insatisfeitos, mas não sabe por quê
2. **Usar apenas qualitativo** — Entende profundamente 10 clientes, mas não sabe se representam a maioria
3. **Generalizar qualitativo** — "Entrevistei 5 pessoas e todas disseram X, então todos pensam X"
4. **Ignorar contexto do quantitativo** — NPS caiu, mas não investiga o que mudou

> "Quantitativo te diz o tamanho do problema. Qualitativo te diz a alma do problema."
> — Protocolo Vértice
`
  },
  {
    id: 6,
    title: "Template: Questionário de Pesquisa Eficaz",
    content: `# Template: Questionário de Pesquisa Eficaz

## Guia Prático para Criar Pesquisas que Geram Insights

Um bom questionário é a diferença entre dados úteis e ruído. Este template vai te ajudar a criar pesquisas que realmente informam decisões.

### Estrutura Recomendada

**1. INTRODUÇÃO (30 segundos)**
- Apresente o propósito da pesquisa
- Informe o tempo estimado
- Garanta confidencialidade
- Agradeça a participação

*Exemplo:*
"Esta pesquisa leva 3 minutos e nos ajuda a melhorar sua experiência. Suas respostas são confidenciais."

**2. PERGUNTAS DE AQUECIMENTO (1-2 perguntas)**
- Fáceis de responder
- Criam engajamento
- Contextualizam o respondente

*Exemplo:*
"Há quanto tempo você é cliente da [empresa]?"

**3. PERGUNTAS PRINCIPAIS (5-10 perguntas)**
- Focadas no objetivo da pesquisa
- Mix de escalas e abertas
- Ordem lógica

**4. PERGUNTAS DEMOGRÁFICAS (2-3 perguntas)**
- Apenas as necessárias para segmentação
- No final (evita abandono)

**5. ENCERRAMENTO**
- Pergunta aberta final
- Agradecimento
- Próximos passos (se aplicável)

### Tipos de Perguntas

**Escala Likert (1-5 ou 1-7)**
- "Quão satisfeito você está com [X]?"
- Muito insatisfeito → Muito satisfeito

**NPS (0-10)**
- "Qual a probabilidade de recomendar?"
- Padrão de mercado, permite benchmark

**Múltipla Escolha**
- "Qual canal você mais utiliza?"
- Opções mutuamente exclusivas

**Ranking**
- "Ordene por importância"
- Máximo 5-7 itens

**Aberta**
- "O que podemos melhorar?"
- Use com moderação (1-2 por pesquisa)

### Regras de Ouro

**1. Uma pergunta, um conceito**
- Ruim: "O atendimento foi rápido e cordial?"
- Bom: "O atendimento foi rápido?" + "O atendimento foi cordial?"

**2. Evite perguntas direcionadas**
- Ruim: "Você concorda que nosso produto é excelente?"
- Bom: "Como você avalia nosso produto?"

**3. Ofereça opção neutra**
- Inclua "Não sei" ou "Não se aplica" quando relevante

**4. Mantenha curto**
- Ideal: 3-5 minutos
- Máximo: 10 minutos
- Taxa de abandono aumenta exponencialmente após 5 minutos

**5. Teste antes de enviar**
- Peça para 3-5 pessoas testarem
- Verifique tempo real de resposta
- Identifique perguntas confusas

### Template Pronto para Uso

**Pesquisa de Satisfação Pós-Atendimento**

1. Como você avalia sua experiência geral com nosso atendimento? (1-5)
2. O problema foi resolvido? (Sim / Parcialmente / Não)
3. O tempo de espera foi adequado? (1-5)
4. O atendente foi claro nas explicações? (1-5)
5. Qual a probabilidade de você recomendar nossa empresa? (0-10)
6. O que podemos fazer para melhorar? (Aberta)

> "Uma pesquisa bem feita é uma conversa estruturada. Uma pesquisa mal feita é um interrogatório."
> — Protocolo Vértice
`
  },
  {
    id: 8,
    title: "Show, Don't Tell: A Arte de Mostrar com Dados",
    content: `# Show, Don't Tell: A Arte de Mostrar com Dados

## A Técnica Cinematográfica Aplicada a Apresentações

"Show, don't tell" é um princípio fundamental do cinema e da literatura. Em vez de DIZER que algo é importante, você MOSTRA. Aplicado a dados, isso transforma apresentações medíocres em narrativas memoráveis.

### O Princípio

**TELL (Contar):**
"Nosso NPS caiu muito e isso é preocupante."

**SHOW (Mostrar):**
"Em janeiro, 45 de cada 100 clientes nos recomendariam. Hoje, são apenas 32. Perdemos 13 promotores por mês — o equivalente a 2.300 clientes que deixaram de nos indicar."

### Por Que Funciona

1. **Concreto > Abstrato**
   - "Muito" é subjetivo
   - "13 pontos" é mensurável

2. **Específico > Genérico**
   - "Clientes insatisfeitos" é vago
   - "2.300 promotores perdidos" é tangível

3. **Impacto > Descrição**
   - "Precisamos melhorar" é passivo
   - "Estamos perdendo R$ 47.000 por ponto de NPS" gera urgência

### Técnicas de "Show"

**1. Tradução Financeira**
- Ruim: "Churn aumentou"
- Bom: "Cada 1% de churn custa R$ 230.000 em receita anual"

**2. Analogia Tangível**
- Ruim: "Processamos muitos dados"
- Bom: "Processamos o equivalente a 50 milhões de páginas de texto por dia"

**3. Comparação Temporal**
- Ruim: "Melhoramos o tempo de resposta"
- Bom: "Há 6 meses, clientes esperavam 4 horas. Hoje, 47 minutos."

**4. Personalização**
- Ruim: "Afeta muitos clientes"
- Bom: "Se você fosse um dos 3.400 clientes afetados ontem..."

**5. Visualização**
- Ruim: Tabela com 50 números
- Bom: Gráfico que destaca a tendência principal

### Framework de Transformação

Para cada afirmação que você faz, pergunte:

1. **Posso quantificar?**
   - "Muito" → "47%"
   - "Rápido" → "em 2 horas"

2. **Posso comparar?**
   - "Bom" → "30% acima da média do setor"
   - "Piorou" → "caiu de X para Y"

3. **Posso traduzir em impacto?**
   - "Problema de qualidade" → "R$ 500.000 em retrabalho"
   - "Clientes insatisfeitos" → "23% de churn projetado"

4. **Posso humanizar?**
   - "1.000 reclamações" → "1.000 pessoas frustradas esperando solução"

### Exemplos Práticos

**Antes:** "O tempo de atendimento está alto"
**Depois:** "Clientes esperam em média 12 minutos — tempo suficiente para desistir e ligar para o concorrente"

**Antes:** "Temos muitos dados de clientes"
**Depois:** "Sabemos o nome, histórico e preferências de 2,3 milhões de pessoas — e usamos menos de 10% dessa informação"

**Antes:** "A satisfação melhorou"
**Depois:** "Há 1 ano, 1 em cada 4 clientes nos daria nota máxima. Hoje, é 1 em cada 2."

### Exercício Protocolo Vértice

Pegue sua última apresentação e identifique:
1. Quantas vezes você DISSE algo sem MOSTRAR?
2. Como você pode transformar cada "tell" em "show"?

> "Dados que você conta são esquecidos. Dados que você mostra são lembrados. Dados que fazem sentir são transformadores."
> — Protocolo Vértice
`
  },
  {
    id: 9,
    title: "Framework: Estrutura de Narrativa com Dados",
    content: `# Framework: Estrutura de Narrativa com Dados

## O Template Completo para Apresentações de Impacto

Este framework é a espinha dorsal de qualquer apresentação de dados eficaz. Use-o como checklist antes de qualquer reunião importante.

### A Estrutura em 5 Atos

**ATO 1: GANCHO (10% do tempo)**
Objetivo: Capturar atenção imediatamente

- Comece com um dado surpreendente
- Ou uma pergunta provocativa
- Ou uma história curta e relevante

*Exemplo:*
"Ontem, 847 clientes tentaram nos ligar e desistiram antes de ser atendidos. Isso é um estádio de futebol lotado de pessoas frustradas — todo dia."

**ATO 2: CONTEXTO (20% do tempo)**
Objetivo: Situar a audiência

- De onde vêm os dados?
- Qual o período analisado?
- Quais as premissas?
- Qual a linha de base?

*Exemplo:*
"Analisamos 3 meses de dados do call center, de janeiro a março de 2024, comparando com o mesmo período do ano anterior."

**ATO 3: TENSÃO (30% do tempo)**
Objetivo: Criar necessidade de ação

- Apresente o problema ou oportunidade
- Quantifique o impacto
- Mostre a urgência
- Use comparações e tendências

*Exemplo:*
"Nossa taxa de abandono subiu de 8% para 23%. Se não agirmos, projetamos perder R$ 2,4 milhões em receita este ano."

**ATO 4: SOLUÇÃO (30% do tempo)**
Objetivo: Apresentar o caminho

- Sua recomendação específica
- Evidências de que funciona
- Cenários e trade-offs
- Recursos necessários

*Exemplo:*
"Propomos implementar callback automático. Empresas similares reduziram abandono em 60%. Investimento: R$ 150.000. Payback: 3 meses."

**ATO 5: CHAMADA À AÇÃO (10% do tempo)**
Objetivo: Gerar compromisso

- Peça algo específico
- Defina próximo passo concreto
- Estabeleça prazo
- Identifique responsáveis

*Exemplo:*
"Preciso de aprovação para um piloto de 30 dias com a equipe de São Paulo. Posso ter uma resposta até sexta?"

### Checklist Pré-Apresentação

**Conteúdo:**
- [ ] Tenho no máximo 3 insights principais?
- [ ] Cada insight tem dados de suporte?
- [ ] Traduzi impacto em linguagem do negócio (R$, %, tempo)?
- [ ] Tenho uma recomendação clara?

**Visual:**
- [ ] Cada slide tem uma mensagem principal?
- [ ] Os gráficos são autoexplicativos?
- [ ] Removi tudo que não é essencial?
- [ ] As cores têm significado consistente?

**Narrativa:**
- [ ] O gancho captura atenção em 10 segundos?
- [ ] A tensão cria urgência?
- [ ] A solução é específica e acionável?
- [ ] O pedido final é claro?

### Adaptando ao Tempo Disponível

**5 minutos:** Gancho + 1 insight + Pedido
**15 minutos:** Estrutura completa resumida
**30 minutos:** Estrutura completa + Q&A
**60 minutos:** Estrutura completa + Deep dive + Discussão

### Template de Slide Único

Se você tivesse apenas 1 slide, ele deveria ter:

1. **Título que conta a história** (não "Análise de NPS", mas "NPS Caiu 13 Pontos — Precisamos Agir")
2. **1 visualização principal** que prova o ponto
3. **3 bullets** com contexto essencial
4. **1 recomendação** clara

> "Uma boa apresentação de dados é como um bom filme: tem início, meio e fim, e você sai querendo fazer algo diferente."
> — Protocolo Vértice
`
  },
  {
    id: 11,
    title: "Gráficos de Linha e Tendências Temporais",
    content: `# Gráficos de Linha e Tendências Temporais

## Dominando a Arte de Mostrar Evolução

O gráfico de linha é a ferramenta mais poderosa para mostrar mudanças ao longo do tempo. Mas usado incorretamente, pode confundir mais do que esclarecer.

### Quando Usar Gráficos de Linha

**Use quando:**
- Mostrar evolução temporal (dias, semanas, meses, anos)
- Comparar tendências de múltiplas séries
- Identificar padrões sazonais
- Destacar pontos de inflexão

**Não use quando:**
- Comparar categorias sem relação temporal
- Mostrar composição (use pizza ou barras empilhadas)
- Poucos pontos de dados (menos de 4)

### Anatomia de um Gráfico de Linha Eficaz

**1. Título que Conta a História**
- Ruim: "NPS por Mês"
- Bom: "NPS Caiu 13 Pontos em 3 Meses — Pior Resultado desde 2022"

**2. Eixo Y Bem Definido**
- Comece em zero quando fizer sentido
- Se não começar em zero, deixe claro visualmente
- Inclua unidade de medida

**3. Eixo X Legível**
- Intervalos consistentes
- Labels não sobrepostos
- Formato de data apropriado

**4. Linhas Distinguíveis**
- Máximo 4-5 séries
- Cores contrastantes
- Espessura adequada

**5. Anotações Estratégicas**
- Destaque pontos importantes
- Explique anomalias
- Marque eventos relevantes

### Técnicas Avançadas

**1. Destacar Tendência**
- Adicione linha de tendência (média móvel)
- Mostre direção geral vs ruído

**2. Marcar Eventos**
- Linhas verticais para marcos importantes
- "Lançamento do novo produto"
- "Mudança de processo"

**3. Zonas de Referência**
- Área sombreada para meta
- Faixa de benchmark do setor

**4. Comparação Temporal**
- Mesmo período, anos diferentes
- "Este ano vs Ano passado"

### Erros Comuns

**1. Muitas Séries**
- Problema: 10 linhas no mesmo gráfico
- Solução: Destaque 2-3 principais, agrupe o resto

**2. Escala Enganosa**
- Problema: Eixo Y de 98% a 100% parece queda dramática
- Solução: Mostre escala completa ou avise claramente

**3. Intervalos Inconsistentes**
- Problema: Jan, Fev, Mar, Jun, Dez
- Solução: Mantenha intervalos regulares

**4. Cores Sem Significado**
- Problema: Cores aleatórias
- Solução: Verde = positivo, Vermelho = negativo

### Exemplo Prático

**Cenário:** Mostrar evolução do NPS nos últimos 12 meses

**Elementos:**
- Linha principal: NPS mensal
- Linha secundária: Meta (45)
- Área sombreada: Benchmark do setor (35-50)
- Anotação: "Mudança de processo" em setembro
- Título: "NPS Recuperou 8 Pontos Após Nova Estratégia de Atendimento"

### Checklist

- [ ] O título conta a história principal?
- [ ] O eixo Y está em escala apropriada?
- [ ] As séries são distinguíveis?
- [ ] Pontos importantes estão anotados?
- [ ] Alguém de fora entenderia em 10 segundos?

> "Um gráfico de linha bem feito é uma máquina do tempo visual — mostra de onde viemos, onde estamos e para onde vamos."
> — Protocolo Vértice
`
  },
  {
    id: 12,
    title: "Gráficos de Barra: Comparações Poderosas",
    content: `# Gráficos de Barra: Comparações Poderosas

## A Ferramenta Universal para Comparar Categorias

O gráfico de barras é provavelmente o mais versátil e intuitivo. Quando bem usado, comunica comparações de forma imediata e inequívoca.

### Quando Usar Gráficos de Barra

**Use quando:**
- Comparar valores entre categorias
- Mostrar ranking ou ordenação
- Apresentar dados discretos (não contínuos)
- Audiência precisa comparar magnitudes

**Variações:**
- **Barras verticais:** Comparação de categorias
- **Barras horizontais:** Muitas categorias ou labels longos
- **Barras empilhadas:** Composição do todo
- **Barras agrupadas:** Comparação de múltiplas séries

### Regras de Ouro

**1. SEMPRE Comece em Zero**
- Barras representam magnitude
- Cortar o eixo distorce a percepção
- Exceção: Nunca (sério, nunca)

**2. Ordene com Propósito**
- Por valor (maior → menor) para ranking
- Alfabético se a ordem importa
- Cronológico se for temporal

**3. Use Cores com Significado**
- Destaque a barra mais importante
- Verde/vermelho para bom/ruim
- Cinza para contexto, cor para foco

**4. Limite o Número de Barras**
- Ideal: 5-7 barras
- Máximo: 12-15 barras
- Mais que isso: agrupe em "Outros"

### Técnicas Avançadas

**1. Destaque a Mensagem**
- Uma barra em cor, resto em cinza
- Chama atenção para o ponto principal

**2. Adicione Linha de Referência**
- Média do grupo
- Meta
- Benchmark do setor

**3. Mostre Variação**
- Barras de erro para incerteza
- Setas para mudança vs período anterior

**4. Combine com Números**
- Valores no topo das barras
- Porcentagem de variação

### Erros Fatais

**1. Eixo Cortado**
- Barra de 95% parece 10x maior que 90%
- SEMPRE comece em zero

**2. 3D Desnecessário**
- Distorce proporções
- Dificulta leitura
- Nunca use

**3. Muitas Cores**
- Cada barra de uma cor sem motivo
- Use cor para destacar, não decorar

**4. Labels Ilegíveis**
- Texto vertical difícil de ler
- Use barras horizontais para labels longos

### Exemplos de Aplicação

**Ranking de Canais por Volume**
- Barras horizontais
- Ordenado do maior para menor
- Destaque o canal principal

**Comparação de NPS por Segmento**
- Barras verticais
- Linha de referência na meta
- Cores: verde (acima), vermelho (abaixo)

**Composição de Reclamações**
- Barras empilhadas
- Cada cor = tipo de reclamação
- Mostra total e composição

### Checklist

- [ ] O eixo Y começa em zero?
- [ ] As barras estão ordenadas com propósito?
- [ ] As cores têm significado?
- [ ] Os labels são legíveis?
- [ ] A mensagem principal está destacada?

> "Um gráfico de barras é uma régua visual. Se você cortar a régua, as medidas perdem o sentido."
> — Protocolo Vértice
`
  },
  {
    id: 13,
    title: "Playbook: Design de Visualizações",
    content: `# Playbook: Design de Visualizações

## Guia Completo para Criar Gráficos que Comunicam

Este playbook reúne os princípios fundamentais de design de visualização de dados. Use como referência antes de criar qualquer gráfico.

### Princípio 1: Clareza Acima de Tudo

**Regra:** Se precisa explicar, não funcionou.

- Remova tudo que não adiciona informação
- Elimine gridlines desnecessárias
- Simplifique legendas
- Use títulos que contam a história

**Teste:** Mostre para alguém por 5 segundos. Ela entendeu a mensagem principal?

### Princípio 2: Hierarquia Visual

**Regra:** Guie o olhar do leitor.

**Níveis de destaque:**
1. **Primário:** Mensagem principal (maior, mais colorido)
2. **Secundário:** Contexto importante (médio, menos saturado)
3. **Terciário:** Detalhes de suporte (menor, cinza)

**Técnicas:**
- Tamanho (maior = mais importante)
- Cor (saturada = mais importante)
- Posição (topo/esquerda = mais importante)
- Contraste (destaque vs fundo)

### Princípio 3: Uso Estratégico de Cores

**Regra:** Cor é informação, não decoração.

**Paleta Recomendada:**
- **Azul:** Neutro, dados gerais
- **Verde:** Positivo, acima da meta
- **Vermelho:** Negativo, abaixo da meta
- **Cinza:** Contexto, referência
- **Laranja/Amarelo:** Alerta, atenção

**Erros a Evitar:**
- Mais de 5-7 cores distintas
- Cores sem significado consistente
- Baixo contraste com fundo
- Vermelho e verde juntos (daltonismo)

### Princípio 4: Proporção e Escala

**Regra:** Não distorça a realidade.

- Gráficos de barra: SEMPRE começam em zero
- Gráficos de linha: Podem ter base ajustada (com aviso)
- Gráficos de pizza: Máximo 5-6 fatias
- Área: Proporcional ao valor, não ao raio

### Princípio 5: Anotações e Contexto

**Regra:** Dados sem contexto são ruído.

**O que anotar:**
- Eventos que explicam anomalias
- Metas e benchmarks
- Pontos de inflexão importantes
- Fonte dos dados

**Como anotar:**
- Texto curto e direto
- Posicionado próximo ao ponto relevante
- Não obstrui a visualização principal

### Guia de Seleção de Gráfico

**Comparação:**
- Entre categorias → Barras
- Ao longo do tempo → Linhas
- Parte do todo → Pizza/Treemap

**Distribuição:**
- Frequência → Histograma
- Estatística → Box plot
- Correlação → Scatter plot

**Composição:**
- Estática → Pizza (poucas partes)
- Temporal → Área empilhada
- Hierárquica → Treemap

### Checklist Final

**Antes de apresentar, verifique:**

- [ ] O título conta a história principal?
- [ ] A escala está correta e não engana?
- [ ] As cores têm significado consistente?
- [ ] Removi tudo que não é essencial?
- [ ] Alguém de fora entenderia em 5 segundos?
- [ ] A fonte dos dados está indicada?
- [ ] O gráfico responde à pergunta principal?

### Template de Documentação

Para cada visualização, documente:

1. **Pergunta que responde:** "Qual canal tem maior volume?"
2. **Fonte dos dados:** "CRM, período Jan-Mar 2024"
3. **Frequência de atualização:** "Mensal"
4. **Responsável:** "Time de BI"
5. **Decisões que suporta:** "Alocação de recursos por canal"

> "Design de visualização não é sobre fazer bonito. É sobre fazer claro."
> — Protocolo Vértice
`
  },
  {
    id: 15,
    title: "Os 4 Passos do Pitch Perfeito",
    content: `# Os 4 Passos do Pitch Perfeito

## A Fórmula para Convencer em Qualquer Situação

Seja em 30 segundos ou 30 minutos, todo pitch eficaz segue a mesma estrutura. Domine estes 4 passos e você nunca mais vai "travar" em uma apresentação.

### Passo 1: MENSAGEM PRINCIPAL

**O que é:** A ideia central que você quer que fique na cabeça da audiência.

**Características:**
- Uma frase, no máximo duas
- Clara e específica
- Memorável

**Teste:** Se a pessoa só lembrar de uma coisa, o que seria?

**Exemplos:**
- Ruim: "Precisamos melhorar o atendimento"
- Bom: "Podemos reduzir 40% das reclamações com uma mudança de processo"

### Passo 2: DOR QUE VOCÊ SOLUCIONA

**O que é:** O problema real que sua audiência enfrenta.

**Características:**
- Específico e quantificado
- Relevante para quem ouve
- Urgente

**Técnica:** Use a linguagem da audiência, não a sua.

**Exemplos:**
- Para CEO: "Estamos perdendo R$ 2 milhões por ano"
- Para Gerente: "Sua equipe gasta 30% do tempo em retrabalho"
- Para Analista: "Você precisa de 4 horas para gerar esse relatório"

### Passo 3: SOLUÇÃO MATADORA

**O que é:** Sua proposta específica para resolver a dor.

**Características:**
- Concreta e acionável
- Com evidências de que funciona
- Viável de implementar

**Estrutura:**
1. O que você propõe
2. Por que vai funcionar (evidências)
3. Como vai implementar (próximos passos)

**Exemplos:**
- "Propomos implementar [X]. Empresas similares reduziram [Y] em [Z]%. Podemos começar com um piloto de 30 dias."

### Passo 4: BENEFÍCIOS CLAROS

**O que é:** O que a audiência ganha se aceitar sua proposta.

**Características:**
- Traduzidos na linguagem do interlocutor
- Quantificados quando possível
- Conectados à dor apresentada

**Tipos de benefícios:**
- Financeiros: "ROI de 300% em 6 meses"
- Operacionais: "Redução de 4 horas para 30 minutos"
- Estratégicos: "Vantagem competitiva no mercado"
- Pessoais: "Sua equipe vai parar de apagar incêndio"

### Montando Seu Pitch

**Template de 30 segundos:**
"[Mensagem principal]. Hoje, [dor específica]. Com [solução], podemos [benefício quantificado]."

**Exemplo:**
"Podemos reduzir 40% das reclamações com uma mudança simples de processo. Hoje, gastamos R$ 500 mil por mês tratando reclamações que poderiam ser evitadas. Implementando triagem inteligente no primeiro contato, empresas similares reduziram esse custo em 40% — o que significa R$ 200 mil de economia mensal para nós."

### Adaptando ao Tempo

**30 segundos:** 1 frase por passo
**3 minutos:** 1 parágrafo por passo
**10 minutos:** 1-2 slides por passo + Q&A
**30 minutos:** Deep dive em cada passo + discussão

### Erros Comuns

1. **Começar com contexto** — Perde a audiência antes de chegar ao ponto
2. **Dor genérica** — "Precisamos melhorar" não gera urgência
3. **Solução vaga** — "Vamos otimizar processos" não convence
4. **Benefícios abstratos** — "Vai ser melhor" não quantifica valor

### Exercício

Prepare seu próximo pitch usando este template:

1. Mensagem principal: _______________
2. Dor específica: _______________
3. Solução proposta: _______________
4. Benefício quantificado: _______________

> "Um pitch não é sobre você. É sobre o problema da audiência e como você pode resolvê-lo."
> — Protocolo Vértice
`
  },
  {
    id: 16,
    title: "Case Study: O Pitch do Airbnb",
    content: `# Case Study: O Pitch do Airbnb

## Análise do Pitch que Levantou Milhões

O pitch deck original do Airbnb é um dos mais estudados da história das startups. Vamos dissecar o que o tornou tão eficaz e extrair lições aplicáveis a qualquer apresentação de dados.

### O Contexto

**Ano:** 2009
**Objetivo:** Levantar investimento seed
**Resultado:** Conseguiram $600.000 da Sequoia Capital

### Análise Slide a Slide

**Slide 1: O Problema**
"Preço é uma preocupação importante para clientes que fazem reservas de viagem online."

*O que funciona:*
- Começa com a dor do cliente, não com a solução
- Simples e direto
- Quantificável

**Slide 2: A Solução**
"Uma plataforma web onde usuários podem alugar seu espaço para viajantes."

*O que funciona:*
- Uma frase clara
- Fácil de entender
- Diferenciado do existente

**Slide 3: Validação de Mercado**
Números de mercado: $X bilhões em reservas online

*O que funciona:*
- Prova que o mercado existe
- Números grandes geram interesse
- Mostra oportunidade

**Slide 4: Tamanho da Oportunidade**
"630.000 usuários no Couchsurfing, 17.000 listagens temporárias no Craigslist SF"

*O que funciona:*
- Prova de demanda existente
- Dados específicos, não genéricos
- Mostra que pessoas já fazem isso (de forma precária)

**Slide 5: O Produto**
Screenshots da plataforma

*O que funciona:*
- Visual > Descrição
- Mostra que já existe (não é só ideia)
- Interface limpa e profissional

**Slide 6: Modelo de Negócio**
"10% de comissão por transação"

*O que funciona:*
- Simples de entender
- Alinhado com sucesso do cliente
- Escalável

**Slide 7: Tração**
Métricas de crescimento

*O que funciona:*
- Prova que funciona
- Tendência positiva
- Números reais, não projeções

### Lições para Data Storytelling

**1. Comece com o Problema**
- Não com sua solução
- Não com sua empresa
- Com a dor do cliente

**2. Use Dados de Validação**
- Mercado existe (tamanho)
- Demanda existe (comportamento atual)
- Solução funciona (tração)

**3. Seja Específico**
- "630.000 usuários" > "muitos usuários"
- "10% de comissão" > "modelo de receita"
- "3x crescimento mês a mês" > "crescendo rápido"

**4. Mostre, Não Conte**
- Screenshots > Descrições
- Gráficos de tração > Promessas
- Dados reais > Projeções

**5. Mantenha Simples**
- 10 slides
- 1 ideia por slide
- Linguagem clara

### Aplicando ao Seu Contexto

**Se você está apresentando um projeto de CX:**

1. **Problema:** "Nosso NPS caiu 13 pontos em 3 meses"
2. **Causa:** "40% das reclamações são sobre tempo de espera"
3. **Solução:** "Sistema de callback automático"
4. **Validação:** "Empresas similares reduziram abandono em 60%"
5. **Pedido:** "Aprovação para piloto de 30 dias"

### Template Inspirado no Airbnb

1. O Problema (1 slide)
2. A Oportunidade (1 slide)
3. A Solução (1-2 slides)
4. Validação/Tração (1-2 slides)
5. Modelo/Implementação (1 slide)
6. Próximos Passos (1 slide)

> "O pitch do Airbnb não era sobre quartos. Era sobre uma nova forma de viajar. Seu pitch não é sobre dados. É sobre a transformação que os dados possibilitam."
> — Protocolo Vértice
`
  },
  {
    id: 17,
    title: "Template: Estrutura de Pitch 3 Minutos",
    content: `# Template: Estrutura de Pitch 3 Minutos

## O Roteiro Completo para Apresentações Rápidas

Três minutos. 180 segundos. É o tempo que você geralmente tem para convencer alguém em uma reunião executiva. Este template te ajuda a usar cada segundo com propósito.

### Cronograma Detalhado

**0:00 - 0:20 | GANCHO (20 segundos)**
Capture atenção imediatamente.

*Script:*
"[Dado surpreendente ou pergunta provocativa que conecta com a dor da audiência]"

*Exemplo:*
"Ontem, 847 clientes desistiram de falar conosco antes de ser atendidos. Isso é um estádio lotado de pessoas frustradas — todo dia."

**0:20 - 0:50 | PROBLEMA (30 segundos)**
Estabeleça a dor e a urgência.

*Script:*
"O problema é [descrição específica]. Isso está custando [impacto quantificado]. Se não agirmos, [consequência projetada]."

*Exemplo:*
"Nossa taxa de abandono subiu de 8% para 23% nos últimos 6 meses. Isso representa R$ 2,4 milhões em receita perdida por ano. Se a tendência continuar, chegaremos a 35% até dezembro."

**0:50 - 1:50 | SOLUÇÃO (60 segundos)**
Apresente sua proposta com evidências.

*Script:*
"Proponho [solução específica]. Isso funciona porque [evidência/caso similar]. A implementação envolve [passos principais]. O investimento é [custo] com retorno de [benefício] em [prazo]."

*Exemplo:*
"Proponho implementar callback automático para clientes em fila. A Empresa X reduziu abandono em 60% com essa solução. Precisamos de 3 semanas para implementar e R$ 50.000 de investimento. O payback é de 2 meses."

**1:50 - 2:30 | BENEFÍCIOS (40 segundos)**
Traduza em valor para a audiência.

*Script:*
"Com isso, vamos [benefício 1], [benefício 2] e [benefício 3]. Em números: [métrica antes] → [métrica depois]."

*Exemplo:*
"Vamos recuperar R$ 1,2 milhão em receita anual, melhorar o NPS em 8 pontos e reduzir a carga do call center em 20%. Nossa taxa de abandono vai de 23% para menos de 10%."

**2:30 - 3:00 | PEDIDO (30 segundos)**
Feche com ação específica.

*Script:*
"Para avançar, preciso de [pedido específico]. O próximo passo é [ação concreta]. Posso ter uma resposta até [prazo]?"

*Exemplo:*
"Preciso de aprovação para um piloto de 30 dias com a equipe de São Paulo. Se aprovarmos hoje, começamos na segunda. Posso contar com seu ok?"

### Checklist de Preparação

**Conteúdo:**
- [ ] Gancho testado (surpreende em 5 segundos?)
- [ ] Problema quantificado (R$, %, tempo)
- [ ] Solução específica (não genérica)
- [ ] Evidência de que funciona
- [ ] Pedido claro e acionável

**Entrega:**
- [ ] Ensaiado 3x em voz alta
- [ ] Cronometrado (máximo 3:00)
- [ ] Backup para perguntas comuns
- [ ] Material de apoio se pedirem detalhes

### Variações por Audiência

**Para CEO:**
- Foco em impacto financeiro
- Linguagem estratégica
- Conexão com objetivos da empresa

**Para Diretor:**
- Foco em resultados operacionais
- Viabilidade de implementação
- Recursos necessários

**Para Gerente:**
- Foco em execução prática
- Impacto na equipe
- Timeline detalhado

### Erros a Evitar

1. **Começar com "Bom dia, meu nome é..."** — Perde 10 segundos preciosos
2. **Slides demais** — Máximo 3-5 slides de apoio
3. **Ler o slide** — Fale com a audiência, não com a tela
4. **Terminar com "É isso"** — Termine com pedido claro
5. **Não ensaiar** — 3 minutos parecem pouco até você tentar

### Modelo de Slide Único

Se só puder usar 1 slide:

**Título:** [Mensagem principal - o que você quer que façam]
**Subtítulo:** [Problema em uma frase]
**Visual:** [1 gráfico que prova o ponto]
**Bullets:** [3 benefícios quantificados]
**Rodapé:** [Pedido específico]

> "Em 3 minutos, você não tem tempo para ser interessante. Você tem tempo para ser relevante."
> — Protocolo Vértice
`
  }
];

async function generateAndSaveContent(contentData: { id: number; title: string; content: string }) {
  try {
    const fileName = "content_" + contentData.id + "_" + Date.now() + ".md";
    const buffer = Buffer.from(contentData.content, 'utf-8');
    
    const { url } = await storagePut(fileName, buffer, 'text/markdown');
    
    await db.update(contents)
      .set({ 
        fileUrl: url,
        mimeType: 'text/markdown',
        updatedAt: new Date()
      })
      .where(eq(contents.id, contentData.id));
    
    console.log("✅ Conteúdo " + contentData.id + " atualizado: " + contentData.title);
    return true;
  } catch (error) {
    console.error("❌ Erro ao atualizar conteúdo " + contentData.id + ":", error);
    return false;
  }
}

async function main() {
  console.log("🚀 Gerando conteúdos autorais - Batch 1 (Data Storytelling)...");
  
  for (const content of contentsBatch1) {
    await generateAndSaveContent(content);
  }
  
  console.log("\n✅ Batch 1 concluído!");
  process.exit(0);
}

main().catch(console.error);
