/**
 * Script para gerar mini apostilas usando API OpenAI diretamente
 * Executa via: OPENAI_API_KEY=sk-... node scripts/generate-apostilas-openai.mjs --skip-existing
 */
import mysql from 'mysql2/promise';
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const MODEL = "gpt-4o";

const ALL_PERSONAS = ["jovem", "gestor", "executivo", "empresario"];

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ---- PERSONA PROFILES ----
const PERSONA_PROFILES = {
  jovem: {
    label: "Jovem Profissional",
    tone: "Linguagem acessível, motivadora e prática. Use analogias do dia a dia. Fale como um mentor próximo que quer ver o aluno crescer rápido. Evite jargões sem explicação. Energia de 'próximo nível'.",
    examples: "Exemplos de início de carreira, estágios, primeiros projetos, situações de quem está entrando no mercado. Referências a startups, empresas de tecnologia, ambientes ágeis.",
    language: "Informal-profissional. Use 'você' direto, frases curtas, parágrafos concisos. Pode usar expressões como 'bora lá', 'na prática funciona assim'.",
  },
  gestor: {
    label: "Gestor / Coordenador",
    tone: "Linguagem direta, orientada a resultado e aplicação imediata. Fale como um par experiente que já viveu os desafios de gestão. Sem achismo: hipótese, evidência e decisão.",
    examples: "Exemplos de gestão de equipes, projetos de melhoria, reuniões de resultado, KPIs de área, rituais de governança. Referências a operações de médio porte.",
    language: "Profissional-executivo. Objetividade, dados, frameworks aplicáveis. Foco em 'como implementar amanhã'.",
  },
  executivo: {
    label: "Executivo / Diretor / C-Level",
    tone: "Linguagem estratégica, concisa e orientada a impacto no negócio. Fale como um conselheiro de alto nível. O que não é medido vira opinião — traga números.",
    examples: "Exemplos de decisões estratégicas, business cases com ROI, transformações organizacionais, board presentations.",
    language: "Executivo-estratégico. Frases assertivas, números de impacto, visão de portfólio. 1-pager mindset.",
  },
  empresario: {
    label: "Empresário / Dono de Negócio",
    tone: "Linguagem pragmática, focada em resultado financeiro e competitividade. Fale como um consultor que entende a dor de quem paga as contas.",
    examples: "Exemplos de PMEs, decisões de investimento, competitividade de mercado, retenção de clientes, margem, fluxo de caixa.",
    language: "Direto ao ponto. Foco em 'quanto custa', 'quanto gera', 'como implementar com pouco'. Linguagem de quem resolve.",
  },
};

// ---- PROMPT COMPONENTS ----
const IDENTITY_DATACX = `
IDENTIDADE DATA CX / PROTOCOLO VÉRTICE:
Você escreve como Samuel Rosa, mentor e especialista em CX, Dados e IA. O tom é de "mentor em sala de guerra" — simples, firme e prático. Humanizado, leve, executivo e com impacto.

FRASES ASSINATURA (use naturalmente, máximo 2-3 por apostila):
- "Vamos ao que interessa."
- "Na prática funciona assim…"
- "Sem achismo: hipótese, evidência e decisão."
- "O que não é medido vira opinião."
- "Próximo nível."

GLOSSÁRIO PROTOCOLO VÉRTICE (inclua no glossário quando relevante):
- Protocolo Vértice: Metodologia que integra CX, Dados e IA para transformar operações e decisões.
- Radar Vértice: Ferramenta diagnóstica de maturidade em CX, Dados e IA.
- Cockpit Executivo: Dashboard estratégico consolidando indicadores-chave.
- Esteira de Impacto: Sequência de ações que transforma diagnóstico em resultado mensurável.
- Mensageria Just-in-Time: Comunicação contextual baseada em dados comportamentais.
- Backlog Vértice: Lista priorizada de iniciativas por impacto e esforço.
- 1-Pager Executivo: Documento síntese para decisores.
- Ritos de Governança: Reuniões estruturadas para acompanhamento de indicadores.
`;

const REFERENCES_GUIDE = `
REFERÊNCIAS (use 5-8 por apostila):
- Fred Reichheld — NPS, "The Ultimate Question 2.0"
- W. Edwards Deming — Qualidade, PDCA, "Out of the Crisis"
- Don Norman — "The Design of Everyday Things"
- Clayton Christensen — Jobs to Be Done
- Teresa Torres — Continuous Discovery Habits
- COPC — Excelência operacional em CX
- Lean Six Sigma — Melhoria contínua
- NIST AI Risk Management Framework
- McKinsey, Forrester, Gartner — Relatórios
Cite como referência, escreva de forma autoral.
`;

const EXERCISES_GUIDE = `
EXERCÍCIOS — com ferramentas reais:
- Excel/Sheets, Power BI, ChatGPT, NotebookLM
Cada exercício gera artefato tangível:
- Rápido: Reflexão escrita ou mini-análise
- Prático: 1-Pager, Backlog, Blueprint, Cockpit
- Projeto: Plano 5W2H, Business Case com ROI
`;

const CASES_GUIDE = `
MINI-CASES:
- 70% fictícios realistas, 30% inspirados em projetos reais anonimizados
- Inclua: contexto com números, desafio, decisão, resultado mensurável
- Varie setores: varejo, saúde, educação, tech, financeiro, indústria, logística
`;

const APOSTILA_STRUCTURE = `
Estrutura obrigatória:
1. CAPA CURTA: Título criativo + "O que você vai dominar" (3-4 linhas)
2. RESUMO EXECUTIVO (~90s leitura): Contexto + problema + aplicação + resultado
3. AULA PRINCIPAL: Explicação completa, subtítulos, exemplos, mínimo 4-5 subtópicos
4. FRAMEWORKS E PASSO A PASSO: 1-2 frameworks com quando usar/não usar
5. MINI-CASE AUTORAL: Caso realista com números
6. EXERCÍCIOS (3 níveis): Rápido / Prático / Projeto + gabarito
7. CHECKLIST DE DOMÍNIO: 5-7 itens
8. GLOSSÁRIO ESSENCIAL: 10-15 termos
9. REFERÊNCIAS: 5-8 referências

REGRAS: Zero tópicos vazios. Zero instruções admin. Mínimo 3500 palavras. Markdown rico.
`;

// ---- LLM CALL via OpenAI (direct fetch) ----
async function callOpenAI(messages, maxTokens = 16000) {
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: MODEL,
      messages,
      max_tokens: maxTokens,
      temperature: 0.7,
    }),
  });
  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    throw new Error(`OpenAI ${res.status}: ${errText.substring(0, 200)}`);
  }
  const data = await res.json();
  return data.choices?.[0]?.message?.content || "";
}

// ---- GENERATE APOSTILA ----
async function generateApostila(title, description, content, persona, pilar) {
  const profile = PERSONA_PROFILES[persona];

  const systemPrompt = `Você é Samuel Rosa, mentor e especialista em CX, Dados e IA, criador do Protocolo Vértice. Você está escrevendo uma MINI APOSTILA completa para a plataforma Data CX Mentoria.

${IDENTITY_DATACX}

PERSONA: ${profile.label}
TOM: ${profile.tone}
EXEMPLOS: ${profile.examples}
LINGUAGEM: ${profile.language}
PILAR: ${pilar}

${APOSTILA_STRUCTURE}
${CASES_GUIDE}
${EXERCISES_GUIDE}
${REFERENCES_GUIDE}

Retorne APENAS o markdown da apostila. Comece direto com o título criativo.`;

  const userPrompt = `Transforme o conteúdo-base do módulo "${title}" em uma mini apostila completa para "${profile.label}".

Descrição: ${description || "Não fornecida"}

Conteúdo-base:
---
${content.substring(0, 12000)}
---

Gere a mini apostila completa. Mínimo 3500 palavras, cases com números, exercícios com ferramentas reais.`;

  const markdown = await callOpenAI([
    { role: "system", content: systemPrompt },
    { role: "user", content: userPrompt },
  ], 16000);

  // Generate audio script
  const durationGuide = persona === "executivo"
    ? "6 a 9 minutos (~900-1350 palavras)"
    : persona === "jovem"
    ? "9 a 13 minutos (~1350-1950 palavras)"
    : "8 a 12 minutos (~1200-1800 palavras)";

  const audioScript = await callOpenAI([
    {
      role: "system",
      content: `Você é Daniel, narrador da Data CX Mentoria. Tom: conversacional-executivo, "mentor em sala de guerra".
Duração: ${durationGuide}. Escreva como se estivesse FALANDO. Sem marcações de roteiro.
Estrutura: Abertura (20s) + 3 pontos principais + Mini-case narrado + Fechamento.
PERSONA: ${profile.label}. TOM: ${profile.tone}
Retorne APENAS o texto do roteiro.`,
    },
    {
      role: "user",
      content: `Roteiro de áudio para "${title}" (pilar: ${pilar}):\n\n${markdown.substring(0, 8000)}`,
    },
  ], 8000);

  return { markdown, audioScript };
}

// ---- RETRY LOGIC ----
async function generateWithRetry(title, description, content, persona, pilar, maxRetries, delayMs) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      if (attempt > 1) {
        const backoff = delayMs * attempt;
        console.log(`    ⏳ Retry ${attempt}/${maxRetries} after ${backoff/1000}s...`);
        await sleep(backoff);
      }
      return await generateApostila(title, description, content, persona, pilar);
    } catch (error) {
      if (attempt === maxRetries) throw error;
      console.log(`    ⚠️  Attempt ${attempt} failed: ${error.message.substring(0, 100)}`);
    }
  }
}

// ---- MAIN ----
async function main() {
  if (!OPENAI_API_KEY) {
    console.error("❌ OPENAI_API_KEY not set!");
    process.exit(1);
  }

  const args = process.argv.slice(2);
  let contentIds = null;
  let personas = ALL_PERSONAS;
  let skipExisting = false;
  let maxRetries = 3;
  let delayMs = 2000; // OpenAI is more stable, shorter delay

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--content-ids' && args[i+1]) {
      contentIds = args[i+1].split(',').map(Number);
      i++;
    } else if (args[i] === '--personas' && args[i+1]) {
      personas = args[i+1].split(',');
      i++;
    } else if (args[i] === '--skip-existing') {
      skipExisting = true;
    } else if (args[i] === '--retries' && args[i+1]) {
      maxRetries = parseInt(args[i+1]);
      i++;
    } else if (args[i] === '--delay' && args[i+1]) {
      delayMs = parseInt(args[i+1]) * 1000;
      i++;
    }
  }

  const conn = await mysql.createConnection(process.env.DATABASE_URL);

  let query = "SELECT id, title, description, markdownContent, pilar, moduleCode FROM contents";
  let params = [];
  if (contentIds) {
    query += ` WHERE id IN (${contentIds.map(() => '?').join(',')})`;
    params = contentIds;
  }
  query += " ORDER BY pilar, id";
  const [modules] = await conn.execute(query, params);

  console.log(`=== Geração de Mini Apostilas (OpenAI ${MODEL}) ===`);
  console.log(`Módulos: ${modules.length}`);
  console.log(`Personas: ${personas.join(', ')}`);
  console.log(`Total máximo: ${modules.length * personas.length}`);
  console.log(`Skip existing: ${skipExisting}`);
  console.log(`Retries: ${maxRetries}, Delay: ${delayMs/1000}s`);
  console.log('');

  let success = 0, skipped = 0, errors = 0;

  for (const mod of modules) {
    console.log(`\n📚 ${mod.moduleCode} - ${mod.title}`);

    for (const persona of personas) {
      const startTime = Date.now();

      if (skipExisting) {
        const [existing] = await conn.execute(
          "SELECT apostilaStatus FROM content_persona_versions WHERE contentId = ? AND persona = ?",
          [mod.id, persona]
        );
        if (existing.length > 0 && existing[0].apostilaStatus === 'ready') {
          console.log(`  ⏭️  ${persona}: já existe`);
          skipped++;
          continue;
        }
      }

      console.log(`  🎯 ${persona}: gerando...`);
      await sleep(delayMs);

      try {
        // Upsert generating status
        const [existing] = await conn.execute(
          "SELECT id FROM content_persona_versions WHERE contentId = ? AND persona = ?",
          [mod.id, persona]
        );
        if (existing.length > 0) {
          await conn.execute(
            "UPDATE content_persona_versions SET apostilaStatus = 'generating', audioStatus = 'pending' WHERE contentId = ? AND persona = ?",
            [mod.id, persona]
          );
        } else {
          await conn.execute(
            "INSERT INTO content_persona_versions (contentId, persona, apostilaStatus, audioStatus) VALUES (?, ?, 'generating', 'pending')",
            [mod.id, persona]
          );
        }

        const { markdown, audioScript } = await generateWithRetry(
          mod.title, mod.description || "", mod.markdownContent || "",
          persona, mod.pilar || "CX", maxRetries, delayMs
        );

        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);

        await conn.execute(
          "UPDATE content_persona_versions SET apostilaMarkdown = ?, audioScriptAdmin = ?, apostilaStatus = 'ready', generatedAt = NOW() WHERE contentId = ? AND persona = ?",
          [markdown, audioScript, mod.id, persona]
        );

        console.log(`  ✅ ${persona}: ${markdown.length} chars, ${elapsed}s`);
        success++;

      } catch (error) {
        console.error(`  ❌ ${persona}: ${error.message?.substring(0, 120)}`);
        await conn.execute(
          "UPDATE content_persona_versions SET apostilaStatus = 'error' WHERE contentId = ? AND persona = ?",
          [mod.id, persona]
        ).catch(() => {});
        errors++;
      }
    }
  }

  await conn.end();

  console.log(`\n=== Resultado ===`);
  console.log(`✅ Sucesso: ${success}`);
  console.log(`⏭️  Pulados: ${skipped}`);
  console.log(`❌ Erros: ${errors}`);
}

main().catch(console.error);
