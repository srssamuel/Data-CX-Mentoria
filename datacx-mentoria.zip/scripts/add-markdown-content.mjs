import mysql from 'mysql2/promise';

const contentMarkdown = {
  1: `# Módulo 1: Introdução ao Data Storytelling

## O que é Data Storytelling?

**Data Storytelling** é a arte de transformar dados brutos em narrativas poderosas que influenciam decisões. Não se trata apenas de criar gráficos bonitos, mas de construir uma história que conecta dados a ações concretas.

> "Dados são a nova moeda do século XXI, mas sem contexto e narrativa, são apenas números." — Protocolo Vértice

## Por que Data Storytelling é essencial?

Segundo pesquisas da McKinsey, **80% das inovações de negócios até 2025 serão baseadas em dados visualizados**. Empresas que dominam a arte de contar histórias com dados têm:

- **3x mais chances** de tomar decisões assertivas
- **40% mais engajamento** em apresentações executivas
- **2x mais velocidade** na aprovação de projetos

## Os 3 Pilares do Data Storytelling

### 1. Dados (A Fundação)
Sem dados confiáveis, não há história. A coleta, limpeza e validação são etapas fundamentais.

### 2. Narrativa (O Fio Condutor)
A estrutura da história: contexto, conflito, resolução. Todo dado precisa de um "por quê".

### 3. Visualização (O Impacto)
O visual certo amplifica a mensagem. Gráficos mal escolhidos podem destruir uma boa história.

## Exercício Prático

Pense em uma decisão recente na sua empresa que foi tomada "no achismo". Como dados poderiam ter mudado essa decisão?

---

*Este conteúdo faz parte do Protocolo Vértice — Mentoria em CX, Dados e IA.*
`,

  2: `# A História de Florence Nightingale

## A Mãe da Visualização de Dados

**Florence Nightingale** (1820-1910) não foi apenas a fundadora da enfermagem moderna. Ela foi uma das primeiras pessoas a usar visualização de dados para influenciar políticas públicas.

> "Para entender os pensamentos de Deus, devemos estudar estatísticas, pois estas são a medida de Seus propósitos." — Florence Nightingale

## O Contexto: Guerra da Crimeia (1853-1856)

Durante a Guerra da Crimeia, Florence percebeu que mais soldados morriam de doenças evitáveis do que em combate. Mas como convencer os políticos britânicos a agir?

## A Solução: O Diagrama da Rosa

Florence criou o famoso **"Diagrama da Rosa"** (Coxcomb Chart), uma visualização inovadora que mostrava claramente:

- **Azul**: Mortes por doenças evitáveis
- **Vermelho**: Mortes em combate
- **Preto**: Outras causas

O impacto visual foi devastador: as mortes evitáveis superavam dramaticamente as mortes em batalha.

## O Resultado

Com essa visualização, Florence conseguiu:

1. **Convencer o Parlamento** a reformar os hospitais militares
2. **Reduzir a taxa de mortalidade** de 42% para 2%
3. **Criar padrões sanitários** que salvaram milhões de vidas

## A Lição para Hoje

Florence nos ensina que **dados sem visualização são apenas números**. A forma como apresentamos informações pode literalmente salvar vidas — ou, no contexto empresarial, salvar projetos, carreiras e empresas.

## Reflexão

Você tem dados importantes que não estão sendo "ouvidos"? Talvez o problema não seja o dado, mas a forma como você está contando a história.

---

*Este conteúdo faz parte do Protocolo Vértice — Mentoria em CX, Dados e IA.*
`,

  3: `# Dados, Informação e Insight: A Pirâmide do Conhecimento

## Entendendo a Hierarquia

Muitos profissionais confundem **dados** com **informação** e **informação** com **insight**. Essa confusão custa caro: decisões erradas, projetos mal direcionados e oportunidades perdidas.

## A Pirâmide DIKW

A Pirâmide DIKW (Data, Information, Knowledge, Wisdom) é um modelo clássico que nos ajuda a entender a transformação de dados brutos em sabedoria aplicável.

### Nível 1: Dados (Data)
**O que são?** Fatos brutos, sem contexto.

*Exemplo:* "42"

### Nível 2: Informação (Information)
**O que é?** Dados com contexto e significado.

*Exemplo:* "42 é o NPS da empresa no último trimestre"

### Nível 3: Conhecimento (Knowledge)
**O que é?** Informação processada e conectada a padrões.

*Exemplo:* "O NPS de 42 está 15 pontos abaixo da média do setor e caiu 8 pontos em relação ao trimestre anterior"

### Nível 4: Sabedoria/Insight (Wisdom)
**O que é?** Conhecimento aplicado para ação.

*Exemplo:* "Precisamos investigar o atendimento pós-venda, pois 70% das reclamações do período estão relacionadas a esse touchpoint"

## O Erro Comum

A maioria das empresas para no Nível 2 (Informação). Criam dashboards cheios de números, mas não transformam esses números em ações.

> "Um dashboard sem insight é apenas decoração de parede." — Protocolo Vértice

## Como Subir na Pirâmide

1. **Sempre pergunte "E daí?"** — Se o dado não leva a uma ação, ele é apenas ruído.
2. **Compare com benchmarks** — Dados isolados não dizem nada.
3. **Busque padrões temporais** — Tendências são mais importantes que snapshots.
4. **Conecte com o negócio** — Todo insight deve ter impacto em receita, custo ou experiência.

---

*Este conteúdo faz parte do Protocolo Vértice — Mentoria em CX, Dados e IA.*
`,

  18: `# Pilar 1: Introdução às Metodologias Ágeis

## O Fim do "Achismo" na Gestão

**Metodologias Ágeis** não são apenas sobre desenvolvimento de software. São sobre criar uma cultura de **experimentação, feedback rápido e melhoria contínua** em qualquer área.

> "Agilidade não é fazer mais rápido. É aprender mais rápido." — Protocolo Vértice

## Por que Metodologias Ágeis?

O mundo mudou. O ciclo de planejamento anual não funciona mais quando:

- **Mercados mudam em semanas**, não em anos
- **Clientes esperam respostas imediatas**
- **Tecnologia evolui exponencialmente**

## Os 4 Valores do Manifesto Ágil

1. **Indivíduos e interações** mais que processos e ferramentas
2. **Software funcionando** mais que documentação abrangente
3. **Colaboração com o cliente** mais que negociação de contratos
4. **Responder a mudanças** mais que seguir um plano

## Metodologias que Você Vai Aprender

### Scrum
Framework para times que precisam entregar valor em ciclos curtos (Sprints).

### Kanban
Sistema visual para gerenciar fluxo de trabalho e identificar gargalos.

### OKRs
Método para alinhar objetivos estratégicos com resultados mensuráveis.

### Design Thinking
Abordagem centrada no usuário para resolver problemas complexos.

## O Protocolo Vértice e Agilidade

No Protocolo Vértice, usamos metodologias ágeis para:

- **Clareza**: Definir o problema antes de buscar soluções
- **Evidência**: Validar hipóteses com dados reais
- **Prioridade**: Focar no que gera mais impacto
- **Execução**: Entregar em ciclos curtos com feedback
- **Escala**: Replicar o que funciona

---

*Este conteúdo faz parte do Protocolo Vértice — Mentoria em CX, Dados e IA.*
`,

  24: `# Pilar 2: Fundamentos de Customer Experience

## CX não é Atendimento

**Customer Experience (CX)** é a soma de todas as interações que um cliente tem com sua marca. Não é apenas o SAC ou o pós-venda — é toda a jornada.

> "CX é o que o cliente sente sobre sua empresa. Não é o que você acha que ele sente." — Protocolo Vértice

## Os 6 Pilares do CX

### 1. Personalização
Tratar cada cliente como único, usando dados para criar experiências relevantes.

### 2. Integridade
Cumprir promessas e ser transparente, mesmo quando é difícil.

### 3. Expectativas
Gerenciar e superar expectativas de forma consistente.

### 4. Resolução
Transformar problemas em oportunidades de fidelização.

### 5. Tempo e Esforço
Minimizar o esforço do cliente em cada interação.

### 6. Empatia
Demonstrar compreensão genuína das necessidades do cliente.

## O Impacto Financeiro do CX

Segundo a Forrester Research:

- Empresas líderes em CX têm **5,7x mais receita** que retardatárias
- **86% dos clientes** pagam mais por uma experiência melhor
- Aumentar retenção em **5%** pode aumentar lucros em **25-95%**

## CX e o Protocolo Vértice

No Protocolo Vértice, CX é o centro de tudo:

- **Clareza**: Entender a jornada real do cliente
- **Evidência**: Medir cada touchpoint
- **Prioridade**: Focar nos momentos de verdade
- **Execução**: Implementar melhorias rápidas
- **Escala**: Sistematizar a excelência

## Exercício

Mapeie os últimos 3 touchpoints que você teve como cliente de alguma empresa. O que funcionou? O que frustrou?

---

*Este conteúdo faz parte do Protocolo Vértice — Mentoria em CX, Dados e IA.*
`,

  30: `# Pilar 3: Noções de Estatística para CX

## Estatística sem Medo

Você não precisa ser estatístico para usar dados. Precisa entender os conceitos fundamentais que transformam números em decisões.

> "Estatística é a arte de torturar números até que eles confessem." — Protocolo Vértice (com humor)

## Os 5 Conceitos Essenciais

### 1. Média, Mediana e Moda

- **Média**: Soma dividida pela quantidade. Sensível a outliers.
- **Mediana**: O valor do meio. Mais robusta para dados assimétricos.
- **Moda**: O valor mais frequente. Útil para dados categóricos.

*Exemplo CX:* Se 9 clientes dão nota 8 e 1 cliente dá nota 0, a média é 7,2. Mas a mediana é 8. Qual representa melhor a realidade?

### 2. Desvio Padrão

Mede a dispersão dos dados. Um NPS médio de 50 com desvio padrão de 5 é muito diferente de um NPS 50 com desvio de 30.

### 3. Correlação vs Causalidade

**Correlação**: Duas variáveis se movem juntas.
**Causalidade**: Uma variável causa a outra.

*Armadilha comum:* "Vendas de sorvete e afogamentos estão correlacionados" não significa que sorvete causa afogamentos. Ambos são causados pelo verão.

### 4. Amostragem

Não precisa pesquisar 100% dos clientes. Uma amostra bem selecionada pode representar a população com margem de erro conhecida.

### 5. Significância Estatística

Quando uma diferença é real ou apenas ruído? Testes estatísticos ajudam a responder.

## Aplicação Prática em CX

- **NPS**: Use mediana além da média
- **Pesquisas**: Calcule margem de erro
- **A/B Tests**: Verifique significância antes de concluir
- **Tendências**: Cuidado com correlações espúrias

---

*Este conteúdo faz parte do Protocolo Vértice — Mentoria em CX, Dados e IA.*
`
};

async function updateContents() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  
  for (const [id, markdown] of Object.entries(contentMarkdown)) {
    try {
      await conn.execute(
        'UPDATE contents SET markdownContent = ? WHERE id = ?',
        [markdown, parseInt(id)]
      );
      console.log('✓ Atualizado conteúdo ID ' + id);
    } catch (err) {
      console.error('✗ Erro ao atualizar ID ' + id + ':', err.message);
    }
  }
  
  // Atualizar categorias dos conteúdos
  const categoryUpdates = [
    // Introdução (1-17)
    { ids: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17], category: 'introducao' },
    // Metodologias Ágeis (18-23) -> dados
    { ids: [18, 19, 20, 21, 22, 23], category: 'dados' },
    // CX (24-29)
    { ids: [24, 25, 26, 27, 28, 29], category: 'cx' },
    // Dados/BI (30-35)
    { ids: [30, 31, 32, 33, 34, 35], category: 'dados' }
  ];
  
  for (const update of categoryUpdates) {
    for (const id of update.ids) {
      try {
        await conn.execute(
          'UPDATE contents SET category = ? WHERE id = ?',
          [update.category, id]
        );
      } catch (err) {
        console.error('Erro ao atualizar categoria do ID ' + id + ':', err.message);
      }
    }
    console.log('✓ Categoria "' + update.category + '" aplicada aos IDs: ' + update.ids.join(', '));
  }
  
  // Adicionar URLs de vídeo do YouTube para alguns conteúdos de tipo video
  const videoUpdates = [
    { id: 3, videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
    { id: 4, videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
    { id: 7, videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
    { id: 18, videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
    { id: 24, videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  ];
  
  for (const update of videoUpdates) {
    try {
      await conn.execute(
        'UPDATE contents SET videoUrl = ? WHERE id = ?',
        [update.videoUrl, update.id]
      );
      console.log('✓ Vídeo adicionado ao ID ' + update.id);
    } catch (err) {
      console.error('Erro ao adicionar vídeo ao ID ' + update.id + ':', err.message);
    }
  }
  
  await conn.end();
  console.log('\n✓ Todos os conteúdos atualizados com sucesso!');
}

updateContents().catch(console.error);
