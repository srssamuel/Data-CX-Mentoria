import mysql from 'mysql2/promise';

const plans = [
  {
    slug: 'playbook_377',
    name: 'Playbook — Fundamentos',
    description: 'Base + linguagem + aplicação rápida com leitura robusta. 16 módulos cobrindo fundamentos de CX, Dados e IA.',
    shortDescription: 'Fundamentos de CX, Dados e IA em 16 módulos',
    type: 'group',
    duration: 'Acesso por 6 meses',
    price: '377.00',
    features: JSON.stringify(['16 módulos de fundamentos', 'Quizzes por módulo', 'Chat IA contextual', 'Certificado por categoria', 'Acesso ao Radar Vértice']),
  },
  {
    slug: 'grupo_8_semanas',
    name: 'Mentoria em Grupo — 8 Semanas',
    description: 'Fundamentos completos + prática guiada + entregáveis. 36 módulos com acompanhamento em grupo.',
    shortDescription: 'Fundamentos + prática guiada em 36 módulos',
    type: 'group',
    duration: '8 semanas',
    price: '1497.00',
    features: JSON.stringify(['36 módulos (fundamentos + prática)', 'Sessões em grupo semanais', 'Quizzes e exercícios práticos', 'Chat IA contextual', 'Certificado por categoria', 'Acesso ao Radar Vértice', 'Comunidade exclusiva']),
  },
  {
    slug: 'individual_90_dias',
    name: 'Mentoria Individual — 90 Dias',
    description: 'Fundamentos + prática completa + especialização selecionada por Radar. 52 módulos com acompanhamento individual.',
    shortDescription: 'Programa completo com 52 módulos e mentoria individual',
    type: 'individual',
    duration: '90 dias',
    price: '4997.00',
    features: JSON.stringify(['52 módulos (fundamentos + prática + especialização)', 'Sessões individuais semanais', 'Trilha personalizada pelo Radar Vértice', 'Quizzes e projetos práticos', 'Chat IA contextual', 'Certificado por categoria', 'Acesso vitalício ao conteúdo', 'Comunidade exclusiva']),
  },
  {
    slug: 'executive_6m',
    name: 'Mentoria Executive — 6 Meses',
    description: 'Decisão + governança + ROI + risco, sem virar técnico. 24 módulos focados em liderança e estratégia.',
    shortDescription: 'Liderança e estratégia em CX, Dados e IA',
    type: 'individual',
    duration: '6 meses',
    price: '9997.00',
    features: JSON.stringify(['24 módulos de liderança e estratégia', 'Sessões individuais quinzenais', 'Foco em decisão e governança', 'ROI e business case', 'Chat IA contextual', 'Certificado executivo', 'Acesso vitalício', 'Networking executivo']),
  },
  {
    slug: 'empresas_diagnostico',
    name: 'Empresas — Diagnóstico Vértice',
    description: 'Diagnóstico + backlog + roadmap 90 dias + business case. 11 módulos focados em diagnóstico empresarial.',
    shortDescription: 'Diagnóstico empresarial com roadmap e business case',
    type: 'diagnostic',
    duration: '2–4 semanas',
    price: '14997.00',
    features: JSON.stringify(['11 módulos de diagnóstico', 'Diagnóstico completo da operação', 'Backlog priorizado', 'Roadmap 90 dias', 'Business case com ROI', 'Relatório executivo', 'Sessões com liderança']),
  },
];

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);

  // Delete old programs
  await conn.query('DELETE FROM enrollments');
  await conn.query('DELETE FROM mentorship_programs');

  // Insert new programs
  for (const plan of plans) {
    await conn.query(
      `INSERT INTO mentorship_programs (slug, name, description, shortDescription, type, duration, price, features, isActive)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, true)`,
      [plan.slug, plan.name, plan.description, plan.shortDescription, plan.type, plan.duration, plan.price, plan.features]
    );
    console.log(`✅ Plano criado: ${plan.slug} - ${plan.name}`);
  }

  // Verify
  const [rows] = await conn.query('SELECT id, slug, name, price FROM mentorship_programs ORDER BY id');
  console.log('\nPlanos criados:', JSON.stringify(rows, null, 2));

  await conn.end();
  console.log('\n✅ Planos V2 atualizados com sucesso!');
}

main().catch(console.error);
