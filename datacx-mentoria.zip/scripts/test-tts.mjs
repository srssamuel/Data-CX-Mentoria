import { ENV } from '../server/_core/env.ts';
import fs from 'fs';

const baseUrl = ENV.forgeApiUrl.endsWith('/') ? ENV.forgeApiUrl : ENV.forgeApiUrl + '/';
const ttsUrl = new URL('v1/audio/speech', baseUrl).toString();
console.log('TTS URL:', ttsUrl);
console.log('API Key (first 20):', ENV.forgeApiKey.substring(0, 20));

const response = await fetch(ttsUrl, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + ENV.forgeApiKey,
  },
  body: JSON.stringify({
    model: 'tts-1',
    input: 'Olá, este é um teste de geração de áudio para a plataforma Data CX Mentoria.',
    voice: 'nova',
    speed: 1.0,
    response_format: 'mp3',
  }),
});

console.log('Status:', response.status, response.statusText);
const contentType = response.headers.get('content-type');
console.log('Content-Type:', contentType);

if (response.ok) {
  const buf = Buffer.from(await response.arrayBuffer());
  console.log('Audio size:', buf.length, 'bytes');
  fs.writeFileSync('/tmp/test-audio.mp3', buf);
  console.log('Saved to /tmp/test-audio.mp3');
} else {
  const text = await response.text();
  console.log('Error body:', text);
}
