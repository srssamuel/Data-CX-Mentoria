/**
 * Script to create an admin user directly via the project's database helpers.
 * Run from the project root: node scripts/create-admin.mjs
 * 
 * This script loads env from the running server process.
 */
import crypto from "crypto";
import { scrypt, randomBytes } from "crypto";

// We need to connect directly. Let's use the server's env.
// The DATABASE_URL is injected at runtime, so we read it from the running process.

async function hashPassword(password) {
  return new Promise((resolve, reject) => {
    const salt = randomBytes(16).toString("hex");
    scrypt(password, salt, 64, (err, derivedKey) => {
      if (err) reject(err);
      resolve(`${salt}:${derivedKey.toString("hex")}`);
    });
  });
}

async function main() {
  // Get DATABASE_URL from the dev server process
  const { execSync } = await import("child_process");
  
  // Try to get it from the running node process
  let dbUrl;
  try {
    const pid = execSync("pgrep -f 'tsx.*server/_core/index.ts' | head -1", { encoding: "utf-8" }).trim();
    if (pid) {
      dbUrl = execSync(`cat /proc/${pid}/environ 2>/dev/null | tr '\\0' '\\n' | grep '^DATABASE_URL=' | cut -d= -f2-`, { encoding: "utf-8" }).trim();
    }
  } catch (e) {}
  
  if (!dbUrl) {
    // Try from the webdev secrets
    try {
      dbUrl = execSync("cat /proc/$(pgrep -f 'node.*server' | head -1)/environ 2>/dev/null | tr '\\0' '\\n' | grep '^DATABASE_URL=' | cut -d= -f2-", { encoding: "utf-8" }).trim();
    } catch (e) {}
  }

  if (!dbUrl) {
    console.error("Could not find DATABASE_URL. Make sure the dev server is running.");
    process.exit(1);
  }

  console.log("Found DATABASE_URL, connecting...");

  // Dynamic import mysql2
  const mysql = await import("mysql2/promise");
  
  const url = new URL(dbUrl);
  const conn = await mysql.createConnection({
    host: url.hostname,
    port: parseInt(url.port || "4000"),
    user: url.username,
    password: decodeURIComponent(url.password),
    database: url.pathname.slice(1),
    ssl: { rejectUnauthorized: false },
  });

  const email = "admin@datacx.com.br";
  const name = "Admin DCX";
  const rawPassword = "DataCX@2026!";
  const openId = `email_${crypto.randomUUID()}`;
  const passwordHash = await hashPassword(rawPassword);

  // Check if already exists
  const [existing] = await conn.query("SELECT id, role FROM users WHERE email = ?", [email]);
  if (existing.length > 0) {
    await conn.query(
      "UPDATE users SET role = 'admin', passwordHash = ?, name = ?, updatedAt = NOW() WHERE email = ?",
      [passwordHash, name, email]
    );
    console.log(`User ${email} updated to admin with new password.`);
    console.log(`User ID: ${existing[0].id}`);
  } else {
    await conn.query(
      `INSERT INTO users (openId, name, email, passwordHash, loginMethod, role, lastSignedIn, createdAt, updatedAt) 
       VALUES (?, ?, ?, ?, 'email', 'admin', NOW(), NOW(), NOW())`,
      [openId, name, email, passwordHash]
    );
    const [newUser] = await conn.query("SELECT id FROM users WHERE email = ?", [email]);
    console.log(`Admin user created: ${email}`);
    console.log(`User ID: ${newUser[0].id}`);
  }

  // Grant all module access
  const [userRow] = await conn.query("SELECT id FROM users WHERE email = ?", [email]);
  const userId = userRow[0].id;

  const [modules] = await conn.query("SELECT code FROM modules");
  console.log(`Found ${modules.length} modules to grant access.`);

  for (const mod of modules) {
    await conn.query(
      `INSERT IGNORE INTO user_module_overrides (userId, moduleCode, granted, createdAt) VALUES (?, ?, true, NOW())`,
      [userId, mod.code]
    );
  }
  console.log(`Granted access to all ${modules.length} modules.`);

  console.log("\n=== CREDENCIAIS ===");
  console.log(`E-mail: ${email}`);
  console.log(`Senha: ${rawPassword}`);
  console.log(`Role: admin`);
  console.log(`Acesso: Total (área de membros + painel admin)`);

  await conn.end();
}

main().catch(console.error);
