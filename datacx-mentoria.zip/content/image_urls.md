# URLs das Imagens - Data CX Mentoria

## Fotos Profissionais do Samuel Rosa

1. **Foto Profissional 1** (Estilo corporativo com fundo azul)
   - CDN URL: https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/fwSUhaduregnJktK.png

2. **Foto Profissional 2** (Estilo executivo com fundo neutro)
   - CDN URL: https://files.manuscdn.com/user_upload_by_module/session_file/310519663200698662/LCMloBDMEmUQZzBD.png

## Uso no Site

As fotos podem ser utilizadas nas seguintes seções:
- Página Sobre (hero section)
- Seção de apresentação na Home
- Cards de depoimentos/mentor
- Área de membros (perfil)
