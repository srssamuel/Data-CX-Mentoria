# Protocolo Vértice

## Definição

Protocolo Vértice é a metodologia de Samuel Rosa para transformar CX, dados e IA em resultado real. Ele existe para tirar a operação do "achismo", aumentar previsibilidade e acelerar decisão — com governança, cadência e execução.

## Taglines

- **Onde CX, dados e IA viram resultado.**
- Evidência. Prioridade. Execução. Escala.
- Do atrito ao ROI — com método.

## O que "Vértice" significa

Vértice é o ponto de convergência. Na prática, é onde três coisas se encontram e deixam de ser discurso:

1. **Experiência do cliente (CX)** — o que o cliente sente e por que ele insiste/reclama/abandona.
2. **Dados** — o que explica causa, não só efeito.
3. **IA aplicada** — o que escala análise e automação com controle.

No Vértice, você para de discutir opinião e começa a discutir evidência.

## Manifesto

Eu não acredito em CX como "projeto bonito". Eu acredito em CX como sistema.

Eu não acredito em dados como "report". Eu acredito em dados como motor de decisão.

Eu não acredito em IA como mágica. Eu acredito em IA como alavanca — com governança e responsabilidade.

O Protocolo Vértice é o caminho prático para isso.

## Os 5 Passos do Protocolo Vértice

### 1. Clareza
Qual problema estamos resolvendo, pra quem, e como isso se traduz em negócio?

**Saídas:** objetivo, métrica, recorte, baseline.

### 2. Evidência
Diagnóstico orientado por dados + realidade da operação (sem romantizar).

**Saídas:** padrões, causas prováveis, hipóteses testáveis.

### 3. Prioridade
Foco no que muda resultado primeiro: impacto × esforço × risco.

**Saídas:** backlog priorizado, quick wins e frentes estruturantes.

### 4. Execução
Plano que roda na vida real: dono, cadência, ritual, governança e acompanhamento.

**Saídas:** plano 30/60/90, ritos de gestão, rotinas e checkpoints.

### 5. Escala
IA e automação entram como alavanca: ampliar leitura, reduzir retrabalho e sustentar padrão.

**Saídas:** playbooks, curadoria/validação, modelo de escala e governança.
