# Análise GPT - Itens Priorizados por Viabilidade

## ALTA PRIORIDADE (Implementáveis agora, impacto direto)

### 1. SEO & Meta Tags
- Meta descriptions dinâmicas por página
- Títulos únicos por página
- Dados estruturados (JSON-LD)

### 2. Erros 404 e URLs inconsistentes
- /programas → redirecionar para /ofertas
- /case → redirecionar para /cases/120-matriculas
- Consistência menu "Programas" vs URL /ofertas

### 3. Prova social autêntica
- Depoimentos com nome, cargo e foto
- Selos de clientes/instituições atendidas
- Logotipos de parceiros

### 4. Acessibilidade
- Alt text em imagens
- Contraste adequado em botões
- Formulários acessíveis

### 5. Performance
- Lazy loading para imagens e vídeos
- Compressão de imagens (WebP)

### 6. UX - Formulário de contato
- Simplificar campos obrigatórios
- Multi-step ou campos básicos primeiro

### 7. UX - Navegação admin
- Agrupar abas em categorias (muitas abas no admin)
- Tooltips de ajuda contextual

### 8. Área de membros
- Onboarding/tour guiado para novos alunos
- Progresso 0/0 módulos (bug de sincronização)

## MÉDIA PRIORIDADE (Bom ter, mas mais complexo)

### 9. CTAs refinadas
- Verbos de ação mais claros
- Elementos de urgência/escassez

### 10. Transparência de preços
- Faixa de investimento nas mentorias individuais

### 11. Garantia de satisfação
- Política de reembolso visível

### 12. Política de privacidade/LGPD
- Link no rodapé

### 13. Gamificação
- Badges e níveis além da barra de progresso

## BAIXA PRIORIDADE (Estratégico/futuro)

### 14. Blog/conteúdo educativo
### 15. Integração CRM (HubSpot/Pipedrive)
### 16. Pixels Meta/Facebook/LinkedIn
### 17. Google Analytics 4 / Hotjar
### 18. Automação de e-mail pós-Radar
### 19. Teste A/B
### 20. Calendly/agendamento
